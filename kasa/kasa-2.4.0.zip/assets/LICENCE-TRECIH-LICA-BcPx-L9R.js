const e=`IRIS CORVINA Kasa\r
© 2026 Dragomir Dačević. Sva prava zadržana.\r
\r
LICENCE BIBLIOTEKA TREĆIH LICA\r
\r
Program koristi biblioteke trećih lica navedene u ovom fajlu. Svaka biblioteka pripada svojim\r
autorima i koristi se pod licencom navedenom uz nju. Tekstovi licenci su preneseni onako kako ih\r
biblioteke isporučuju. Navedene licence važe samo za te biblioteke; program IRIS CORVINA Kasa\r
nije obuhvaćen njima.\r
\r
Fajl pravi skripta scripts/licence-trecih-lica.mjs iz paketa koji ulaze u program.\r
\r
SADRŽAJ\r
   1. @capacitor-mlkit/barcode-scanning 6.2.0 — Apache-2.0\r
   2. @capacitor/android 6.2.1 — MIT\r
   3. @capacitor/app 6.0.3 — MIT\r
   4. @capacitor/core 6.2.1 — MIT\r
   5. @capacitor/filesystem 6.0.4 — MIT\r
   6. electron 33.4.11 — MIT\r
   7. node-forge 1.4.0 — (BSD-3-Clause OR GPL-2.0) (koristi se: BSD-3-Clause)\r
   8. qrcode-generator 2.0.4 — MIT\r
   9. sql.js 1.14.1 — MIT\r
  10. tslib 2.8.1 — 0BSD\r
  11. Biblioteke Android aplikacije (Gradle)\r
  12. Komponente Windows programa i instalacije\r
\r
==============================================================================\r
1. @capacitor-mlkit/barcode-scanning 6.2.0\r
   Licenca: Apache-2.0\r
   Izvor: https://github.com/capawesome-team/capacitor-mlkit\r
   U programu: ekran (Windows program, Android aplikacija, paket ažuriranja); native dio Android aplikacije\r
------------------------------------------------------------------------------\r
Apache License\r
                           Version 2.0, January 2004\r
                        http://www.apache.org/licenses/\r
\r
   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION\r
\r
   1. Definitions.\r
\r
      "License" shall mean the terms and conditions for use, reproduction,\r
      and distribution as defined by Sections 1 through 9 of this document.\r
\r
      "Licensor" shall mean the copyright owner or entity authorized by\r
      the copyright owner that is granting the License.\r
\r
      "Legal Entity" shall mean the union of the acting entity and all\r
      other entities that control, are controlled by, or are under common\r
      control with that entity. For the purposes of this definition,\r
      "control" means (i) the power, direct or indirect, to cause the\r
      direction or management of such entity, whether by contract or\r
      otherwise, or (ii) ownership of fifty percent (50%) or more of the\r
      outstanding shares, or (iii) beneficial ownership of such entity.\r
\r
      "You" (or "Your") shall mean an individual or Legal Entity\r
      exercising permissions granted by this License.\r
\r
      "Source" form shall mean the preferred form for making modifications,\r
      including but not limited to software source code, documentation\r
      source, and configuration files.\r
\r
      "Object" form shall mean any form resulting from mechanical\r
      transformation or translation of a Source form, including but\r
      not limited to compiled object code, generated documentation,\r
      and conversions to other media types.\r
\r
      "Work" shall mean the work of authorship, whether in Source or\r
      Object form, made available under the License, as indicated by a\r
      copyright notice that is included in or attached to the work\r
      (an example is provided in the Appendix below).\r
\r
      "Derivative Works" shall mean any work, whether in Source or Object\r
      form, that is based on (or derived from) the Work and for which the\r
      editorial revisions, annotations, elaborations, or other modifications\r
      represent, as a whole, an original work of authorship. For the purposes\r
      of this License, Derivative Works shall not include works that remain\r
      separable from, or merely link (or bind by name) to the interfaces of,\r
      the Work and Derivative Works thereof.\r
\r
      "Contribution" shall mean any work of authorship, including\r
      the original version of the Work and any modifications or additions\r
      to that Work or Derivative Works thereof, that is intentionally\r
      submitted to Licensor for inclusion in the Work by the copyright owner\r
      or by an individual or Legal Entity authorized to submit on behalf of\r
      the copyright owner. For the purposes of this definition, "submitted"\r
      means any form of electronic, verbal, or written communication sent\r
      to the Licensor or its representatives, including but not limited to\r
      communication on electronic mailing lists, source code control systems,\r
      and issue tracking systems that are managed by, or on behalf of, the\r
      Licensor for the purpose of discussing and improving the Work, but\r
      excluding communication that is conspicuously marked or otherwise\r
      designated in writing by the copyright owner as "Not a Contribution."\r
\r
      "Contributor" shall mean Licensor and any individual or Legal Entity\r
      on behalf of whom a Contribution has been received by Licensor and\r
      subsequently incorporated within the Work.\r
\r
   2. Grant of Copyright License. Subject to the terms and conditions of\r
      this License, each Contributor hereby grants to You a perpetual,\r
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable\r
      copyright license to reproduce, prepare Derivative Works of,\r
      publicly display, publicly perform, sublicense, and distribute the\r
      Work and such Derivative Works in Source or Object form.\r
\r
   3. Grant of Patent License. Subject to the terms and conditions of\r
      this License, each Contributor hereby grants to You a perpetual,\r
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable\r
      (except as stated in this section) patent license to make, have made,\r
      use, offer to sell, sell, import, and otherwise transfer the Work,\r
      where such license applies only to those patent claims licensable\r
      by such Contributor that are necessarily infringed by their\r
      Contribution(s) alone or by combination of their Contribution(s)\r
      with the Work to which such Contribution(s) was submitted. If You\r
      institute patent litigation against any entity (including a\r
      cross-claim or counterclaim in a lawsuit) alleging that the Work\r
      or a Contribution incorporated within the Work constitutes direct\r
      or contributory patent infringement, then any patent licenses\r
      granted to You under this License for that Work shall terminate\r
      as of the date such litigation is filed.\r
\r
   4. Redistribution. You may reproduce and distribute copies of the\r
      Work or Derivative Works thereof in any medium, with or without\r
      modifications, and in Source or Object form, provided that You\r
      meet the following conditions:\r
\r
      (a) You must give any other recipients of the Work or\r
          Derivative Works a copy of this License; and\r
\r
      (b) You must cause any modified files to carry prominent notices\r
          stating that You changed the files; and\r
\r
      (c) You must retain, in the Source form of any Derivative Works\r
          that You distribute, all copyright, patent, trademark, and\r
          attribution notices from the Source form of the Work,\r
          excluding those notices that do not pertain to any part of\r
          the Derivative Works; and\r
\r
      (d) If the Work includes a "NOTICE" text file as part of its\r
          distribution, then any Derivative Works that You distribute must\r
          include a readable copy of the attribution notices contained\r
          within such NOTICE file, excluding those notices that do not\r
          pertain to any part of the Derivative Works, in at least one\r
          of the following places: within a NOTICE text file distributed\r
          as part of the Derivative Works; within the Source form or\r
          documentation, if provided along with the Derivative Works; or,\r
          within a display generated by the Derivative Works, if and\r
          wherever such third-party notices normally appear. The contents\r
          of the NOTICE file are for informational purposes only and\r
          do not modify the License. You may add Your own attribution\r
          notices within Derivative Works that You distribute, alongside\r
          or as an addendum to the NOTICE text from the Work, provided\r
          that such additional attribution notices cannot be construed\r
          as modifying the License.\r
\r
      You may add Your own copyright statement to Your modifications and\r
      may provide additional or different license terms and conditions\r
      for use, reproduction, or distribution of Your modifications, or\r
      for any such Derivative Works as a whole, provided Your use,\r
      reproduction, and distribution of the Work otherwise complies with\r
      the conditions stated in this License.\r
\r
   5. Submission of Contributions. Unless You explicitly state otherwise,\r
      any Contribution intentionally submitted for inclusion in the Work\r
      by You to the Licensor shall be under the terms and conditions of\r
      this License, without any additional terms or conditions.\r
      Notwithstanding the above, nothing herein shall supersede or modify\r
      the terms of any separate license agreement you may have executed\r
      with Licensor regarding such Contributions.\r
\r
   6. Trademarks. This License does not grant permission to use the trade\r
      names, trademarks, service marks, or product names of the Licensor,\r
      except as required for reasonable and customary use in describing the\r
      origin of the Work and reproducing the content of the NOTICE file.\r
\r
   7. Disclaimer of Warranty. Unless required by applicable law or\r
      agreed to in writing, Licensor provides the Work (and each\r
      Contributor provides its Contributions) on an "AS IS" BASIS,\r
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or\r
      implied, including, without limitation, any warranties or conditions\r
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A\r
      PARTICULAR PURPOSE. You are solely responsible for determining the\r
      appropriateness of using or redistributing the Work and assume any\r
      risks associated with Your exercise of permissions under this License.\r
\r
   8. Limitation of Liability. In no event and under no legal theory,\r
      whether in tort (including negligence), contract, or otherwise,\r
      unless required by applicable law (such as deliberate and grossly\r
      negligent acts) or agreed to in writing, shall any Contributor be\r
      liable to You for damages, including any direct, indirect, special,\r
      incidental, or consequential damages of any character arising as a\r
      result of this License or out of the use or inability to use the\r
      Work (including but not limited to damages for loss of goodwill,\r
      work stoppage, computer failure or malfunction, or any and all\r
      other commercial damages or losses), even if such Contributor\r
      has been advised of the possibility of such damages.\r
\r
   9. Accepting Warranty or Additional Liability. While redistributing\r
      the Work or Derivative Works thereof, You may choose to offer,\r
      and charge a fee for, acceptance of support, warranty, indemnity,\r
      or other liability obligations and/or rights consistent with this\r
      License. However, in accepting such obligations, You may act only\r
      on Your own behalf and on Your sole responsibility, not on behalf\r
      of any other Contributor, and only if You agree to indemnify,\r
      defend, and hold each Contributor harmless for any liability\r
      incurred by, or claims asserted against, such Contributor by reason\r
      of your accepting any such warranty or additional liability.\r
\r
   END OF TERMS AND CONDITIONS\r
\r
   APPENDIX: How to apply the Apache License to your work.\r
\r
      To apply the Apache License to your work, attach the following\r
      boilerplate notice, with the fields enclosed by brackets "[]"\r
      replaced with your own identifying information. (Don't include\r
      the brackets!)  The text should be enclosed in the appropriate\r
      comment syntax for the file format. We also recommend that a\r
      file or class name and description of purpose be included on the\r
      same "printed page" as the copyright notice for easier\r
      identification within third-party archives.\r
\r
   Copyright 2023 Robin Genz\r
\r
   Licensed under the Apache License, Version 2.0 (the "License");\r
   you may not use this file except in compliance with the License.\r
   You may obtain a copy of the License at\r
\r
       http://www.apache.org/licenses/LICENSE-2.0\r
\r
   Unless required by applicable law or agreed to in writing, software\r
   distributed under the License is distributed on an "AS IS" BASIS,\r
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r
   See the License for the specific language governing permissions and\r
   limitations under the License.\r
\r
==============================================================================\r
2. @capacitor/android 6.2.1\r
   Licenca: MIT\r
   Izvor: https://github.com/ionic-team/capacitor\r
   U programu: Android aplikacija (APK)\r
------------------------------------------------------------------------------\r
MIT License\r
\r
Copyright (c) 2017-present Drifty Co.\r
\r
Permission is hereby granted, free of charge, to any person obtaining a copy\r
of this software and associated documentation files (the "Software"), to deal\r
in the Software without restriction, including without limitation the rights\r
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\r
copies of the Software, and to permit persons to whom the Software is\r
furnished to do so, subject to the following conditions:\r
\r
The above copyright notice and this permission notice shall be included in all\r
copies or substantial portions of the Software.\r
\r
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\r
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\r
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\r
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\r
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\r
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\r
SOFTWARE.\r
\r
==============================================================================\r
3. @capacitor/app 6.0.3\r
   Licenca: MIT\r
   Izvor: https://github.com/ionic-team/capacitor-plugins\r
   U programu: ekran (Windows program, Android aplikacija, paket ažuriranja); native dio Android aplikacije\r
------------------------------------------------------------------------------\r
Copyright 2020-present Ionic\r
https://ionic.io\r
\r
MIT License\r
\r
Permission is hereby granted, free of charge, to any person obtaining\r
a copy of this software and associated documentation files (the\r
"Software"), to deal in the Software without restriction, including\r
without limitation the rights to use, copy, modify, merge, publish,\r
distribute, sublicense, and/or sell copies of the Software, and to\r
permit persons to whom the Software is furnished to do so, subject to\r
the following conditions:\r
\r
The above copyright notice and this permission notice shall be\r
included in all copies or substantial portions of the Software.\r
\r
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,\r
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF\r
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND\r
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE\r
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION\r
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION\r
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\r
\r
==============================================================================\r
4. @capacitor/core 6.2.1\r
   Licenca: MIT\r
   Izvor: https://github.com/ionic-team/capacitor\r
   U programu: ekran (Windows program, Android aplikacija, paket ažuriranja)\r
------------------------------------------------------------------------------\r
MIT License\r
\r
Copyright (c) 2017-present Drifty Co.\r
\r
Permission is hereby granted, free of charge, to any person obtaining a copy\r
of this software and associated documentation files (the "Software"), to deal\r
in the Software without restriction, including without limitation the rights\r
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\r
copies of the Software, and to permit persons to whom the Software is\r
furnished to do so, subject to the following conditions:\r
\r
The above copyright notice and this permission notice shall be included in all\r
copies or substantial portions of the Software.\r
\r
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\r
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\r
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\r
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\r
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\r
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\r
SOFTWARE.\r
\r
==============================================================================\r
5. @capacitor/filesystem 6.0.4\r
   Licenca: MIT\r
   Izvor: https://github.com/ionic-team/capacitor-plugins\r
   U programu: ekran (Windows program, Android aplikacija, paket ažuriranja); native dio Android aplikacije\r
------------------------------------------------------------------------------\r
Copyright 2020-present Ionic\r
https://ionic.io\r
\r
MIT License\r
\r
Permission is hereby granted, free of charge, to any person obtaining\r
a copy of this software and associated documentation files (the\r
"Software"), to deal in the Software without restriction, including\r
without limitation the rights to use, copy, modify, merge, publish,\r
distribute, sublicense, and/or sell copies of the Software, and to\r
permit persons to whom the Software is furnished to do so, subject to\r
the following conditions:\r
\r
The above copyright notice and this permission notice shall be\r
included in all copies or substantial portions of the Software.\r
\r
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,\r
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF\r
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND\r
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE\r
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION\r
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION\r
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\r
\r
==============================================================================\r
6. electron 33.4.11\r
   Licenca: MIT\r
   Izvor: https://github.com/electron/electron\r
   U programu: Windows program (Setup)\r
------------------------------------------------------------------------------\r
Copyright (c) Electron contributors\r
Copyright (c) 2013-2020 GitHub Inc.\r
\r
Permission is hereby granted, free of charge, to any person obtaining\r
a copy of this software and associated documentation files (the\r
"Software"), to deal in the Software without restriction, including\r
without limitation the rights to use, copy, modify, merge, publish,\r
distribute, sublicense, and/or sell copies of the Software, and to\r
permit persons to whom the Software is furnished to do so, subject to\r
the following conditions:\r
\r
The above copyright notice and this permission notice shall be\r
included in all copies or substantial portions of the Software.\r
\r
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,\r
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF\r
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND\r
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE\r
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION\r
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION\r
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\r
\r
==============================================================================\r
7. node-forge 1.4.0\r
   Licenca: (BSD-3-Clause OR GPL-2.0) — licenca po izboru; program je koristi pod BSD-3-Clause\r
   Izvor: https://github.com/digitalbazaar/forge\r
   U programu: ekran (Windows program, Android aplikacija, paket ažuriranja)\r
------------------------------------------------------------------------------\r
You may use the Forge project under the terms of either the BSD License or the\r
GNU General Public License (GPL) Version 2.\r
\r
The BSD License is recommended for most projects. It is simple and easy to\r
understand and it places almost no restrictions on what you can do with the\r
Forge project.\r
\r
If the GPL suits your project better you are also free to use Forge under\r
that license.\r
\r
You don't have to do anything special to choose one license or the other and\r
you don't have to notify anyone which license you are using. You are free to\r
use this project in commercial projects as long as the copyright header is\r
left intact.\r
\r
If you are a commercial entity and use this set of libraries in your\r
commercial software then reasonable payment to Digital Bazaar, if you can\r
afford it, is not required but is expected and would be appreciated. If this\r
library saves you time, then it's saving you money. The cost of developing\r
the Forge software was on the order of several hundred hours and tens of\r
thousands of dollars. We are attempting to strike a balance between helping\r
the development community while not being taken advantage of by lucrative\r
commercial entities for our efforts.\r
\r
-------------------------------------------------------------------------------\r
New BSD License (3-clause)\r
Copyright (c) 2010, Digital Bazaar, Inc.\r
All rights reserved.\r
\r
Redistribution and use in source and binary forms, with or without\r
modification, are permitted provided that the following conditions are met:\r
    * Redistributions of source code must retain the above copyright\r
      notice, this list of conditions and the following disclaimer.\r
    * Redistributions in binary form must reproduce the above copyright\r
      notice, this list of conditions and the following disclaimer in the\r
      documentation and/or other materials provided with the distribution.\r
    * Neither the name of Digital Bazaar, Inc. nor the\r
      names of its contributors may be used to endorse or promote products\r
      derived from this software without specific prior written permission.\r
\r
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND\r
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED\r
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE\r
DISCLAIMED. IN NO EVENT SHALL DIGITAL BAZAAR BE LIABLE FOR ANY\r
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES\r
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;\r
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND\r
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT\r
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS\r
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\r
\r
-------------------------------------------------------------------------------\r
        GNU GENERAL PUBLIC LICENSE\r
           Version 2, June 1991\r
\r
 Copyright (C) 1989, 1991 Free Software Foundation, Inc.\r
 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA\r
 Everyone is permitted to copy and distribute verbatim copies\r
 of this license document, but changing it is not allowed.\r
\r
          Preamble\r
\r
  The licenses for most software are designed to take away your\r
freedom to share and change it.  By contrast, the GNU General Public\r
License is intended to guarantee your freedom to share and change free\r
software--to make sure the software is free for all its users.  This\r
General Public License applies to most of the Free Software\r
Foundation's software and to any other program whose authors commit to\r
using it.  (Some other Free Software Foundation software is covered by\r
the GNU Lesser General Public License instead.)  You can apply it to\r
your programs, too.\r
\r
  When we speak of free software, we are referring to freedom, not\r
price.  Our General Public Licenses are designed to make sure that you\r
have the freedom to distribute copies of free software (and charge for\r
this service if you wish), that you receive source code or can get it\r
if you want it, that you can change the software or use pieces of it\r
in new free programs; and that you know you can do these things.\r
\r
  To protect your rights, we need to make restrictions that forbid\r
anyone to deny you these rights or to ask you to surrender the rights.\r
These restrictions translate to certain responsibilities for you if you\r
distribute copies of the software, or if you modify it.\r
\r
  For example, if you distribute copies of such a program, whether\r
gratis or for a fee, you must give the recipients all the rights that\r
you have.  You must make sure that they, too, receive or can get the\r
source code.  And you must show them these terms so they know their\r
rights.\r
\r
  We protect your rights with two steps: (1) copyright the software, and\r
(2) offer you this license which gives you legal permission to copy,\r
distribute and/or modify the software.\r
\r
  Also, for each author's protection and ours, we want to make certain\r
that everyone understands that there is no warranty for this free\r
software.  If the software is modified by someone else and passed on, we\r
want its recipients to know that what they have is not the original, so\r
that any problems introduced by others will not reflect on the original\r
authors' reputations.\r
\r
  Finally, any free program is threatened constantly by software\r
patents.  We wish to avoid the danger that redistributors of a free\r
program will individually obtain patent licenses, in effect making the\r
program proprietary.  To prevent this, we have made it clear that any\r
patent must be licensed for everyone's free use or not licensed at all.\r
\r
  The precise terms and conditions for copying, distribution and\r
modification follow.\r
\r
        GNU GENERAL PUBLIC LICENSE\r
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\r
\r
  0. This License applies to any program or other work which contains\r
a notice placed by the copyright holder saying it may be distributed\r
under the terms of this General Public License.  The "Program", below,\r
refers to any such program or work, and a "work based on the Program"\r
means either the Program or any derivative work under copyright law:\r
that is to say, a work containing the Program or a portion of it,\r
either verbatim or with modifications and/or translated into another\r
language.  (Hereinafter, translation is included without limitation in\r
the term "modification".)  Each licensee is addressed as "you".\r
\r
Activities other than copying, distribution and modification are not\r
covered by this License; they are outside its scope.  The act of\r
running the Program is not restricted, and the output from the Program\r
is covered only if its contents constitute a work based on the\r
Program (independent of having been made by running the Program).\r
Whether that is true depends on what the Program does.\r
\r
  1. You may copy and distribute verbatim copies of the Program's\r
source code as you receive it, in any medium, provided that you\r
conspicuously and appropriately publish on each copy an appropriate\r
copyright notice and disclaimer of warranty; keep intact all the\r
notices that refer to this License and to the absence of any warranty;\r
and give any other recipients of the Program a copy of this License\r
along with the Program.\r
\r
You may charge a fee for the physical act of transferring a copy, and\r
you may at your option offer warranty protection in exchange for a fee.\r
\r
  2. You may modify your copy or copies of the Program or any portion\r
of it, thus forming a work based on the Program, and copy and\r
distribute such modifications or work under the terms of Section 1\r
above, provided that you also meet all of these conditions:\r
\r
    a) You must cause the modified files to carry prominent notices\r
    stating that you changed the files and the date of any change.\r
\r
    b) You must cause any work that you distribute or publish, that in\r
    whole or in part contains or is derived from the Program or any\r
    part thereof, to be licensed as a whole at no charge to all third\r
    parties under the terms of this License.\r
\r
    c) If the modified program normally reads commands interactively\r
    when run, you must cause it, when started running for such\r
    interactive use in the most ordinary way, to print or display an\r
    announcement including an appropriate copyright notice and a\r
    notice that there is no warranty (or else, saying that you provide\r
    a warranty) and that users may redistribute the program under\r
    these conditions, and telling the user how to view a copy of this\r
    License.  (Exception: if the Program itself is interactive but\r
    does not normally print such an announcement, your work based on\r
    the Program is not required to print an announcement.)\r
\r
These requirements apply to the modified work as a whole.  If\r
identifiable sections of that work are not derived from the Program,\r
and can be reasonably considered independent and separate works in\r
themselves, then this License, and its terms, do not apply to those\r
sections when you distribute them as separate works.  But when you\r
distribute the same sections as part of a whole which is a work based\r
on the Program, the distribution of the whole must be on the terms of\r
this License, whose permissions for other licensees extend to the\r
entire whole, and thus to each and every part regardless of who wrote it.\r
\r
Thus, it is not the intent of this section to claim rights or contest\r
your rights to work written entirely by you; rather, the intent is to\r
exercise the right to control the distribution of derivative or\r
collective works based on the Program.\r
\r
In addition, mere aggregation of another work not based on the Program\r
with the Program (or with a work based on the Program) on a volume of\r
a storage or distribution medium does not bring the other work under\r
the scope of this License.\r
\r
  3. You may copy and distribute the Program (or a work based on it,\r
under Section 2) in object code or executable form under the terms of\r
Sections 1 and 2 above provided that you also do one of the following:\r
\r
    a) Accompany it with the complete corresponding machine-readable\r
    source code, which must be distributed under the terms of Sections\r
    1 and 2 above on a medium customarily used for software interchange; or,\r
\r
    b) Accompany it with a written offer, valid for at least three\r
    years, to give any third party, for a charge no more than your\r
    cost of physically performing source distribution, a complete\r
    machine-readable copy of the corresponding source code, to be\r
    distributed under the terms of Sections 1 and 2 above on a medium\r
    customarily used for software interchange; or,\r
\r
    c) Accompany it with the information you received as to the offer\r
    to distribute corresponding source code.  (This alternative is\r
    allowed only for noncommercial distribution and only if you\r
    received the program in object code or executable form with such\r
    an offer, in accord with Subsection b above.)\r
\r
The source code for a work means the preferred form of the work for\r
making modifications to it.  For an executable work, complete source\r
code means all the source code for all modules it contains, plus any\r
associated interface definition files, plus the scripts used to\r
control compilation and installation of the executable.  However, as a\r
special exception, the source code distributed need not include\r
anything that is normally distributed (in either source or binary\r
form) with the major components (compiler, kernel, and so on) of the\r
operating system on which the executable runs, unless that component\r
itself accompanies the executable.\r
\r
If distribution of executable or object code is made by offering\r
access to copy from a designated place, then offering equivalent\r
access to copy the source code from the same place counts as\r
distribution of the source code, even though third parties are not\r
compelled to copy the source along with the object code.\r
\r
  4. You may not copy, modify, sublicense, or distribute the Program\r
except as expressly provided under this License.  Any attempt\r
otherwise to copy, modify, sublicense or distribute the Program is\r
void, and will automatically terminate your rights under this License.\r
However, parties who have received copies, or rights, from you under\r
this License will not have their licenses terminated so long as such\r
parties remain in full compliance.\r
\r
  5. You are not required to accept this License, since you have not\r
signed it.  However, nothing else grants you permission to modify or\r
distribute the Program or its derivative works.  These actions are\r
prohibited by law if you do not accept this License.  Therefore, by\r
modifying or distributing the Program (or any work based on the\r
Program), you indicate your acceptance of this License to do so, and\r
all its terms and conditions for copying, distributing or modifying\r
the Program or works based on it.\r
\r
  6. Each time you redistribute the Program (or any work based on the\r
Program), the recipient automatically receives a license from the\r
original licensor to copy, distribute or modify the Program subject to\r
these terms and conditions.  You may not impose any further\r
restrictions on the recipients' exercise of the rights granted herein.\r
You are not responsible for enforcing compliance by third parties to\r
this License.\r
\r
  7. If, as a consequence of a court judgment or allegation of patent\r
infringement or for any other reason (not limited to patent issues),\r
conditions are imposed on you (whether by court order, agreement or\r
otherwise) that contradict the conditions of this License, they do not\r
excuse you from the conditions of this License.  If you cannot\r
distribute so as to satisfy simultaneously your obligations under this\r
License and any other pertinent obligations, then as a consequence you\r
may not distribute the Program at all.  For example, if a patent\r
license would not permit royalty-free redistribution of the Program by\r
all those who receive copies directly or indirectly through you, then\r
the only way you could satisfy both it and this License would be to\r
refrain entirely from distribution of the Program.\r
\r
If any portion of this section is held invalid or unenforceable under\r
any particular circumstance, the balance of the section is intended to\r
apply and the section as a whole is intended to apply in other\r
circumstances.\r
\r
It is not the purpose of this section to induce you to infringe any\r
patents or other property right claims or to contest validity of any\r
such claims; this section has the sole purpose of protecting the\r
integrity of the free software distribution system, which is\r
implemented by public license practices.  Many people have made\r
generous contributions to the wide range of software distributed\r
through that system in reliance on consistent application of that\r
system; it is up to the author/donor to decide if he or she is willing\r
to distribute software through any other system and a licensee cannot\r
impose that choice.\r
\r
This section is intended to make thoroughly clear what is believed to\r
be a consequence of the rest of this License.\r
\r
  8. If the distribution and/or use of the Program is restricted in\r
certain countries either by patents or by copyrighted interfaces, the\r
original copyright holder who places the Program under this License\r
may add an explicit geographical distribution limitation excluding\r
those countries, so that distribution is permitted only in or among\r
countries not thus excluded.  In such case, this License incorporates\r
the limitation as if written in the body of this License.\r
\r
  9. The Free Software Foundation may publish revised and/or new versions\r
of the General Public License from time to time.  Such new versions will\r
be similar in spirit to the present version, but may differ in detail to\r
address new problems or concerns.\r
\r
Each version is given a distinguishing version number.  If the Program\r
specifies a version number of this License which applies to it and "any\r
later version", you have the option of following the terms and conditions\r
either of that version or of any later version published by the Free\r
Software Foundation.  If the Program does not specify a version number of\r
this License, you may choose any version ever published by the Free Software\r
Foundation.\r
\r
  10. If you wish to incorporate parts of the Program into other free\r
programs whose distribution conditions are different, write to the author\r
to ask for permission.  For software which is copyrighted by the Free\r
Software Foundation, write to the Free Software Foundation; we sometimes\r
make exceptions for this.  Our decision will be guided by the two goals\r
of preserving the free status of all derivatives of our free software and\r
of promoting the sharing and reuse of software generally.\r
\r
          NO WARRANTY\r
\r
  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\r
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\r
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\r
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\r
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\r
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\r
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\r
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\r
REPAIR OR CORRECTION.\r
\r
  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\r
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\r
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\r
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\r
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\r
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\r
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\r
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\r
POSSIBILITY OF SUCH DAMAGES.\r
\r
==============================================================================\r
8. qrcode-generator 2.0.4\r
   Licenca: MIT\r
   Izvor: https://github.com/kazuhikoarase/qrcode-generator\r
   U programu: ekran (Windows program, Android aplikacija, paket ažuriranja)\r
------------------------------------------------------------------------------\r
[zaglavlje izvornog fajla dist/qrcode.js]\r
QR Code Generator for JavaScript\r
\r
Copyright (c) 2009 Kazuhiko Arase\r
\r
URL: http://www.d-project.com/\r
\r
Licensed under the MIT license:\r
 http://www.opensource.org/licenses/mit-license.php\r
\r
The word 'QR Code' is registered trademark of\r
DENSO WAVE INCORPORATED\r
 http://www.denso-wave.com/qrcode/faqpatent-e.html\r
\r
[paket nema fajl licence; standardni tekst licence MIT]\r
MIT License\r
\r
Copyright (c) 2009 Kazuhiko Arase\r
\r
Permission is hereby granted, free of charge, to any person obtaining a copy\r
of this software and associated documentation files (the "Software"), to deal\r
in the Software without restriction, including without limitation the rights\r
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\r
copies of the Software, and to permit persons to whom the Software is\r
furnished to do so, subject to the following conditions:\r
\r
The above copyright notice and this permission notice shall be included in all\r
copies or substantial portions of the Software.\r
\r
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\r
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\r
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\r
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\r
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\r
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\r
SOFTWARE.\r
\r
==============================================================================\r
9. sql.js 1.14.1\r
   Licenca: MIT\r
   Izvor: http://github.com/sql-js/sql.js\r
   U programu: ekran (Windows program, Android aplikacija, paket ažuriranja)\r
------------------------------------------------------------------------------\r
MIT license\r
===========\r
\r
Copyright (c) 2017 sql.js authors (see AUTHORS)\r
\r
Permission is hereby granted, free of charge, to any person obtaining a copy\r
of this software and associated documentation files (the "Software"), to deal\r
in the Software without restriction, including without limitation the rights\r
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\r
copies of the Software, and to permit persons to whom the Software is\r
furnished to do so, subject to the following conditions:\r
\r
The above copyright notice and this permission notice shall be included in all\r
copies or substantial portions of the Software.\r
\r
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\r
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\r
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\r
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\r
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\r
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\r
SOFTWARE.\r
\r
# Some portions of the Makefile taken from:\r
Copyright 2017 Ryusei Yamaguchi\r
\r
Permission is hereby granted, free of charge, to any person obtaining a copy of\r
this software and associated documentation files (the "Software"), to deal in\r
the Software without restriction, including without limitation the rights to\r
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of\r
the Software, and to permit persons to whom the Software is furnished to do so,\r
subject to the following conditions:\r
\r
The above copyright notice and this permission notice shall be included in all\r
copies or substantial portions of the Software.\r
\r
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\r
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS\r
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR\r
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER\r
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN\r
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\r
\r
==============================================================================\r
10. tslib 2.8.1\r
   Licenca: 0BSD\r
   Izvor: https://github.com/Microsoft/tslib\r
   U programu: ekran (Windows program, Android aplikacija, paket ažuriranja)\r
------------------------------------------------------------------------------\r
Copyright (c) Microsoft Corporation.\r
\r
Permission to use, copy, modify, and/or distribute this software for any\r
purpose with or without fee is hereby granted.\r
\r
THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH\r
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY\r
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,\r
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM\r
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR\r
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR\r
PERFORMANCE OF THIS SOFTWARE.\r
\r
==============================================================================\r
11. Biblioteke Android aplikacije (Gradle)\r
------------------------------------------------------------------------------\r
Direktne zavisnosti Android projekta i dodataka Capacitor-a (grupa:artefakt:verzija — licenca):\r
  androidx.activity:activity:1.8.0 — Apache-2.0\r
  androidx.appcompat:appcompat:1.6.1 — Apache-2.0\r
  androidx.camera:camera-camera2:1.1.0 — Apache-2.0\r
  androidx.camera:camera-core:1.1.0 — Apache-2.0\r
  androidx.camera:camera-lifecycle:1.1.0 — Apache-2.0\r
  androidx.camera:camera-view:1.1.0 — Apache-2.0\r
  androidx.coordinatorlayout:coordinatorlayout:1.2.0 — Apache-2.0\r
  androidx.core:core:1.12.0 — Apache-2.0\r
  androidx.core:core-splashscreen:1.0.1 — Apache-2.0\r
  androidx.fragment:fragment:1.6.2 — Apache-2.0\r
  androidx.webkit:webkit:1.9.0 — Apache-2.0\r
  com.google.android.gms:play-services-code-scanner:16.1.0 — Google Play services — uslovi korišćenja Google-a (Android SDK / Google APIs Terms of Service); nije licenca otvorenog koda\r
  com.google.mlkit:barcode-scanning:17.2.0 — Google ML Kit — uslovi korišćenja Google-a (ML Kit Terms of Service); nije licenca otvorenog koda\r
  org.apache.cordova:framework:10.1.1 — Apache-2.0\r
\r
Prenosne zavisnosti ovih biblioteka su iz istih grupa (AndroidX i Kotlin pod licencom Apache 2.0,\r
Google Play services i ML Kit pod uslovima korišćenja Google-a). Potpun spisak biblioteka u APK-u:\r
  gradlew :app:dependencies --configuration releaseRuntimeClasspath\r
Tekst licence Apache 2.0 nalazi se u ovom fajlu uz paket @capacitor-mlkit/barcode-scanning.\r
\r
==============================================================================\r
12. Komponente Windows programa i instalacije\r
------------------------------------------------------------------------------\r
Windows program radi u okruženju Electron (paket electron gore). Electron sadrži Chromium, Node.js,\r
V8, FFmpeg i druge komponente; njihove licence su u fajlovima LICENSE.electron.txt i\r
LICENSES.chromium.html u folderu programa (pored Kasa.exe). Biblioteka FFmpeg (ffmpeg.dll) je pod\r
licencom LGPL 2.1 i isporučuje se kao zasebna dinamička biblioteka, bez izmjena.\r
\r
Instalacioni program (Setup) je napravljen alatom NSIS (Nullsoft Scriptable Install System),\r
licenca zlib/libpng; modul kompresije LZMA: Common Public License 1.0, modul bzip2: licenca bzip2.\r
Pomoćni program elevate.exe (pokretanje uz administratorska prava) isporučuje alat electron-builder.\r
`;export{e as default};
