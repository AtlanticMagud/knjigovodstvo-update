const e=`[\r
"-Command",\r
"-ExecutionPolicy",\r
"-NonInteractive",\r
"-NoProfile",\r
"— (until the register is registered with the Tax Administration)",\r
"— (the computer is not on the local network)",\r
"— (entered in Settings → Fiscalization)",\r
"— {0}+{1} free",\r
"— no table —",\r
"— prices have been updated.",\r
"— the prescribed medicine is dispensed —",\r
"— card (POS)",\r
"— a register registered as a kiosk (e.g. in front of a shop). Works on Sundays and holidays too, only with goods permitted for a kiosk.",\r
"— a register inside the shop. Does not work on Sundays and holidays (Art. 35b of the Law on Internal Trade).",\r
"— from {0} pcs {1}",\r
"— pays by bank transfer",\r
"— REPEATED",\r
"— room account",\r
", and the register works with",\r
", but not completely. Contact maintenance.",\r
", used",\r
", cashier {0}",\r
", licence {0}",\r
", lot {0}",\r
", paid {0} of {1}{2}",\r
", from {0}",\r
", approval {0}",\r
", approved without receipt:",\r
", so the previous one was restored. Maintenance must be notified.",\r
", so the previous was restored. Maintenance must be notified.",\r
", PIB {0}",\r
", card payment (POS)",\r
", disc.",\r
", Tax Administration",\r
", reference number",\r
", skipped {0}",\r
", invoice {0}",\r
", receipt cancellation, settings, cashiers and changing the register require their PIN.",\r
", valid until",\r
", valid until {0}{1}.",\r
", refunded {0}",\r
", value of goods at catalogue prices",\r
"; the item is no longer sold",\r
"; prices: {0}",\r
"; until then: \\"Manual confirmation\\" or \\"Test terminal\\".",\r
"; pending: {0} messages.",\r
"; the rest is at table {0}",\r
"; all entries are saved.",\r
": items sold by weight (kg) with price per kg and PLU number, for import into the scale software.",\r
": delivery (an order as a table \\"Wolt 123\\"), kitchen screen (tablet in \\"Kitchen\\" mode or More → Kitchen screen), reservations and floor layout (table overview).",\r
": amount",\r
": amount {0}, used {1},",\r
": opens when paying in cash and with the \\"Open drawer\\" button (with a reason, which is recorded). The drawer is usually connected to the thermal printer.",\r
": confirmation from the terminal before the receipt is issued (no receipt is issued for a declined card); on Android also the bank's app for payment by phone (SoftPOS; the package name is in the Google Play address of the bank's app). Instant: the customer pays from their bank to the company's account; it goes to the Tax Administration as \\"OTHER-CASH\\" (verification on a test system is needed).",\r
": rules for scale barcodes in the form \\"prefixes:type:item digits:value digits:decimals\\", separated by semicolons; type: tezina (weight) | iznos (amount) | komad (piece). Example: \\"27,28:iznos:5:5:2; 2:tezina:5:5:3\\". Empty = default rule (prefixes 20–29, weight).",\r
": sale of vouchers (More → Gift vouchers) and payment by voucher (More methods → Voucher). The voucher is valid at all registers of the company (exchange via the server). The sale of a voucher is a fiscal receipt with VAT (single-purpose voucher), and payment by voucher is reported to the Tax Administration as \\"SVOUCHER\\". This method",\r
": the receipt and voucher go directly to the thermal printer, without a driver (faster, with paper cutting and a QR code). On Android, also to a Bluetooth printer and the built-in printer of the Android register (\\"InnerPrinter\\").",\r
": a table of all items with price, price per kg / l and the previous lowest price during a promotion, for import into the label software.",\r
": a table of all items with price, price per kg / l and the previous lowest price during a promotion, for import into the label software. {0}",\r
": {0} in the catalogue",\r
". If the register issued receipts in another program at {0} on this code, its last receipt number must be entered (Settings → Fiscalization → \\"Set…\\").",\r
". A fiscal receipt is issued upon payment.",\r
". The register does not change this fiscal data automatically (the register is registered with the Tax Administration at its own business premises). The correct code is verified in SEP: if the code from the price list is correct, it is entered in the \\"Business premises code\\" field (Fiscalization) and saved; if the code on the register is correct, the correction is made in Accounting (Register price list → Registers and stores).",\r
". The ENU code from the list is the code of a previously registered register. The register does not send receipts to the Tax Administration until a new ENU code is entered (register registration) or the manager confirms the existing code together with the last receipt number of the previous register (Settings → Fiscalization).",\r
". They stay on the phone and are sent after login. Log out?",\r
". The other items are available through search.",\r
". After entering items: \\"Send order ticket\\" or \\"To table\\"; payment closes the table.",\r
". The QR code is valid for 10 minutes and for one phone only.",\r
". The receipt is issued when the money arrives.",\r
". Currently entered:",\r
". Prints A4 with 4 A6 cards (stand or sticker).",\r
"… and another",\r
"… and {0} more",\r
"· {0} items · {1} tables · register {2} · ordering {3}",\r
"· {0} waiting",\r
"· © 2026 Dragomir Dačević, author and rights holder. All rights reserved.",\r
"· promotion until {0}.{1}.",\r
"· promotion: {0}",\r
"· antibiotic (prescription valid for 3 days)",\r
"· barcode {0}{1}",\r
"· points: {0}",\r
"· points +{0}{1} = {2}",\r
"· no. {0}",\r
"· waiting: {0}",\r
"· register price {0} €",\r
"· prices checked {0}{1}",\r
"· added to labels",\r
"· arrival {0}",\r
"· ERROR",\r
"· group {0}",\r
"· IKOF {0}",\r
"· register {0}",\r
"· the register is not paired with the server",\r
"· late from {0}",\r
"· waiter {0}",\r
"· FZO list: {0}",\r
"· not on the FZO list",\r
"· not on the register menu",\r
"· not checked",\r
"· departure {0}",\r
"· departure was {0}",\r
"· approval {0}",\r
"· advance paid",\r
"· discount {0}",\r
"· discount {0} %",\r
"· It will be reported to the Tax Administration when the cash register is ready to send.",\r
"· change {0}",\r
"· calls: {0}",\r
"· skipped {0} (the price would be below €0.01 or above {1} €)",\r
"· the receipt has been cancelled",\r
"· receipts no. {0}",\r
"· order {0}",\r
"· certificate valid for {0} more {1}",\r
"· shift #{0}",\r
"· in the register {0}",\r
"· paired {0} · {1}",\r
"· paired with the server",\r
"› search \\"{0}\\"",\r
"\\"{0}\\" does not print but saves to a file. Select a real printer in Settings.",\r
"\\"To room\\": the guest's receipt in the room is not paid immediately, but goes onto the room's bill and is paid at check-out (summary receipt). Requires a connection to the server.",\r
"\\"Start as a new register\\" works from register installation 1.8.0 (new Setup).",\r
"\\"Start as a new cash register\\" works in the installed cash register (Windows, Android).",\r
"\\"Start as a new cash register\\" requires cash register installation 1.8.0 or later (a new Setup).",\r
"\\"Start as a new register\\": the register starts as after the first installation (connection to the company, without receipts, cashiers and settings) — e.g. a register for another company. The existing data is not deleted: it is moved to a separate dated folder inside the register's data folder, together with a database backup. Supervisor only, after the shift is closed.",\r
"\\"Void\\" of the last receipt {0} ({1})",\r
"\\"Void\\" of the last receipt requires the supervisor's PIN",\r
"\\"Scan QR from the register\\"",\r
"\\"Valid until\\" is before \\"valid from\\".",\r
"\\"Valid until\\" cannot be in the past.",\r
"\\"Valid from\\" cannot be in the past.",\r
"( , avg.",\r
"({0} or newer)",\r
"({0} person-nights)",\r
"({0} rec.)",\r
"({0} already exists)",\r
"({0}) AND {1}",\r
"(no parent group)",\r
"(unmarked ones are skipped)",\r
"(no subgroup)",\r
"(not signed in)",\r
"(the \\"New prices\\" button).",\r
"(register ENU, store). With the code the register connects to the company through the server, automatically picks up prices and sends changes and closings to Accounting.",\r
"(Google Drive for computer; the folder shared by Accounting and Manager).",\r
"(and {0} more)",\r
"(and previously removed from this receipt: {0})",\r
"(expired {0} ago)",\r
"(selection at every print)",\r
"({0} left)",\r
"(loyalty customers by phone): the customer collects points and spends them as a discount; valid at all registers of the company.",\r
"(local server)",\r
"(inactive)",\r
"(no PIN)",\r
"(none; everything on one order ticket)",\r
"(not chosen from the list).",\r
"(not turnover)",\r
"(not included in the total)",\r
"(not entered: Settings → Extras)",\r
"(new items: {0})",\r
"(new items {0})",\r
"(approval {0})",\r
"(approved by supervisor)",\r
"(base",\r
"(base",\r
"(base {0})",\r
"(p.broj = ?{0})",\r
"(PIB {0})",\r
"(a subfolder in \\"Documents\\" filled by synchronization, by default \\"KnjigSync\\").",\r
"(discount {0})",\r
"(Tax Administration)",\r
"(empty code)",\r
"(account {0})",\r
"(roll)",\r
"(hidden from sale; restored by unchecking the box)",\r
"(matches)",\r
"(receipt printer)",\r
"(voided)",\r
"(removed earlier)",\r
"(saving",\r
"(saving {0} per piece)",\r
"(always)",\r
"(already has receipts)",\r
"(version {0})",\r
"(More → Warnings; Manager): cancellation, voiding, drawer without a receipt and cash over the limit are always reported; for other warnings the limits below apply.",\r
"(loyalty)",\r
"(occupied, merge)",\r
"), transferred to the register (USB, mail, Drive) and loaded here.",\r
"). Details are in the note in the \\"Register\\" section.",\r
"[DllImport(\\"winspool.drv\\", CharSet = CharSet.Unicode, SetLastError = true)] public static extern bool OpenPrinter(string p, out IntPtr h, IntPtr d);",\r
"[DllImport(\\"winspool.drv\\", CharSet = CharSet.Unicode, SetLastError = true)] public static extern int StartDocPrinter(IntPtr h, int l, DI d);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool ClosePrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool EndDocPrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool EndPagePrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool StartPagePrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool WritePrinter(IntPtr h, byte[] b, int n, out int w);",\r
"[KasaRaw]::Posalji($env:KASA_RAW_STAMPAC, [Convert]::FromBase64String([IO.File]::ReadAllText($env:KASA_RAW_FAJL)))",\r
"[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] public class DI { public string n; public string o; public string t; }",\r
"{0}\\n\\nIs the customer 18 or older?",\r
"{0}\\n\\nWhile \\"Send receipts to the Tax Administration\\" is enabled and this is not corrected, the register does not issue receipts.\\n\\nDisable sending (test operation) until it is corrected?",\r
"{0}\\n\\nIssuing a receipt outside working hours requires confirmation.",\r
"{0}\\n\\nThe amount {1} must be entered on the terminal. The receipt is issued only when the terminal approves the payment. Approval number from the slip:",\r
"{0}\\n\\nThe payment {1}{2} must be cancelled on the terminal itself. The transaction stays in \\"Terminal transactions\\" until resolved.",\r
"{0}\\n(e.g. no ice, with milk, well done)",\r
"{0}\\n{1} kg = {2}\\n\\nConfirm the quantity?",\r
"{0} — {1} EUR",\r
"{0} — {1} EUR {2}",\r
"{0} — {1} EUR. The item is closed without payment and is not included in the balance.",\r
"{0} — files are waiting in the cash register.",\r
"{0} — room account {1}",\r
"{0} — printing was previously interrupted because memory ran out: close the cash register and start it again.",\r
"{0} · {1} – {2} · {3} nights",\r
"{0} · {1} (does not limit operation)",\r
"{0} · {1} EUR (free {2})",\r
"{0} · until {1} · balance {2} EUR",\r
"{0} · until {1}{2}{3}",\r
"{0} · VAT {1}%",\r
"{0} · PIB {1}",\r
"{0} · discount {1} %",\r
"{0} · tables",\r
"{0} · searched: {1}",\r
"{0} · loyalty {1} %",\r
"{0} (no room)",\r
"{0} (at table {1})",\r
"{0} (max {1})",\r
"{0} (not in the catalogue)",\r
"{0} (not found)",\r
"{0} (PIB {1})",\r
"{0} {1} registration",\r
"{0} AND {1}",\r
"{0} items",\r
"{0} items ({1})",\r
"{0} items",\r
"{0} without a pack size (the label will have no price per kg / l)",\r
"{0} no. {1}",\r
"{0} waiting",\r
"{0} is not available today",\r
"{0} Details: click the label.",\r
"{0} Until this is fixed, receipts are not issued.",\r
"{0} labels",\r
"{0} labels",\r
"{0} EUR",\r
"{0} EUR {1}",\r
"{0} file(s)",\r
"{0} file(s) waiting to be sent",\r
"The company {0} on the receipt ({1}) and for fiscalization ({2}) must be the same.",\r
"{0} has {1} points (value {2}). Number of points for this receipt (at most {3}):",\r
"{0} The choice has been saved on the cash register.",\r
"{0} was issued in trial mode (not reported to the Tax Administration), so the actual document cannot refer to it.",\r
"{0} is still a test one ({1}). A code assigned by the Tax Administration is required.",\r
"{0} is on a receipt that is waiting (on hold or on a table). The unit and VAT can be changed only after that receipt is paid or deleted.",\r
"{0} is on the receipt on screen. The unit and VAT can be changed once the receipt is paid or deleted.",\r
"{0} was rejected by the Tax Administration. It must be sent again first (Receipts → Unsent).",\r
"{0} is empty.",\r
"{0} is too large.",\r
"{0} is larger than {1} × {2} pixels.",\r
"{0} is larger than {1} KB.",\r
"{0} kg · {1}",\r
"{0} min",\r
"{0} has no PIN. The PIN is entered on the cash register (Settings → Cashiers).",\r
"{0} is not a number.",\r
"{0} no receipt was deleted.",\r
"{0} was not sent",\r
"{0} is not in the form 2026-07-31T07:01:00+02:00 (given: \\"{1}\\").",\r
"{0} is not in the form ab123ab123 (given: \\"{1}\\").",\r
"{0} is not in the form ab123ab123 (entered: {1}).",\r
"{0} has not been entered.",\r
"{0} no item was removed from an issued receipt.",\r
"{0} Nothing was issued.",\r
"{0} nights",\r
"{0} A new shift cannot be opened.",\r
"{0} of {1}",\r
"{0} rejected",\r
"{0} The refund must be made on the terminal.",\r
"{0} prescriptions",\r
"{0} is no longer sold. The item must be removed from the receipt or written off (More → Goods write-off).",\r
"{0} is no longer sold. The item needs to be removed from the receipt.",\r
"{0} is no longer sold. A receipt with this item cannot be paid; only a write-off is possible (More → Goods write-off).",\r
"{0} items",\r
"{0} Printing therefore goes through the printer selection window; for printing without that window, select the receipt printer.",\r
"{0} item",\r
"{0} items",\r
"{0} items",\r
"{0} larger than 3× (marked)",\r
"{0} is no longer on sale",\r
"{0} To confirm: press Save (Enter) once more.",\r
"{0}, of which {1} with this location's price",\r
"{0}, all at general prices",\r
"{0}: {1} (retry in {2} min)",\r
"{0}: a VAT-exempt item must have a rate of 0 ({1} % was given).",\r
"{0}: the receipt number must be a positive integer.",\r
"{0}: hour in the form 14:00",\r
"{0}: the price cannot be negative (a cancellation has a negative quantity).",\r
"{0}: a date or null.",\r
"{0}: the company is not in the VAT system, but the item carries VAT.",\r
"{0}: select a date.",\r
"{0}: between 0 and 100 %",\r
"{0}: the quantity is zero.",\r
"{0}: prescription medicine. It can be dispensed only with a prescription (Dispensing on prescription).",\r
"{0}: the name is required.",\r
"{0}: a negative quantity is only possible on a corrective receipt (cancellation).",\r
"{0}: invalid number",\r
"{0}: invalid price.",\r
"{0}: invalid quantity.",\r
"{0}: invalid VAT rate.",\r
"{0}: unknown VAT exemption basis \\"{1}\\".",\r
"{0}: an exemption basis is allowed only with a rate of 0 ({1} % was given).",\r
"{0}: the exemption code \\"{1}\\" is unknown or the rate is not 0 %.",\r
"{0}: pack of {1} pcs. Added {2} pcs.",\r
"{0}: data saved.",\r
"{0}: the discount cannot be negative.",\r
"{0}: the manager's PIN is required.",\r
"{0}: expires on {1}.",\r
"{0}: expired on {1}. The item was not added.",\r
"{0}: a VAT rate of {1} % is not possible.",\r
"{0}: enter a whole number.",\r
"{0}. A fiscal receipt is issued upon payment.",\r
"{0}{1} — {2}, {3}.\\nThe deletion remains in the deleted records (More → Deleted receipts), from where the receipt can be restored.",\r
"{0}{1} · {2} items{3}{4}",\r
"{0}{1} · {2} characters",\r
"{0}{1} {2} has been printed.",\r
"{0}{1} was not printed (printer). The cash register has been notified; it needs to be sent again when the printer works.",\r
"{0}a.sifra IN ({1})",\r
"{0}files wait in the cash register and are sent when the connection is restored.",\r
"{0}{1} was not issued: {2} Collect the remainder again; documents already issued are not issued a second time.",\r
"{0}Not sent: the cash register switched to PRODUCTION before sending to the trial service.",\r
"{0}Package from a file (no internet)",\r
"{0}The Tax Administration service did not accept this message {1} times and gave no reason (it accepted other messages). Last response: {2} Check {3} and send again.",\r
"{0}Everything from table {1} has already been sent.",\r
"{mjesto}: {naziv} · {stara} → {nova}",\r
"*izbor-pri-svakoj-stampi*",\r
"&amp;",\r
"&gt;",\r
"&lt;",\r
"&quot;",\r
"%\\"kljuc\\":\\"{0}\\"%",\r
"%\\"tip\\":\\"korekcija\\"%",\r
"%\\"tip\\":\\"namjera\\"%",\r
"%\\"tip\\":\\"prijava\\"%",\r
"%\\"uid\\":\\"{0}\\"%",\r
"•••••••• (saved; empty = no change)",\r
"← Another cashier",\r
"← Back to the list",\r
"↩ Return of {0} goods…",\r
"＋ {0} at this location",\r
"+ New item with this code",\r
"± amount (€)",\r
"± percentage (%)",\r
"<!doctype html>",\r
"= IN THE REGISTER",\r
"★ Quick",\r
"⚠ Warnings (30 days)",\r
"⟳ Publish menu now",\r
"🍽 Split table bill",\r
"🏢 {0} · PIB {1}",\r
"🏢 Add customer…",\r
"💳 Register devices",\r
"💳 Register devices{0}",\r
"📝 Menu content",\r
"📝 Menu content (names, descriptions, images, languages)",\r
"📤 Export prices",\r
"📱 Waiters: {0}",\r
"📱 QR menu at the tables",\r
"📱 QR menu at tables",\r
"📱 QR menu{1}{2}",\r
"📷 Scan QR from the register",\r
"🔍 Search by name or code (all items)…",\r
"🔍 Search: location or register code…",\r
"🖨 A4 / PDF",\r
"🖨 Roll",\r
"🖨 Print (Z)",\r
"🖨 Print document",\r
"🖨 Print copy",\r
"🖨 Print interim report (X)",\r
"🧑‍🍳 Kitchen screen",\r
"🧑‍🍳 Kitchen",\r
"🧾 Guest asks for the bill",\r
"🧾 Bill",\r
"🙋 Calling the waiter",\r
"🚫 Not available today",\r
"🚫 Not available today",\r
"🛟 Support: new reply",\r
"🛟 Support",\r
"$ErrorActionPreference = \\"Stop\\"",\r
"0 = no limit",\r
"0 = no limit.",\r
"0 = no message",\r
"0 = only expired",\r
"1. Code from Accounting (recommended)",\r
"28 except 288",\r
"2D barcode (GS1 DataMatrix / QR)",\r
"4–8 digits; empty = no change",\r
"4–8 digits; empty = no PIN",\r
"40 except 400 and 404",\r
"58 mm (32 characters)",\r
"6A4D-92DE-B3DB-A31D",\r
"80 mm (42 characters)",\r
"80 mm (48 characters)",\r
"a.naziv_n LIKE ?",\r
"ABSOLUT",\r
"ACCOUNT",\r
"ACTIMEL",\r
"ACTIVIA",\r
"Add-Type -TypeDefinition @\\"",\r
"admin",\r
"Address",\r
"FZO WebService address",\r
"IRIS address (works immediately): {0}",\r
"Cash register address",\r
"Register address: {0}",\r
"Customer address",\r
"The local server address has been entered. Pairing: pairing code, then \\"Connect\\" / \\"Pair\\".",\r
"Guest menu address",\r
"Server address",\r
"The server address must start with \\"https://\\".",\r
"The server address is not https.",\r
"The server address is not valid.",\r
"The server address, API key and API secret are required.",\r
"Device address is not valid (IP:port).",\r
"Device address is not valid. Enter the IP address and port (e.g. 192.168.1.60:8888).",\r
"Update address",\r
"The update address is not valid.",\r
"The update address is not set.",\r
"The address for downloading the new version is not available.",\r
"Address for the tablet:",\r
"ADVANCE",\r
"AES-GCM",\r
"Agency",\r
"AJVAR",\r
"Promotion",\r
"promotion ·",\r
"promotion · {0}",\r
"Promotion \\"{0}\\": {1}{2}",\r
"Action (Intent)",\r
"PROMO −",\r
"PROMO −{0}",\r
"akcija TEXT",\r
"promotion: {0}",\r
"Promotions and loyalty",\r
"promotional price",\r
"If the clock is correct now (it was previously wrongly set forward), the supervisor confirms this with a PIN. Otherwise, the date and time on the device must be set. Until then a receipt cannot be issued.",\r
"If the device clock was wrongly set forward and then corrected, the register refuses to issue receipts (clock set back). With this button the supervisor confirms that the clock is now correct.",\r
"If the type is unknown, the choice is Store; the type must also be entered in Accounting.",\r
"aktivan",\r
"Active",\r
"An active ENU cannot be changed.",\r
"aktivna",\r
"active",\r
"allergens",\r
"Allergens (Regulation on providing food information to consumers)",\r
"ALEVA",\r
"alcohol",\r
"Alcoholic – Beer",\r
"Alcoholic – Wine",\r
"Alcoholic – Spirits",\r
"ALU FOLIJ",\r
"AMARETTO",\r
"AMARO",\r
"AMEX",\r
"AMSTEL",\r
"analytical",\r
"Analysis",\r
"Analysis {0} – {1}",\r
"AND {0}",\r
"AND client_uid=?",\r
"AND id=?",\r
"AND kasa_id = ?",\r
"AND p.godina = ?",\r
"AND rezervacija = {0}",\r
"Andrijevica",\r
"Android",\r
"Antibiotic",\r
"AnyDesk / RustDesk",\r
"APEROL",\r
"API key",\r
"API secret",\r
"Bank app (SoftPOS package)",\r
"The bank app returned an unclear result.",\r
"Bank app on this device (Android)",\r
"The bank app does not accept the amount from the register.",\r
"The application has no list of cash registers. A data package (file) must be imported.",\r
"Voucher denominations (€, comma-separated)",\r
"Pharmacy — settings",\r
"application/json; charset=utf-8",\r
"APPROVED",\r
"APPROVED,OK,0,00",\r
"April",\r
"April",\r
"AQUA",\r
"AQUA VIVA",\r
"AQUAFRESH",\r
"Arabic",\r
"ARASID",\r
"ARAŠID",\r
"ARIEL",\r
"AROXOL",\r
"Item",\r
"Item \\" \\" not found.",\r
"Item \\"{0}\\" does not have barcode {1}.",\r
"Item \\"{0}\\" not found.",\r
"Item \\"{0}\\" already has barcode {1}.",\r
"Item {0} is not on this receipt.",\r
"Item {0} is not in the catalogue.",\r
"The voucher item was not created. Check the denominations (Settings → Extras).",\r
"Item added: {0}, {1}, code {2}.",\r
"The item is already in the list.",\r
"An item can have at most {0} barcodes.",\r
"The item was not added: sale to minors is not permitted.",\r
"This item is not allowed for sale on Sundays and public holidays (Art. 35b).",\r
"Item not found.",\r
"Item is not in the catalogue: {0}",\r
"The item is not in the catalogue.",\r
"No item with that code, barcode or name was found.",\r
"the item is added to \\"New prices\\" for labels",\r
"artikal TEXT",\r
"The item enters this register's catalogue with the price for this point of sale and is sent to Accounting and Manager. The code is assigned by the program.",\r
"The item already has this price.",\r
"The item is no longer in the catalogue and has been removed from the list.",\r
"Items",\r
"Catalogue items that were not sold",\r
"Items waiting for a new label: {0}.\\nRemove them from the list without printing (labels are already on the shelves)?",\r
"Items marked \\"currently unavailable\\": {0}.",\r
"items are no longer in the catalogue",\r
"Items no longer in the catalogue",\r
"items; the printout and the table contain all of them.",\r
"items. The import replaces all items and prices; issued receipts are not changed. The file can be the catalogue of one register or a package with prices per store.",\r
"There is no item \\"{0}\\" in the catalogue.",\r
"Item \\"{0}\\" is no longer in the cash register catalogue. The catalogue needs to be refreshed.",\r
"There is no item with code \\"{0}\\" in the catalogue. A name is also required for a new item.",\r
"The item no longer exists in the catalogue: {0}. It must be removed from the screen.",\r
"Items and prices can be changed only by the manager. A manager with a PIN must be entered (Settings → Cashiers).",\r
"Items and prices are changed by the supervisor on the \\"Items and prices\\" screen (More → Items and prices): price change, new item, data edit, bulk change. Changes are recorded and sent to Accounting and Manager; change files (\\"kasa-cijene\\" format) can also be transferred manually.",\r
"Only the manager can change items on the cash register. A manager with a PIN must be entered (Settings → Cashiers).",\r
"Items",\r
"Items without a barcode (bread, bags, fruit) as buttons above the code field; tapping a button adds the item to the receipt. Maximum 24.",\r
"Items and prices",\r
"Items and prices (supervisor)…",\r
"The items and prices on this register are replaced with those from the company's last package received from Accounting (the prices of this register's point of sale), even when newer prices are on the register. Issued receipts are not changed.",\r
"The items and prices on this register are replaced with the contents of the file \\"{0}\\". Issued receipts are not changed.",\r
"Items that no longer exist in the catalogue were not returned: {0}.",\r
"item",\r
"ATLANTIC INVESTMENT D.O.O.",\r
"AUTIĆ",\r
"Automatic printing after payment is turned off because no printer is selected. The printer is selected in Settings (Receipt and printing); until then, the receipt is printed with the \\"Last\\" button.",\r
"Automatic \\"No-show\\"",\r
"Automatic update download",\r
"Automatic sending of technical errors is turned off (Settings → Support and errors). This report will not be sent either until sending is turned on.",\r
"Automatic sending of technical errors is turned on (Settings → Support and errors).",\r
"Automatic sending of technical errors is turned on (Settings → Support and errors).{0}",\r
"advance",\r
"Advance",\r
"Advance — {0}",\r
"The advance of {0} EUR has been collected.",\r
"The advance of {0} EUR has been returned.",\r
"Advance and cancellation",\r
"Advance on cancellation",\r
"Accommodation advance",\r
"Advance for accommodation {0} – {1}",\r
"Advances",\r
"Advances used",\r
"Advances received",\r
"Advances refunded",\r
"advance receipt",\r
"Advance receipt",\r
"ADVANCE RECEIPT",\r
"Advance receipt IKOF",\r
"Advance receipt IKOF {0}",\r
"The advance receipt was issued (IKOF {0}), but saving to the server failed. Retry the save; the receipt is not issued again.",\r
"The advance receipt was rejected by the Tax Administration. It must be sent again first.",\r
"The advance receipt has already been corrected for this receipt.",\r
"An advance receipt cannot also be a corrective receipt.",\r
"The advance receipt does not exist on this cash register.",\r
"The advance receipt has no IKOF.",\r
"The advance receipt was not issued on this cash register, and the advance receipt data has not been recorded on the server.",\r
"Advance receipt with a VAT rate of {0} %.",\r
"An advance receipt is issued for a received payment: the payment method cannot be advance or deferred payment.",\r
"An advance receipt does not refer to other receipts.",\r
"An advance receipt is not cancelled here. The advance is returned through \\"Advance refund\\" on the room bill.",\r
"August",\r
"August",\r
"AXE",\r
"Updating from within the program is not supported in the browser; it is available in the cash register on Windows and Android.",\r
"Updates are allowed only over an HTTPS connection.",\r
"Update downloaded",\r
"An update is already in progress — wait for it to finish.",\r
"The update failed ({0}). Nothing was changed.",\r
"The update failed.",\r
"Program update",\r
"Updates are accepted only from the official cash register release address ({0}).",\r
"update: {0}",\r
"update: deletion outside the Verzije folder refused: {0}",\r
"update: userData must be a full path",\r
"BABY",\r
"BACARDI",\r
"Backspace",\r
"BADEM",\r
"BAGET",\r
"BAILEYS",\r
"BAJADER",\r
"BALLANTIN",\r
"BALLANTINES",\r
"BALON",\r
"BANINI",\r
"Bar",\r
"BARILLA",\r
"Barcode",\r
"Barcode \\"{0}\\" is not valid (digits, letters, hyphen and full stop, at most 32 characters).",\r
"barcode {0} linked to item {1}{2}",\r
"Barcode {0} already belongs to another item. A choice below the barcode field is required.",\r
"Barcode {0} is already held by items {1}.",\r
"Barcode {barkod} is linked to the item \\"{naziv}\\".",\r
"Barcode {barkod} already has the item \\"{naziv}\\".",\r
"The barcode is required.",\r
"The barcode is not valid (digits, letters, hyphen and dot, at most 32 characters).",\r
"The barcode was not accepted because a question is open. Close the question, then scan the barcode again.",\r
"The barcode is not linked to any item.",\r
"Only the manager moves a barcode. A manager with a PIN must be entered (Settings → Cashiers).",\r
"Only the manager removes a barcode from an item. A manager with a PIN must be entered (Settings → Cashiers).",\r
"a barcode is added to an existing item that has none; the name and price are not changed",\r
"The barcode is added to the existing item. The item's name and price are not changed.",\r
"Barcode, code or part of the name",\r
"barcode, then Enter",\r
"Barcodes",\r
"Barcodes",\r
"BATAK",\r
"BATERIJ",\r
"The item database was not loaded: {0}",\r
"The database reported an error while reading, and the check of the entire database passed; a computer memory error is possible. If the error repeats, the computer needs to be inspected.",\r
"The register database is damaged and cannot be opened (neither the last nor the previous snapshot). The database files were not changed.",\r
"The cash register database has not yet been saved to disk — try again in a minute.",\r
"The database was not saved ({0}). The installation was cancelled.",\r
"The database was not saved ({0}). The restart was cancelled.",\r
"The database in the register's memory is damaged (computer memory error) and was not written to disk. Issued receipts are saved. Close and restart the register.",\r
"BB",\r
"Bearer {0}",\r
"BEBETO",\r
"BEBI",\r
"Baby products",\r
"bečići",\r
"BECK",\r
"BEEFEATER",\r
"BEER",\r
"BELVEDERE",\r
"Berane",\r
"Without \\"Calculate IKOF and QR\\" sending to the Tax Administration is not possible: receipts are issued without an IKOF and QR code, as non-fiscal.\\n\\nDisable both fiscalization and sending (test operation)?",\r
"No barcode",\r
"No points",\r
"No room assigned",\r
"Gluten-free",\r
"no group",\r
"With no selection, the business mode entered on the server applies; if there is none, the register shows everything.",\r
"No camera: enter the QR code text",\r
"no customer",\r
"No customer",\r
"No customer. For a pro forma to a company, a customer (PIB and name) must be selected.",\r
"without diacritics (c c z s dj)",\r
"Lactose-free",\r
"no licence (operation without limits)",\r
"no new data",\r
"no response",\r
"without a pack size (the label will have no price per kg / l)",\r
"No partner",\r
"No turnover in the period",\r
"without receipt",\r
"without a receipt, with a reason; opening is logged",\r
"No layout (grid)",\r
"no reason",\r
"without prescription",\r
"no end date",\r
"No image",\r
"no room",\r
"No room",\r
"No printing",\r
"No tax after nights",\r
"no tax: {0}",\r
"No contract with the FZO (private prescriptions only)",\r
"With no cashiers entered, the register works without login. Once at least one cashier is entered, the register asks for a login at startup and the cashier's name is printed on the receipt.",\r
"no connection",\r
"Unlinked",\r
"No connection since {0}",\r
"No connection since {0}:{1}",\r
"no connection since the register started",\r
"No connection to the server for {0} {1} (allowed {2}). Read-only and export until the connection to the server is restored.",\r
"No loyalty",\r
"Non-alcoholic – Energy drinks",\r
"Non-alcoholic – Carbonated",\r
"Non-alcoholic – Juice/Nectar",\r
"Non-alcoholic – Water",\r
"BIBER",\r
"Bijelo Polje",\r
"Balance sheet, Income statement, Simplified notes, Statistical annex",\r
"Selecting items for bulk change:",\r
"BISCUIT",\r
"BISKVIT",\r
"Data bits",\r
"BITTER",\r
"Bluetooth",\r
"Bluetooth (Android)",\r
"Points per euro (0 = off)",\r
"Points cannot be spent together with a % discount.",\r
"Points are spent only with a loyalty customer (Customer → Phone).",\r
"Loyalty points",\r
"Colour",\r
"BOMBAY",\r
"BOMBON",\r
"Voucher",\r
"Voucher {0} expired on {1}.",\r
"Voucher {0} is not known to this cash register. If it was bought today at another register, wait for the exchange with the server (Settings → Server).",\r
"Voucher {0} from this receipt has already been used ({1} €). The receipt cannot be cancelled.",\r
"The voucher expired on {0}.",\r
"The voucher is not known to this register (it may not have arrived from another register yet).",\r
"The voucher is used in all our shops, in one or more purchases, up to the voucher amount. It cannot be exchanged for cash.",\r
"The voucher can be used in all our shops, in one or more purchases, up to the voucher amount. It cannot be exchanged for cash.",\r
"Voucher valid (days)",\r
"BON-{0}",\r
"Combatant / war military invalid",\r
"Stay",\r
"Stay longer than {0} days",\r
"Stay longer than 30 days",\r
"Tourist tax",\r
"Tourist tax ({0}{1}",\r
"Tourist tax (EUR per person per night)",\r
"Tourist tax (estimate)",\r
"Tourist tax (outside the receipt)",\r
"The tourist tax is not revenue; summary receipts are not turnover (the turnover is on the individual receipts).",\r
"Tourist tax by months",\r
"The tourist tax for the municipality {0} is {1} EUR; in the property rules it is {2} EUR.",\r
"Tourist tax",\r
"BOUNTY",\r
"br",\r
"BR",\r
"No.",\r
"no. {0}",\r
"no. {0} ·",\r
"BRANDY",\r
"BRASNO",\r
"BRAŠNO",\r
"BRAVO",\r
"BREF",\r
"BRENDI",\r
"BRIJAC",\r
"BRIJAČ",\r
"Deletions dated in the future ({0}; device clock was moved)",\r
"Deletions:",\r
"Deletion",\r
"Delete last item",\r
"Delete the receipt being entered (customer changed their mind, no money); it stays in the deleted records",\r
"Deletion is recorded: who, when, how much, why. The manager sees all deleted receipts.",\r
"Deleting the old code from the item",\r
"Item deletion",\r
"Number",\r
"Document number",\r
"document number",\r
"Document number",\r
"The number is already {0}. No change.",\r
"Register number for the terminal",\r
"Card number",\r
"The number shown by the {0} program on this computer. Without that program the field stays empty.",\r
"The number of pieces per pack must be greater than zero.",\r
"The licence number must be in the form L-2026-0001.",\r
"Order number",\r
"The number is not valid (a whole number, e.g. 1250).",\r
"The number of people is not valid.",\r
"Receipt number",\r
"Prescription number",\r
"The prescription number has not been entered.",\r
"Number of rooms",\r
"The phone number is required.",\r
"Visa number",\r
"Health insurance card number or JMBG",\r
"The health card number or JMBG is not valid.",\r
"The receipt counter of this cash register ({0}) is behind the last number from the exchange folder ({1}). The cash register was restored from a copy or reinstalled. The receipt was not issued. The last issued number must be entered, at least {2} (Settings → Fiscalization → \\"Set…\\").",\r
"The receipt counter of this cash register ({0}/{1}) is behind the number from the exchange folder ({2}). The cash register was restored from a copy or reinstalled. Until the last issued number is set, at least {3} (Settings → Fiscalization → \\"Set…\\"), the cash register does not issue receipts for the Tax Administration.",\r
"BRUT",\r
"Gross",\r
"GROSS",\r
"bruto REAL",\r
"Quick keys (codes, comma-separated)",\r
"Quick select",\r
"Speed",\r
"Speed (serial)",\r
"Budva",\r
"BUDWEIS",\r
"BUREK",\r
"BURN",\r
"button",\r
"BUTTON",\r
"Bypass",\r
"Byte",\r
"CABERNET",\r
"CACKALIC",\r
"ČAČKALIC",\r
"CAJ",\r
"ČAJ",\r
"CAMEL",\r
"CAMPARI",\r
"cancel",\r
"CANCELED",\r
"CANCELED,CANCELLED,ABORTED",\r
"CAPPUC",\r
"CAPTAIN MORGAN",\r
"Hour (0–23) of the day after the planned arrival.",\r
"CAS (ST/US,GS)",\r
"CASH",\r
"CAST(ROUND({0} * 100) AS INTEGER)",\r
"CAST(ROUND(COALESCE({0}, 0) * 100) AS INTEGER)",\r
"CEDEVIT",\r
"pending",\r
"waiting (table at the register)",\r
"Waiting for the Tax Administration to receive {0} first.",\r
"Waiting for the Tax Administration to first receive the receipt being cancelled.",\r
"Waiting to retry the download",\r
"awaiting Tax Administration",\r
"awaiting confirmation from the Tax Administration",\r
"Waiting for the price list from Accounting (main computer: Register price list → \\"Exchange now\\"). The register picks up the price list automatically.",\r
"Waiting to be sent",\r
"Waiting to be sent to the server",\r
"awaiting summary receipt",\r
"Waiting: {0}.",\r
"Awaiting Tax Administration",\r
"Holds",\r
"Wait for result (s)",\r
"Wait for stable weight (ms)",\r
"Celery",\r
"Waiting to be sent to the central receipt server: {0}.",\r
"Thu",\r
"Cetinje",\r
"CETKIC",\r
"ČETKIC",\r
"Thursday",\r
"CEVAP",\r
"ĆEVAP",\r
"CHAMPAGNE",\r
"CHANDON",\r
"CHARDON",\r
"checked",\r
"CHESTERFIELD",\r
"CHIO",\r
"chip",\r
"connection chip",\r
"CHIPS",\r
"CHIPSY",\r
"CHIVAS",\r
"CIF",\r
"CIGARE",\r
"CIGARET",\r
"CIGARETA",\r
"cigarettes",\r
"CIGARETE",\r
"whole group",\r
"all",\r
"Price",\r
"price · code",\r
"Price (EUR incl. VAT)",\r
"The price {0} € is too large (maximum {1} €).",\r
"The price {nova} is lower than the purchase price ({nabavna}). Enter the price?",\r
"The price {nova} exceeds the maximum permitted price of the medicine ({max}).",\r
"item price and promotion, without entry on a receipt",\r
"price and price per kg / l",\r
"price and price per kg / l, printing",\r
"price and price per kg / l, printing",\r
"Price and payment",\r
"The price is too high.",\r
"The price has changed in the meantime. Undoing is not possible.",\r
"The price must be greater than zero.",\r
"Price per night",\r
"Price per night (EUR)",\r
"The price per night is not valid.",\r
"Price per night incl. VAT by period. A period for a room type takes precedence over a period for all types; outside periods the base price of the type applies.",\r
"Price per unit",\r
"Price by nights",\r
"Price with VAT",\r
"Price incl. VAT (EUR)",\r
"A price is changed by tapping the item's price and applies to this point of sale. Changes are sent to Accounting and Manager.",\r
"price in one touch, new item, item edit, bulk change; supervisor only, transferred to Accounting and Manager",\r
"price entered for this point of sale",\r
"cijena_utc TEXT",\r
"cijena_vrijeme TEXT",\r
"Prices from the company package",\r
"Prices that arrived from the office and are waiting for a new label",\r
"Only the manager can change prices on the cash register. A manager with a PIN must be entered (Settings → Cashiers).",\r
"The prices on the cash register are from a newer package ({0}) than the package in the program ({1}). The newer price file must be loaded first (\\"Load package from file…\\").",\r
"Prices have been updated.",\r
"Prices in the catalogue have changed; the amount must be checked.",\r
"Prices in the catalogue have changed. The amount must be checked and the payment repeated.",\r
"prices for \\"{0}\\"",\r
"Prices: {0}.",\r
"The price is changed by a user with authorisation.",\r
"CIMET",\r
"CINZANO",\r
"The whole catalogue is replaced with the items and prices from the server.",\r
"CIPS",\r
"ČIPS",\r
"Cleaning",\r
"Cleaning up old deleted receipts failed: {0}",\r
"Cleaning in progress",\r
"Clean",\r
"The barcode reader is being downloaded (Google Play services). You can try again in half a minute.",\r
"The document reader enters the zone here; it can also be done manually, row by row.",\r
"Read weight from barcode (scale)",\r
"Price list",\r
"The price list from Accounting for this register states the business premises code",\r
"The price list is from another company (PIB {0}) and was not applied.",\r
"Register price list → \\"Save price list to file\\"",\r
"The price list states a different business premises code (",\r
"The price list was not applied: {0}",\r
"The price list cannot be read: {0}",\r
"The price list in the folder is from another company (PIB {0}).",\r
"Art. {0}",\r
"Art. 26",\r
"Art. 27",\r
"CLIPSY",\r
"COALESCE(p.kupac_pib, '') LIKE ?",\r
"COALESCE(podgrupa,'') = ?",\r
"COALESCE(r.popust, 0)",\r
"COALESCE(r.popust, 0) <> 0",\r
"COALESCE(r.vrsta, 'racun') <> 'otpis'",\r
"COALESCE(st.popust, 0)",\r
"COALESCE(vrsta, 'racun') <> 'otpis'",\r
"COCA",\r
"COCKTA",\r
"COGNAC",\r
"COINTREAU",\r
"COKOLAD",\r
"ČOKOLAD",\r
"COLA",\r
"COLGATE",\r
"Concert does not support the operation: {0}",\r
"Concert: response of unexpected length ({0})",\r
"Concert: message is not 34 characters long",\r
"Content-Type, {0}",\r
"CORNFLAKE",\r
"CORONA",\r
"CORRECTIVE",\r
"CP852 (č ć ž š đ)",\r
"Montenegrin",\r
"CROCKY",\r
"CROISS",\r
"CUBA",\r
"CUCLA",\r
"stored masked",\r
"Retention of personal data (years)",\r
"Retention of personal data: at least 1 year",\r
"Yes",\r
"Next",\r
"day",\r
"Day",\r
"Day / from",\r
"Report day: from 1 to 31",\r
"days",\r
"Days after the end of each 15 days in a month.",\r
"today",\r
"Today",\r
"Today is {0}. It is not specified which goods this kiosk may sell on Sundays and holidays (Art. 35b). Sales are not restricted.\\n\\nThe list of permitted item groups is entered in Accounting (Register price list → register).",\r
"Days",\r
"Danilovgrad",\r
"DATA",\r
"data-rn=\\"smjena\\" data-id=\\"{0}\\" title=\\"Reprint the closing (Z) report of this shift\\"",\r
"datalist",\r
"Date",\r
"The \\"to\\" date is before the \\"from\\" date.",\r
"The \\"to\\" date must be YYYY-MM-DD or null (no deadline).",\r
"The \\"from\\" date is after the \\"to\\" date.",\r
"The \\"from\\" date must be YYYY-MM-DD.",\r
"The \\"valid until\\" date is before the \\"valid from\\" date.",\r
"The \\"valid until\\" date is not in the form 2026-07-31 (given: \\"{0}\\").",\r
"The \\"valid from\\" date is not in the form 2026-07-31 (given: \\"{0}\\").",\r
"The date is not valid.",\r
"Date of prescription",\r
"The prescribing date is in the future.",\r
"The prescribing date has not been entered.",\r
"The reservation date is not valid.",\r
"date of birth",\r
"Date of birth",\r
"date in the future",\r
"Date of entry into Montenegro",\r
"The device date ({0}) is earlier than the date of the last receipt ({1}). Receipts are not issued until the device clock and date are correct.",\r
"Organ / blood donor (more than 10 times)",\r
"DAVIDOFF",\r
"DAYS",\r
"A deactivated ENU cannot be changed.",\r
"December",\r
"December",\r
"DECLINED",\r
"DEFGHIJKLMNOPQRSTUVWXYZ",\r
"DEO",\r
"Deposit",\r
"Deposit — money into the register",\r
"deposit / withdrawal",\r
"Deposit recorded:",\r
"DEPOSIT…",\r
"Deposits",\r
"Deposits and withdrawals",\r
"DETERDZ",\r
"DETERDŽ",\r
"DEZINF",\r
"DEZODOR",\r
"Dibal (as Toledo)",\r
"DIGESTIV",\r
"part of the",\r
"also shared by",\r
"also shared by {0}",\r
"Child",\r
"Child up to {0} years",\r
"Child up to 12 years",\r
"The image dimensions cannot be read.",\r
"DINERS",\r
"Guest's part ({0} EUR)",\r
"Guest's part (balance)",\r
"Patient share",\r
"Partner's part ({0} EUR)",\r
"Partner's part (balance)",\r
"Part of the partner's bill is left for invoicing.",\r
"Part of the goods has already been returned; the rest is returned by a return, not by a cancellation.",\r
"Part of the goods from this receipt has already been returned. The rest is returned through \\"Partial return of goods\\".",\r
"part of the items for payment, the rest stays on the table",\r
"Direct printing",\r
"Direct printing (ESC/POS)",\r
"Direct printing is not available. A new version of the application (1.5) is required.",\r
"Direct printing failed: {0}. Printing goes through the printer driver.",\r
"Direct receipt printing",\r
"Direct receipt printing (ESC/POS) is set in Settings → Add-ons. Here the paper status is checked: Sunmi through the manufacturer service, other ESC/POS printers with the \\"DLE EOT 4\\" query (the printer must answer the query). For wholesale in the field: a 58 mm (32 characters) or 80 mm (48 characters) Bluetooth printer also prints the business customer (name, tax ID, address) and the card approval number.",\r
"Direct printing works only in the installed cash register (Windows / Android).",\r
"Direct submission",\r
"Direct submission: available after the technical instructions of the Police Administration are received.",\r
"director",\r
"disabled",\r
"disabled title=\\"The code is the item's code; moving is not possible.\\"",\r
"disabled title=\\"The medicine is not in the register's code list\\"",\r
"DISARONNO",\r
"The disk is full — the file was not saved. Free up space and try again. (ENOSPC)",\r
"The disk is full — the exchange file was not written. (ENOSPC)",\r
"The disk is full — free up space (e.g. old backup copies in Dokumenti\\\\Kasa), then try again. (ENOSPC)",\r
"The disk is full — the backup copy was not written. (ENOSPC)",\r
"div",\r
"Children",\r
"Company activities",\r
"DJELIMICNO",\r
"Daily report",\r
"Daily report for this day",\r
"Daily overview",\r
"log",\r
"The log is larger than {0} MB.",\r
"The log is kept automatically and retained as long as the guest registration data.",\r
"Log attachment: an array of up to {0} lines of text (a line of up to {1} characters).",\r
"Log: entries {0}–{1} are missing; recovery stopped (a copy of the log has been saved).",\r
"Log: row {0} is damaged; recovery stopped at that point (a copy of the log has been saved).",\r
"Log: entry {0} could not be applied ({1}) and was skipped; later entries were applied. A copy of the log has been saved. Contact maintenance.",\r
"to",\r
"To",\r
"To (inclusive)",\r
"Until {0}",\r
"By when the guest leaves the room on the day of departure.",\r
"supplier",\r
"Suppliers",\r
"supplier",\r
"dobro",\r
"Welcome",\r
"DOCUMENTS",\r
"Extras (1.5)",\r
"Add",\r
"Add guest",\r
"Add to this item too",\r
"Add as a new item",\r
"Add payment method",\r
"Add property",\r
"Add prescription",\r
"Add rooms",\r
"Add service",\r
"Add room type",\r
"add to labels",\r
"Additional cash registers or devices, extension of the trial period, an additional module (Accounting, Manager) or something else. The publisher replies here (approved / rejected, with an explanation).",\r
"Additional module (Accounting, Manager…)",\r
"Extra beds",\r
"Added to table {0}.",\r
"Rooms added: {0}{1}.",\r
"Added to the list: {0} with new prices.",\r
"Added: {0}",\r
"Added.",\r
"Adding — table {0}",\r
"Adding multiple rooms",\r
"Tapping the price opens a keypad for the new price. The price applies to this point of sale, is logged (who, when, old → new) and is sent to Accounting and Manager.",\r
"Agreed price per night (EUR)",\r
"While the register has no ENU, receipts are",\r
"while there is no certificate and codes from the Tax Administration or while the environment is TEST. Below the title on the receipt it says \\"TEST MODE — NOT REPORTED TO THE TAX ADMINISTRATION\\".",\r
"until the receipt is issued",\r
"Until this is corrected, receipts cannot be issued.",\r
"docs,",\r
"Evidence",\r
"Write-off documents:",\r
"Document",\r
"Document no.",\r
"The document gets its own number (O-1, O-2…), is printed and can be seen in the receipt overview under \\"Write-offs\\".",\r
"The document from the queue does not exist on this cash register or has no IKOF.",\r
"The document was issued without an IKOF.",\r
"The document is too large to print ({0} MB). Narrow the period or selection and print in parts (the report can also be saved as a spreadsheet).",\r
"The document is not fiscal and does not count towards turnover. The goods are removed from stock as if sold. Purpose: goods that have expired, or damaged or unusable goods that the supplier does not take back.",\r
"Write-off document",\r
"The write-off document is not a receipt. A return is not possible.",\r
"A write-off document is not cancelled. A goods write-off is a record document, not a receipt.",\r
"A write-off document cannot be cancelled. A goods write-off is not a receipt.",\r
"The document cannot be issued without an IKOF (fiscalization is not enabled or there is no certificate). Nothing was issued.",\r
"The documents have been issued. Posting to the room's bill is waiting for a connection to the server.",\r
"Arrivals",\r
"Arrivals and overnight stays by country (TU-11)",\r
"Arrivals and overnight stays by country and month",\r
"Arrivals from today",\r
"Arrival",\r
"Arrival (first night)",\r
"arrival {0}",\r
"arrival today",\r
"Arrival today",\r
"The arrival has been registered.",\r
"Arrival delayed ({0})",\r
"Arrival from",\r
"Arrival from (hour)",\r
"Homemade",\r
"domestic",\r
"Domestic guest",\r
"Domestic guest (citizen of Montenegro)",\r
"Domestic: {0} arrivals, {1} overnight stays · foreign: {2} arrivals, {3} overnight stays.",\r
"DOMACIC",\r
"DOMAĆIC",\r
"Domain {0} has been entered. QR codes with this domain are printed on the main register (QR menu → Settings → own domain).",\r
"The domain was removed. QR codes lead to the IRIS menu address.",\r
"DOMESTOS",\r
"ĐON",\r
"Co-payment",\r
"extra payment {0}",\r
"Surcharges",\r
"DORINA",\r
"DORITOS",\r
"Breakfast, half board, full board.",\r
"Delivery",\r
"A new cash register version {0} is available (Settings → Update).",\r
"A new version is available:",\r
"A new version is available: {0}",\r
"dot",\r
"DOVE",\r
"The permit was issued for cash register {0}, and this is cash register {1}.",\r
"The permit is valid only {0}. A new permit is needed for today.",\r
"Allow access",\r
"allowed",\r
"Dr Test (facsimile 0000)",\r
"DRAZE",\r
"DRAŽE",\r
"DRESING",\r
"DRINA",\r
"Narcotic",\r
"narcotic (PRp)",\r
"Drugs and psychotropic substances are not dispensed at the expense of FZO in a private pharmacy.",\r
"Other document",\r
"another register",\r
"Another register",\r
"Other types",\r
"A second window with the items and the receipt total; on the second monitor it opens full screen. Applies from the next receipt.",\r
"other",\r
"Other",\r
"Other (note)",\r
"Other (description in the note)",\r
"Country",\r
"Country of issue",\r
"Country of document issue",\r
"country that issued the document",\r
"country of birth",\r
"Country of birth",\r
"Citizenship",\r
"citizenship",\r
"Citizenship",\r
"ĐUBR",\r
"DUEL",\r
"The debt of the corrective receipt has no document.",\r
"button",\r
"The \\"↩ Void\\" button on the main screen voids the last receipt (customer did not pay, data entry error) up to 30 min after issue; without this tick, the cashier who issued the receipt voids it without the supervisor's approval. Cancellation of older receipts (Receipts) always requires the supervisor.",\r
"DUHAN",\r
"DUNHILL",\r
"duplicate but not found",\r
"Tobacco",\r
"DUVAN",\r
"Double room",\r
"Double payment",\r
"Double payment ({0}): {1} Receipt overview → cancellation.",\r
"Double payment: {0} — the receipt should be cancelled",\r
"DZAK",\r
"DŽAK",\r
"DZEM",\r
"DŽEM",\r
"E-copy: receipt QR on the customer screen (seconds)",\r
"E-mail",\r
"e-prescription FZO (service)",\r
"FZO e-prescription, FZO prescription (Fund app / manual), private prescription; pharmacist",\r
"Patient's e-prescriptions",\r
"e.g. The kitchen is open until 11 pm",\r
"EACCES",\r
"EADDRINUSE",\r
"EAN-13",\r
"EAN-8",\r
"EBUSY",\r
"EC",\r
"ECDSA",\r
"EDAMER",\r
"efi_uuid TEXT",\r
"efi_zadnji TEXT",\r
"the screen reported: {0}",\r
"The screen is empty.",\r
"Kitchen screen (orders also on screen)",\r
"The kitchen screen is not enabled on the cash register (Settings → Add-ons).",\r
"Customer display",\r
"Customer display on the second screen of the Android register (Sunmi T2, D2s and similar dual-screen registers).",\r
"Network customer display is not enabled on the register.",\r
"Customer display on",\r
"Customer display: a window on the second monitor of this computer and/or a tablet on the local network (the tablet browser opens the address below). The tablet requires the waiter phone server to be on (Settings → Waiters).",\r
"The receipt screen is not ready.",\r
"the screen did not load ({0})",\r
"the screen crashed ({0})",\r
"Customer display (second monitor)",\r
"screen: {0}",\r
"Electronic copy of the receipt: scan the QR with a phone",\r
"Electronic labels",\r
"Email",\r
"ENERG",\r
"English",\r
"ENOENT",\r
"ENOSPC",\r
"Enter",\r
"enu TEXT",\r
"EPERM",\r
"ERDINGER",\r
"Esc",\r
"Escape",\r
"ESPRESSO",\r
"ESSE",\r
"Label",\r
"Label with price and price per kg / l",\r
"Labels",\r
"Price labels",\r
"EUR",\r
"EUR · balance",\r
"EUR · paid",\r
"EUROCREM",\r
"EUROKREM",\r
"The records are kept for one year; older entries are deleted automatically.",\r
"The records are kept for one year. The earliest available date is {0}.",\r
"Record document (not a fiscal receipt). The goods have been removed from stock; it is not included in turnover and is not reported to the Tax Administration.",\r
"ex TEXT",\r
"F-keys",\r
"F-keys on the main screen (work without a mouse). F5 and F12 are not used. A key works when no dialog is open.",\r
"FA",\r
"FAIRY",\r
"File",\r
"The file \\"{0}\\" contains the catalogue of one register, not a package with a list of registers. The entire catalogue is replaced with the contents of the file; the list of registers stays the same. Issued receipts are not changed.",\r
"file {0} is corrupted",\r
"file {0} is damaged and not readable",\r
"file {0} is empty",\r
"file {0} cannot be read ({1})",\r
"file {0} cannot be unpacked",\r
"The price change file belongs to a different company (PIB {0}).",\r
"the file is larger than {0} MB and is not sent to the server.",\r
"The file does not look like the cash register config.json (it has no cash register code, company or server address).",\r
"The file is not readable (a config.json settings file is expected).",\r
"The file is not readable (a JSON cash register catalogue is expected).",\r
"The file is not readable (JSON is expected).",\r
"The file is not a PIN reset permit.",\r
"The file is not a price change file (the format \\"kasa-cijene\\").",\r
"The file is not a price changes file (the \\"kasa-cijene\\" format is expected).",\r
"The file is not a cash register catalogue (the \\"kasa-katalog\\" format is expected).",\r
"The file has not been changed; the register is running in test mode. The register must be restarted. If the error repeats (e.g. the data was transferred from another computer), the unreadable keys are discarded with the button below, and the certificate is imported again.",\r
"The file is not a cash register data package (the format \\"kasa-paket\\" is expected).",\r
"The file was not written completely.",\r
"The file was not written in full. The action must be repeated.",\r
"The file with the certificate, key and server password is moved aside (not deleted), and the register continues without them, as new.\\n\\nAfter that, the certificate (.pfx) must be imported again and the server password entered.\\n\\nThis step is intended only when restarting the register did not fix the error. Continue?",\r
"The file is created in Accounting (",\r
"The certificate file is empty.",\r
"the file tajne.json has disappeared, and its previous copy tajne.json.stari exists — it must be restored manually",\r
"the file tajne.json is corrupted — it is empty or unreadable",\r
"the file tajne.json cannot be opened — it is held by another program or access is denied ({0})",\r
"the file tajne.json is not in a form the cash register recognises",\r
"The closing file of cash register {0} in the exchange folder is written by another device (created {1}). If the cash register was not just reinstalled or restored from a copy, two devices are working as the same cash register. On one of them the correct cash register must be selected (Settings → Change cash register).",\r
"change files: {0}, applied {1}{2}",\r
"Cash register files waiting to be sent to the server: {0}.",\r
"The register keeps the files from the server and its own exchange files in its own space (not in the exchange folder), so neither Autosync nor the \\"access to all files\\" permission is needed for exchange.",\r
"The update files are in use (antivirus?). Nothing was changed — try again in a minute.",\r
"Cash register files are waiting to be sent to the server.",\r
"Files of this register that did not reach the server: {0}. They remain only in the exchange folder.",\r
"FANTA",\r
"Pharmacist:",\r
"Pharmacist: {0}",\r
"February",\r
"February",\r
"Feed",\r
"The feed has an invalid minimum Setup version (minSetup).",\r
"The feed has an invalid version label for the Android package.",\r
"The feed has an invalid version label.",\r
"The feed has no valid checksum (sha256) — the package cannot be accepted.",\r
"The feed has no \\"verzija\\" and \\"url\\" fields.",\r
"The feed is not valid JSON.",\r
"FETA",\r
"fic IS NOT NULL",\r
"FIDE",\r
"FINLANDIA",\r
"Drawer",\r
"The drawer is open (logged).",\r
"Drawer opened without a receipt: {0}",\r
"The drawer did not open: {0}",\r
"The drawer is opened via",\r
"Cash drawer",\r
"company",\r
"Company",\r
"Company / package",\r
"company disabled on the server",\r
"the company has turned off receiving technical errors at the publisher",\r
"The company has turned off the receipt of technical errors at the issuer. The report was not sent; you can write to support with a message (Messages tab).",\r
"The company has turned off the receipt of technical errors at the issuer. The report is not sent; you can write to support with a message (Messages tab).",\r
"The company is temporarily disabled on the server. This register's files wait and are sent automatically when the company is enabled again (an attempt every 15 minutes). Re-pairing is not necessary.",\r
"Company on the receipt",\r
"The company does not exist in the Register of Taxpayers.",\r
"The company is not active in the Register of Taxpayers.",\r
"The company is not in the VAT system (Settings), but the receipt has an item with VAT. The item VAT rates or the company VAT status must be corrected.",\r
"The company is not in the VAT system, but the receipt has an item with VAT.",\r
"Companies:",\r
"fiscal_error LIKE ?",\r
"Fiscalisation",\r
"Fiscalization is turned off in the settings.",\r
"fiscalised",\r
"Fiscal documents at checkout",\r
"Fiscal data",\r
"Fiscal receipt",\r
"A fiscal receipt is issued upon payment.",\r
"The fiscal service responded with HTTP {0} without a readable response.",\r
"The fiscal service did not recognize the message. Possible cause: a wrong service address (Settings → Fiscalization) or a program error.",\r
"Fiscal",\r
"FLASIC",\r
"FLAŠIC",\r
"FLIPS",\r
"Folder (Google Drive)",\r
"The folder (Google Drive) is not set up.",\r
"the cash register's data folder is unknown",\r
"The exchange folder does not exist or is not available: {0}",\r
"The exchange folder is not set (Settings → Exchange with Accounting).",\r
"Exchange folder with Accounting (Google Drive)",\r
"The folder is used for the register's database backup: once a day, the last 7 days, in the \\"Kasa rezerva\\" subfolder.",\r
"The folder for automatic saving has not been set up (Settings → Extras).",\r
"Folder for electronic labels",\r
"formula",\r
"FRUCTAL",\r
"FRUVITA",\r
"FZO",\r
"FZO (Fund application)",\r
"FZO {0}",\r
"FZO manual prescription",\r
"FZO service (not set up)",\r
"FZO WebService (per the Fund's specification)",\r
"GARNIER",\r
"GAUDA",\r
"GAULOISES",\r
"GAZIRAN",\r
"GEL ZA TUS",\r
"GEL ZA TUŠ",\r
"GET",\r
"GILLETTE",\r
"GIN",\r
"GLADE",\r
"main",\r
"main",\r
"the main register",\r
"GLO",\r
"year",\r
"Google Drive",\r
"Google Drive (Autosync)",\r
"Google Drive (backup)",\r
"GORDON",\r
"GORDONS",\r
"GORKI LIST",\r
"GORSKA",\r
"guest",\r
"Guest",\r
"Guest — {0} {1}",\r
"Guest (QR menu)",\r
"Guest (QR){0}",\r
"guest is awaiting",\r
"The guest arrived after all",\r
"The guest has been deleted.",\r
"The guest has been checked out.{0}",\r
"The guest has been moved.",\r
"The guest has been saved.",\r
"No-show",\r
"guest departs today",\r
"The guest cancels their own order",\r
"Guest cancelled the order (QR menu)",\r
"The guest scans the QR code at the table, sees the menu in their own language and orders — the order goes straight to the table and to the kitchen / bar (the waiter does not confirm). The guest can cancel the order until the receipt is issued, call the waiter and ask for the bill (card on the POS terminal or cash). The fiscal receipt is issued by this cash register when the waiter charges the table.",\r
"The guest is asking for the bill. The register has been notified.",\r
"Guest asks for the bill",\r
"guest in room",\r
"Guest in room",\r
"guest is calling",\r
"Guest is calling the waiter",\r
"Guest: {0}",\r
"guests are awaiting",\r
"Guests",\r
"guests order from their phones, waiter call, payment of the bill by card / cash; QR codes, languages, images",\r
"Guests order by themselves (without this: menu only, waiter call and bill)",\r
"guests have not been entered",\r
"Guests have not been entered.",\r
"guests in house",\r
"ready",\r
"cash",\r
"Cash",\r
"CASH",\r
"Cash from the same customer",\r
"Cash from the same customer in one day: {0} (limit 10,000 €, Art. 65 para. 2) — {1}",\r
"Cash of 10,000 € or more is not allowed (Law on the Prevention of Money Laundering and Terrorist Financing, Art. 65). The receipt was not issued. Payment is possible by card or bank transfer.",\r
"Cash in the register",\r
"Maximum cash in the register (€)",\r
"Cash turnover",\r
"done",\r
"Done",\r
"Done ({0})",\r
"City",\r
"GRAH",\r
"GRAND KAF",\r
"GRANINI",\r
"GRASAK",\r
"GRAŠAK",\r
"free (N+M)",\r
"error",\r
"greška",\r
"Error",\r
"Register error (code {0}).",\r
"Screen error",\r
"Cash register error: {0}",\r
"Error on the cash register.",\r
"Error on the fiscal service side. Sending will be repeated later.",\r
"Error reading the electronic signature.",\r
"Error reading the signature element.",\r
"Payment error",\r
"startup error",\r
"worker error",\r
"Server error.",\r
"typing error",\r
"Typing error",\r
"Error: {0}",\r
"GREY GOOSE",\r
"Snacks",\r
"GRISIN",\r
"GRIZ",\r
"group",\r
"Group",\r
"The group is empty.",\r
"grupa_id INTEGER",\r
"grupa_id, proizvodjac, neto, neto_jm, pakovanje, max_zaliha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",\r
"Groups (categories)",\r
"Groups that go to the bar",\r
"Bulk change",\r
"Bulk price change",\r
"GST PLUS",\r
"GUARANA",\r
"GUMENE",\r
"Gusinje",\r
"GUSTIN",\r
"H:TAKSA",\r
"HALLS",\r
"HARIBO",\r
"HAVANA CLUB",\r
"HEETS",\r
"HEINEKEN",\r
"HELJD",\r
"HELL",\r
"household chemicals",\r
"HEMIJSK OL",\r
"HENNESSY",\r
"Herceg Novi",\r
"hidden",\r
"hygiene",\r
"Hygiene and chemicals",\r
"Urgent (cito)",\r
"HLEB",\r
"HLJEB",\r
"HMAC",\r
"Hostel",\r
"Hotel",\r
"hotel: {0}{1}",\r
"Hotel business (hotels, apartments, rooms)",\r
"Food with accommodation",\r
"HRENOVK",\r
"Chronic illness under Art. 17 (malignant, diabetes, epilepsy, MS, HIV, hepatitis…)",\r
"http",\r
"HTTP {0}",\r
"HTTP {0}: {1}",\r
"https",\r
"https://… or http://…:8080",\r
"Humanitarian aid",\r
"Thank you for your purchase",\r
"and whether the receipt was paid afterwards.",\r
"and are not sent to the Tax Administration. The ENU is entered after the register is registered (Settings → Fiscalization).",\r
"and does not count towards turnover; the goods are removed from stock.",\r
"and does not count towards turnover; the goods are removed from stock.{0}",\r
"ICE TEA",\r
"ICE-TEA",\r
"ID",\r
"Program ID ({0})",\r
"iframe",\r
"IGRACK",\r
"IGRAČK",\r
"IHDR",\r
"IKOF",\r
"IKOF {0}",\r
"IKOF {0}{1}",\r
"The IKOF of the advance receipt is not valid (\\"{0}\\").",\r
"The IKOF of the advance receipt is not valid.",\r
"The IKOF of the receipt with deferred payment is not valid.",\r
"The IKOF does not match its signature (the IKOF must be the MD5 of the signature). The receipt was recorded incorrectly.",\r
"or",\r
"or amount €",\r
"ILUMA",\r
"has",\r
"First name",\r
"the name {0} is reserved",\r
"the file name goes outside the folder: {0}",\r
"file name with characters the cash register cannot read",\r
"The guest name is required.",\r
"full name",\r
"First and last name",\r
"The cashier's name is required.",\r
"Phone name (visible on the register)",\r
"img",\r
"INDIJSK",\r
"for information: takings entered by OCR often lack \\"total excl. VAT\\"; the voucher takes incl. VAT − VAT",\r
"Ingenico Telium (Concert)",\r
"input",\r
"INPUT",\r
"inputmode=\\"decimal\\" placeholder=\\"0 = no limit\\"",\r
"inputmode=\\"numeric\\" placeholder=\\"8765\\"",\r
"inputmode=\\"url\\" placeholder=\\"https://…\\"",\r
"INSEKT",\r
"Installation is possible after the shift is closed.",\r
"The installation cannot be started.",\r
"It is installed over the existing version; the data remains saved.",\r
"It is installed over the existing version; the data is preserved.{0}",\r
"Install now",\r
"Instant",\r
"Instant payment",\r
"Instant payment (transfer to account)",\r
"Instant payment is not enabled (Settings → Add-ons).",\r
"Instant transfer",\r
"INTEGRAL",\r
"IntPtr h; if (!OpenPrinter(stampac, out h, IntPtr.Zero)) throw new Exception(\\"KASA_NEMA_STAMPACA\\");",\r
"Disability",\r
"INVOICE",\r
"IP (192.168.1.50), Windows printer name or Bluetooth address",\r
"IP, Bluetooth address, InnerPrinter, USB \\"vid:pid\\" (empty = first USB printer)",\r
"IP, Windows printer name, Bluetooth address or InnerPrinter",\r
"IPv4",\r
"IQOS",\r
"IRIS",\r
"IRIS CORVINA",\r
"IRIS CORVINA Kasa",\r
"IRIS CORVINA Kasa {0} · © 2026 Dragomir Dačević, author and rights holder. All rights reserved.",\r
"IRIS ECR (JSON, bridge to terminal)",\r
"IRIS Cash register",\r
"IRIS Cash register — customer display",\r
"IRIS Server",\r
"IRIS Server was not found on this network. The address can be entered manually (\\"Overview\\" screen of the IRIS Server program), or the pairing code is entered as a link from IRIS Admin.",\r
"Result",\r
"Payment result unknown",\r
"Slip for the guest's signature",\r
"Off",\r
"disabled on the server",\r
"disabled",\r
"Disabled: receipts are issued without VAT.",\r
"Disable",\r
"Disable both",\r
"Disable sending",\r
"Disconnect",\r
"Disabling fiscalization",\r
"Disabling sending",\r
"Disconnecting from the server",\r
"Used",\r
"Points used: {0}, discount {1}.",\r
"Use",\r
"Experience",\r
"Paid out",\r
"payout at closing",\r
"Document",\r
"Document valid until",\r
"Data correction",\r
"Fixes and improvements.",\r
"Corrects advance receipt IKOF",\r
"Corrects advance receipt IKOF {0}{1}",\r
"Document issued by",\r
"The same report has already been sent in the last 10 minutes.",\r
"expired",\r
"expired",\r
"Expiry date passed",\r
"Download timed out.",\r
"The same receipt is listed twice among the reference receipts.",\r
"The same receipt is listed twice.",\r
"the same name is both a file and a folder: {0}",\r
"the same name appears twice: {0}",\r
"Item",\r
"Item Price",\r
"Item Tax",\r
"ITF",\r
"from the delivery app (or the customer's name)",\r
"From advance",\r
"from advance {0}",\r
"More than the receipt amount ({0}) cannot be paid from an advance.",\r
"More than the receipt amount cannot be paid from an advance.",\r
"From the file \\"{0}\\" a new list of registers is taken and {1} are loaded. Issued receipts are not changed.",\r
"The server address, printing and similar settings are taken from the file \\"{0}\\".\\n\\nThe register label, point of sale, company, all Tax Administration codes, the environment and the sending switches are not changed (the register is selected from the register list).",\r
"From the file \\"{0}\\", the register label, store, company and Tax Administration codes are taken as well, besides the server and printing. The environment (TEST/PRODUCTION) and the sending switches are not taken.",\r
"Only data is read from the document; the image is not saved.",\r
"from the name",\r
"from the FZO specification",\r
"Select items in the list…",\r
"Choose file…",\r
"Select a register from the list…",\r
"Choose image…",\r
"Select…",\r
"Select the advance receipt.",\r
"Select a date.",\r
"Select a valid period.",\r
"Select a report and a period, then \\"Show\\".",\r
"Select the last night in the same row.",\r
"Select a room type.",\r
"selected",\r
"The same table was selected.",\r
"selected",\r
"Selected",\r
"selected items ( )",\r
"selected items ({0})",\r
"selected. Items are marked in the list.",\r
"Selecting an item from the list opens its name and description in each language, allergens, labels and image.",\r
"Selecting a group from the list opens its name in each language, order on the menu and tile image.",\r
"Register selection",\r
"Register selection is not available.",\r
"Choose by group or search by name.",\r
"Choose the working store",\r
"Selecting from the list opens editing; \\"New entry\\" adds a new one.",\r
"Selecting from the list shows the data.",\r
"The choice can be changed later in settings (Settings → Cash register).",\r
"Dispense — cash",\r
"Dispense — card",\r
"Issue advance receipt",\r
"Issue receipt",\r
"A cancellation receipt is issued, and this one remains in the records as cancelled. Voiding cannot be undone.",\r
"Issued by",\r
"Issued by (authority)",\r
"Issued:",\r
"Issued:",\r
"Dispensed on prescription. Receipt: {0} ({1}).",\r
"Issued: {0}.",\r
"izdavac",\r
"issuer: {0}",\r
"issuer: screen access request",\r
"Dispensing on prescription",\r
"Statement",\r
"Edit",\r
"Edit item data",\r
"Change",\r
"Edit item",\r
"The change was undone. The price was restored to {stara}.",\r
"Edit cashier",\r
"The change was not found.",\r
"An item data change is not cancelled here. The data is changed in the item form.",\r
"Price changes have been saved: {0}",\r
"Price changes: applied {0}{1}, skipped {2}, for other registers {3}.",\r
"Menu changes were not saved",\r
"Changes have not been saved. Discard them?",\r
"Changes on this cash register were not written to the folder: {0}",\r
"This register's changes have been entered.",\r
"changes from this register recorded",\r
"Changes to the menu content were not saved and will be discarded.",\r
"Changes in version {0}",\r
"Amount",\r
"IZNOS",\r
"Amount (EUR)",\r
"The advance amount must be greater than zero.",\r
"The advance receipt amount must be greater than zero.",\r
"The deposit amount cannot be negative.",\r
"Amount of cash in the register at the start of the shift (€).\\nEmpty or 0 = no float.",\r
"Amount is required.",\r
"The amount has been sent to the terminal. The customer pays by card on the terminal.",\r
"The amount is too large.",\r
"The amount exceeds the terminal maximum ({0} €).",\r
"The amount is greater than the free part of the advance.",\r
"The advance correction amount must be greater than zero.",\r
"The amount must be greater than zero.",\r
"Amount on the terminal: {0}. The receipt is issued only once the terminal approves the payment. Approval number from the slip (optional):",\r
"The fee amount must be greater than zero.",\r
"The amount is not valid",\r
"The amount is not valid. Example: 1250,50 (no thousands separator, at most two decimals).",\r
"The amount of the deleted receipt cannot be negative.",\r
"The payment amount is not valid.",\r
"The cash withdrawal amount must be greater than zero.",\r
"The cash withdrawal amount cannot be zero.",\r
"The discount amount is not valid.",\r
"Refund amount (EUR)",\r
"The return amount is 0.",\r
"The refund amount must be greater than zero.",\r
"The amount exceeds the room's permitted debt.",\r
"The receipt amount ({0}) is greater than the sum of its items ({1}).",\r
"The amount is offered by municipality; for other municipalities enter the amount from the municipality's decision.",\r
"The amount of a summary receipt cancellation must be less than zero.",\r
"The summary receipt amount must be greater than zero.",\r
"The summary receipt amount is not equal to the total of the individual receipts.",\r
"Tax amount",\r
"Tax amount (EUR per person per night)",\r
"The tax amount has been saved.",\r
"The tax amount is greater than 10 EUR",\r
"The tax amount is not valid.",\r
"Amount in cents (otherwise in euros)",\r
"The amount in the message ({0}) is not the receipt amount ({1}).",\r
"The amount for \\"{0}\\" is not valid.",\r
"Payment amount is not valid.",\r
"Amount for the terminal is not valid.",\r
"Report",\r
"Tax report for the previous month.",\r
"Reports",\r
"Reports are not available.",\r
"Source",\r
"izvor TEXT",\r
"IZVORSKA",\r
"Export",\r
"Export CSV",\r
"j4sVG68Z6QZGUfZ64qBQSMeUiLa8LQYOxzMKIXC-Pmg",\r
"Strength",\r
"Strength",\r
"JACK",\r
"JACK DANIELS",\r
"JACOBS",\r
"JAFA",\r
"JAFFA",\r
"JAGER",\r
"JÄGER",\r
"JAGERMAISTER",\r
"JAGERMEIJSTER",\r
"JAGERMEISTER",\r
"JÄGERMEISTER",\r
"JAGNJET",\r
"Eggs",\r
"JAMESON",\r
"JANA",\r
"January",\r
"January",\r
"JAR",\r
"JCB",\r
"there are {0} receipts",\r
"there is 1 receipt",\r
"is on screen.",\r
"is open.",\r
"has been downloaded and deployed.",\r
"has been downloaded and will be applied at the next start.",\r
"has been downloaded and verified.",\r
"One manager has no PIN and cannot approve (another manager's PIN is requested). The PIN is entered with the \\"Edit\\" button.",\r
"Unit",\r
"The unit of measure is not from the list.",\r
"The net quantity unit must be one of: {0}.",\r
"The package unit must be kg, l or pcs.",\r
"one",\r
"one-off",\r
"Single room",\r
"JELEN",\r
"Language",\r
"Language of the on-screen text on this cash register; applies immediately. Fiscal receipts, printouts, labels and exports remain in Montenegrin.",\r
"Language of the on-screen text on this device. Exports (Excel, PDF), printouts and labels remain in Montenegrin.",\r
"Language of the on-screen text on this device. Exports (PDF, Excel, XML), printouts, fiscal receipts and Tax Administration forms remain in Montenegrin.",\r
"The language was not changed: {0}",\r
"Program language",\r
"Language: {0}{1}",\r
"JIKR",\r
"JIM BEAM",\r
"UoM",\r
"JM neto",\r
"jm TEXT",\r
"JMB",\r
"JOGURT",\r
"JOHNNIE",\r
"JOHNNIE WALKER",\r
"{0} left",\r
"More registers / devices",\r
"No guest orders yet.",\r
"not yet",\r
"Yesterday",\r
"JUICE",\r
"July",\r
"July",\r
"June",\r
"June",\r
"JUNEC",\r
"JUNEĆ",\r
"JUNETINA",\r
"When",\r
"When enabled, receipts, cancellations, deposits and withdrawals go to the Tax Administration as soon as the internet is available. A certificate and valid codes are required. A change takes effect only after \\"Save\\". While it is enabled and the register is not ready (no certificate, invalid code), receipts are not issued.",\r
"When entered",\r
"KAFA",\r
"Coffee and tea",\r
"KAHLUA",\r
"KAHVA",\r
"KAJMAK",\r
"KAKAO",\r
"How receipts are issued when the guest leaves.",\r
"Calendar",\r
"Camp",\r
"Channel",\r
"The channel must be trial or stable.",\r
"Delivery channels (comma-separated)",\r
"Delivery channels have not been entered (Settings → Extras).",\r
"KAPUCIN",\r
"KARLOV",\r
"Card",\r
"CARD",\r
"Card / instant",\r
"Card: confirmation \\"Approved on the terminal?\\"",\r
"Register",\r
"REGISTER",\r
"Cash register (ENU)",\r
"Cash register {0} · {1} · paired with the server",\r
"Register {0} has started the payment. It can be released only if that register is not working.",\r
"Register ↔ terminal",\r
"The cash register automatically sends technical errors to the publisher (screen crash, server error, rejection by the Tax Administration), without receipt content; personal data (names, phone numbers, amounts) is removed before sending. Here you describe what the cash register does not record: which action was being performed, what was expected and what happened.",\r
"Register and terminal match.",\r
"A register selected from the company's register list also receives the prices of its point of sale.",\r
"The register issues a corrective receipt for the advance receipt.",\r
"The register automatically writes it to the folder \\"{0}\\" (esl_cijene.json) on every price change.",\r
"The cash register is connected to the server and the exchange is up to date.",\r
"The cash register is connected to the server and the exchange is up to date.{0}",\r
"The cash register has been notified: table {0} asks for the bill.",\r
"The cash register started as new. Previous data has been saved in the folder: {0}.",\r
"The register has been set up: {0} · {1}, {2}{3}{4}",\r
"The register has been set up: {0} · label {1}, {2}",\r
"The register is connected to the company",\r
"The register is connected to company {0} (PIB {1})",\r
"The register is connected to company {0}. Fetching prices…",\r
"The register is connected. The company's price list is not on the server (Accounting: Register price list → \\"Exchange now\\").",\r
"The register is in test mode",\r
"The register has been paired with the server: {0} ({1}).",\r
"The register is paired with the server. Exchange with Accounting and Manager goes exclusively through the server, without this folder. {0}",\r
"The register is already paired. A new pairing is possible after \\"Disconnect\\".",\r
"The cash register returned an unreadable response.",\r
"the cash register has not been selected yet",\r
"The register is not yet ready for pairing.",\r
"The cash register is not responding — try again.",\r
"The register does not recognise this phone. Pairing must be done again.",\r
"The cash register has no company package. The cash register connects to Accounting with a code or a package from a file.",\r
"The register has no role \\"{0}\\". Only the roles register supervisor (sef-kase) and cashier exist on the register. The order was not executed.",\r
"cash register not selected",\r
"Cash register not selected",\r
"The cash register is not connected to the server (Settings → Server) — the QR menu goes through the server.",\r
"The cash register is not connected to the IRIS CORVINA server and has no exchange with Accounting.",\r
"The cash register is not ready (the cash register window is not open).",\r
"The register is not ready for the Tax Administration",\r
"The register is not ready to receive from the server (not paired or no exchange folder).",\r
"The cash register is not ready.",\r
"the register is not paired (Server section)",\r
"The register is not paired with the server (Settings → Server). The report cannot be sent.",\r
"The register is not paired with the IRIS CORVINA server (Settings → Server). Support through the program works only for a paired register.",\r
"The cash register is not paired with the IRIS CORVINA server. Messages, requests and error reports go through the server. Pairing: with the code provided by the publisher (Settings → IRIS CORVINA server).",\r
"The cash register is not paired with the IRIS CORVINA server. Pairing is done by the supervisor with a code issued by the administrator (Settings → \\"IRIS CORVINA server (exchange)\\"); the exchange then goes through the server, within a few seconds.",\r
"The register is not paired with the server, and the folder is not set up.{0}",\r
"The register is not paired with the server, so exchange goes through this folderAfter pairing with the server (section above), exchange goes through the server, without waiting, and the folder is used for backup. Empty = disabled.",\r
"The register is not paired with the server. Changes wait on the register until pairing (Settings → IRIS CORVINA server).",\r
"The register is not paired.",\r
"The register stays on ENU code {0} (the code of a previously registered register) and receipts are sent to the Tax Administration under that code. Confirmation is allowed only by agreement with the Tax Administration; otherwise a new ENU code is entered.",\r
"The cash register is starting as new. The program is closing and will start again…",\r
"The cash register starts as after the first installation: the screen for connecting to a company, with no receipts, cashiers, settings or server connection. The program closes and starts again.\\n\\nExisting data is not deleted: it is moved to a separate dated folder inside the cash register data folder, together with a database backup.\\n\\nTo confirm, the word NOVA must be entered.",\r
"The register stops exchanging files with the server and forgets its token (the administrator disables the device on the server). Exchange through the folder (Google Drive) keeps working, as before pairing. A new code is needed to pair again.{0}",\r
"The register takes the company's data, points of sale, items and prices from Accounting.",\r
"The cash register receives guest orders from the QR menu.",\r
"The register receives orders from the waiters' phones ({0}). Connected in the last 90 s: {1}.",\r
"The register receives phones at:",\r
"Kasa Racun",\r
"The register works without a server too. When a server is entered, every receipt is sent automatically as soon as the internet is available.",\r
"The register also works as a reception",\r
"The register cannot start as new now:\\n\\n· {0}",\r
"The register sends the amount to the terminal, the terminal returns the result (approval number, masked card, card type). The receipt is issued only when the terminal approves the payment. For the NLB terminal, the type and connection are determined by the bank app on the terminal —",\r
"The cash register cannot be started on this device: \\"Android System WebView\\" is too old.\\n\\n\\"Android System WebView\\" must be updated in the Play Store (version {1} or later) and the cash register restarted. If the update is not possible, the device does not support the cash register.\\n\\nThe data has not been touched.",\r
"The cash register could not be started.\\n\\n{0}\\n\\nThe data has not been touched. Close and restart the program. If the error recurs, save the data folder and contact maintenance.",\r
"The cash register is connecting to the server.",\r
"the register writes esl_cijene.json when prices change",\r
"The cash register is currently running from version {0}, and its files are not valid. Close the cash register, open it again, then repeat the update.",\r
"Kasa-Azuriranje",\r
"Register: {0}{1}",\r
"Register: by card",\r
"Registers and stores → Add register and create code",\r
"cashier",\r
"Cashier",\r
"Cashier · reason · what",\r
"Cashier · what was removed",\r
"Cashier / operator",\r
"The cashier has been saved: {0}",\r
"The cashier has been saved: {0}. Cashier login follows when settings are closed.",\r
"The cashier does not exist.",\r
"cashier by name",\r
"cashier confirmed from the terminal",\r
"cashier confirmed: not approved",\r
"At shift closing the cashier enters the counted amount; the expected amount and the difference are seen only at closing (Z). The supervisor with a PIN sees everything, including on the interim report (X).",\r
"A cashier named \\"{0}\\" already exists.",\r
"kasir TEXT",\r
"kasir_id INTEGER",\r
"Cashiers",\r
"Cashiers are entered in the \\"Cashiers\\" section: name, PIN and operator code. After that, the register asks who is working at startup, and the cashier's name appears on the receipt.",\r
"late",\r
"Later",\r
"The catalogue is empty.",\r
"The catalogue has been saved: {0}",\r
"Catalogue imported: {0}, {1} barcodes",\r
"Catalogue from the server",\r
"catalogue: —",\r
"catalogue: {0}",\r
"Catalogue: {0} items.",\r
"Category",\r
"Categories",\r
"KECAP",\r
"KEČAP",\r
"KEFIR",\r
"KEKS",\r
"KESA ZA",\r
"kg",\r
"KG",\r
"KIFL",\r
"Peanuts",\r
"KIKIRIKI",\r
"KILLA",\r
"kilogram (weighed)",\r
"KINDER",\r
"kiosk",\r
"Kiosk",\r
"Kiosk — Sunday mode",\r
"Kiosk — also works on Sundays and holidays",\r
"Kiosk (also works on Sundays and holidays)",\r
"Kiosk (also open on Sundays)",\r
"KISELO ML",\r
"KISJEL",\r
"KIT KAT",\r
"KITKAT",\r
"KLAMERIC",\r
"class",\r
"clicking a table opens its receipt on screen",\r
"The key is in an old format (RSA PRIVATE KEY). PKCS#8 (\\"BEGIN PRIVATE KEY\\") is required.",\r
"The key has been imported",\r
"The key is password-protected. An unprotected PKCS#8 is required.",\r
"The key does not belong to the imported certificate. Import a certificate (.pfx) that also contains the key, or remove the existing certificate first.",\r
"Signing key",\r
"kljuc=vrijednost; kljuc2=vrijednost2",\r
"The keys are readable. Nothing was moved.",\r
"The keys have been removed, but the file still cannot be read ({0}). The cash register must be restarted.",\r
"KNJAZ",\r
"Domestic guest book",\r
"Guest book",\r
"Foreign guest book",\r
"Accounting",\r
"Knjigovodstvo-sync",\r
"Ko",\r
"KOBASIC",\r
"The code {0} is an ENU registered with another program and must not be used.",\r
"The code {0} is an ENU registered with another program and must not be used. A new ENU for this cash register is required (Accounting → Cash registers and stores) or the choice \\"Another cash register at this location\\".",\r
"Code {0} is the code of item \\"{1}\\" and cannot be removed.",\r
"Code {0} is the code of item \\"{1}\\". It cannot be moved.",\r
"The code {stari} is also the barcode of the item \\"{drugi}\\". Delete it from this item?",\r
"ENU code (register)",\r
"ENU code from the list",\r
"The ENU code has been confirmed.",\r
"The ENU code was taken from the register list and belongs to a previously registered register. For this program the Tax Administration assigns a new ENU code (register registration), which is entered here and saved. Until then the register does not send receipts to the Tax Administration. If, by agreement with the Tax Administration, the register stays on this code, the supervisor confirms it with the button below and enters the last receipt number of the previous register (\\"Set…\\").",\r
"The ENU code is not registered, is not active or does not belong to this company.",\r
"The ENU code is not in the form ab123ab123 (given: \\"{0}\\").",\r
"The code is issued by the server administrator (valid for 48 hours; one code can be valid for all the company's registers, in which case the device name is appended after the code name). While the register is not paired, exchange goes only through the folder (Google Drive, section below).",\r
"Register code",\r
"Cash register code (ENU)",\r
"The cash register code (ENU) {0} was taken from the list of registers and belongs to a previously registered register. For this program the Tax Administration assigns a new ENU code (Settings → Fiscalization → ENU code). If, by agreement with the Tax Administration, the register keeps this code, the supervisor gives the confirmation (\\"Confirm ENU from the list…\\").",\r
"The maintainer code does not match the active maintainer.",\r
"Software maintainer code",\r
"Operator code",\r
"operator code at the Tax Administration",\r
"The operator code is not valid: 10 characters, in order 2 letters, 3 digits, 2 letters, 3 digits (e.g. ab123cd456). The field may be left empty.",\r
"The operator code is not in the form assigned by the Tax Administration (ab123cd456: two letters, three digits, two letters, three digits). If the cashier does not have one yet, leave the field empty.",\r
"The operator code applies to the receipts of a cashier who has no code of their own (Cashiers → Edit).",\r
"Operator code: {0} · PIN: {1}{2}",\r
"Business premises code",\r
"The business premises code does not belong to an active business unit.",\r
"At your domain registrar (e.g. domain.me) create a CNAME DNS record: name \\"meni\\" (or whichever you want) → value {0}.",\r
"A code with weight (scale label) is not an item barcode.",\r
"A code with weight (scale label) is not linked to an item.",\r
"The code is created in Accounting:",\r
"Software code",\r
"The software code does not match the active software (Settings → Fiscalization).",\r
"The code leads to:",\r
"The code leads to: {0}. Prints A4 with 4 A6 cards (stand or sticker).",\r
"Pairing code",\r
"The pairing code has expired or has already been used. A new code is needed (on the cash register: \\"Pair phone\\").",\r
"The pairing code is required (provided by the server administrator).",\r
"The pairing code is required (issued by the server administrator).",\r
"The pairing code is required (Accounting: Registers and stores → Add register and create code).",\r
"The pairing code is not from this cash register (or has been replaced by a new one).",\r
"pairing code, e.g. ABCD-EFGH-IJKL",\r
"The codes in the form are not valid and were not saved. {0}",\r
"Coefficient",\r
"KOKIC",\r
"KOKTEL",\r
"Qty",\r
"Kolašin",\r
"Quantity",\r
"Quantity",\r
"Quantity (kg)",\r
"Quantity (packs)",\r
"A quantity is required for at least one item.",\r
"A quantity is required for at least one item.",\r
"invalid quantity",\r
"The quantity is not valid.",\r
"Quantity of last item",\r
"The quantity of each item paid by this guest stays on screen for payment; the rest goes back to the table.",\r
"The quantity for \\"{0}\\" is too large ({1}, at most {2}).",\r
"The quantity for \\"{0}\\" must be from 0 to {1}.",\r
"The quantity for \\"{0}\\" is not valid.",\r
"quantity price",\r
"how many",\r
"Pcs",\r
"KOM",\r
"Komada u pakovanju",\r
"Command (\\\\r, \\\\n, \\\\x05)",\r
"Set-off",\r
"offset",\r
"KOMPLET",\r
"KONJAK",\r
"waiter",\r
"Waiter (and waiter's phone)",\r
"The waiter on the phone (Android, Register in \\"Waiter phone\\" mode) selects a table, enters an order and sends it; this register prints the order ticket, and the receipt is issued on this register. The waiter signs in with a name and PIN (Cashiers → role \\"Waiter\\"). The register computer needs a fixed address on the router (after the address changes, the phone is paired again). When first enabled, Windows asks for permission to access the private network; the permission is required.",\r
"The waiter is no longer active on the cash register.",\r
"Waiters: error",\r
"Contacts",\r
"Guest contacts require the right \\"Reception (guest personal data)\\".",\r
"Contacts for notifications and offers",\r
"Context \\"{0}\\": field not allowed or text too long.",\r
"The attached context must be an object {program, verzija, uloga, ekran}.",\r
"The barcode check digit is not valid. The entered digits need to be checked.",\r
"The check digit does not match. Verify the data against the document.",\r
"The package checksum does not match — the download was refused.",\r
"KONZERV",\r
"canned",\r
"Copy",\r
"Copy entire registration",\r
"Copying failed.",\r
"Copied",\r
"advance receipt correction",\r
"Advance receipt correction — advance used",\r
"corrective receipt of the advance receipt",\r
"The corrective receipt of the advance was not issued The cash register will issue it by itself on the next attempt.",\r
"CORRECTIVE RECEIPT OF AN ADVANCE RECEIPT",\r
"A corrective receipt of an advance receipt must list the receipts paid from that advance.",\r
"Corrective receipt of an advance receipt: the correction amount is not equal to the total of the amounts paid from the advance on the listed receipts.",\r
"The corrective receipt of the advance for the previous payment was not issued {1} when it is issued.",\r
"The corrective receipt was issued (IKOF {0}), but saving to the server failed. Retry the save.",\r
"A corrective receipt cannot be issued before the receipt it corrects.",\r
"The corrective receipt refers to its own IKOF instead of the IKOF of the original receipt.",\r
"User",\r
"Recipient of the lowest pension",\r
"The user has no right to change prices for {mjesto}.",\r
"Recipient of social protection",\r
"Used only for registration.",\r
"KOTANYI",\r
"Kotor",\r
"The end of the period is before the start.",\r
"short code",\r
"KREMA",\r
"The cryptographic signature is not valid. Check the certificate.",\r
"KROASAN",\r
"KROISAN",\r
"Through the bank app the register sends only payments; cancellation and refund are done in the bank app.",\r
"through the driver / print dialog",\r
"through a folder (Google Drive)",\r
"KRSTAC",\r
"krug INTEGER",\r
"server exchange cycle",\r
"KRUH",\r
"KRUSKOVAC",\r
"KRUŠKOVAC",\r
"Home and miscellaneous",\r
"House or apartment",\r
"Household chemicals",\r
"KITCHEN",\r
"KUKURUZ",\r
"KUMOVA",\r
"Customer",\r
"Customer (company) on the receipt",\r
"Customer (company) on the receipt or loyalty customer (phone)",\r
"Customer / cashier",\r
"The customer has {0} points and cannot spend {1}.",\r
"Customer on the receipt",\r
"The customer on the receipt must have both a PIB and a name.",\r
"Customer on the receipt: {0}{1}.",\r
"customer has no money",\r
"Customer has no money",\r
"customer did not pay",\r
"Customer did not pay",\r
"customer changed their mind",\r
"Customer changed their mind",\r
"The customer pays from their bank's app to the account",\r
"The customer pays {0} to account {1}, reference number {2}.\\n\\nHas the payment arrived (check in the bank's app)?",\r
"loyalty customer",\r
"Loyalty customer — phone",\r
"loyalty customer · {0}",\r
"Loyalty customer: {0}{1}{2}",\r
"kupac_adresa TEXT",\r
"kupac_grad TEXT",\r
"kupac_naziv TEXT",\r
"kupac_pib TEXT",\r
"Customer: the country must be a code of three capital letters, e.g. MNE, SRB (given: \\"{0}\\").",\r
"Customer: name is required.",\r
"Customer: unknown type of identification number \\"{0}\\".",\r
"Customer: PIB is required (for a natural person, JMBG or ID document number).",\r
"Customer: PIB is not valid (5–20 digits/letters, no spaces).",\r
"Loyalty customers:",\r
"KVASAC",\r
"Quota {0} must be a whole number ≥ 0 or null (unlimited).",\r
"Quotas are required.",\r
"label",\r
"LAK ZA",\r
"the chain does not start with the connection certificate",\r
"the certificate chain is not valid",\r
"LAV",\r
"LAVAZZA",\r
"LAY",\r
"LEDEN",\r
"LEDENI CAJ",\r
"LEDENI ČAJ",\r
"left",\r
"LEIBNIZ",\r
"LESNIK",\r
"LEŠNIK",\r
"beds",\r
"Beds",\r
"li",\r
"Person with severe sensory or physical disabilities",\r
"Person over 65 years of age",\r
"Licence",\r
"Licence {0} (package \\"{1}\\") does not include the Cash register module. A new shift cannot be opened; the licence can be extended by the issuer.",\r
"Licence {0} expires {1} (in {2} {3}).",\r
"Licence {0} expired {1} The program will keep working for {2} {3}. The licence needs to be extended.",\r
"Licence {0} expired {1} The program works only for reading and exporting data. The licence needs to be extended.",\r
"Licence {0} was revoked {1} The program works only for reading and exporting data.",\r
"Licence {0} has been suspended since {1} The program works only for reading and exporting data until the suspension is lifted.",\r
"Licence {0} is not valid.",\r
"Licence {0} is valid without an end date.",\r
"Licence {0} is valid until {1}",\r
"Pharmacist licence — {0}",\r
"The company licence is not valid. A new shift cannot be opened.",\r
"The licence is not valid: {0}",\r
"The licence is not an object.",\r
"Licence from the server",\r
"Licences of the libraries used",\r
"Personal hygiene",\r
"ID card",\r
"The guests' personal data is viewed and entered by reception.",\r
"The guests' personal data is viewed by a user with that authorisation.",\r
"Personal data",\r
"Personal data was deleted after the retention period expired.",\r
"Medicine",\r
"Prescription medicine is dispensed by a pharmacist. No pharmacist is signed in on the cash register.",\r
"The medicine is not on the FZO List of Medicines.",\r
"LIKER",\r
"LILY",\r
"LIMIT {0}",\r
"LIMONCELLO",\r
"LINDT",\r
"LION",\r
"LIQUEUR",\r
"LIZALIC",\r
"Doctor (facsimile)",\r
"LJESNIK",\r
"LJEŠNIK",\r
"Spicy",\r
"LOGEX",\r
"Logo",\r
"Logo · {0} × {1}",\r
"Company logo",\r
"The company's logo and emblem are set by Accounting (Settings → Company); the register takes them from the server and stores them, so they are visible without the internet too. The logo is printed above the receipt header (black and white on a thermal printer), and the emblem is in the register header and on the cashier sign-in.",\r
"The company's logo and emblem are set by Accounting (Settings → Company); a register paired with the server takes them automatically. Until then the receipt has no logo.",\r
"Logo on the receipt",\r
"Local IRIS server",\r
"Local IRIS server (the IRIS Server program on the computer in the shop): the address from the \\"Overview\\" screen of that program or from the network search; a pairing link from IRIS Admin (iris://upari…) can also be entered in the code field. The register accepts only the CA certificate of that server; nothing is written to Windows.",\r
"Local IRIS server (a computer in the shop): the address from the \\"Overview\\" screen of the IRIS Server program or from the network search. Instead of a code, a pairing link from IRIS Admin (iris://upari…) can be entered.",\r
"A local IRIS server (own CA certificate) is not yet supported on Android; the register on the phone works through api.iriscorvina.me.",\r
"local",\r
"breakage",\r
"LOPTA",\r
"LOREAL",\r
"lose",\r
"LOT",\r
"LOVOR",\r
"lower(COALESCE(p.kupac_naziv, '')) LIKE ?",\r
"LOZA",\r
"Password",\r
"The password received with the certificate.",\r
"Certificate password",\r
"LOZOVACA",\r
"LOZOVAČA",\r
"LUCKY",\r
"LUCKY STRIKE",\r
"Lupin",\r
"LYFT",\r
"MAC address or name of the paired terminal",\r
"MAESTRO",\r
"MAGUD COMPANY D.O.O.",\r
"May",\r
"May",\r
"MAJONEZ",\r
"MAKARON",\r
"Small hotel",\r
"MALIBU",\r
"Retail (store, kiosk)",\r
"shortage",\r
"Less",\r
"MARABU",\r
"MARAMIC",\r
"MARGARIN",\r
"MARINAD",\r
"store",\r
"Store",\r
"Store — does not work on Sundays and holidays",\r
"Store (does not work on Sundays and holidays)",\r
"Store (closed on Sundays)",\r
"A store does not operate on Sundays. A register in front of a shop that is registered as a kiosk also operates on Sundays.",\r
"store",\r
"MARLBOR",\r
"MARLBORO",\r
"MARMELAD",\r
"MARS",\r
"March",\r
"March",\r
"MARTINI",\r
"Marza {0}",\r
"MASKA",\r
"MASLAC",\r
"MASLINOVO",\r
"MASTERCARD",\r
"MAX FACTOR",\r
"max_zaliha REAL",\r
"MED",\r
"MEDENJ",\r
"MEDOVACA",\r
"MEDOVAČA",\r
"Subtotal",\r
"Molluscs",\r
"The device memory is full. Free up space (old backups in Documents/Kasa, unnecessary photos) and repeat the action. ({0})",\r
"manager",\r
"Manager",\r
"Menu",\r
"The menu has been published. This cash register receives the orders for this location.",\r
"The menu has not yet been published from any register.",\r
"The menu has not been published yet.",\r
"The menu has not been published yet. The QR menu is enabled on the outlet's main cash register.",\r
"The menu has not been published. The QR menu is turned on in settings.",\r
"Menu: {0} {1}, {2} items",\r
"MENTOL",\r
"MENTOS",\r
"MERLOT",\r
"MESO",\r
"Meat and meat products",\r
"METAXA",\r
"METLA",\r
"Mettler Toledo 8217",\r
"MICRO",\r
"MILK",\r
"MILKA",\r
"MILKY WAY",\r
"milostDana: 0–90.",\r
"MINERALNA",\r
"minmax(46px, 1fr)",\r
"minmax(92px, max-content) repeat({0}, {1})",\r
"minus",\r
"Measure",\r
"Month",\r
"Monthly report due by (day of month)",\r
"Mixed",\r
"places",\r
"Places and tables",\r
"place",\r
"Place",\r
"Place of visa issue",\r
"place of birth",\r
"Place of birth",\r
"Place of entry",\r
"mjesto_id INTEGER",\r
"MKB-10",\r
"ML",\r
"Persons younger than this many years do not pay the tax.",\r
"Persons younger than this many years pay a reduced amount.",\r
"MLEKO",\r
"Dairy products",\r
"Milk",\r
"MLIJEKO",\r
"Milk and dairy products",\r
"MNE",\r
"Modules: at least one of {0}.",\r
"MOET",\r
"MOËT",\r
"MOGYI",\r
"Moj disk",\r
"My changes today",\r
"Mojkovac",\r
"MONSTER",\r
"MONTE CARLO",\r
"MORTADEL",\r
"Motel",\r
"Between {0} and {1} points can be spent.",\r
"MOZZAR",\r
"Network (LAN / Wi-Fi): IP:port",\r
"network printer",\r
"Network printer (IP, port 9100)",\r
"MULTIVIT",\r
"male",\r
"MUSLI",\r
"My Drive",\r
"On Android, the new version is installed by downloading the APK (the address is in the check: urlAndroid).",\r
"On Android, restoring a previous version is not possible without deleting data, because the system does not allow installing an older version over a newer one. The fix is published as a new version.",\r
"The advance receipt has {0} left, and the correction is {1}.",\r
"The advance receipt has {0} available, and {1} is requested.",\r
"Voucher {0} has {1} € left. Payment of {2} € is not possible.",\r
"{0} remains on the voucher.",\r
"Put on hold",\r
"Pending",\r
"On hold {0}. They must be paid or deleted.",\r
"What the labels are printed on",\r
"There is not enough disk space for the update (free {0} MB, at least {1} MB needed). Nothing was changed.",\r
"There is not enough disk space for the update. Nothing was changed.",\r
"Only a summary receipt and a corrective receipt of an advance receipt refer to other receipts.",\r
"The receipt that was being rung up when the register was shut down has been restored to the screen. The receipt must be paid or deleted.{1}",\r
"on screen",\r
"Part of the bill is on screen for payment.",\r
"There is another receipt on the screen. Put it on hold and return the selected one?",\r
"Another receipt is open on screen. Put it on hold and load the pro forma?",\r
"Another receipt is open on the screen. Put it on hold and restore the deleted receipt?",\r
"On screen are the first",\r
"On screen are the first {0} items; the printout and the table contain all of them.",\r
"There is a receipt without a table on screen. Put it on table {0}?",\r
"A table receipt is on screen. It needs to be returned to the table or charged, and then the pro forma loaded.",\r
"A receipt is in progress on the screen (items: {0}). It stays on the screen and goes into the next shift.",\r
"On screen is table",\r
"There is no table receipt on screen.",\r
"{n} items on the invoice have no barcode.",\r
"On fiscal receipts",\r
"On the main register: Settings → QR menu → Address in QR code: \\"Own domain\\", then print the table codes again.",\r
"on the cash register",\r
"The register has",\r
"weighed",\r
"There is no cashier \\"{0}\\" on this cash register.",\r
"at this location",\r
"A shift with receipts is open on this device, so choosing a register is not possible now. Order: \\"Demo register\\", shift closing (Z), then choose the register (Settings → Cash register).",\r
"The folder {0} was found on this device. It must be entered in the \\"Folder\\" field and saved.",\r
"This device has no way to connect to the terminal.",\r
"On this device unreadable keys cannot be discarded from the program.",\r
"The scale is not available on this device.",\r
"No serial port found on the computer (or the shell does not support port selection — a new Setup is required).",\r
"The receipt contains an item that is no longer in the catalogue. The item must be removed from the receipt.{0}",\r
"The receipt does not contain the codes it was issued with (the QR address is incomplete).",\r
"There are no items to pay on the room bill.",\r
"On the receipt: {0}. The voucher is printed after payment.",\r
"prescription-only",\r
"The prescription is marked \\"Do not substitute!\\".",\r
"Waiting to be sent to the IRIS CORVINA server: {0} file(s) (closings, prices). A connection to the server is needed (\\"Exchange now\\").",\r
"To room",\r
"To room — guest's signature",\r
"to room {0}",\r
"To room / deferred",\r
"To table",\r
"To the table without an order ticket",\r
"at the table",\r
"The table has items that have not been sent to the kitchen / bar. Save them without an order ticket?",\r
"The table has a smaller quantity of that item than requested. The table needs to be refreshed.",\r
"On the table:",\r
"On the table: {0}",\r
"On the phone the folder is used only for the transitional mode.",\r
"On the phone: Register →",\r
"At {0} the terminal approved {1}{2}, but no receipt was issued. The receipt is issued with that payment, without a new charge.",\r
"There is nothing on the scale.",\r
"online",\r
"Connected · up to date",\r
"Purch. price",\r
"Purch. value",\r
"Purchase",\r
"Method",\r
"Method",\r
"How the tax is shown on the checkout receipt.",\r
"Payment method",\r
"Type of business",\r
"Company's business mode (optional)",\r
"Refund method",\r
"Registration method",\r
"the receipt draft is too large",\r
"drafts",\r
"Parent group",\r
"Find",\r
"Superior",\r
"guest arrival notices by day and table",\r
"NAJLEPŠE",\r
"Minimum points to spend",\r
"minimum nights",\r
"Minimum nights",\r
"A minimum of {0} points is spent.",\r
"Best-selling items (by amount)",\r
"Maximum stock",\r
"The maximum stock cannot be less than zero.",\r
"Maximum debt per room",\r
"Maximum debt per room (EUR)",\r
"Largest manual discounts (control — without promotions and loyalty)",\r
"At most {0} items in one order.",\r
"Fee",\r
"Pharmacy fee per prescription charged to the FZO (€)",\r
"Fee on the receipt",\r
"order",\r
"Voucher",\r
"NALOG",\r
"The order \\"{0}\\" is not supported in this version of the program ({1} {2}).",\r
"The \\"poruka\\" order has no text.",\r
"The order \\"reset-pin\\" has no person role (owner/admin/sef-kase or kasir). The order was not executed.",\r
"Order ticket {0} {1}{2}",\r
"Order ticket {0} has been sent ({1} {2}). Table {3} is on hold.",\r
"Order no.",\r
"Order to the kitchen / bar for items not yet sent",\r
"The order ticket was not printed; the items have not been marked as sent. The printer needs to be checked.",\r
"The order ticket was not printed.",\r
"order ticket not sent",\r
"The order from the phone ({0}, table {1}) was not printed. Check the printer and send the order again.",\r
"orders and \\"ready\\"",\r
"Orders from the register and the waiters' phones. \\"Done\\" tells the waiter it is ready. Tablet in the kitchen: the Android app in \\"Kitchen\\" mode (paired like a waiter's phone).",\r
"Dedicated FZO application (the prescription is filled in the Fund's application)",\r
"naplaceno REAL",\r
"Collected by summary receipts",\r
"Payment — room {0}",\r
"Payment — multiple payment methods",\r
"\\"Charge to room\\" payment",\r
"Cash payment",\r
"Payment is possible",\r
"The payment has been released.",\r
"Payment is in progress at register {0}.",\r
"The payment has been entered.",\r
"Card payment",\r
"Card payment — manual",\r
"Card payment on an Android phone (Tap to Phone): the register sends the amount to the bank app and reads the result. The register does not process cards. Field names depend on the bank (NLB Smart POS, OTP mPOS, Hipotekarna MojPOS) and are entered per the bank specification. Package \\"proba\\" = simulated bank app for testing. Terminal type must be \\"Bank app on this device\\".",\r
"Card payment on the phone (SoftPOS) works on an Android device.",\r
"Payment via terminal is not available.",\r
"Room bill payment",\r
"Phone payment (SoftPOS) works on an Android device.",\r
"Payment in the bank app: the customer taps a card or phone.",\r
"Payment in progress at register {0}",\r
"Charge",\r
"Charge in cash",\r
"Charge and issue receipt",\r
"Charge all nights",\r
"NAPOLITAN",\r
"Note",\r
"Note — {0}",\r
"A note is required.",\r
"Note for the kitchen / bar",\r
"The note must be text (it may be empty).",\r
"napomena TEXT",\r
"Note: {0}",\r
"Create a NEW code for the selected table (the old QR stops working — e.g. if it is being misused)",\r
"Create property and rooms",\r
"Make a database backup",\r
"Make a backup to the folder now",\r
"Advanced: server address, local IRIS server in the shop",\r
"Forward ›",\r
"Discard changes",\r
"Order \\"{0}\\" is open.",\r
"A delivery order is a \\"table\\" with the channel name and number: enter items, \\"Send order\\" to the kitchen, pay when the courier picks it up. In reports it is seen by name.",\r
"The guest's order for table \\"{0}\\" was rejected: the table is not entered on the register.",\r
"The order is empty.",\r
"The order was not received: {0}. Call the waiter.",\r
"Delivery order",\r
"Guest orders (last 6 hours)",\r
"Orders for this place are received by another cash register. Reception on this register: QR menu → Publish menu now.",\r
"Orders that did not reach the register:",\r
"Orders that did not reach the register: {0}. They stay on the phone and are sent after login. Log out?",\r
"The order was cancelled by the waiter.",\r
"Our letters on the printer",\r
"Title",\r
"naSobu.limit",\r
"naSobu.potpis",\r
"naSobu.ukljuceno",\r
"Continue bulk change",\r
"Continue editing",\r
"nav",\r
"Back",\r
"Back to items",\r
"name",\r
"Name",\r
"Item name",\r
"Item name is required.",\r
"Company name is required.",\r
"The group name can have at most 60 characters.",\r
"Group name by language",\r
"Name and description by language (* required; empty = base name / English)",\r
"Name or INN (at least 2 letters)",\r
"Item name or code",\r
"The name is too long (maximum 120 characters).",\r
"name of the new group",\r
"The name of the new group is required.",\r
"Property name",\r
"Property name, municipality and number of rooms by type. Rooms can be changed later in Settings.",\r
"Period name",\r
"Seller name",\r
"The seller name is required.",\r
"Device name",\r
"naziv_n LIKE ?",\r
"naziv_n TEXT",\r
"Names in languages, descriptions, allergens and images are entered in the Cash register (📝 Menu content), Manager and Accounting — the same content on the server. Prices are always the prices of this cash register.",\r
"no",\r
"No",\r
"no — waiter only",\r
"No (cash)",\r
"Do not allow",\r
"Do not show on the guest menu (the register still sells it)",\r
"not for sale",\r
"No longer sold",\r
"does not enter turnover and is not reported to the Tax Administration.",\r
"are not taken into account",\r
"Do not substitute!",\r
"inactive",\r
"The unreadable file tajne.json cannot be moved aside ({0}).",\r
"The unreadable keys have been moved. The certificate must be imported again.",\r
"unreadable file name",\r
"NECTAR",\r
"Sun",\r
"Sunday",\r
"Sunday",\r
"SUNDAY",\r
"SUNDAY · store",\r
"No-show on the day after arrival at (hour)",\r
"No-show: hour from 0 to 23",\r
"nedolazak.doSati",\r
"Missing",\r
"The number of the issued receipt is missing.",\r
"Missing: {0}",\r
"Missing: {0}.",\r
"Invalid exchange file name: {0}",\r
"disallowed file name: {0}",\r
"neg",\r
"Invalid payment amount ({0}).",\r
"Invalid key of the update record.",\r
"Invalid record.",\r
"Invalid quantity for: {0}",\r
"Unclear result",\r
"Unclear result on the terminal ({0}, {1}) — the terminal must be checked",\r
"unclear results {0}",\r
"unclear (timeout)",\r
"NEKTAR",\r
"none",\r
"none (card without terminal)",\r
"none (created at the first receipt)",\r
"no address on the local network",\r
"There are no items without a barcode. Search for an item by name or code.",\r
"There are no items to save.",\r
"There are no items for this selection.",\r
"No items for this search.",\r
"There are no items to print.",\r
"No item with that barcode",\r
"no barcode",\r
"no price list in the folder",\r
"Not available today — guest menu",\r
"There are no deposits or withdrawals in this shift.",\r
"No arrivals today.",\r
"There is not enough free memory to open the database (the database is {0} MB). Close other programs or restart the computer, then start the register. Data were not changed.",\r
"File {0} does not exist (neither on the server nor among the register files).",\r
"There are no guests in the property.",\r
"There are no groups — groups come from the item code list (Accounting).",\r
"There is no valid checksum (SHA-256) — the package is not accepted.",\r
"No price or item changes.",\r
"No register for \\" \\".",\r
"No register for \\"{0}\\".",\r
"There is no key or certificate for signing.",\r
"There is no loyalty customer with that number. Customers are entered in Accounting (Register price list → Customers).",\r
"No orders.",\r
"The table has no name.",\r
"No new prices for labels.",\r
"There is no newer version.",\r
"There is no newer version. The register has the latest version ( ).",\r
"There is no newer version. The register has the latest version ({0}).",\r
"No property.",\r
"No response from the local server.",\r
"No departures today.",\r
"no update description",\r
"No goods write-offs in this period.",\r
"No open shift.",\r
"There are no open pro formas.",\r
"There is no data package with prices.",\r
"no price package",\r
"The printer is out of paper.",\r
"There is no package data. The update must be checked first.",\r
"No data for the period.",\r
"There is no data to print (or it is too large).",\r
"No data.",\r
"There are no messages waiting to be sent.",\r
"There are no messages to send. Previously rejected: {0}.",\r
"No messages. Support replies in the program.",\r
"No linked barcodes.",\r
"There are no pro formas for this search.",\r
"There are no pro formas.",\r
"There is no private key for signing.",\r
"No sales in this period.",\r
"No vouchers have been sold.",\r
"No receipts",\r
"No receipts {0}.",\r
"No receipts on hold.",\r
"No receipts in this period.",\r
"No receipts in the period.",\r
"No accounts for this search.",\r
"No receipts to print.",\r
"No earlier customer with that PIB or name.",\r
"No earlier customers.",\r
"No reservations for this selection.",\r
"No results",\r
"There is no certificate for signing.",\r
"No item code.",\r
"There is no vacant room of this type in that period.",\r
"No vacant room for that period.",\r
"No rooms to clean.",\r
"There are no items to write off.",\r
"No items.",\r
"No customer display page.",\r
"No such receipts in this period.",\r
"No terminal transactions.",\r
"No entries.",\r
"There are no paired Bluetooth devices. The printer is paired in the phone settings.",\r
"No cashiers entered.",\r
"No cashiers entered. An entered cashier logs in with a PIN and their name appears on the receipt.",\r
"No payments.",\r
"No warnings.",\r
"No connection",\r
"No connection to the fiscal service.",\r
"No connection to the register (the shop's Wi-Fi network).",\r
"No connection to the Tax Administration. Sending continues when the connection is established.",\r
"no connection to the server",\r
"No connection to the server ({0}).",\r
"No connection to the server.",\r
"No connection to the server. {0} requires a connection. Nothing was issued.",\r
"No connection to the server. Paying a room bill requires a connection.",\r
"No connection to the server. Charging to a room is not available.",\r
"No connection to the server. An advance refund requires a connection.",\r
"No connection to the server. Cancelling a room charge receipt requires a connection (summary receipt check).",\r
"No requests from this cash register.",\r
"No scheduled prices.",\r
"none, everything has been sent",\r
"optional",\r
"optional (required for \\"Other\\")",\r
"optional (delivery deadline, payment method…)",\r
"Optional; required for the reason \\"Other\\".",\r
"unhandled rejection",\r
"odd",\r
"not supported",\r
"not sent",\r
"Unknown barcode {barkod}",\r
"Unknown result code: {0}",\r
"Unknown payment method: \\"{0}\\" (possible: Cash, Card, Bank transfer, Voucher, Instant).",\r
"Unknown payment method: {0}",\r
"Unknown refund method: {0}",\r
"Unknown order.",\r
"Unknown tourist tax display: {0}",\r
"unknown reason",\r
"Unknown request.",\r
"unknown error",\r
"Unknown error",\r
"Unknown deposit operation: \\"{0}\\".",\r
"Unknown action.",\r
"Unknown licence version.",\r
"Unknown type of cash register: \\"{0}\\".",\r
"Unknown type of fee: \\"{0}\\" (possible: PACK, COMMISSION, OTHER).",\r
"Unknown type of subsequent submission: \\"{0}\\".",\r
"Unknown request type.",\r
"Unread support replies",\r
"Non-working",\r
"NESCAFE",\r
"NESKAF",\r
"NESQUIK",\r
"NESTLE",\r
"Net quantity",\r
"The net quantity must be greater than zero.",\r
"Net quantity, pieces per pack and maximum stock are entered as a number.",\r
"neto REAL",\r
"neto_jm TEXT",\r
"uncaught error",\r
"Unusable",\r
"🆕 New prices ({0})",\r
"NEXT",\r
"NFC",\r
"NFD",\r
"not",\r
"is not a fiscal receipt",\r
"No line has been selected for return.",\r
"Not yet",\r
"Not copied",\r
"A voucher code cannot be generated. Please try again.",\r
"NOT connected (orders are not received)",\r
"Not paid:",\r
"no receipt was deleted.",\r
"Not approved",\r
"did not pay · receipt no. {0}",\r
"The printer location is not set (Settings → Add-ons).",\r
"not sent",\r
"Not connected to the server",\r
"is not known to this register (a voucher from another register may not have arrived yet through the server exchange).",\r
"it did not start in {0} launches in a row",\r
"not ready",\r
"Not arrived",\r
"not in the catalogue",\r
"No serial port entered (e.g. COM3).",\r
"No bank app entered for phone payment (Settings → Register devices → SoftPOS).",\r
"not entered",\r
"The fiscalization certificate (.pfx) has not been imported. The cash register works with a test key.",\r
"No item matches the entered name or code.",\r
"No item selected.",\r
"No prescription has been added.",\r
"No phone is paired.",\r
"no item was removed from an issued receipt.",\r
"None of the items from this pro forma exist in the catalogue any more. The pro forma cannot be loaded.",\r
"None of the items from that receipt exist in the catalogue any more ({0}). The receipt was not returned and remains in the deleted records.",\r
"None of the items from that receipt exist in the catalogue any more ({0}). Returning it to the screen is not possible; the record remains in the records.",\r
"No item's price would change.",\r
"NIKOTIN",\r
"NIKSIC",\r
"NIKŠIC",\r
"Nikšić",\r
"none",\r
"Nothing was changed.",\r
"did not show up",\r
"NIVEA",\r
"German",\r
"night",\r
"Overnight stays",\r
"Overnight stay — {0}",\r
"Overnight stay and surcharges with accommodation that are not food.",\r
"nights",\r
"Nights",\r
"NONCASH",\r
"noopener noreferrer",\r
"carries the expiry date: expired goods are sold only with the supervisor's approval (with a warning), and a warning is shown for goods close to expiry.",\r
"Reservation holder",\r
"new item",\r
"New item",\r
"new price list from Accounting ({0} items, {1})",\r
"new price list from {0} ({1} items)",\r
"A new table code has been created. The previous QR code is no longer valid.",\r
"new reply",\r
"New reply from IRIS CORVINA support (More → Support)",\r
"new support reply:",\r
"new support reply: {0}",\r
"New pro forma",\r
"New table QR code",\r
"New request to the publisher",\r
"nova",\r
"New",\r
"NOVA",\r
"new price (€)",\r
"The new price would be below €0.01 or above {0} € (items: {1}). Prices are not changed.",\r
"The new price must be greater than zero.",\r
"New group",\r
"New charge",\r
"New charge of {0} on the terminal (the previously approved one was not used)",\r
"New message to support",\r
"New reservation",\r
"New reservation: select the first and last night in the room's row.",\r
"New shift",\r
"new round",\r
"New version {0}",\r
"The new version is downloaded automatically while the register is idle and applied at the next start of the program. While a shift is open, restarting is not offered.",\r
"The new version is downloaded automatically only over Wi-Fi; on mobile data, the download is started with the \\"Download now\\" button. Installation starts only on \\"Install now\\".",\r
"Money taken out of the register (handover of daily takings, payment from the register).{0}",\r
"Money put into the register outside of sales (small change, top-up).",\r
"New prices",\r
"The new prices are already in the list.",\r
"new prices for labels:",\r
"new prices for labels: {0}",\r
"new prices for labels: {0} (More → Price labels)",\r
"November",\r
"November",\r
"New guest",\r
"New cashier",\r
"New property",\r
"New entry",\r
"New prices from the office for labels:",\r
"New prices from the office for labels: {0} (the \\"New prices\\" button).",\r
"new",\r
"New",\r
"e.g. 0.5",\r
"e.g. 067 123 456",\r
"e.g. 1, 2, 3, 4, Bar, Terrace 1",\r
"e.g. 10",\r
"e.g. 10 or -5",\r
"e.g. 1001, 1002, 4475",\r
"e.g. 101-110, 201",\r
"e.g. 19:30",\r
"e.g. 24",\r
"e.g. 250 g",\r
"e.g. 4*",\r
"e.g. no ice, well done",\r
"e.g. COCA COLA 0.5L",\r
"e.g. supplier, batch, what happened",\r
"e.g. G:\\\\My Drive\\\\Knjigovodstvo-sync",\r
"e.g. guest cancelled by phone",\r
"e.g. The kitchen is open until 11 pm",\r
"e.g. me.banka.pos",\r
"e.g. me.banka.softpos or proba",\r
"e.g. meni.vasrestoran.me",\r
"e.g. MNE",\r
"e.g. faulty goods",\r
"e.g. After a cancellation the receipt remains in \\"recent receipts\\" without a label…",\r
"e.g. handover of daily takings",\r
"e.g. small change",\r
"e.g. will be back in 10 min",\r
"NRp",\r
"NT",\r
"Offered when entering a guest; one basis per row.",\r
"NUDLE",\r
"NUTELLA",\r
"NUTRINO",\r
"About the program",\r
"Both dates are required.",\r
"A reason for deleting the receipt is required.",\r
"A reason for the write-off is required.",\r
"Publisher notices (since the cash register was started)",\r
"Outlet",\r
"The property has been added.",\r
"The property has been saved.",\r
"The property is in use",\r
"The property has been entered.",\r
"The property has not been entered yet. Entry is done by a user with settings authorisation.",\r
"The outlet has no rooms.",\r
"The property has no rooms. Rooms are entered in Settings.",\r
"The property has no room types. Types are entered in Settings.",\r
"Form",\r
"A renewable prescription is dispensed at most 3 times.",\r
"Calculation",\r
"Calculated",\r
"deleted",\r
"Deleted receipt",\r
"Receipt deleted before payment ({0})",\r
"Deleted receipt worth at least (€)",\r
"deleted from hold",\r
"Deleted from hold",\r
"Deleted before payment ({0}{1})",\r
"The deleted receipt is unreadable.",\r
"Deleted receipts",\r
"Deleted receipts — older",\r
"Deleted receipts, write-off of goods, price labels",\r
"Deleted.",\r
"Delete guest {0} {1}?",\r
"Delete this entry?",\r
"Delete",\r
"Delete digit",\r
"Delete receipt",\r
"Delete held receipt",\r
"Delete the old code from this item",\r
"VAT-registered",\r
"Expected in the register: {0}",\r
"Clear",\r
"Clear list",\r
"Read document (machine-readable zone)",\r
"Read weight",\r
"A scale label (code with weight) was scanned, not the item's barcode. A weighed item is entered with the unit kilogram.",\r
"A scale label was read (a code with weight). Such a code is not linked to an item.",\r
"The scanned code is not a QR for pairing with the register (on the register: Settings → Waiter phones → \\"Pair phone\\").",\r
"Scan a barcode or enter an item code…",\r
"Scan a barcode with the camera",\r
"of",\r
"From",\r
"of {0}",\r
"from {0} —",\r
"from {0} ({1})",\r
"from {0} ({1}){2}{3}",\r
"from {0}, {1}.",\r
"{0} EUR of the advance is available. The refund is not possible.",\r
"{0} of the advance is available. A refund of {1} is not possible.",\r
"From when the room is ready for the guest.",\r
"The registration deadline runs from this time.",\r
"of which via terminal",\r
"Source",\r
"Discard",\r
"Discard changes",\r
"Discard unreadable keys…",\r
"Discarding unreadable keys",\r
"denied",\r
"Deducted",\r
"Declined (test)",\r
"Declined (test).",\r
"Promise rejected without a message",\r
"The response of the fiscal service cannot be read.",\r
"Publisher's reply",\r
"Publisher reply: {1}",\r
"The reply has been sent.",\r
"The register's response is unreadable (code {0}).",\r
"reply to support",\r
"The response from the Tax Administration cannot be read.",\r
"The server response is too large.",\r
"The server response is not valid (compression).",\r
"The terminal response is not readable.",\r
"The terminal response is not clear. The result must be checked on the terminal.",\r
"Reply in this thread",\r
"Replies",\r
"Checkout",\r
"Deregistration with the police",\r
"Deregistration with the police {0}",\r
"odjava.vrijemeDolaska",\r
"odjava.vrijemeOdlaska",\r
"Check out",\r
"Check out with debt",\r
"Check out the guest? The room changes to the \\"to be cleaned\\" state.",\r
"Checked out",\r
"Deregistered with the police",\r
"Deregistered with the tourist organisation",\r
"Mark the guests' deregistration with the police in the Guests tab.",\r
"Setting a receipt aside and charging the next customer",\r
"Departures",\r
"Departure",\r
"departure {0}",\r
"Departure today",\r
"Departure by",\r
"Departure by (hour)",\r
"Departure is planned for {0} Shorten the stay to {1}?",\r
"Departure must be after arrival.",\r
"Departure: {0}",\r
"Held receipts have not been paid. Payment is possible after returning them to the screen.",\r
"Held",\r
"Deferred payment (ORDER) cannot be combined with another payment method on the same receipt.",\r
"Deferred payment is not combined with another payment method.",\r
"approved",\r
"approved",\r
"Approval",\r
"Manager approval",\r
"Approved — issue receipt",\r
"Approved (test)",\r
"Approved (test).",\r
"Approved {0}{1}{2}",\r
"Approved without receipt",\r
"approved without receipt {0}",\r
"It is approved",\r
"Approved on the terminal without receipt ({0}{1})",\r
"Approved on the terminal without receipt: {0}{1}",\r
"Approved.",\r
"Approve",\r
"Adults",\r
"Set by the municipality, from 0.10 to 1.00 EUR.",\r
"Disconnecting the phone",\r
"Disconnect",\r
"Print a label with the new price (and price per kg / l)?",\r
"Print a label for the new item?",\r
"Cancel",\r
"off",\r
"offline",\r
"offline: {0}",\r
"offlineDana: 1–365.",\r
"ok",\r
"environment",\r
"Environment",\r
"environment {0}",\r
"The environment is PRODUCTION and the register sends receipts to the Tax Administration. The receipts are fiscal.",\r
"October",\r
"October",\r
"ol",\r
"OL",\r
"OLOVK",\r
"OMEKSIV",\r
"OMEKŠIV",\r
"on",\r
"online",\r
"Operator",\r
"operater_kod TEXT",\r
"Description",\r
"Description (optional), e.g. customer name. The receipt waits until it is returned to the screen.",\r
"description (ingredients, weight…)",\r
"the update description is not readable",\r
"the update description is incomplete",\r
"The error description is required.",\r
"Description on the receipt",\r
"A problem description is required.",\r
"Description of the request and the reason (e.g. one more cash register in the Bečići store from 1 December)…",\r
"The request description is required.",\r
"A narcotic drug is dispensed only on a special prescription (PRp).",\r
"Taxable",\r
"Taxable supplies at the 0% rate (Art. 25 of the VAT Act) (takings by item basis + invoices with Art. 25 basis + manual)",\r
"Taxable supplies at the 15% rate — base (takings + issued invoices)",\r
"Taxable supplies at the 21% rate — base (takings + issued invoices)",\r
"Taxable supplies at the 7% rate — base (takings + issued invoices)",\r
"standard",\r
"general price",\r
"General price",\r
"company's general price (not entered for this location)",\r
"The general price applies at {n} locations that have no price of their own. Change the general price?",\r
"general prices",\r
"general prices (demo register)",\r
"Generic format",\r
"Municipality",\r
"Municipality",\r
"The general price can be changed by the administrator and the director.",\r
"optgroup",\r
"option",\r
"OPTIONS",\r
"ORAL",\r
"Tree nuts",\r
"ORBIT",\r
"OREO",\r
"org_stavka INTEGER",\r
"authority that issued the document",\r
"ORp",\r
"Exempt from co-payment",\r
"Exempt under an international agreement",\r
"Exempt up to",\r
"Exempt up to (years)",\r
"Exempt supplies — deliveries (Art. 26 and 27) (takings by item basis + invoices with that basis + manual)",\r
"Exempted",\r
"Release payment",\r
"Exempt",\r
"Exempt",\r
"Basis",\r
"Basis for exemption, if any.",\r
"osnov0 TEXT",\r
"osnov0_clan TEXT",\r
"Exemption bases",\r
"Tax base",\r
"Base price per night (EUR incl. VAT)",\r
"Basic groceries",\r
"Basic beds",\r
"person",\r
"Person",\r
"The person \\"{0}\\" is a cashier on the register, but the order specifies the role \\"{1}\\". The order was not executed.",\r
"The person \\"{0}\\" is a supervisor on the register, but the order specifies the role \\"{1}\\". The order was not executed.",\r
"Person-nights",\r
"persons",\r
"The partner's debt of {0} EUR remains for invoicing. Check out the guest?",\r
"other",\r
"Other",\r
"remainder",\r
"Remainder",\r
"remaining {0}",\r
"remainder of the payment",\r
"the rest of the",\r
"Keep enabled",\r
"damaged",\r
"Damaged (breakage, fault, spoiled)",\r
"OSVEZIV",\r
"Refresh",\r
"Refresh catalogue",\r
"OSVJEŽIV",\r
"OTHER",\r
"The CA fingerprint reported by the server is not in its certificate. The connection was not established.",\r
"Local server CA fingerprint",\r
"the CA fingerprint is not valid",\r
"The certificate fingerprint from the pairing link does not match the certificate of the server at address {0}. The connection was not established.",\r
"The fingerprints match",\r
"cancelled",\r
"Cancellation",\r
"CANCELLED",\r
"The cancellation was sent to the kitchen / bar.",\r
"Reservation cancellation",\r
"otkaz.stopaNaknade",\r
"otkaz.zadrzaniAvans",\r
"Cancelled",\r
"cancelled",\r
"cancelled",\r
"cancelled ({0}) / refund ({1})",\r
"It is cancelled",\r
"cancelled on the terminal (manually)",\r
"Cancel",\r
"Cancel on the terminal",\r
"Cancel reservation",\r
"Cancellation",\r
"Cancellation on the terminal",\r
"Cancellation on the terminal failed ({0}): {1}{2}",\r
"Cancellation failed",\r
"Payment cancellation",\r
"Payment cancellation on the terminal",\r
"Cancelling payment on the terminal…",\r
"write-off",\r
"Write-off",\r
"Write-off {0}",\r
"The write-off has been recorded: {0}, value {1}. The document is not a fiscal receipt.",\r
"Goods write-off",\r
"Goods write-off no.",\r
"Goods write-off no. {0}",\r
"goods write-off:",\r
"goods write-off: {0} docs, {1} (not included in the total)",\r
"Written-off goods (expired, damaged…), value at catalogue prices. Not turnover and not for sale.",\r
"Written-off goods by item",\r
"written off",\r
"Write-offs",\r
"Write off",\r
"Write off item",\r
"Opening the database…",\r
"Opening the drawer without a receipt",\r
"The opening has been logged. The drawer is not set up to open from the register (Settings → Extras).",\r
"open",\r
"open",\r
"Opened",\r
"A new shift was opened without an opening float (#{0}). Cash found in the drawer is entered as a deposit (Shift → DEPOSIT).",\r
"Open since",\r
"open",\r
"Open",\r
"Open",\r
"Open drawer",\r
"Open data folder",\r
"Open order",\r
"Open a new shift…",\r
"Open receipt ›",\r
"Open the receipt for cancellation",\r
"Open shift",\r
"Open the cancellation ›",\r
"Open that receipt ›",\r
"OUZO",\r
"This year",\r
"This cash register installation has no update from within the program. A newer Setup must be installed.",\r
"This cash register installation cannot restart from within the program. The program must be closed and opened again.",\r
"this register",\r
"This register",\r
"This cash register is entered as a store, and today is {0}. Stores do not operate on Sundays and holidays; on those days receipts are issued from a register registered as a kiosk (Art. 35b).\\n\\nIf this register is registered as a kiosk, the register type needs to be corrected (Settings → Cash register).",\r
"This register is already selected. Prices are being loaded again.",\r
"this register",\r
"This action is not allowed on this device.",\r
"This version of the program ({0}) is no longer supported on the server. An update to version {1} or newer is required — writing to the server is waiting for the update.",\r
"this one",\r
"This ENU is registered with another program. A new ENU for this cash register, registered for this program, is required.",\r
"This software code is registered with another program. Enter the software code of this program (it is assigned when the program is registered on the Tax Administration portal).",\r
"This month",\r
"This print mode does not exist on Windows (Bluetooth printing is for Android).",\r
"This signed order has already been executed on this register — a repeated order is not executed; issue a new one.",\r
"This device has no random number generator (WebCrypto).",\r
"This device has no cryptography (WebCrypto).",\r
"This device has no cryptography for signing (WebCrypto).",\r
"This device has no cryptography for signing receipts (WebCrypto).",\r
"here",\r
"Only the last issued receipt can be voided here, within 30 minutes of issue. An older receipt is cancelled in the receipt overview (Receipts → receipt → \\"Cancel receipt…\\").",\r
"These items are no longer in the catalogue: {0}.",\r
"This is a corrective receipt. Returning goods from it is not possible.",\r
"This is a cancellation receipt and cannot be cancelled.",\r
"This is a cancellation of a summary receipt and cannot be cancelled.",\r
"This is not a fiscal receipt.",\r
"This customer has already paid {0} in cash at this register today. With this receipt ({1}) that makes {2}.\\n\\nThe law also does not allow linked cash payments that together amount to 10,000 € or more (Art. 65 para. 2). If these receipts are part of the same deal, payment goes by card or bank transfer.",\r
"OVSEN",\r
"The marked items stay on the menu with the label \\"currently unavailable\\" and guests cannot order them. The cash register still sells them.",\r
"marked",\r
"Mark the guest as a no-show? The room is released.",\r
"Code",\r
"Exemption code of the tax item",\r
"Register label",\r
"The cash register code (register number in the business premises) is required.",\r
"Code of the business premises the property belongs to; empty = not linked.",\r
"Room label",\r
"The version label is not valid — the package is not accepted.",\r
"Menu labels",\r
"Room codes",\r
"OZUJSK",\r
"OŽUJSK",\r
"p.id, p.uid, p.niz, p.godina, p.broj, p.datum, p.vazi_do, p.kasa_id, p.market, p.enu, p.kasir, p.kupac_pib, p.kupac_naziv, p.kupac_adresa, p.kupac_grad, p.napomena, p.bruto, p.popust, p.ukupno, p.status, p.racun_uid, p.pretvoren, p.ponisten, p.ponistio, p.razlog, r.client_uid r_uid, r.ord_num r_ord, r.issue_dt r_issue, r.datum r_datum, r.fiscal_status r_fs, r.vrsta r_vrsta, r.iic r_iic, r.ukupno r_ukupno, r.stornirao_uid r_storn",\r
"p.status = ?",\r
"The patient has no valid e-prescriptions.",\r
"Patient pays:",\r
"patient agrees",\r
"Screen crashes, server exchange errors and Tax Administration rejections are sent to the issuer IRIS CORVINA through the server, without the content of receipts; personal ID numbers, bank accounts, emails, phone numbers, amounts and the names of cashiers and customers are removed before sending. Disabled = nothing is sent (not even a manual report from Support).",\r
"PAGO",\r
"PAHULJIC",\r
"PAK",\r
"Package",\r
"Bank app package",\r
"Package from a file (no internet)",\r
"The package is too large.",\r
"Package loaded: {0}, {1}",\r
"The package has been loaded. A register must be chosen from the list.",\r
"The package has been loaded. A register must be selected.",\r
"The package must be: {0}.",\r
"The package does not contain index.html — it is not a valid cash register package.",\r
"The package has no items.",\r
"The package is not a valid cash register package ({0}).",\r
"The package is not a valid ZIP (truncated or corrupted file).",\r
"The package was not written to disk correctly. Nothing was changed — try again.",\r
"The package is not for the cash register — it is not accepted.",\r
"Package",\r
"The item package size is entered by the manager (the manager PIN is required). Without approval it applies only to the print in progress.",\r
"The package size must be greater than zero (e.g. 250 g, 0.5 l, 10 pcs).",\r
"The pack size is not understood. Examples: 250 g, 0.5 l, 6x0.33 l, 10 pcs.",\r
"pack size not entered (e.g. 250 g); without it there is no price per kg / l",\r
"pakovanje REAL",\r
"the pack size in the name is unclear",\r
"The pack size applies to this print only. A permanent entry is approved by the manager.",\r
"Pack size: 250 g, 0.5 l, 6x0.33 l, 10 pcs",\r
"PALL MALL",\r
"PALMOLIVE",\r
"PALOMA",\r
"PANCET",\r
"PANFLEX",\r
"Guesthouse",\r
"PANTENE",\r
"Paper is running low.",\r
"PAPIRIC",\r
"PAPIRIĆ",\r
"PAPIRN",\r
"Paper goods",\r
"PAR",\r
"PARADAJZ",\r
"even",\r
"PARFEM",\r
"Parity",\r
"PARIZER",\r
"PARLIAMENT",\r
"PARMEZ",\r
"co-pay {0}% {1}{2}",\r
"Co-pay",\r
"Co-payment",\r
"Co-payment per prescription (€)",\r
"Partner",\r
"Partner: {0}{1}{2}.",\r
"Partners",\r
"Partners (companies and agencies)",\r
"Partner",\r
"Passport",\r
"PASS",\r
"PASTA",\r
"PASTA ZA ZUB",\r
"PASTET",\r
"PAŠTET",\r
"PASULJ",\r
"PAUŠAL",\r
"Flat-rate compensation paid to a farmer at the 8% rate (manual)",\r
"Flat-rate payment",\r
"Flat-rate tax payment",\r
"Pauses: an array of {od, do} dates.",\r
"PAVLAKA",\r
"paznja",\r
"VAT",\r
"VAT {0}",\r
"VAT {0}{1}",\r
"VAT on domestic supplies at the 15% rate (takings + issued invoices)",\r
"VAT on domestic supplies at the 21% rate (takings + issued invoices)",\r
"VAT on domestic supplies at the 7% rate (takings + issued invoices)",\r
"VAT on voucher sales",\r
"VAT on supply of gas, electricity and heating/cooling (reverse charge) (manual)",\r
"VAT on services by foreign persons (services of foreign persons (Imports and foreign services) + manual)",\r
"VAT paid on imports (customs declarations (Imports and foreign services) + manual)",\r
"VAT by rates",\r
"The company's VAT status does not match what was sent on the receipt.",\r
"The VAT rate must be one of: {0} %.",\r
"PECIVO",\r
"Bakery and cereals",\r
"PEKMEZ",\r
"PELAT",\r
"PELENE",\r
"PELINKOV",\r
"PELINKOVAC",\r
"pending",\r
"PEPSI",\r
"PERECE",\r
"PERFEX",\r
"Period",\r
"Period {0} – {1}",\r
"Period: {0}",\r
"Periodic",\r
"Periodic report",\r
"PERSIL",\r
"Fri",\r
"Friday",\r
"PETIT",\r
"Petnjica",\r
"PFANNER",\r
"PIB",\r
"PIB (seller)",\r
"PIB {0}",\r
"PIB {0}{1}",\r
"PIB / phone",\r
"The company PIB ({0}) is not in the certificate (in the certificate: {1}).",\r
"The company PIB must have 8 digits, or 13 for a JMB (given: \\"{0}\\").",\r
"The company PIB on the receipt ({0}) and the PIB for fiscalization ({1}) differ. The PIB must be aligned (Settings → Company on receipt / Fiscalization).",\r
"The company PIB has not been entered or is not valid (8 digits).",\r
"The customer's PIB and name are required.",\r
"PIB has 8 digits (13 for natural persons).",\r
"Customer PIB",\r
"The PIB must have 8 or 13 digits.",\r
"The PIB in the certificate does not match the company PIB on the receipt.",\r
"PIB, registered office town (municipality), at least one outlet (store, premises, office)",\r
"PIB: {0}",\r
"Drinks",\r
"Drinks, Coffee and tea",\r
"PILEC",\r
"PILEĆ",\r
"PIN",\r
"PIN — {0}",\r
"The PIN has at least 4 digits.",\r
"The PIN is required.",\r
"The PIN has been reset. A new PIN must be entered (Settings → Cashiers).",\r
"PIN entered",\r
"The PIN must have 4 to 8 digits.",\r
"The PIN is not correct.",\r
"The PIN is reset with a permit (file) issued by maintenance. The permit is valid only today and only for this register. The manager's PIN is reset, and when no manager is entered, the PIN of all cashiers.\\n\\nRegister label for maintenance:\\n{0}\\n\\nThe permit file is chosen in the next step.",\r
"Supervisor PIN",\r
"The manager's PIN is not correct.",\r
"PIRE",\r
"PIRINAC",\r
"PIRINAČ",\r
"PISKOT",\r
"PIŠKOT",\r
"PIŠTOLJ",\r
"Ask for age when selling alcohol and tobacco",\r
"The question about screen access is not possible on this register screen. The order was not executed.",\r
"label question",\r
"A question, request or description of a problem. The reply arrives here (a \\"new reply\\" label appears in the cash register header).",\r
"ask about a label",\r
"PIVO",\r
"PJURE",\r
"Pays",\r
"Pays (by years)",\r
"Pays by bank transfer",\r
"Card payments on receipts (with voids and refunds) compared with terminal transactions for the same day. Manual confirmations (without a terminal connection) cannot be checked by the register — they are compared with the bank statement.",\r
"Payment",\r
"Payment \\"To room\\"",\r
"The payment of {0} was cancelled on the terminal.",\r
"The payment {0}{1} must be cancelled on the terminal / in the bank app. Has it been cancelled?",\r
"Payment by voucher is not enabled (Settings → Add-ons).",\r
"Payment by voucher: the voucher code must be entered.",\r
"cash payment",\r
"Payment in cash",\r
"The law does not allow a cash payment of 10,000 € or more to another party (supplier, loan, payout) (Art. 65). Such a payment goes through a bank account.\\n\\nHanding over the daily takings to the bank is not covered by the ban.\\n\\nRecord the withdrawal?",\r
"A payment from an advance must carry the IKOF of the advance receipt.",\r
"The payment was declined.",\r
"The payment was approved.",\r
"The payment was cancelled on the terminal.",\r
"Payment already approved",\r
"Payment by card (the waiter brings the POS terminal)",\r
"card payment (POS)",\r
"Payment by bank transfer requires a customer with a PIB.",\r
"Payment by bank transfer requires a partner with a PIB on the reservation.",\r
"placeholder=\\"https://… or http://…:8080\\" inputmode=\\"url\\"",\r
"placeholder=\\"e.g. 1, 2, 3, 4, Bar, Terrace 1\\"",\r
"placeholder=\\"e.g. 1001, 1002, 4475\\"",\r
"placeholder=\\"Drinks, Coffee and tea\\"",\r
"placeholder=\\"XXXX-XXXX-XXXX or link iris://upari…\\" autocapitalize=\\"characters\\"",\r
"Advance paid",\r
"paid",\r
"Paid by advance",\r
"Planned departure",\r
"PLANTAZE",\r
"PLANTAŽE",\r
"Plav",\r
"PLAZMA",\r
"Pljevlja",\r
"Plužine",\r
"PNG",\r
"per price list",\r
"By days",\r
"By day of the week",\r
"According to the records the register now holds",\r
"According to the records there is {0} in the register, and the withdrawal is {1}.\\n\\nRecord the withdrawal?",\r
"According to the records there is {0} in the register. Enter the amount of counted cash.",\r
"After the period from checkout expires, the guest's personal data is deleted.",\r
"By cashier",\r
"per kg",\r
"per piece)",\r
"By customer",\r
"By months",\r
"by name",\r
"per night",\r
"The tourist tax amount is offered by municipality.",\r
"per person per night",\r
"A receipt has been issued for this pro forma. The pro forma cannot be cancelled.",\r
"A receipt has already been issued for this pro forma.",\r
"On start-up",\r
"initial float",\r
"Opening float",\r
"The initial float has already been reported to the Tax Administration (or sending has already been attempted). The difference is entered as DEPOSIT or WITHDRAWAL.",\r
"The opening deposit cannot be negative.",\r
"The opening float is being sent to the Tax Administration right now. Repeat the correction in a few seconds.",\r
"Opening float: {0}",\r
"Opening float: amount of cash in the register at the start of the shift (€).\\nEmpty or 0 = no float.",\r
"The initial cash deposit has already been reported for today.",\r
"The opening cash deposit for today has not been reported. The deposit must be reported first, then the receipt sent.",\r
"Start",\r
"Start as a new register",\r
"Data",\r
"item data",\r
"Guest data — {0} {1}",\r
"The data from the document has been entered. Check and complete it.",\r
"The receipt data does not match its QR code. The receipt was changed after it was issued.",\r
"The data was changed on another device. Save or discard your changes, then refresh.",\r
"The registration data is complete.",\r
"Data for registration with the Police Administration and the tourist organisation.",\r
"podaci_upijeni TEXT",\r
"The data was changed in the meantime by another user. The data has been refreshed; repeat the change.",\r
"Settings",\r
"Settings → Waiter phones → \\"Pair phone\\"",\r
"Pharmacy settings",\r
"Pharmacy settings have been saved.",\r
"Settings from file",\r
"QR menu settings",\r
"QR menu settings have been saved.",\r
"The settings have been saved.",\r
"Register device settings",\r
"Device settings have been saved.",\r
"Podgorica",\r
"Subgroup",\r
"Share",\r
"Split the bill of table {0}",\r
"Split table bill…",\r
"Withdrawals",\r
"Withdrawal",\r
"Withdrawal — money out of the register",\r
"Withdrawal recorded:",\r
"Withdrawal of 10,000 € or more",\r
"Withdrawal larger than the balance",\r
"WITHDRAWAL…",\r
"Subcategories",\r
"Default printer (Windows){0}",\r
"The default printer in Windows (\\"{0}\\") does not print but saves to a file.",\r
"Windows default",\r
"Support",\r
"Support and errors (IRIS CORVINA)",\r
"IRIS CORVINA support is requesting access to this cash register's screen in order to help.",\r
"IRIS CORVINA support is requesting access to this cash register's screen.",\r
"Support through the program works in the installed cash register (Windows, Android), not in the browser.",\r
"Support is not available in this register.",\r
"Support: messages, error report, requests…",\r
"POGAC",\r
"POGAČ",\r
"wrong check digit",\r
"Wrong check digit",\r
"Wrong PIN.",\r
"Wrong certificate password (or the file is not .pfx/.p12).",\r
"Wrong canonicalization method.",\r
"Wrong signature method.",\r
"Wrong digest method.",\r
"poIsteku must be \\"citanje\\".",\r
"gift voucher {0}",\r
"Gift voucher {0}",\r
"GIFT VOUCHER {0} €",\r
"The gift voucher has been printed: {0} ({1} pcs).",\r
"A gift voucher cannot be bought with another voucher.",\r
"A gift voucher is sold per piece (1–50 pieces on a receipt).",\r
"Gift vouchers",\r
"Gift vouchers are not turned on. The manager turns them on (Settings → Extras: denominations, VAT, validity period).",\r
"Gift vouchers enabled",\r
"started: {0}",\r
"Sex",\r
"Police",\r
"Fields of the wrong form (Tax Administration schema check): {0}.",\r
"The \\"issued by\\" field is required.",\r
"The \\"issued on\\" field must be an ISO time.",\r
"The \\"Discount\\" field is empty. For a percentage, enter a number, then %.",\r
"Approval number field",\r
"The format field must be \\"iris-licenca\\".",\r
"Result field",\r
"Amount field",\r
"Card field",\r
"Message field",\r
"Reference field",\r
"RRN field",\r
"Currency field",\r
"Returned reference field",\r
"Card type field",\r
"POMFRIT",\r
"Auxiliary",\r
"Mon",\r
"Repeat (ORp)",\r
"Monday",\r
"reverses",\r
"being voided",\r
"Only a change made at this cash register can be cancelled.",\r
"Only an open pro forma can be voided.",\r
"ponistava TEXT",\r
"Voiding",\r
"Undoing a price change",\r
"Cancel the last receipt (customer did not pay, entry error); the items can be put on hold",\r
"Voiding the pro forma",\r
"Voiding the receipt",\r
"Undoing a barcode link",\r
"cancelled",\r
"Voided",\r
"Voided {0}{1}{2}.",\r
"undone",\r
"Voided",\r
"Voiding a guest order",\r
"undone",\r
"Undo",\r
"Clear selection",\r
"Void the last receipt",\r
"Void receipt",\r
"Undo all",\r
"Cancelled by the waiter.",\r
"Retry saving to the server",\r
"price list received again (service)",\r
"Re-receipt from the server: {0}",\r
"Restarting is possible after the shift is closed.",\r
"The restart failed. The program must be closed and opened again.",\r
"Resending rejected messages…",\r
"deleted again",\r
"deleted again {0} {1} {2}{3}",\r
"Restart",\r
"Restart now",\r
"ponovo_kasir TEXT",\r
"ponovo_kasir_id INTEGER",\r
"ponovo_razlog TEXT",\r
"ponovo_vrijeme TEXT",\r
"The offered version {0} is older than the one already on the cash register ({1}).",\r
"Occupancy",\r
"Occupancy and revenue",\r
"Discount",\r
"Discount {0} % on receipt {1}",\r
"discount %",\r
"The discount and customer from the screen for a write-off",\r
"The discount and customer from the screen are not taken into account for a write-off.",\r
"The discount was removed (the price has changed) from: {0}.",\r
"The loyalty customer's discount applies to the whole receipt (if there is no manual discount). The list of customers comes from Accounting.",\r
"Discount on the price per night (%)",\r
"Discount on last item",\r
"Discount on receipt",\r
"The receipt discount cannot be negative.",\r
"Item discount",\r
"The discount cannot be greater than the item amount ({0}).",\r
"The discount is not valid.",\r
"The discount of {0} was removed from the item \\"{1}\\" because it is not less than the item's new amount.",\r
"The discount in % must be a number from 0 to 100.",\r
"Discount in percent: a number, then %",\r
"popust_pct REAL",\r
"Discount: between 0 and 100 %.",\r
"Discounts",\r
"PORCIJA",\r
"The Tax Administration rejected the message",\r
"The Tax Administration rejected: {0} (Settings → Fiscalization).",\r
"The Tax Administration does not accept this cash register's certificate. Sending waits for a valid certificate.",\r
"Rejected by Tax Administration",\r
"The Tax Administration rejected it ({0}): {1}",\r
"The Tax Administration rejected {0}, so this document cannot be reported either. After the cause is removed: \\"Resend rejected\\".",\r
"The Tax Administration rejected messages: {0}. They must be resolved (Settings → Fiscalization).",\r
"The Tax Administration rejected the receipt",\r
"The Tax Administration rejected the receipt that is being cancelled, so the cancellation cannot be received either. After the cause is fixed: \\"Resend rejected\\" (the original goes first, the cancellation after it).",\r
"The Tax Administration already has an opening deposit reported for this day (code 56). This entry is not recorded separately.",\r
"Tax Administration: {0} waiting · sending OFF",\r
"Tax Administration: {0}{1}",\r
"Tax Administration: NOT READY",\r
"Tax Administration: CERTIFICATE EXPIRED",\r
"The tax treatment of the fee should be checked with the Tax Administration.",\r
"Waiting to be sent to the Tax Administration: {0}. An internet connection and sending are required (the Tax Administration indicator in the header).",\r
"Port",\r
"Port {0} is in use (is another cash register running?) — choose a different port.",\r
"Port {0} not found on this computer (connected device, driver).{1}",\r
"Port {0} cannot be opened (used by another program or disconnected): {1}",\r
"Port / address",\r
"The port must first be connected with the \\"Test\\" button in Settings.",\r
"Portal",\r
"PORTO",\r
"Message to guests (Montenegrin)",\r
"Message to guests (English)",\r
"Message from the issuer",\r
"The message has been sent to support.",\r
"The message is too large (150 kB at most). The receipt must be split into several receipts.",\r
"Messages waiting to be sent to the Tax Administration: {0}. While sending is disabled, messages are not sent (the delivery deadline is 48 hours from the issue of the receipt).\\n\\nDisable sending?",\r
"Messages waiting to be sent to the Tax Administration: {0}. They stay in the queue and are sent only when the certificate is imported again.",\r
"The message could not be read (size check).",\r
"The message could not be read during XSD schema validation.",\r
"The message failed schema validation: a field has the wrong form or the VAT on the receipt does not match the company VAT status.",\r
"message to support",\r
"message to IRIS CORVINA support, error report, request (another cash register, extension, module)",\r
"Support message:",\r
"The message for the Tax Administration is {0} kB, and at most 150 kB is allowed. The receipt must be split into several receipts.",\r
"The message for the device is too large.",\r
"message: {0}",\r
"Messages",\r
"Messages rejected by the Tax Administration ({0}) are not resent automatically. After the cause is fixed, they are sent with the \\"Resend rejected\\" button.",\r
"Messages",\r
"pos",\r
"POS terminal",\r
"Bank POS terminal, phone payment, scale, F-keys, customer display; terminal transactions and reconciliation with the register",\r
"POS terminal: {0}{1}{2}. Review: More → Register devices → Terminal transactions.",\r
"Send",\r
"Resend rejected",\r
"Send message",\r
"Send now",\r
"Send request",\r
"Send",\r
"Job",\r
"Separate item without VAT",\r
"sent",\r
"sent",\r
"Sent",\r
"sent",\r
"Sent",\r
"More key information was sent than needed.",\r
"More signatures were sent than allowed.",\r
"Sent to print: {0}{1}",\r
"Sent to the Tax Administration: {0}.",\r
"after",\r
"After this many consecutive nights the tax is not charged; 0 = not applied.",\r
"After a price change",\r
"After the price change: {0}.",\r
"Last two days. Yellow: needs attention — unclear result (check the terminal) or approved without receipt (issue a receipt for the same amount or cancel). Unclear:",\r
"Last error:",\r
"Last error: {0}",\r
"The last catalogue change was not completed ({0}). Check the prices and import them again (Settings → Items and prices).",\r
"The last catalogue change was not completed. Prices were reloaded from the program for \\"{0}\\". If a newer price file exists, it must be imported again (Settings → Items and prices).",\r
"Last note: {0}",\r
"Last check",\r
"Last exchange",\r
"Last backup to the folder",\r
"last connection {0}",\r
"Latest changes",\r
"The last download failed: {0} A new attempt is made at the next check.",\r
"Last sent",\r
"Last number",\r
"The last issued number is {0}. The next receipt gets number {1}.",\r
"The last issued number becomes {0}, so the next receipt gets number {1}.\\n\\nMoving the counter backwards later is not possible.",\r
"Last issued receipt number",\r
"Last issued receipt number ({0})",\r
"The last issued receipt no longer blocks issuing because of the time. Confirmation is allowed only when the date and time on the device are now correct.",\r
"The last receipt is from {0}, and today is {1} ({2} days). If the cash register was not idle that long, check the date and year on the device before the first receipt.",\r
"The last database snapshot was damaged. The database was restored from the previous snapshot and the log",\r
"Last {0} h",\r
"Last 48 h",\r
"shop supervisor",\r
"POST",\r
"POST, GET",\r
"Set",\r
"Set {0} EUR",\r
"Version {0} exists, but the feed has no valid (HTTPS) address for the Android package.",\r
"The permit signature is not valid. A permit is issued only by maintenance.",\r
"Guest's signature",\r
"The order signature does not match the issuer's key. The order was not executed.",\r
"The signature as a whole is not valid.",\r
"The request signature is not valid.",\r
"The wrong part of the message was signed.",\r
"The signed order is older than 7 days (or has no valid time) — it was not executed; issue a new order.",\r
"Only a request composed by this module (racunXml / depozitXml / enuXml) is signed.",\r
"Credit",\r
"At least one payment method is required.",\r
"the bank ECR specification is required",\r
"A new version of the application (1.5) is required.",\r
"A new app version is required (SoftPOS with amount).",\r
"A new app version is required.",\r
"You need to sign in again (waiter and PIN).",\r
"A new login is required.",\r
"You must choose:",\r
"The program must be restarted.",\r
"The register data must be checked and confirmed again.",\r
"The point of sale data must be checked and confirmed again.",\r
"The voucher code must be entered.",\r
"The register must be paired with the server (IRIS CORVINA Server section).",\r
"Consumption on the room",\r
"Room charge",\r
"Confirmation",\r
"Number confirmation",\r
"Register confirmation",\r
"The confirmation was not entered (NOVA). Nothing was changed.",\r
"Co-payment certificate",\r
"CERTIFICATE OF PAID CO-PAYMENT",\r
"Pack size confirmation",\r
"Point of sale confirmation",\r
"Device clock confirmation",\r
"confirmation: receipt outside working hours",\r
"Confirmed",\r
"Confirmed (occupies the room)",\r
"Confirm",\r
"Confirm ENU from the list…",\r
"Confirm return",\r
"Confirm device clock",\r
"Confirmed by",\r
"is confirmed by the accountant",\r
"linked",\r
"Linked barcodes",\r
"Linked",\r
"Link",\r
"Link barcode to an item",\r
"Link to an item",\r
"Link to an existing item",\r
"Connection",\r
"Connecting the register to the company",\r
"Connecting to the company",\r
"Connecting to the server…",\r
"Connecting…",\r
"The refund of {0} to the card is made on the terminal / in the bank app.",\r
"Refund to card",\r
"Refund to card failed ({0}): {1}",\r
"Refund",\r
"return ({0} items{1})",\r
"advance refund",\r
"Advance refund",\r
"ADVANCE REFUND — CORRECTIVE RECEIPT OF AN ADVANCE RECEIPT",\r
"An advance refund requires manager approval. The refund was not made.",\r
"The return would exceed the receipt amount ({0}; already returned {1}). The return was not done.",\r
"Partial return of goods",\r
"Partial return of goods: corrective receipt no.",\r
"A return of dispensed medicine is not allowed. A dispensing error is corrected by cancelling the receipt with a reason.",\r
"A refund is possible",\r
"A return is possible only from an issued receipt that has not been cancelled.",\r
"The return has been recorded: corrective receipt {0}.",\r
"RETURN TO CUSTOMER (change)",\r
"Refund to card",\r
"Refund to card: the customer taps the same card on the terminal.",\r
"Refund on the terminal",\r
"povrat REAL",\r
"Goods return",\r
"Return for receipt {0}",\r
"A refund by bank transfer requires a partner with a PIB on the reservation.",\r
"Returning to the previous version failed.",\r
"Returning to the previous version exists only on the Windows cash register.",\r
"Returning a receipt to its table (without an order)",\r
"Violation",\r
"Pull",\r
"Pull catalogue from server",\r
"The guest call has been resolved.",\r
"Guest calls",\r
"calls: {0}",\r
"PRAŠAK ZA PEC",\r
"Scale barcode rules",\r
"Rules and taxes",\r
"The property rules have been saved.",\r
"it is empty",\r
"Empty receipt.",\r
"Empty fields that must have a value: {0}.",\r
"Holiday",\r
"HOLIDAY",\r
"Holidays",\r
"empty = the app only opens",\r
"Empty = no visa.",\r
"empty = Cyrillic from Montenegrin",\r
"empty = activity result code",\r
"empty = not checked",\r
"empty = not a pharmacist",\r
"Empty = per price list.",\r
"empty = default",\r
"empty = first USB device or vid:pid",\r
"empty = first USB device, or Bluetooth address",\r
"Empty = accommodation rate.",\r
"Empty = accommodation rate. The fee never carries the tourist tax.",\r
"empty or too long file name",\r
"place of residence",\r
"Residence",\r
"Counted cash (€)",\r
"The counted cash is required before closing.",\r
"The counted cash is not valid (e.g. 125,50).",\r
"Counted",\r
"Counted: {0}",\r
"Counted: {0}. The difference is visible on the closing report (Z).",\r
"Counted: not entered",\r
"Pro forma",\r
"PRO FORMA — not a fiscal receipt. It is not included in turnover and is not reported to the Tax Administration.",\r
"Pro forma {0}",\r
"Pro forma {0} has been voided.",\r
"Pro forma {0} has been saved ({1}).",\r
"Pro forma {0} has been loaded without the items that no longer exist in the catalogue: {1}. Amount: {2}.",\r
"Pro forma {0} has been loaded onto the screen ({1}).",\r
"Pro forma {0} has been loaded. The amount at current prices is {1}, on the pro forma {2}.",\r
"Pro forma {0} from {1}, {2}.\\nA voided pro forma cannot be loaded into the basket.\\n\\nReason (optional):",\r
"The pro forma has been cancelled.",\r
"The pro forma is loaded onto the receipt screen. It needs to be removed from the screen before voiding.",\r
"The pro forma is already on hold.",\r
"The pro forma has already been cancelled.",\r
"The pro forma was not found.",\r
"Pro forma from the receipt on screen (not a fiscal receipt); list of pro formas",\r
"A pro forma is not made for a table. The table's bill is charged with a fiscal receipt.",\r
"A pro forma is made from the receipt on screen (items, discounts, customer). After saving, the receipt is removed from the screen; the pro forma is later loaded into the basket and charged as a fiscal receipt.",\r
"pro formas. Search is required for older ones.",\r
"Fields that are too long: {0}.",\r
"file name too long: {0}",\r
"Overview",\r
"Deleted receipts overview",\r
"Viewing is recorded in the access log (user, time, reason).",\r
"Overview of all deletions before payment for the selected period: deleted receipts and items removed from receipts (who, when, what, how much, why and whether the receipt was paid afterwards).",\r
"Preview: {0} of {1} items{3}",\r
"View only. Changes are made by a user with settings authorisation.",\r
"browser",\r
"browser (IndexedDB)",\r
"the interrupted write to file {0} cannot be completed ({1})",\r
"Cancelled on the terminal (test).",\r
"Interrupted.",\r
"via the shop's Wi-Fi network. Pairing: QR code from the main register (",\r
"Overrun: {uredjaja, dana} whole numbers ≥ 0.",\r
"transitional mode (server + folder)",\r
"transitional mode: through the server and through the folder",\r
"Transitional mode: exchange through the folder too",\r
"vs. previous 7",\r
"According to the entered working hours, the cash register is not working today.",\r
"is being moved",\r
"Moving / merging — table {0}",\r
"Moving / merging a table",\r
"Moving the barcode to another item",\r
"Move to another room",\r
"moved",\r
"Move",\r
"Move / merge",\r
"Move / merge table…",\r
"Transferring item package sizes failed: {0}",\r
"Transferring item package sizes: {0}",\r
"Remaining",\r
"{0} remains to be allocated.",\r
"Transcription into the authority's application",\r
"Transcription: the registration is prepared here and entered into the authority's application.",\r
"Correspondence",\r
"Recommended",\r
"Interim report",\r
"interim report (X)",\r
"PRESJEK | Kasa:{0} | {1}..{2} | Racuna:{3} | Promet:{4} EUR | Got:{5} | Kar:{6} | Popust:{7}",\r
"Interim report at",\r
"A change larger than 3× is skipped: {0} (\\"Include changes larger than 3×\\" is not checked).",\r
"Skip",\r
"Previous day",\r
"Previous data",\r
"The previous entry is in progress.",\r
"Search",\r
"Search (name or code)",\r
"Item search",\r
"Item search: name or code…",\r
"Search by barcode, code or part of the name.",\r
"Search by supplier, number and source",\r
"Search by name",\r
"Search: number, amount, customer, cashier, IKOF…",\r
"Search: number, customer, PIB…",\r
"Search: name, room",\r
"Search: name, phone, room",\r
"converted to receipt",\r
"Converted to receipt",\r
"Version {0} has been downloaded and verified. Installation is possible after the shift is closed; data remains saved.",\r
"Version {0} has been downloaded and verified. It is installed over the existing version; data is preserved.",\r
"Version {0} has been downloaded and verified. The new version is applied at the next cash register start, after the shift is closed.",\r
"Version {0} has been downloaded and verified. The new version is applied the next time the program starts.{1}",\r
"downloaded version {0}{1}",\r
"The downloaded version is not valid on disk, so the version from the installation is running. The update must be downloaded again.",\r
"The downloaded version requires a newer Setup ({0} or newer). Until then, the current version keeps running.",\r
"Settings imported: {0}.",\r
"Downloaded: {0} items (margin {1} %)",\r
"The download is already in progress.",\r
"Downloading the catalogue…",\r
"The download failed.",\r
"Downloading the new version is in progress.",\r
"Downloading a new version is not possible on this device.",\r
"Downloading version {0}…",\r
"download: {0}",\r
"Import",\r
"Fetch e-prescriptions",\r
"Take over and send",\r
"Download and deploy",\r
"Download new version",\r
"Download now",\r
"Take over table",\r
"too many files",\r
"Too many wrong PINs in a row. Trying again is possible in {0}.",\r
"Too many redirects at the update address.",\r
"Surname",\r
"Surname and first name",\r
"at closing",\r
"Pricing Rule",\r
"Revenue by reservation source",\r
"Revenue per available room",\r
"Accommodation revenue",\r
"login",\r
"Report",\r
"Arrival registration",\r
"Guest registration — {0} {1}",\r
"Guest registration",\r
"Report a program error",\r
"The registration has been copied.",\r
"The report has been sent to the issuer.",\r
"The report has been saved and is sent when the connection to the server is established.",\r
"Cashier login",\r
"User report: {0}",\r
"Login failed.",\r
"Login failed. The cashier must be chosen again.",\r
"Report to the authorities",\r
"Registration with the police",\r
"Registration with the tourist organisation",\r
"Registration for transcription",\r
"prijava.cuvanjeGodina",\r
"prijava.rokPolicijaSati",\r
"prijava.rokToSati",\r
"prijava.turistickaOrganizacija",\r
"Guest registrations",\r
"Register",\r
"Register arrival",\r
"Report an error",\r
"the logged-in cashier is not entered as a pharmacist",\r
"Registered with the police",\r
"Registered with the tourist organisation",\r
"before",\r
"{0} d ago",\r
"{0} days ago",\r
"{0} h ago",\r
"{0} min ago",\r
"{0} s ago",\r
"Suggested name: {naziv}",\r
"Receiving orders from the waiters' phones is not turned on (Settings → Waiters' phones).",\r
"Receiving technical errors is disabled at the issuer for this company. Errors in the queue are not sent.",\r
"Showing the FZO share on the fiscal receipt: the receipt is issued for the amount paid by the patient (the FZO share is an item discount). This method should be confirmed with the accountant and the Revenue and Customs Administration.",\r
"Showing 500 of {0} — narrow the search.",\r
"Showing the last",\r
"Showing the last {0} pro formas. Search is required for older ones.",\r
"Showing the first",\r
"The first {0} receipts are shown. For the rest, narrow the period or the search.",\r
"The first {0} are shown. The other items are available through search.",\r
"Locations shown: {0} of {1}",\r
"Shown:",\r
"Show",\r
"Show {0}",\r
"Show data",\r
"Show all registers",\r
"Only the parts of the register for the selected activities are shown. With no selection, everything is shown. A paired register also writes the selection to the server, for all of the company's programs.",\r
"PRIL",\r
"The attachment \\"{0}\\" is not allowed (allowed: log, image, context).",\r
"The attachment must be an object.",\r
"attachment: screenshot (of this window)",\r
"attachment: cash register technical log (last 200 actions, without amounts and receipts)",\r
"The attached certificate is not X.509.",\r
"Accept orders from waiters' phones",\r
"primary",\r
"Apply",\r
"Apply ({0})",\r
"Apply also to…",\r
"Applying VAT rates by date failed: {0}",\r
"Applying scheduled prices failed: {0}",\r
"It is applied at the next start of the program.",\r
"The cash received is less than the amount to be paid in cash.",\r
"The cash received is not a valid amount.",\r
"Received",\r
"Received (empty = exact amount)",\r
"received {0} price changes",\r
"Received {0}, change {1}.\\n\\nConfirm the change amount?",\r
"Cash received",\r
"primljeno REAL",\r
"PRINCES",\r
"PRINGLES",\r
"Preparing the demo register…",\r
"Preparing the queue for the Tax Administration failed: {0}",\r
"Screen access — IRIS CORVINA support",\r
"Screen access is allowed. Support has been notified.",\r
"screen access: {0}",\r
"Access is possible only with your consent. Without consent, support cannot see the screen and nothing is changed. Every access is recorded at the publisher.",\r
"Access to guest data",\r
"The private key does not match the certificate.",\r
"the application's private space on the device",\r
"the application's private space, folder {0}",\r
"private prescription",\r
"the temporary file was not written completely",\r
"PROBA",\r
"Test customer display",\r
"CUSTOMER DISPLAY TEST",\r
"The test was sent to the customer display.",\r
"Test charge 1.00 €",\r
"Connection test (status)",\r
"PROBA-{0}-{1}",\r
"PROBA-POTVRDA-{0}",\r
"Demo register",\r
"Demo register (no point of sale)",\r
"The demo register has been set up",\r
"The demo register is not tied to any point of sale (trial, training): {0} and with the label entered in settings.\\n\\nA register from the list can be chosen later (Settings → Cash register).",\r
"trial",\r
"test (created on this device)",\r
"Test FZO (training — fictitious e-prescriptions)",\r
"Test FZO (training)",\r
"TEST FZO (training)",\r
"probni INTEGER",\r
"TEST MODE",\r
"TEST MODE — THE RECEIPT HAS NOT BEEN REPORTED TO THE TAX ADMINISTRATION",\r
"TEST MODE · TEST",\r
"The percentage takes precedence. Both empty = no discount.",\r
"estimate",\r
"Estimate",\r
"PROD",\r
"Sale",\r
"sale ({0} items{1})",\r
"Sales = receipts and cancellations; Write-off = written-off goods (not turnover)",\r
"Sale of alcohol / tobacco",\r
"Sale of an item with an expired date ({0}, expiry {1})",\r
"voucher sales (denomination added to a receipt), voucher balance check, list",\r
"Sales by customer {0}",\r
"Sale of gift vouchers is not enabled (Settings → Add-ons).",\r
"Sale: choosing an amount adds the voucher to the receipt as an item; after payment the register prints a voucher with a code. Paying with a voucher: \\"More methods\\" → Voucher (code).",\r
"Points of sale",\r
"Points of sale: {0} · registers in the package: {1}",\r
"Point of sale",\r
"Company point of sale",\r
"PRODUCTION",\r
"Trial period extension",\r
"Extend by a night",\r
"The program has been updated",\r
"The program has been updated to version {0}.",\r
"The program must be closed and opened again.",\r
"The program has no item database to load.",\r
"The program has no log to send.",\r
"The program is not connected to the server (Settings → Server).",\r
"The program is not connected to the server.",\r
"The program is not connected to the server. Menu editing works with a server connection (Settings → Server).",\r
"Manufacturer",\r
"The manufacturer can have at most 80 characters.",\r
"Manufacturer",\r
"proizvodjac TEXT",\r
"promet",\r
"Turnover",\r
"TURNOVER",\r
"Supply of gas, electricity and heating/cooling with reverse charge (manual)",\r
"Turnover by item",\r
"Turnover by hour",\r
"Change prices",\r
"Change price",\r
"Change cashier",\r
"Change register…",\r
"Change store",\r
"Change the general price",\r
"Change the price for {0} item(s)?{1}",\r
"Prices changed: {0}{1}.",\r
"Change",\r
"Change of register",\r
"PRONTO",\r
"Prescribed",\r
"the prescribed medicine is not available",\r
"PROPOLIS RAK",\r
"PROSEC",\r
"PROSECCO",\r
"Average receipt",\r
"Average price",\r
"Average",\r
"Last month",\r
"Exchange space",\r
"The automatic printing check failed: {0}",\r
"Checking for updates…",\r
"database check failed",\r
"Voucher check",\r
"Price check",\r
"A price check does not add the item to the receipt.",\r
"Checking the company's price list…",\r
"Money check",\r
"Data verification",\r
"Checking the connection…",\r
"check: {0}",\r
"Verified with the server",\r
"Checked…",\r
"Check",\r
"Check for updates",\r
"Check prices now",\r
"Check folder now",\r
"Check paper",\r
"Check again",\r
"Check now",\r
"Check connection",\r
"Check the quantity, price and rate.",\r
"Window on the second monitor",\r
"PRp",\r
"PRSUT",\r
"PRŠUT",\r
"Enter the room types first.",\r
"public class KasaRaw {",\r
"public static void Posalji(string stampac, byte[] b) {",\r
"PUEBLO",\r
"PUEBLO TEQUILA",\r
"pulsing",\r
"Full amount",\r
"PUT",\r
"PUTER",\r
"QR codes and domain",\r
"Table QR codes",\r
"QR codes lead to the company's own domain (entered in the editor → \\"QR codes and domain\\")",\r
"QR menu — settings",\r
"QR menu — menu content",\r
"The QR menu works in hospitality mode (Settings → Hospitality).",\r
"No.",\r
"r.datum >= ? AND r.datum <= ?",\r
"r.fic IS NOT NULL",\r
"r.fiscal_status IN ('ceka', 'error')",\r
"r.smjena_id = ?",\r
"r.smjena_id = ? AND date(r.datum) = ?",\r
"r.vrsta = 'otpis'",\r
"rec.)",\r
"račun",\r
"Account",\r
"invoice {0}",\r
"Receipt {0}",\r
"Receipt {0} is already included in a summary receipt.",\r
"Receipt {0} cannot be calculated by VAT rates.",\r
"Receipt {0}:",\r
"Receipt {0}…: the total by rates ({1}) is not equal to the receipt amount ({2}).",\r
"receipt {0}{1}",\r
"Invoice no.",\r
"Receipt no. {0} has been voided (cancellation).{1}",\r
"Receipt no. {0} has been cancelled.",\r
"Receipt no. {0} from {1}, {2}.\\n\\nA cancellation receipt is being issued; this receipt stays in the records as cancelled. A cancellation cannot be undone.\\n\\nReason for cancellation:",\r
"The guest's account has not been paid ({0} EUR). Collect payment before checkout.",\r
"hotel receipt",\r
"Receipt and printing",\r
"The receipt goes directly to the selected printer, without a selection window. \\"Default printer (Windows)\\" is the printer set as default in Windows. The printer selection window opens only with \\"(selection at every print)\\". Documents are printed in order, one by one.",\r
"The receipt has {0} different rates/exemptions, and the Tax Administration accepts at most 20.",\r
"The receipt has {0} items, and the Tax Administration accepts at most 1000. The receipt must be split into several receipts.",\r
"The receipt issued for this pro forma is not in this cash register's database.",\r
"The receipt has been emptied and remains in the record of deleted receipts (More → Deleted receipts).",\r
"The receipt was issued without an IKOF.",\r
"The receipt was issued while the cash register was running in a different environment (TEST / PRODUCTION) and is not sent to this service.",\r
"The receipt was issued to room {0}. Posting to the room's bill is waiting for a connection to the server.",\r
"The receipt was issued more than 6 hours ago. It must be sent as a subsequent submission.",\r
"The receipt is on hold.",\r
"The receipt has been deleted and remains in the deleted records (More → Deleted receipts).",\r
"The held receipt has been deleted.",\r
"The receipt was paid from an advance, and the advance receipt has already been corrected for that amount. The cancellation was not made.",\r
"The receipt was paid by card via the terminal{0}. {1} {2} on the terminal?",\r
"The receipt is empty.",\r
"The receipt was reported to the Tax Administration in PRODUCTION, and the cash register is now working in the trial environment. The return was not made. For a return, the environment must be switched back to PRODUCTION (Settings → Fiscalization).",\r
"The receipt was reported to the Tax Administration in PRODUCTION, and the cash register is now working in the trial environment. The cancellation was not made. To cancel, the environment must be switched back to PRODUCTION (Settings → Fiscalization).",\r
"The receipt was reported to the Tax Administration, so the return must be reported too, and the cash register cannot send at the moment: {0} The return was not made.",\r
"The receipt was reported to the Tax Administration, so the cancellation must be reported too, and the cash register cannot send at the moment: {0} The cancellation was not made.",\r
"The receipt has been saved: {0} ({1}){2}{3}",\r
"THE RECEIPT HAS BEEN CANCELLED (cancellation no.",\r
"The receipt has been cancelled: cancellation receipt no.",\r
"The receipt has been cancelled.",\r
"The receipt is already included in a summary receipt (issued on another cash register). The cancellation was not made.",\r
"The receipt is already included in a summary receipt.",\r
"The receipt is already included in a summary receipt. The cancellation was not made.",\r
"The receipt has already been cancelled in full.",\r
"The receipt has already been cancelled.",\r
"The receipt has already been restored to the screen and is on hold (\\"Holds\\").",\r
"The receipt was returned to the screen without the items that no longer exist in the catalogue: {0}.",\r
"The receipt has been returned to the screen.",\r
"A receipt charged to a room cannot have another payment method.",\r
"The receipt that was being rung up when the register was shut down could not be restored (the record is damaged). The receipt must be rung up again.",\r
"The receipt that was being rung up when the register was shut down was not restored to the screen: none of its items are in the catalogue any more ({0}). It has been entered in the deleted receipts (More → Deleted receipts).",\r
"The receipt being cancelled was issued in a different environment (TEST / PRODUCTION), so the cancellation is not sent to this service either.",\r
"The receipt being cancelled has no IKOF, so the cancellation cannot be reported.",\r
"The receipt being cancelled was not reported to the Tax Administration (it was issued in trial mode), so the cancellation is not sent either.",\r
"The receipt with which it was returned does not exist.",\r
"A receipt can carry only one advance receipt, so the free advance cannot be fully used in this payment. Pay part by another method or separately. Nothing was issued.",\r
"A receipt can carry only one advance receipt. Part of the advance was not used; collect the remainder separately.",\r
"Put receipt on hold",\r
"The receipt on hold is unreadable.",\r
"Receipt on screen",\r
"The receipt on screen is empty.",\r
"The receipt on screen is empty. A pro forma is made from the items of the receipt on screen: items are keyed in as for a receipt, then \\"Pro forma\\" is pressed.",\r
"The receipt on the screen is empty. A pro forma is made from the receipt items.",\r
"The receipt on the screen has changed in the meantime. The write-off was not recorded.",\r
"The referenced receipt has not yet been reported to the Tax Administration. Try again later.",\r
"Receipt to a guest's room…",\r
"The room charge receipt does not exist on this cash register or has no IKOF.",\r
"A receipt charged to a room cannot be issued without IKOF (fiscalization is not enabled or there is no certificate). The receipt was not issued.",\r
"A receipt charged to a room requires a reservation.",\r
"The receipt does not exist.",\r
"The receipt has no IKOF (it was not signed when issued).",\r
"The receipt has no payment method.",\r
"The receipt has no line items.",\r
"Receipt not issued",\r
"The receipt was not issued{0}, but the payment of {1} was approved on the terminal. The payment is cancelled on the terminal, or kept for another attempt to issue the receipt (the next charge of the same amount uses it, without a new charge).",\r
"The receipt was not found.",\r
"The receipt was not paid from this advance.",\r
"The receipt is not a summary receipt.",\r
"The receipt from {0} has been returned to the screen.",\r
"receipt paid from an advance",\r
"Receipt paid from an advance",\r
"A receipt paid from an advance has been cancelled. The advance receipt is not corrected for it.",\r
"A receipt paid from an advance is not cancelled on the cash register: the advance on the room bill remains used. The cancellation was not made.",\r
"Receipt paid by card without terminal connection (manual confirmation)",\r
"The receipt from the screen is on order \\"{0}\\".",\r
"receipt with deferred payment",\r
"Receipt with deferred payment",\r
"RECEIPT WITH DEFERRED PAYMENT",\r
"receipt with deferred payment {0}",\r
"A receipt with deferred payment cannot have another payment method.",\r
"A receipt with deferred payment cannot carry a fee or tax outside the receipt: the summary receipt covers only the receipt amounts.",\r
"A receipt with deferred payment cannot carry a fee: the summary receipt covers only the receipt amounts.",\r
"A receipt with deferred payment has no IKOF, so it cannot go into a summary receipt.",\r
"A receipt with a gift voucher (voucher sold or paid by voucher) is returned only by cancelling the entire receipt. The amount is then returned to the voucher.",\r
"The receipt refers to its own IKOF as the advance receipt.",\r
"The receipt refers to its own IKOF among the reference receipts.",\r
"The receipt cannot be signed ({0}). The receipt was not issued. Check the certificate (Settings → Fiscalization).",\r
"The receipt is not paid and not sent to the Tax Administration. A deleted receipt can be restored to the screen and paid (More → Deleted receipts).",\r
"The receipt refers to {0} receipts, and the Tax Administration accepts at most 1000. Several summary receipts must be issued.",\r
"Room account",\r
"Room account {0}",\r
"The room bill has just been changed. Nothing was issued.",\r
"The room bill was not found on the server.",\r
"The room bill is currently being paid on another cash register.",\r
"The table's receipt is unreadable.",\r
"The receipt is no longer the last issued or more than {0} min have passed. Cancellation is possible from the receipt overview (Receipts → receipt → Cancel).",\r
"Accommodation receipt and summary receipt for room consumption",\r
"racun_uid TEXT",\r
"Receipt: {0} · {1}",\r
"Receipts",\r
"Receipts with a discount",\r
"Counted from the guest's time of arrival.",\r
"receipts. For the rest, narrow the period or the search.",\r
"Calculate IKOF and QR",\r
"The computer is not connected to the local network (Wi-Fi / cable). The phones cannot find it.",\r
"računi",\r
"Receipts",\r
"receipts without a customer",\r
"Receipts no.",\r
"Receipts and reports",\r
"Receipts on hold",\r
"Receipts on hold ( ) — not charged",\r
"Receipts on hold ({0}) — not charged",\r
"Receipts on hold ({0}) stay saved after closing.",\r
"receipts deleted and items removed before payment, last 48 h; older ones are seen by the supervisor",\r
"receipts deleted and items removed before payment, last 48 h; older ones are visible to the manager",\r
"receipts deleted and items removed before payment, last 48 h; older ones are seen by the supervisor",\r
"Receipts deleted before payment, with all the items entered. Every deletion is recorded: who, when, what, how much, why",\r
"Receipts included in the summary receipt",\r
"Receipts paid from an advance",\r
"Work",\r
"WORK",\r
"Working through a local IRIS server (certificate of its own CA) requires register version 1.8.0 or newer (a new Setup). A local server is not yet supported on Android.",\r
"Working through a local IRIS server requires a new cash register Setup (1.8.0 or later).",\r
"Working —",\r
"Working — {0} tables on the menu, orders arrive at this cash register",\r
"works with general prices",\r
"RADLER",\r
"Working store",\r
"Action",\r
"The action has already been processed.",\r
"The action does not have a valid number.",\r
"An action with that number already exists (another phone).",\r
"Job position",\r
"Cash register working hours today: {0}–{1}.",\r
"RAKIJA",\r
"RAKIJA DUNJA",\r
"RAKIJE",\r
"Crustaceans",\r
"RAMAZZOTTI",\r
"Earlier customers",\r
"Earlier departure",\r
"unpacked it would be larger than {0} MB",\r
"Available (room-nights)",\r
"A range or a list, separated by commas.",\r
"Floor layout",\r
"The floor layout has been saved.",\r
"Allocated",\r
"{0} more than the receipt amount has been allocated.",\r
"RAUCH",\r
"Goods discharge 134000 — PAZ+IZF vouchers vs takings incl. VAT (goods invoices add their amount)",\r
"Difference",\r
"Difference (terminal − register)",\r
"Amount difference: terminal − register (excluding manual confirmations)",\r
"Closing difference of at least (€)",\r
"Difference at shift closing: {0} {1} €",\r
"The difference is visible on the closing report (Z).",\r
"Difference: {0}",\r
"Reason",\r
"Reason (e.g. guest changed their mind)",\r
"A reason for deletion is required (e.g. \\"guest changed their mind\\").",\r
"Write-off reason",\r
"A reason for opening the drawer is required.",\r
"Reason for return",\r
"A reason for the return is required.",\r
"Reason for viewing",\r
"Cancellation reason",\r
"reason",\r
"Exchange now",\r
"Exchanged with the server: sent {0}, received {1}{2}",\r
"Exchange",\r
"Exchange goes through a folder (Google Drive); the cash register is not connected to the IRIS CORVINA server.",\r
"Exchange via folder (Google Drive)",\r
"Exchange via folder (Google Drive){0} · the register is not paired with the server",\r
"Exchange via folder",\r
"Exchange via server:",\r
"Exchange via server: {0}{1}",\r
"Exchange with Accounting and Manager goes through the server: the register sends shift closings, price changes and new items, and receives the price list and price changes, within a few seconds as soon as the internet is available. A paired register does not need an exchange folder; {0}it is used only for backup (section below). Selling and printing do not depend on the server.",\r
"Exchange with Accounting is not set up. The cash register must be paired with the server (Settings → IRIS CORVINA server) or the exchange folder must be set (Settings → Google Drive).",\r
"Exchange with the server is in progress.",\r
"Exchange with the server: {0}",\r
"Exchange with the server…",\r
"Exchange: no new changes.{0}",\r
"Reception",\r
"Reception (guests' personal data)",\r
"Hotel reception",\r
"Reception requires the register to be connected to the server and the hotel turned on (Settings → Business mode).",\r
"Prescription",\r
"Prescription {0}: {1}",\r
"Prescription {0}: the medicine is not on the receipt.",\r
"The prescription expired on {0}.",\r
"The prescription has already been dispensed.",\r
"RED BULL",\r
"REDBULL",\r
"Serial number",\r
"The sequence number must be zero or a positive integer.",\r
"The receipt sequence number must be a positive integer (given: {0}).",\r
"Order",\r
"Order on the menu",\r
"Order within the group",\r
"Rows",\r
"ref TEXT",\r
"Reference receipt {0}…: the issue time is not in the form 2026-07-31T07:01:00+02:00.",\r
"Reference receipt: the IKOF is not valid (\\"{0}\\").",\r
"RELKON",\r
"REMY MARTIN",\r
"PIN reset (service): {0}, cashier: {1}",\r
"Resetting the register supervisor's PIN requires an order SIGNED with the issuer's key — in IRIS Admin issue an order with the role admin/owner (signed). The order was not executed.",\r
"REXONA",\r
"res. {0} · {1} pers.",\r
"REZANC",\r
"Reservation",\r
"The reservation has been cancelled.",\r
"The reservation has been confirmed again. Register the guest's arrival.",\r
"The reservation has been saved.",\r
"The reservation has been entered.",\r
"The reservation is closed: the guest did not show up.",\r
"Reservation not found.",\r
"Reservations",\r
"The reservation was changed in the meantime by another user. The view has been refreshed.",\r
"Reserved type",\r
"Reserved",\r
"Database backup to this folder works from register installation 1.3.6 (new Setup). Until then the register makes daily copies in its own data folder (Kopije).",\r
"Backup to a folder requires cash register version 1.3.6 or newer (new Setup).",\r
"Backup to the folder: {0}",\r
"Backup: {0}",\r
"Mode",\r
"Mode",\r
"Regime {0} is not dispensed at the expense of FZO in a private pharmacy.",\r
"Pharmacy mode (prescription medicine only with a prescription and a pharmacist, no returns of medicines)",\r
"Pharmacy mode is not turned on (⋯ More → Pharmacy settings).",\r
"Pharmacy mode, connection with the FZO, co-payment, pharmacists",\r
"Operating mode",\r
"Results",\r
"Fish",\r
"RIBLJI ŠTAP",\r
"RIFF",\r
"right",\r
"Resolved",\r
"RIZA",\r
"RIŽA",\r
"RIZLA",\r
"The language dictionary is not valid.",\r
"goods that cannot be sold or returned; deducted from stock, the document is not fiscal",\r
"The goods to be written off are entered (scanned) on the screen as for a sale, and then the write-off is selected (More → Goods write-off).",\r
"of goods",\r
"Due",\r
"deadline passed {0} ago",\r
"Police deadline: {0}",\r
"Deadline for registration with the police",\r
"Deadline for registration with the police (hours)",\r
"Deadline for registration with the tourist organisation",\r
"Deadline for registration with the tourist organisation (hours)",\r
"Payment deadline (days)",\r
"document validity period",\r
"The validity period can be at most {0} days.",\r
"The validity deadline cannot be before the day the pro forma was created.",\r
"The pro forma validity deadline is not a valid date.",\r
"The deadline for sending receipts to the Tax Administration is 48 hours from issue. Check the internet connection; to send: click the indicator.",\r
"ROL",\r
"ROSA",\r
"ROSE",\r
"ROSTILJ",\r
"ROŠTILJ",\r
"ROTHMANS",\r
"Rožaje",\r
"ROZE",\r
"manual confirmation",\r
"Manual confirmation",\r
"cashier manual confirmation",\r
"Manual confirmation from the slip",\r
"manual report",\r
"Choose an item manually (when the barcode cannot be read)",\r
"Manual discount {0} % (without the manager at most {1} %)",\r
"Manual discount without supervisor PIN, at most (%)",\r
"A cashier's manual discount (on items without a promotion and on the whole receipt) above this percentage of the goods value requires the supervisor's PIN at payment. Promotions and loyalty customers are not counted. 0 or empty = no limit.",\r
"Manual discount greater than (%)",\r
"Manual discounts",\r
"Manual",\r
"manual",\r
"RUKAVIC",\r
"RUM",\r
"Russian",\r
"With a price or sales at this location",\r
"Part of the goods has already been returned from this receipt (return). The cancellation was not done. The remainder is returned through \\"Return part of goods\\".",\r
"Including VAT",\r
"From recent invoices",\r
"Part of the goods cannot be returned from a hotel receipt. The whole receipt is cancelled, and a new one is issued.",\r
"Part of the goods cannot be returned from a receipt paid from an advance. The whole receipt is cancelled, and a new one is issued.",\r
"Part of the goods cannot be returned from a receipt with deferred payment. The whole receipt is cancelled, and a new one is issued.",\r
"From table",\r
"Part of a summary receipt cannot be returned. The whole summary receipt is cancelled.",\r
"it is compressed in a way the cash register cannot read",\r
"template",\r
"Save",\r
"Save items for the scale (CSV)",\r
"Save without order ticket",\r
"Save domain",\r
"Save guest",\r
"Save changes",\r
"Save changes from this register to file",\r
"Save as a table (CSV)",\r
"Save catalogue to file",\r
"Save rules",\r
"Save pro forma",\r
"Save layout",\r
"Save table for labels (CSV)",\r
"Group {0} saved.",\r
"Saved: {0}",\r
"Saved: {0}.",\r
"Saved.",\r
"Now",\r
"now {0}{1} · {2} price · code {3}",\r
"Now: demo register",\r
"the content of the file tajne.json is corrupted",\r
"the content was corrupted in transfer",\r
"The content was changed in the meantime in another program. The new state has been loaded; the change was not saved.",\r
"it contains shortcuts (links)",\r
"Agrees to notifications and offers",\r
"Consent given {0}{1}.",\r
"Consent from",\r
"Consent withdrawn {0}.",\r
"Website",\r
"Hide the entire group from the menu",\r
"hidden",\r
"hidden",\r
"Dining room",\r
"SALAMA",\r
"Balance",\r
"Balance {0} EUR",\r
"balance {0} EUR",\r
"The room account balance is {0} EUR. Check out the guest with an unsettled balance?",\r
"The room account balance is not settled: {0} EUR.",\r
"Sending {0}…",\r
"sending",\r
"Sending to the Tax Administration: {0} remaining",\r
"Send receipts to the Tax Administration",\r
"Send technical errors to the publisher",\r
"SALVET",\r
"SAMBUCA",\r
"only without English",\r
"Kitchen screen only (no paper)",\r
"Only the shop's local network.",\r
"Only holders who gave consent and have not withdrawn it. Every export is recorded in the access log.",\r
"through the server only",\r
"through the server only (the folder is not used for exchange)",\r
"Only rooms to clean",\r
"SAMPANJAC",\r
"ŠAMPANJAC",\r
"ŠAMPANJCA",\r
"SAMPON",\r
"ŠAMPON",\r
"BAR",\r
"SAPUN",\r
"SARDIN",\r
"SAT",\r
"The clock has been confirmed. The payment must be repeated.",\r
"The phone and cash register clocks differ by more than 10 minutes. Turn on automatic time on the phone and check the cash register clock.",\r
"sat TEXT",\r
"The background clock was not started: {0}",\r
"Background clock: {0}",\r
"Background clock: unreadable worker message",\r
"Device clock",\r
"the device clock showed {0}.{1}. {2}",\r
"The device clock has been confirmed.",\r
"the device clock was set forward at the time of deletion",\r
"The device clock was set back: the last receipt was issued {0}, and the clock now shows an earlier time. {1}",\r
"The device clock was set back: the supervisor confirmed the clock {0}, and the clock now shows an earlier time. {1}",\r
"The device clock shows a time earlier than the last receipt (or the last clock confirmation). The clock may have been set forward and then corrected.\\n\\nIf the clock is now correct, the supervisor confirms it and the register continues issuing receipts. If not, the device date and time must be adjusted.",\r
"SAUVIGNON",\r
"SAVANNA",\r
"Šavnik",\r
"The digest does not match the message content.",\r
"Scan for the menu & ordering",\r
"SCHWEPP",\r
"did not start on this register",\r
"SECER",\r
"ŠECER",\r
"ŠEĆER",\r
"manager",\r
"Manager",\r
"a manager always has it",\r
"The manager has no PIN, so manager approval is not requested. The PIN is entered with the \\"Edit\\" button.",\r
"manager with a PIN",\r
"register supervisor",\r
"select",\r
"selected",\r
"Mustard",\r
"SENF",\r
"SENSATION",\r
"September",\r
"September",\r
"Batch",\r
"Batch {0} has been withdrawn from sale ({1}). Medicine from that batch is not dispensed.",\r
"the batch has been withdrawn from sale",\r
"serija TEXT",\r
"Serial / USB port (COM)",\r
"The serial port is closed.",\r
"The serial port requires a new register Setup (shell 2111).",\r
"Serial ports: {0}",\r
"Serial ports…",\r
"Certificate",\r
"The register's certificate and keys could not be read at startup, so the connection to the server cannot be recorded either. The register must be restarted. If the error repeats: Settings → Fiscalization → \\"Discard unreadable keys…\\".",\r
"The certificate and keys are unreadable",\r
"The certificate and keys are unreadable (Fiscalization section). Until this is resolved, entering the server connection is not possible.",\r
"The certificate and keys were NOT saved — the file tajne.json cannot be written ({0}). The existing file was not touched.",\r
"The certificate and keys were not written in full; the existing file was left unchanged.",\r
"The certificate and keys are read correctly, so there is nothing to discard.",\r
"The certificate and keys could not be read at startup, so they cannot be changed now either. The cash register must be restarted. If the error repeats: Settings → Fiscalization → \\"Discard unreadable keys…\\".",\r
"The certificate and its key are deleted from this register. The register switches to the test key and stops sending receipts to the Tax Administration.\\n\\nTo send again, the certificate must be imported again from the file.{0}",\r
"The certificate expired on {0}. A new certificate is required.",\r
"The certificate has expired. A new certificate is required.",\r
"The certificate was issued for PIB {0}, but the company PIB in settings is {1}. A certificate of this company is required. If the cash register belongs to another company, change the company (Settings → Company on receipt) and select the register from that company's price list.",\r
"The certificate has been revoked.",\r
"The certificate has been removed",\r
"The certificate has been imported",\r
"the local server certificate has expired (check the date on the computer)",\r
"the local server certificate is not yet valid (check the date on the computer)",\r
"The certificate was not issued by a registered issuer (CA). A fiscalization certificate (CoreIT or Pošta CG) is required.",\r
"The certificate is not valid.",\r
"The certificate cannot be read or is not RSA (X.509).",\r
"The certificate cannot be read: {0}",\r
"The server certificate does not match the remembered CA fingerprint of the local server — the connection was interrupted",\r
"the server certificate does not sign the remembered CA of the local server",\r
"the server certificate is not readable",\r
"the server certificate is not signed by the remembered CA of the local server",\r
"The certificate is valid only from {0}.",\r
"The fiscalization certificate expired on {0}. Receipts are issued, but cannot be sent to the Tax Administration until a new certificate is imported (Settings → Fiscalization). The deadline for late submission is 48 hours.",\r
"The fiscalization certificate is valid until {0}. A new certificate must be imported in time (Settings → Fiscalization).",\r
"The certificate, the signing key and the server password could not be read ({0}). The data was not changed. The cash register must be restarted. If the error repeats, the keys can be discarded and the certificate imported again (Settings → Fiscalization). Until then the cash register works in trial mode, without sending data.",\r
"Server",\r
"IRIS CORVINA server (exchange)",\r
"The server reports a different CA fingerprint than the pairing link. The connection was not established.",\r
"The server rejected this register (the device is disabled on the server). The register retries every 15 minutes. To continue working, the connection must be disconnected (\\"Disconnect\\") and the register paired with a new code.",\r
"The server rejected this cash register.",\r
"The server rejected the entry: {0}",\r
"The server responded with error {0}.",\r
"The server returned a response that is not JSON.",\r
"The server at address {0} is not responding.",\r
"The server is not responding ({0} s). The exchange continues in the background; register files wait in the send queue.{1}",\r
"The server is not responding (timed out).",\r
"The server does not return the request status to the cash register. The publisher's reply (approved / rejected) arrives through support messages (the Messages tab).",\r
"The server does not support cancellation of a summary receipt (old server version). The items on the server were not returned to waiting; a server upgrade is required.",\r
"Server unavailable",\r
"The server is not available — the re-receipt was not done.",\r
"The server is not available. Register files wait in the queue and are sent when the connection is established.{0}",\r
"The server is not available. Order outcomes are waiting to be sent.",\r
"The server is not set up.",\r
"the server did not send a certificate",\r
"The server did not receive",\r
"The server did not accept a change from this cash register: {0}",\r
"The server returned no item with a price. The catalogue was not changed.",\r
"Server refused",\r
"Server rejected the change",\r
"The server refused the change: {0}",\r
"The server manages this register under a different identifier ({0}), while the register now works as {1}, so the server rejects its files (price changes, closings). The register must be paired again (Settings → Server: \\"Disconnect\\", then \\"Pair\\" with a new code) or a change of identifier requested from the issuer (Support → Request).",\r
"The server manages this cash register under a different code.",\r
"The waiter phone server is not on — the tablet cannot connect.",\r
"The update server responded with an error (HTTP {0}).",\r
"The update server is not available ({0}).",\r
"The update server is not available. There may be no network connection.",\r
"Receipt server — ERPNext (legacy, optional)",\r
"The server for phones did not start: {0}",\r
"Server at address {1}.\\n\\nCertificate fingerprint (CA):\\n{2}\\n\\nThe fingerprint must be compared with the one on the \\"Overview\\" screen of the IRIS Server program on the computer in the shop. After pairing, the register accepts only the certificate of this CA.",\r
"SERVICE",\r
"The Tax Administration service is currently not working. Sending is repeated automatically.",\r
"service orders: executed {0}, errors {1}",\r
"SET",\r
"Seasonal pause from {0} to {1} The program works only for reading and exporting data.",\r
"Seasonal worker with registered residence",\r
"SHA-256",\r
"show",\r
"Code",\r
"code",\r
"Code",\r
"Code {0} · price {1} (the price is changed by tapping the price in the list).",\r
"code {0} · VAT {1} %{2}{3}",\r
"code {0}{1}",\r
"code {0}{1} · {2} · VAT {3} %{4}",\r
"Code {0}{1}{2}",\r
"Code / barcode (e.g. 3*7613…)",\r
"Code / barcode / part of the name",\r
"sifra = ?",\r
"The item code is required.",\r
"voucher code",\r
"Voucher code",\r
"The code must not contain spaces.",\r
"Code not found. Search results are shown.",\r
"sifra, naziv, cijena, pdv_stopa, jm, grupa, podgrupa, svoja, cijena_vrijeme, cijena_utc, grupa_id, proizvodjac, neto, neto_jm, pakovanje, max_zaliha",\r
"SIGNAL",\r
"SIJALIC",\r
"Syncing…",\r
"synthetic",\r
"Synthetic",\r
"SIR",\r
"SIRCE",\r
"SIRĆE",\r
"Roll width",\r
"Raw printing failed: {0}",\r
"grey",\r
"Scan — menu and ordering",\r
"Scanned item with an expired date: {0} (expiry {1}{2})",\r
"Remove from the waiting list without printing (labels are already on the shelves)",\r
"Remove 1",\r
"Remove one piece from the table?",\r
"Shorten the stay",\r
"Shorten by a night",\r
"SLADOLED",\r
"SLANINA",\r
"Sending the log is not supported in this version of the program.",\r
"Sending has been disabled. The register is running in test mode.",\r
"Sending is disabled. \\"Send receipts to the Tax Administration\\" must be enabled and the settings saved.",\r
"Sending is complete.",\r
"Sending to the Tax Administration is not set up.",\r
"Sending to the Tax Administration is turned off, and there are unsent messages. Sending is turned on in Settings → Fiscalization.",\r
"Sending to the Tax Administration is turned off To turn on: Settings → Fiscalization → \\"Send receipts to the Tax Administration\\", then \\"Save\\".",\r
"Sending to the Tax Administration is enabled, but the cash register is not ready: {0} The receipt was not issued. The cause must be removed (Settings → Fiscalization / Cashiers) or sending turned off.",\r
"Sending to the Tax Administration is still pending ({0}). Switching to the trial environment is not possible until everything has been sent.",\r
"Sending to the Tax Administration is not set up.",\r
"Sending to the Tax Administration is not turned on.",\r
"Sending to the Tax Administration…",\r
"Uploading an image is not supported in this program.",\r
"Uploading image…",\r
"Sending technical errors to the issuer is turned off (Settings → Support and errors).",\r
"sending of technical errors is turned off (Settings → Support and errors)",\r
"Sweets",\r
"SLATKO",\r
"SLAUF",\r
"Blind / deaf-mute person, person with autism",\r
"Blind cash count (the cashier does not see the expected amount)",\r
"Blind counting: the supervisor and the closing (Z) report show how much should be in the register.",\r
"Blind count: the counted cash is entered below. The expected balance and the difference are visible after closing; the manager sees them before.",\r
"image",\r
"The image is smaller than {0} × {1} pixels.",\r
"The image was corrupted in transfer.",\r
"The image was uploaded. The change has not been saved yet.",\r
"The image is empty.",\r
"The image is too large and cannot be reduced enough.",\r
"The image is larger than {0} KB.",\r
"The image must be in PNG, JPEG or WebP format.",\r
"Image not available",\r
"The image was not found.",\r
"The attached image must be a PNG or JPEG data URL (base64).",\r
"The next dispensing on a renewable prescription is possible from {0}.",\r
"Next day",\r
"The next receipt gets a number one higher.",\r
"SLJIVOVICA",\r
"ŠLJIVOVICA",\r
"off",\r
"Free advance",\r
"The free advance of {0} EUR is counted toward the payments.",\r
"Vacant",\r
"Vacant, clean",\r
"vacant rooms",\r
"Vacant rooms of this type in the period: {0}.",\r
"Free",\r
"small",\r
"SMASH",\r
"SMINK",\r
"ŠMINK",\r
"SMIRNOFF",\r
"Shift",\r
"Shift #{0}",\r
"Shift #{0} has been opened (float {1}).{2}",\r
"Shift #{0} has been closed (Z).",\r
"Shift #{0} is being closed and can no longer be changed afterwards.",\r
"The shift is still open. The interim report (X) is under \\"Shift\\".",\r
"The shift was opened on {0} and has {1} receipts ({2}).\\n\\nA closing (Z) is required before today's sales: takings are recorded on the closing date, so the earlier day's turnover would be entered under today's date.",\r
"A shift is open and has receipts. Another register can be chosen only after the shift closing (Z).",\r
"A shift is open and has receipts. Changing the cash register is possible only after the shift closing (Z).",\r
"A shift is open and has receipts. Changing the cash register code (ENU) is possible only after the shift closing (Z).",\r
"A shift is open. A shift closing (Z) is required.",\r
"The shift is already open and has receipts. The opening float was not changed.",\r
"The shift was not found.",\r
"Shift from an earlier day",\r
"shift open",\r
"The shift has changed in the meantime. The current state is shown.",\r
"The shift already has receipts. The opening float cannot be changed; the difference is recorded as a deposit or withdrawal.",\r
"shift: {0} · {1}",\r
"Shifts",\r
"Accommodation",\r
"Accommodation (incl. VAT)",\r
"Accommodation paid by",\r
"SMOKI",\r
"SMOOTHIE",\r
"SMRZNUT",\r
"Frozen foods",\r
"frozen",\r
"SNICKERS",\r
"the database snapshot was not read in full ({0} of {1} bytes)",\r
"the database snapshot was not written in full",\r
"the database snapshot was not started",\r
"The database snapshot at startup failed ({0}). Receipts are saved in the log. Free up space on the device.",\r
"Saving the database failed: {0}",\r
"SO",\r
"Room",\r
"room {0}",\r
"Room {0}",\r
"Room {0} — {1}",\r
"Room {0} — {1}{2}",\r
"Room {0} — occupied in that period",\r
"Room {0} · {1}\\nPayment to the room is allowed. Amount {2}.",\r
"Room {0} · {1}: charging to the room was refused. {2}",\r
"Room {0} is not occupied.",\r
"Room {0}: {1}.",\r
"Room {0}{1}",\r
"The room is occupied in that period: {0}",\r
"The room is occupied: {0}",\r
"The room is not marked as clean.",\r
"A room with code {0} already exists.",\r
"rooms to be cleaned",\r
"Rooms",\r
"Rooms to clean",\r
"rooms, reservations, guests, room bill, advance payment and collection",\r
"Rooms: {0} in total, {1} occupied, {2} vacant, {3} to be cleaned, {4} out of service.",\r
"SOBRANIE",\r
"SODA BIKARB",\r
"Soy",\r
"SOK",\r
"SOMERSBY",\r
"Company's own domain: {0}",\r
"Own domain: not entered.",\r
"SOS",\r
"SPAGET",\r
"ŠPAGET",\r
"merging",\r
"span",\r
"The service specification and certificate are provided by the FZO to a contracted pharmacy.",\r
"The label list is empty.",\r
"The list has {0} items; the receipt roll will be long.\\nFor a shorter list, narrow the period or the search.",\r
"The list is empty. Items are added by barcode, code or part of the name.",\r
"Pro forma list",\r
"Floor",\r
"Floor {0}",\r
"Qualification",\r
"ready",\r
"Ready: {0}",\r
"SPRITE",\r
"SPUMANTE",\r
"Wed",\r
"Wednesday",\r
"Serbian (Cyrillic)",\r
"ST",\r
"What happens to the paid advance when the guest cancels.",\r
"What is being charged",\r
"Fixed fields",\r
"Print",\r
"Printing is waiting: the printer selection window is open. The following documents are printed in order after that window is closed.",\r
"Printing was interrupted — the computer ran out of memory for this document. Close the cash register and start it again (printing does not work until then); print a long report in parts.",\r
"Printing is not available on this device.",\r
"Printing failed: {0}",\r
"Print of written-off goods by item",\r
"Print the last receipt",\r
"Print of turnover by item",\r
"Printer",\r
"Printer",\r
"Printer \\"{0}\\" does not accept a raw job (ESC/POS) — choose the network mode or another printer.",\r
"Printer \\"{0}\\" was not found in Windows (check the exact name in Settings).",\r
"Printer \\"{0}\\" did not receive all the data — check the connection and paper.",\r
"The printer \\"{0}\\" was not found in Windows. Select a printer in Settings (Receipt and printing).",\r
"Printer {0}:{1} is not responding.",\r
"Printer {0}:{1}: {2}",\r
"Drawer printer",\r
"The printer is ready.",\r
"No printer is selected (selection at every print). After every payment a printer selection window opens and takes focus from the register; documents are printed in order, only when the previous window is closed. For printing without that window, select a printer or \\"Default printer (Windows)\\".",\r
"The printer did not report its status.",\r
"the printer did not respond within 60 seconds",\r
"Order ticket printer (kitchen)",\r
"Bar printer",\r
"Print",\r
"Print label",\r
"Print immediately after payment",\r
"printing was refused",\r
"Printed",\r
"Standard Buying",\r
"Balance",\r
"Register balance",\r
"balance at the start of the day",\r
"Reservation status",\r
"The sending status cannot be read:",\r
"The sending status cannot be read: {0}",\r
"STAPIC",\r
"ŠTAPIĆ",\r
"Old",\r
"stara_svoja INTEGER",\r
"Old code",\r
"Old QR codes with the IRIS address still work.",\r
"Older (supervisor)…",\r
"STARK",\r
"ŠTARK",\r
"STAROPRAMEN",\r
"StartPagePrinter(h); int w; bool ok = WritePrinter(h, b, b.Length, out w); EndPagePrinter(h); EndDocPrinter(h);",\r
"Status",\r
"status = 'obrisan'",\r
"status = 'otvoren'",\r
"The certificate status is unknown.",\r
"Put on hold",\r
"Put on table {0}",\r
"item",\r
"item {0}",\r
"Item {0} (\\"{1}\\"): the amount {2} is greater than quantity × price ({3}).",\r
"Line {0} is not item {1}.",\r
"Line {0} is not on this receipt.",\r
"Item {0}{1}",\r
"The item has been written off.",\r
"The item has been voided.",\r
"The item has already been sent to the kitchen / bar. Deletion is approved by the supervisor: the supervisor's PIN and a reason are required.",\r
"The line has already been sent to the kitchen / bar. Removal is approved by the supervisor (PIN and reason); a CANCELLATION goes to the kitchen.",\r
"items",\r
"Items",\r
"Put the items on hold (customer is fetching money)",\r
"The order items are removed from the table; for items already sent, a cancellation goes to the kitchen / bar.",\r
"The items are on hold (Held → Return to screen).",\r
"The items have already been charged on another receipt. This receipt should be cancelled.",\r
"Items removed before payment ({0})",\r
"Items removed from the receipt before payment (removing an item or reducing the quantity), after which the receipt was issued. Every deletion is recorded: who, when, what, how much.",\r
"items",\r
"Items",\r
"STELLA",\r
"A price list from Accounting has arrived. You must choose which cash register this is.",\r
"arrived",\r
"STIKS",\r
"ŠTIPALJK",\r
"Table",\r
"Table \\"{0}\\" does not exist. Tables are entered on the cash register (Settings → Hospitality).",\r
"table {0}",\r
"Table {0}",\r
"table {0} ({1})",\r
"Table {0} is on hold.",\r
"Table {0} is empty.",\r
"Table {0} has been moved to {1}.",\r
"Table {0} has been taken over.",\r
"Table {0} is free.",\r
"Table {0} has been merged with table {1}.",\r
"Table {0} is currently open on the cash register. It can be changed once the cashier releases the table.",\r
"Table {0} is handled by {1}. The table can be taken over.",\r
"Table {0} is handled by {1}. To merge, that table must be taken over first.",\r
"Table {0}: the guest cancelled the order (QR menu). The table is open on the register; the items are removed when the table is returned (To table).",\r
"Table {0}: the guest cancelled the order (QR menu).{1}",\r
"Table {0}: guest asks for the bill ({1}).",\r
"Table {0}: guest requests the bill.",\r
"Table {0}: guest is calling the waiter.",\r
"Table {0}: the order ticket for the guest's order was not printed. The printer is not available.",\r
"Table {0}: the guest's order (QR menu) is waiting. The table is open on the register; the order is added when the table is returned (To table).",\r
"Table {0}: guest order (QR menu), items: {1}, amount {2} €.{3}",\r
"Table {0}: the guest's order was rejected ({1}).",\r
"Table {0}: the guest's order was not processed ({1}).",\r
"Table {0}: the cancellation (guest's order cancelled) was not printed.",\r
"Table {0}: the cancellation was not printed ({1}). The kitchen / bar needs to be notified.",\r
"Table {0}: cancellation of a sent item ({1}).",\r
"Table {0}{1}",\r
"The table is on screen. It needs to be put back on hold first (\\"To table\\").",\r
"The table is open on the register (payment). Changes from the phone are not possible.",\r
"The table is empty.",\r
"The table was closed in the meantime.",\r
"The table is already closed on the register — call the waiter.",\r
"No table is selected (the \\"Tables\\" button).",\r
"sto TEXT",\r
"The table no longer exists on the register — call the waiter.",\r
"Table handled by",\r
"STOCK",\r
"tables on the menu, orders arrive at this cash register",\r
"Tables",\r
"Tables (names, comma-separated)",\r
"Tables (waiter)",\r
"The tables must be different.",\r
"Tables have not been entered (Settings → Hospitality, e.g. \\"1, 2, 3, Bar\\").",\r
"Tables have not been entered (Settings → Hospitality).",\r
"Drag the tables into place as they stand in the room. The table overview shows them in that layout.",\r
"Tables are shown in a grid.",\r
"Tables: table on screen, moving, splitting the bill",\r
"Rate",\r
"Rate on the advance receipt",\r
"Rate on food",\r
"Rate on food with accommodation (%)",\r
"Rate on the cancellation fee",\r
"Rate on accommodation",\r
"VAT rate (%)",\r
"VAT rate on the advance receipt (%)",\r
"VAT rate on the cancellation fee (%)",\r
"accommodation rate",\r
"Cancellations",\r
"cancellations {0}",\r
"Void",\r
"Cancel receipt…",\r
"cancelled",\r
"Cancelled",\r
"Cancelled",\r
"stornirao_uid TEXT",\r
"void",\r
"Void",\r
"Cancellation ({0})",\r
"A cancellation of a hotel document cannot be issued without an IKOF (fiscalization is not enabled or there is no certificate). The cancellation was not made.",\r
"cancellation receipt",\r
"Cancellation receipt",\r
"A cancellation receipt cannot be cancelled.",\r
"Cancelling the receipt",\r
"Cancellation of receipt {0}",\r
"Cancellation of receipt {0}{1}",\r
"Cancellation of receipt no.",\r
"Receipt cancellation on the cash register",\r
"Cancelling a receipt with a prescription requires a reason (e.g. a dispensing error).",\r
"Receipt void: refund to card",\r
"Item void",\r
"CANCELLATION OF A SUMMARY RECEIPT — CORRECTIVE SUMMARY RECEIPT",\r
"A cancellation of a summary receipt must have a negative amount (receipts from the summary with a minus).",\r
"A cancellation of a summary receipt cannot be issued without an IKOF (fiscalization is not enabled or there is no certificate). The cancellation was not made.",\r
"storno_uid TEXT",\r
"cancellation, deletions, large discounts, drawer, cash, differences; supervisor only",\r
"Cancellation, voiding, deletion, large discounts, drawer without a receipt, cash above the limit, difference at closing. The owner sees the same warnings in Manager.",\r
"Foreign",\r
"Foreign guest",\r
"STREČ",\r
"strong",\r
"STRONGBOW",\r
"electricity",\r
"Sat",\r
"Saturday",\r
"SUDZUK",\r
"SUDŽUK",\r
"summary receipt",\r
"SUMMARY RECEIPT",\r
"summary receipt {0}{1}",\r
"The summary receipt is made out to a customer, and some of the receipts were not issued to that customer.",\r
"The summary receipt has already been cancelled.",\r
"A summary receipt must list the receipts it refers to (IKOF, time and amount of each).",\r
"A summary receipt must list the receipts it refers to.",\r
"A summary receipt cannot have a fee: it has no turnover apart from the individual receipts.",\r
"A summary receipt cannot have a discount.",\r
"A summary receipt carries no items: the turnover is already on the individual receipts.",\r
"The summary receipt has no IKOF, so a cancellation cannot be issued.",\r
"The summary receipt has no list of receipts.",\r
"The summary receipt has no totals by rate.",\r
"A summary receipt carries the actual payment method, not deferred payment (ORDER).",\r
"A summary receipt carries the actual payment method, not deferred payment.",\r
"A summary receipt paid from an advance is not cancelled on the cash register: the advance remains used. The cancellation was not made.",\r
"A summary receipt paid by bank transfer is made out to a customer, and the room charge was issued without that customer. Pay the room charge by another method or separately. Nothing was issued.",\r
"A summary receipt can refer to at most 1000 receipts (given: {0}). Several summary receipts must be issued.",\r
"A summary receipt can refer to at most 1000 receipts.",\r
"A summary receipt is cancelled through \\"Receipt cancellation\\" (corrective summary receipt).",\r
"Summary receipt: the same VAT rate is listed twice.",\r
"Summary receipt: the {0} % rate is listed on more receipts than there are in the list.",\r
"Summary receipt: the total of the individual receipts ({0}) is not equal to the total by rates ({1}).",\r
"Sulphur dioxide and sulphites",\r
"SUNCOKRET",\r
"SUNĐER",\r
"SUNDJER",\r
"SUNKA",\r
"ŠUNKA",\r
"SUPA",\r
"Sesame",\r
"sv-SE",\r
"all",\r
"All the goods from this receipt have already been returned.",\r
"Each change is logged as a price change for this point of sale and sent to Accounting.",\r
"Each item in the list is one label with the price and the price per kg / l.",\r
"Each item in the list is one label with the price and the price per kg / l.{0}",\r
"Every opening without a receipt is logged (who, when, why) and the owner sees it in the warnings.",\r
"Each point of sale has its own prices. Choose the register this device is at, or \\"This register at this location\\" when the register is not in the list. The prices of that location are loaded.",\r
"Each point of sale has its own prices. Choose the register this device is at, or \\"This register at this location\\" when the register is not in the list. The prices of that location are loaded.{0}",\r
"all",\r
"All",\r
"All ({0} EUR)",\r
"All groups",\r
"Everything on one summary receipt",\r
"All rooms are clean.",\r
"All items of the table have already been sent. There are no new items for an order ticket.",\r
"all items removed",\r
"All items removed",\r
"all tables ({0})",\r
"all types",\r
"All room types",\r
"SVEĆ",\r
"SVESK",\r
"all",\r
"All",\r
"All menu items are available.",\r
"all cashiers",\r
"All in \\"{0}\\"",\r
"SVIJEĆ",\r
"SVINJ",\r
"own",\r
"Sync now",\r
"Sync: sent {0}{1}, queued {2}",\r
"synced",\r
"sheet",\r
"sheets",\r
"The table has been saved: {0}",\r
"table for electronic labels and items for the scale (PLU)",\r
"Room board",\r
"table",\r
"Tablet over the local network",\r
"exact amount",\r
"on top of",\r
"Exact",\r
"That pro forma is already on screen.",\r
"that receipt has been cancelled",\r
"That receipt is already on the screen.",\r
"That receipt has already been restored and paid.",\r
"Tax on the fiscal receipt",\r
"The tax collected outside the receipt is greater than the actual payments on the receipt.",\r
"The tax is not revenue of the property; it is paid to the municipality.",\r
"Tax is included in the VAT base",\r
"taksa.bezTaksePoslijeNoci",\r
"taksa.danIzvjestaja",\r
"taksa.djecaDo",\r
"taksa.exOznaka",\r
"taksa.rokUplateDana",\r
"taksa.umanjenjeProc",\r
"taksa.umanjenoDo",\r
"taksa.uOsnoviciPdv",\r
"TANQUERAY",\r
"tbody",\r
"td",\r
"TEA",\r
"TECHNICALERROR",\r
"Technical errors waiting to be sent",\r
"technical errors waiting to be sent: {0}",\r
"TEKILA",\r
"The reply text is required.",\r
"The message text is required.",\r
"tel.",\r
"Telephone",\r
"The phone \\"{0}\\" has been disconnected.",\r
"The phone \\"{0}\\" can no longer send orders; to work again it must be paired anew. Disconnect the phone?",\r
"The phone is paired with the register \\"{0}\\".",\r
"The phone has been paired.",\r
"Waiter's phone",\r
"The waiter's phone does not issue receipts: the waiter selects a table on it and sends orders to the shop's main register (over Wi-Fi), and the main register prints the order and issues the receipt. Pairing is done on the main register (Settings → Waiters' phones → \\"Pair phone\\"). Continue?",\r
"The waiter's phone works only on Android.",\r
"The phone must be on the shop's Wi-Fi. The waiter then logs in with their name and PIN (Settings → Cashiers).",\r
"The phone is not paired with this cash register or has been disconnected. It must be paired again.",\r
"The phone sends orders",\r
"telefon TEXT",\r
"The register on Windows receives waiters' phones with Setup 1.4 or newer. A new Setup must be installed.",\r
"Waiters' phones are received only by the register on Windows (Setup 1.4 or newer).",\r
"Waiters' phones (orders over the shop's Wi-Fi)",\r
"Phones work only in \\"Hospitality\\" mode.",\r
"TEQUIL",\r
"TEQUILA",\r
"TEREA",\r
"thermal roll",\r
"The terminal approved a different amount ({0} instead of {1}).",\r
"The terminal is ready.",\r
"The terminal is ready. ({0})",\r
"The terminal returned a response for another transaction.",\r
"The terminal is busy.",\r
"The terminal does not respond.",\r
"The terminal does not support this operation.",\r
"Terminal unavailable: offer manual confirmation",\r
"Terminal net",\r
"The terminal did not receive bank approval.",\r
"Terminal unavailable (test).",\r
"Terminal unavailable: {0}",\r
"Terminal unavailable. The card was not charged.",\r
"The terminal did not report a result (test).",\r
"The terminal did not report the result of the payment {0} ({1}). The card may have been charged. Check on the terminal or the slip whether the payment was approved.\\n\\nApproval number from the slip (if approved):",\r
"The terminal did not report a result within {0} s.",\r
"The terminal did not report a result. The result must be checked on the terminal.",\r
"The terminal did not receive the request.",\r
"Test terminal (no device)",\r
"The test terminal is ready.",\r
"terminal: {0}",\r
"Terminal: {0}",\r
"Terminal: {0} transactions, {1}.",\r
"Terminal: approved ({0})",\r
"terminal: sale {0}",\r
"TEST",\r
"text/html; charset=utf-8",\r
"text/plain; charset=utf-8",\r
"text/xml; charset=utf-8",\r
"textarea",\r
"Weight",\r
"The weight is out of the scale range.",\r
"The weight is not stable. Wait for the scale to settle.",\r
"The weight of goods sold by weight is read from the scale connected to the register. Only a stable weight goes on the receipt; the cashier confirms it. Toledo 8217 (and Dibal / CAS in that mode): command \\"W\\"; CAS: the scale sends the line \\"ST,GS,…kg\\"; generic: any line with a weight.",\r
"th",\r
"thead",\r
"The request body is not valid.",\r
"TIN",\r
"Type",\r
"The type must be: {0}.",\r
"Tivat",\r
"TJESTENIN",\r
"To",\r
"That is already this item's price.",\r
"These are all the items on the table. The whole table can be deleted only on the cash register, with a reason (deletion log).",\r
"TOALET PAPIR",\r
"TOBLERON",\r
"That waiter does not exist (or is not active) on the cash register.",\r
"There is no such deleted receipt.",\r
"That receipt is no longer on hold.",\r
"token {0}:{1}",\r
"TOMATO SOS",\r
"TONIC",\r
"TONIK",\r
"TOPLJENI",\r
"TOST",\r
"tr",\r
"Permanent licence ({0}): no limits, all modules",\r
"traka",\r
"Terminal transaction not found.",\r
"Terminal transactions",\r
"TRAPIST",\r
"TRAVARICA",\r
"Searching the network…",\r
"requires installing a new Setup . Deployment from within the program is not possible.",\r
"Find IRIS Server on the network",\r
"asking for the bill",\r
"Retail (stores, kiosks, shops)",\r
"TROLLI",\r
"Expense",\r
"labour cost in the period",\r
"Expenses",\r
"Three-letter code, e.g. DEU.",\r
"Three-letter code, e.g. MNE.",\r
"Three-letter code.",\r
"Pregnant woman / new mother up to 1 year",\r
"try { DI d = new DI(); d.n = \\"Kasa\\"; d.t = \\"RAW\\"; if (StartDocPrinter(h, 1, d) == 0) throw new Exception(\\"KASA_NE_PRIMA\\");",\r
"TUBORG",\r
"TUNA",\r
"Tourist org.",\r
"Tourist villa",\r
"Tourist apartments",\r
"Turkish",\r
"Tuzi",\r
"TWIX",\r
"type=\\"password\\" inputmode=\\"numeric\\" maxlength=\\"8\\"",\r
"type=\\"text\\" inputmode=\\"decimal\\"",\r
"type=\\"text\\" inputmode=\\"decimal\\" class=\\"iznos\\"",\r
"In the print dialog, an A4 printer or saving as PDF is selected.",\r
"In the print dialog an A4 printer must be selected (the receipt printer is for the roll).",\r
"The file has no item with a code, name and price. The catalogue was not changed.",\r
"The file has no RSA private key. A .pfx/.p12 file with a key is required (not .cer).",\r
"The file has no certificate (X.509) matching the private key.",\r
"in the Dokumenti\\\\Kasa folder",\r
"There is no price list of the company with PIB {0} in the folder, but there is one for PIB {1}. If this cash register belongs to that company, the PIB and name must be changed (Settings → Company on receipt).",\r
"The cash register holds {0} € in cash (limit {1} €) — set aside the excess",\r
"The register holds {0} in cash (limit {1}). The excess must be set aside (Shift → Withdrawal).",\r
"Something has changed in the meantime (shift, hold, sending). It needs to be checked again.",\r
"being charged",\r
"In house",\r
"There are no items in this group.",\r
"There are no receipts in this shift.",\r
"This package has no point of sale for this cash register (\\"{0}\\"). Prices were not changed.",\r
"in this period",\r
"In this period",\r
"In this period the price list requires at least {0} nights.",\r
"There are no points of sale in the company's package. A store is added in Accounting (Settings → Stores) and published to the registers (Register price list → \\"Exchange now\\" or \\"Save price list to file\\").",\r
"The package contains version {0}, but {1} is required — the package is not accepted.",\r
"There is no point of sale {0} in the package.",\r
"That point of sale is not in the package.",\r
"The message contains a control character (the message was not composed in this program).",\r
"The signature is missing from the message.",\r
"The request itself is missing from the message.",\r
"In the last {0} h",\r
"There is no exchange folder in the browser.",\r
"There is no exchange folder in the browser. The file is imported manually.",\r
"OK",\r
"OK",\r
"In the sending queue: {0}.",\r
"OK: {0}",\r
"There is no cash register with code {0} in the list.",\r
"Only receipts with deferred payment (and their cancellations) go into a summary receipt.",\r
"in progress / interrupted",\r
"In hospitality the receipt on the screen is tied to a table: \\"Order\\" prints to the kitchen / bar only what has not yet been sent and puts the table on hold; when paying, an ordinary fiscal receipt is issued. The \\"Put on hold\\" and \\"Held\\" buttons become \\"To table\\" and \\"Tables\\". An item note (✎) is printed on the order ticket.",\r
"In use",\r
"No default printer is set in Windows.",\r
"UBRUS",\r
"School excursion participant",\r
"Load package",\r
"Load package from file…",\r
"Reload",\r
"Load into basket",\r
"Loaded: {0} items ({1})",\r
"Loaded: {0} items, {1} barcodes{3}",\r
"The prices of this location ( ) are being loaded. Issued receipts are not changed.",\r
"The prices of this location ({0}) are being loaded. Issued receipts are not changed.",\r
"Loading prices: {0}…",\r
"Loading prices…",\r
"Loading the file…",\r
"Loading guests…",\r
"Loading waiters from the register…",\r
"Loading the package",\r
"Loading account…",\r
"Loading tables…",\r
"Loading…",\r
"Hospitality",\r
"Hospitality (café, restaurant)",\r
"Hospitality (cafés, restaurants)",\r
"Hospitality (tables, kitchen order)",\r
"built-in version",\r
"built-in Sunmi printer",\r
"Built-in Sunmi printer (manufacturer service)",\r
"uid TEXT",\r
"uid, radnja, barkod, sifra, sa_sifre, naziv, komada, vrijeme, vrijeme_utc, ko, kasir_id, izvor, uredjaj, enu, svoja, upijena, ponistava",\r
"uid, sifra, naziv, jm, pdv_stopa, barkod, stara, cijena, mjesto, enu, pj, vrijeme, ko, izvor, uredjaj, svoja",\r
"Removals:",\r
"Removing the certificate",\r
"Removing the link cannot be undone. The barcode is linked to the item again.",\r
"enabled",\r
"Enabled",\r
"Enabled: the cash register prints a slip that the guest signs.",\r
"Enabled: cash registers in the restaurant and bar record consumption to the room account.",\r
"Enabled: registration with the local tourist organisation is also tracked.",\r
"Enabled: a reservation without check-in the day after arrival becomes \\"No-show\\".",\r
"Enabled: the tax is not calculated per guest.",\r
"Enabled: the tax is taxed at the accommodation rate.",\r
"Turn on the QR menu at the tables (this cash register receives the orders of its location)",\r
"Include changes larger than 3×",\r
"When this option is turned on, the program sends to the shared barcode catalogue: the barcode, item name, unit of measure and VAT rate. Prices, quantities, suppliers and company data are not sent. The data sent is used by all users of the program to suggest a name when an unknown barcode is entered. The option can be turned off at any time; data sent earlier remains in the catalogue.",\r
"Remove",\r
"Remove barcode",\r
"Remove barcode {0}",\r
"Remove from the list",\r
"Remove PIN",\r
"Remove certificate",\r
"Remove image",\r
"Remove {0} from the list?\\nEntered pack sizes remain saved.",\r
"Removed items",\r
"removed before payment",\r
"Removed before payment",\r
"removed before write-off",\r
"Removed before write-off",\r
"removed before the pro forma",\r
"uklonjeno REAL",\r
"Removed from table {0}{1}.",\r
"Ukrainian",\r
"Total",\r
"TOTAL",\r
"TOTAL · discount {0}{1}",\r
"TOTAL · discount is not valid",\r
"Total VAT",\r
"Total discounts",\r
"Total to pay",\r
"ul",\r
"Entry into Montenegro",\r
"Input VAT without the right to deduction (purchases marked \\"no right to deduction\\" + manual addition)",\r
"Input VAT on domestic purchases of goods and services (supplier invoices + equipment/expenses + incidental costs)",\r
"Ulcinj",\r
"ULJE",\r
"Role",\r
"ULOSC",\r
"ULOŠC",\r
"UMAK",\r
"Reduced amount up to",\r
"Reduced amount up to (years)",\r
"Reduction (%)",\r
"Reduction for guests up to the age limit above.",\r
"Reduction: between 0 and 100 %",\r
"Reduced",\r
"Enter barcodes",\r
"UNIMPLEMENTED",\r
"UNIONPAY",\r
"entry",\r
"Entry",\r
"Enter quantity",\r
"The entry of a new item is not cancelled. The item can be marked as \\"no longer sold\\".",\r
"Property entry",\r
"PIN entry",\r
"Enter the amount of counted cash.",\r
"UPALJAC",\r
"UPALJAČ",\r
"paired",\r
"Phone \\"{0}\\" paired.",\r
"paired",\r
"paired register",\r
"The paired register and unsent orders are deleted from the phone. To work again, a new pairing with a QR code from the register is needed.",\r
"Paired Bluetooth devices…",\r
"Paired: {0}",\r
"Pair",\r
"Pair a phone…",\r
"Pairing failed: the QR code is not from this cash register.",\r
"Pairing with the register…",\r
"Pairing with the server",\r
"Pairing a waiter's phone",\r
"UPC-A",\r
"upijena TEXT",\r
"Writing to disk is not possible; the data was not saved. {0} A retry is possible in a minute.",\r
"Writing to disk failed; the data was not saved. ({0})",\r
"Entry to the server is pending: {0}",\r
"Saving property…",\r
"Entering the item's pack size",\r
"Enter the remaining amount",\r
"Recording the previous documents on the server is still waiting for a connection. {0} when the recording is finished.",\r
"A receipt is currently being entered on the screen.",\r
"A receipt is currently being entered on the screen. The deleted receipt was not restored.",\r
"Saving the receipt on screen is in progress. The pro forma was not loaded.",\r
"Saving the receipt…",\r
"Saving rooms…",\r
"Writing to the inbox folder was interrupted.",\r
"A new PIN has been entered and \\"Remove PIN\\" is also checked. Only one of the two is allowed.",\r
"The entered software code belongs to another manufacturer. The software code of this cash register is required.",\r
"Guests entered: {0} of {1}.{2}",\r
"entered manually",\r
"Entered by: {0} · {1}{2}{3}",\r
"Record",\r
"Record deposit",\r
"Record withdrawal",\r
"Enter reservation",\r
"Enter the price per night.",\r
"Enter the guest's first and last name.",\r
"Enter the name of the reservation holder.",\r
"Enter the same domain here and save. The server creates the certificate (https) itself on first opening — up to 1 minute.",\r
"Enter the advance amount.",\r
"Enter the property name.",\r
"Enter the name of each room type.",\r
"Enter the service description.",\r
"Enter the room codes.",\r
"Enter the room code.",\r
"Enter the reason.",\r
"Enter: {0}.",\r
"Entered on the tax item without VAT.",\r
"Inquiry",\r
"Inquiry (does not occupy the room)",\r
"Inquiries",\r
"Inquiries, confirmed, in house",\r
"The paid advance is returned from the room account (Return advance).",\r
"Paid",\r
"Payment",\r
"Payments",\r
"Warnings",\r
"Warnings for the owner",\r
"Warning before expiry (days)",\r
"Referred for spa or climatic treatment",\r
"Device",\r
"Device {0}:{1} does not respond.",\r
"Device {0}:{1}: {2}",\r
"The device will work as a register again (register selection, receipts).",\r
"The device closed the connection.",\r
"Register devices",\r
"USB (OTG cable)",\r
"USB (OTG)",\r
"USB printer (Android, OTG cable)",\r
"using System; using System.Runtime.InteropServices;",\r
"Breaking notes / change",\r
"The service has been added to the room account.",\r
"Services",\r
"Services (IT, agencies, consulting, repair shops, rentals)",\r
"Tue",\r
"Tuesday",\r
"The message UUID is not valid: \\"{0}\\".",\r
"Import prices / catalogue from file…",\r
"Import price changes from file…",\r
"Import key (PEM)…",\r
"Import settings from file (config.json)…",\r
"Import certificate",\r
"Import certificate (.pfx)…",\r
"Import of prices / catalogue",\r
"Catalogue import",\r
"With fiscal receipt no.",\r
"With fiscal receipt no. {0}",\r
"Along with the net quantity unit, the quantity is also entered.",\r
"A unit (net UoM) is also chosen with the net quantity.",\r
"Along with the net quantity, a unit is also entered (KG, G, L, ML, M or KOM).",\r
"with write-off",\r
"with receipt",\r
"For each item, enter the quantity being returned (empty = not returned). The corrective receipt covers only the returned goods; discounts are calculated proportionally. Money is returned as it was paid: bank transfer → by bank transfer (no cash from the register), card only → by card, otherwise in cash.",\r
"VAFL",\r
"Scale",\r
"scale / internal",\r
"The scale did not send a weight.",\r
"Scale: {0}",\r
"Scale: {0} kg (stable).",\r
"Scale: {0} kg = {1}",\r
"Currency",\r
"Outside the fiscal receipt (separate line on the printout)",\r
"Outside working hours",\r
"Out of service",\r
"VANILIN",\r
"VARIKIN",\r
"VAT",\r
"Valid until",\r
"valid until {0}",\r
"valid until {0}{1}",\r
"Applies when the price list has no period for that day.",\r
"Valid from",\r
"vazi_do TEXT",\r
"already {0} h",\r
"Receipt number {0} has already been issued. The counter cannot be moved backwards.",\r
"Receipt number {0} has already been issued. Moving the counter backwards is not possible.",\r
"larger than 3× (marked)",\r
"Vegan",\r
"VEGETA",\r
"Vegetarian",\r
"large",\r
"Large quantity",\r
"Large change: {0} → {1}. To confirm: press Save (Enter) once more.",\r
"Large change",\r
"VELO",\r
"VERMUT",\r
"Version",\r
"version {0}",\r
"Version {0} has been deployed. The register must be closed and opened again.",\r
"Version {0} has been downloaded and deployed.",\r
"Version {0} has been downloaded and is applied at the next start.",\r
"Version {0} has been downloaded and will be applied at the next start. To restart: click the indicator.",\r
"Version {0} has been downloaded and verified.",\r
"Version {0} has been downloaded. To install: click the indicator.",\r
"Version {0} has already been downloaded. The register must be closed and opened again.",\r
"Version {0} did not start on this register",\r
"Version {0} did not start on this cash register, so the previous one was restored. Contact maintenance.",\r
"Version {0} requires installing a new Setup. Deployment from within the program is not possible.",\r
"Installation version",\r
"The version of the cash register installation is unknown — the update is not possible.",\r
"Running version",\r
"Connection",\r
"The link for barcode {0} has been undone.",\r
"The connection is metered (mobile data).",\r
"The connection was interrupted during the download.",\r
"The link has already been cancelled.",\r
"The link was not found.",\r
"The connection works. Signed-in user: {0}",\r
"FZO connection",\r
"The connection to the FZO service is not set up.",\r
"The connection to the FZO service is not set up. The service specification and certificate are provided by FZO to the contracted pharmacy.",\r
"Connection with the issuer",\r
"Connection to server",\r
"The connection to the server has been disconnected.",\r
"The connection to the server has been restored.",\r
"The connection to the server is unavailable. Trying again.",\r
"The connection to the server has not been set up.",\r
"The connection to the server works in an installed register (Windows, Android), not in a browser.",\r
"The connection with the terminal was lost before the response.",\r
"The connection with the terminal was lost: {0}",\r
"The terminal connection requires a new register Setup (shell 2111).",\r
"Connecting to the terminal…",\r
"The connection with the device was lost.",\r
"The connection with the device was not opened.",\r
"The device connection requires a new app version.",\r
"The link no longer exists. Cancellation is not possible.",\r
"Only the manager undoes a barcode link. A manager with a PIN must be entered (Settings → Cashiers).",\r
"VICEROY",\r
"VILJAM",\r
"VILJAMOVKA",\r
"VINJAK",\r
"VINO",\r
"VIOLETA",\r
"Bank transfer",\r
"A bank transfer cannot be combined with other payment methods.",\r
"A bank transfer cannot be combined with cash or card on the same receipt. Two receipts must be issued.",\r
"A bank transfer cannot be combined with cash, card, voucher or instant transfer on the same receipt.",\r
"VIRSL",\r
"VIRŠL",\r
"VISA",\r
"surplus",\r
"More",\r
"Several items have this barcode (choose in the list below).",\r
"Several items have this barcode. Choose the item from the list.",\r
"Split payment",\r
"More payment methods · bank transfer · note…",\r
"No longer in the catalogue: {0}",\r
"more than 3×",\r
"VISKI",\r
"Visa",\r
"Visa valid until",\r
"vjernost_naziv TEXT",\r
"vjernost_telefon TEXT",\r
"own",\r
"VLAZNE MARAM",\r
"VLAŽNE MARAM",\r
"VOĆNI JOG",\r
"VODA",\r
"VODKA",\r
"VOGUE",\r
"VOTKA",\r
"Returned to the guest",\r
"Restoring expired price reductions failed: {0}",\r
"Restoring expired price reductions: {0}",\r
"Rolling back to version {0} is not possible. The database has already been adapted to version {1}, and older versions cannot use it safely.",\r
"Restoring item data failed: {0}",\r
"Restoring a previous version",\r
"Restoring barcode links failed: {0}",\r
"restored → receipt",\r
"restored → receipt{1}",\r
"The version has been restored",\r
"Version {0} has been restored.",\r
"Version {0} has been restored. It is applied at the next start of the program.",\r
"Version {0} has been restored. It is applied the next time the program starts.{1}",\r
"refunded",\r
"Returned",\r
"refunded {0}",\r
"returned {0} manager changes",\r
"{0} refunded to the card.",\r
"Restored and paid:",\r
"vraceno TEXT",\r
"VRANAC",\r
"Restore",\r
"Return advance",\r
"Restore prices",\r
"Restore prices from the company's last package",\r
"Return to screen",\r
"Return to screen and pay",\r
"Return to register",\r
"Restore previous version",\r
"Revert to saved",\r
"Return to service",\r
"Return the device to register mode",\r
"Restore version {0}? Data is preserved. The change takes effect when the program is restarted.",\r
"VREĆA ZA",\r
"Value",\r
"Value of a point (€)",\r
"The value of the points is greater than the receipt amount.",\r
"Value of written-off goods",\r
"The change value is required (e.g. 10 or -5).",\r
"GOODS VALUE",\r
"Goods value:",\r
"Value of removed items:",\r
"Values for approved",\r
"Values for cancelled",\r
"Time",\r
"vrijeme >= ?",\r
"The event time is ahead of the device clock. Check the date and time of the device.",\r
"The event time is not readable.",\r
"The arrival time is entered now; the guest registration deadline runs from it.",\r
"The issue time of the advance receipt is not valid.",\r
"The issue time is not in the form 2026-07-31T07:01:00+02:00 (given: \\"{0}\\").",\r
"The receipt issue time is in the future. Check the device clock.",\r
"The receipt issue time is not readable.",\r
"The time on the receipt is ahead of the device clock. Check the date and time of the device.",\r
"The device time differs from the Tax Administration time by more than allowed (6 hours) or is in the future. Set the correct date and time on the device.",\r
"The deposit change time differs from the Tax Administration time by more than allowed. Set the device clock or send the report as a subsequent submission.",\r
"The reservation time is not valid (e.g. 19:30).",\r
"The sending time is not in the form 2026-07-31T07:01:00+02:00 (given: \\"{0}\\").",\r
"vrijeme_utc TEXT",\r
"vrijeme_z TEXT",\r
"Type",\r
"Type (from Accounting)",\r
"The identification type must be TIN (PIB/JMB).",\r
"Document type",\r
"The register type is not stated in the data from Accounting.",\r
"Property type",\r
"The prescription type is not valid.",\r
"type is selected",\r
"The image type is not valid.",\r
"Room type",\r
"Terminal type",\r
"The request body type is not supported.",\r
"Scale type",\r
"Visa type",\r
"Room types",\r
"The register type (store or kiosk) is determined by Accounting (Register price list → Registers and stores). A wrong type is corrected in Accounting; until then the manager can change it in Settings → Cash register.",\r
"warn",\r
"WC",\r
"WEBP",\r
"WELLNESS",\r
"WHERE {0}",\r
"WHERE aktivan=1",\r
"WHERE kod LIKE ?",\r
"WHERE svoja = 1",\r
"WHISK",\r
"WHISKEY",\r
"WHISKY",\r
"Windows",\r
"Windows cannot unlock the file tajne.json — it is locked by another Windows account or on another computer",\r
"Windows printer (raw)",\r
"A Windows printer exists only on Windows.",\r
"Windows cannot currently unlock the file tajne.json — encryption is not available",\r
"WINSTON",\r
"Wolt, Glovo, Phone",\r
"Wolt, Glovo, phone; an order as a table with a number",\r
"YIPPY",\r
"Z (shift closed)",\r
"Z without an open shift",\r
"For \\"{0}\\" (row {1}) at most {2} can be returned (on the receipt {3}, already returned {4}).",\r
"At most {1} can be returned for \\"{0}\\".",\r
"For item {0} at most {1} can be returned (on the receipt {2}, already returned {3}).",\r
"To clean",\r
"Direct printing and the cash drawer require a new cash register Setup (1.5).",\r
"To install, you must allow installation from this program (phone settings → Install unknown apps), then select \\"Install now\\" again.",\r
"To dispense",\r
"For a register that worked in another program this year, the last receipt number issued by that program is entered; numbering continues from it.",\r
"For a register that worked in another program this year, the last receipt number of that program is entered; numbering continues from it.",\r
"To pay",\r
"To be paid: {0} EUR",\r
"For training and trial, without a company: items are added manually (⋯ More → Items and prices). The company is connected later in Settings → Cash register.",\r
"For the municipality {0} the tax amount is {1} EUR.",\r
"for this day",\r
"There are no reservations for this day.",\r
"The register cannot read the paper status for this printer.",\r
"For this terminal type the register does not send the amount (Settings → Register devices).",\r
"For the period until all the company's devices (registers, Accounting, Manager) are paired with the server: the register writes its files to the folder too, and reads the price list and changes from it too. When all devices are paired, the transitional mode is switched off and the folder is used only for backup. A configured folder is required.",\r
"For payment by bank transfer a customer (PIB and name) must be entered.",\r
"Missing for registration: {0}.",\r
"For a receipt to a company; required for a bank transfer. Natural person: JMBG or ID document number instead of PIB.",\r
"A note is required for the reason \\"Other\\".",\r
"For the item \\"{0}\\", the data of the receipt with deferred payment is missing (issued on another cash register).",\r
"Importing a certificate requires the company PIB (Settings → Fiscalization).",\r
"For version {0}, the new cash register Setup ({1} or newer) must be installed first. This computer has Setup {2}. Cash register data remains saved.",\r
"For version {0}, the new cash register Setup must be installed first. This computer has Setup {2}. Cash register data remains saved.",\r
"A customer (PIB and name) must be entered for a bank transfer.",\r
"The patient's consent is required for substitution.",\r
"Žabljak",\r
"Forget",\r
"Forget register",\r
"Forgotten PIN",\r
"ZACIN",\r
"ZAČIN",\r
"Last check",\r
"Last exchange",\r
"Last",\r
"Recent receipts",\r
"The retained advance is charged as a cancellation fee.",\r
"The retained part is a cancellation fee",\r
"keeps the items and prices that are in it now",\r
"Keep",\r
"Keep for receipt",\r
"Charged",\r
"Charged {0} EUR · paid {1} EUR · balance {2} EUR",\r
"The request was repeated (rejected).",\r
"The request has been sent to the publisher.",\r
"The request is too large.",\r
"The request is already signed.",\r
"A request to the local server requires an https address and the CA fingerprint.",\r
"The request is not valid.",\r
"The request was not sent to the terminal: {0}",\r
"request: {0}",\r
"Requests",\r
"Company requests",\r
"Requests sent from this cash register",\r
"Scheduled prices",\r
"Scheduled prices from the price list were not recorded: {0}",\r
"Closing",\r
"closing (Z)",\r
"Closing {0}",\r
"End of day (test).",\r
"End of day has been done on the terminal.",\r
"End of day on the terminal",\r
"End of day is done on the terminal (Concert does not transfer it to the register).",\r
"Shift closing (Z)",\r
"it is password-protected",\r
"Closings were not written to the folder: {0}",\r
"closed",\r
"Closed",\r
"Close",\r
"Close shift (Z)…",\r
"Replace",\r
"Replace catalogue",\r
"Replacement",\r
"Substitution (private prescription: only if the prescribed medicine is not available and the patient agrees)",\r
"Substitution is allowed only when the prescribed medicine is unavailable.",\r
"Substitution is allowed only with a medicine of the same substance, form and strength.",\r
"Substituting the prescribed medicine at the expense of FZO is not allowed.",\r
"substitute for",\r
"substitute for {0}",\r
"ZAMRZNUT",\r
"Rounding",\r
"remembered until the register is chosen",\r
"the remembered fingerprint is not the fingerprint of a CA certificate",\r
"record {0} was not written ({1})",\r
"The pro forma record is unreadable.",\r
"The record contains items removed from the receipt. They cannot be restored to the screen as a receipt.",\r
"found when the cash register was closed",\r
"Closed",\r
"Close",\r
"Close program",\r
"occupied",\r
"Occupied (actual)",\r
"Sum",\r
"The total of payments ({0}) is less than the receipt amount ({1}).",\r
"The total of payments ({0}) is greater than the receipt amount ({1}), and the excess cannot be returned from cash.",\r
"The total of payments ({0}) is greater than the amount to pay ({1}).",\r
"The total of payments ({0}) is not enough: {1} EUR is missing.",\r
"The total of payments ({0}) is not equal to the advance amount ({1}).",\r
"The sum of payments ({0}) does not equal the receipt amount ({1}).",\r
"The total of payments ({0}) is not equal to the summary receipt amount ({1}).",\r
"The sum of payments ({0}) is not equal to the amount to be paid ({1}).",\r
"Sum of those shown",\r
"The total of the receipts is zero or less. A summary receipt is not needed.",\r
"ŽELE",\r
"ZEMICK",\r
"ZEMIČK",\r
"female",\r
"Zeta",\r
"ZEWA",\r
"ZILAVK",\r
"ŽILAVK",\r
"ZILET",\r
"ŽILET",\r
"multi-part ZIP or ZIP64",\r
"Company bank account for instant payments",\r
"Cereals containing gluten",\r
"ZLATNA DUNJA",\r
"ZLATNA SLJIVA",\r
"ZLATNA ŠLJIVA",\r
"emblem",\r
"Emblem",\r
"Company logo",\r
"The emblem must be square (difference between sides up to 10 %).",\r
"The zone has not been recognised yet.",\r
"ZVAK",\r
"ŽVAK",\r
"ZYN",\r
"The release of the new version did not pass the publisher signature check. The update was not downloaded.",\r
"The release of the new version has no publisher signature. The update was not downloaded.",\r
"The data on valid versions did not pass the publisher signature check. The update was not downloaded.",\r
"The data on valid versions has expired, so updates cannot be verified at the moment. The check is repeated automatically.",\r
"Version {0} has been withdrawn. Waiting for the next version.",\r
"The published version {0} is older than the previously published version {1}. The update was not downloaded.",\r
"update check",\r
"update feed: release has an invalid format",\r
"update feed: release signature is not valid",\r
"update feed: signed release is issued for another program",\r
"update feed: release without signature",\r
"update feed: state signature is not valid",\r
"update feed: state is issued for another program",\r
"update feed: state expired",\r
"update feed: state older than the last accepted one",\r
"update feed: release without state",\r
"update feed: release lower than a previously signed one",\r
"· at the start or end of the shift",\r
"(last {0} of {1})",\r
"(receipts:",\r
"{0}\\n\\nThe customer must be {1} or older. Date of birth from the ID document (optional):",\r
"{0} h · until the 48-hour deadline: {1} h",\r
"{0}: {1} ({2} per 100 receipts; other cashiers {3})",\r
"{0}: {1} ({2} per 100 receipts)",\r
"🌙 Turnover by business day",\r
"📶 Working without internet",\r
"🛡 Exceptions by cashier",\r
"Item not added: by date of birth the customer is {0} years old.",\r
"Program updates, support, the Fund’s e-prescription",\r
"Without internet",\r
"A voucher sold on another cash register is valid here only once the exchange arrives.",\r
"deletions before payment",\r
"waits for connection",\r
"Prices, items, barcodes, promotions",\r
"COALESCE(NULLIF(r.kasir, ''), '{0}')",\r
"The date of birth is not valid. Enter it as day.month.year, for example 15.03.2008.",\r
"Events",\r
"Events{0}",\r
"A second window on the same computer.",\r
"Customer display",\r
"Files wait in the queue and are sent automatically when the connection is back.",\r
"drawer opened without a receipt",\r
"Drawer without receipt",\r
"Drawer opened without a receipt — {0}",\r
"Guests order over the internet; orders from waiters’ phones work.",\r
"h · until the 48-hour deadline:",\r
"Issuing receipts (cash, card, bank transfer)",\r
"Cashiers flagged:",\r
"Exceptions by cashier",\r
"Calendar day",\r
"Calendar day {0} (receipts: {1})",\r
"The cash register sells without internet too: the data is on the device, and what goes to the Tax Administration and to the office waits in the queue and is sent automatically when the connection is back.",\r
"The cash register works offline for as many days as the licence states; after that it needs to contact the server.",\r
"The catalogue is on the cash register. New prices from the office arrive when the connection is back.",\r
"The corrective receipt is issued on the cash register and sent later, like any receipt.",\r
"Oldest has been waiting",\r
"No receipts or events in this period.",\r
"not enabled",\r
"No cashier deviates from the others.",\r
"Of which after midnight (receipts:",\r
"Of which after midnight (receipts: {0})",\r
"Refuse sale",\r
"Rejected by the Tax Administration (review needed in Settings)",\r
"Card payment on the bank terminal",\r
"Gift vouchers and loyalty points",\r
"Discounts (receipts:",\r
"Discounts (receipts: {0})",\r
"Comparison",\r
"Return of goods from receipt",\r
"Returns",\r
"overview for venues open after midnight; manager only",\r
"Overview for venues open after midnight: receipts are totalled from the start of the business day to the same hour of the next day. Receipt dates, fiscal data, shifts, closings (Z) and the daily report are not changed.",\r
"The deposit report to the Tax Administration waits in the same queue.",\r
"Turnover by business day",\r
"Licence check",\r
"Age check",\r
"Age check: sale not confirmed — {0}",\r
"QR menu on tables (guest orders)",\r
"r.datum >= ? AND r.datum < ?",\r
"The receipt gets its IKOF and QR code on the cash register; it is sent to the Tax Administration later.",\r
"Receipt deleted before payment",\r
"Receipts wait in the queue and are sent automatically when the connection is back; the delivery deadline is 48 hours from issue.",\r
"Receipts and reports waiting to be sent to the Tax Administration",\r
"They work over the venue’s local network, without internet.",\r
"works",\r
"Business day",\r
"Business day {0}: {1} – {2} {3}",\r
"Business day starts at",\r
"The business day starts at midnight, so it equals the calendar day.",\r
"Exchange with Accounting and Manager (closings, live turnover, prices)",\r
"manual discounts: {0} % of turnover",\r
"manual discounts: {0} % of turnover (other cashiers {1} %)",\r
"Sending to the Tax Administration",\r
"Sending receipts to the Tax Administration",\r
"Shift: deposit, withdrawal, interim report (X), closing (Z)",\r
"what the cash register does offline and what is currently waiting to be sent",\r
"Printing receipts, labels and reports",\r
"The printer is connected to the cash register or the local network.",\r
"Current status",\r
"Age",\r
"Age: not confirmed",\r
"Items removed before payment",\r
"Tables, kitchen order, waiters’ phones, kitchen display",\r
"cancellations and returns",\r
"cancellations and returns at the start or end of the shift: {0}",\r
"Cancellations, returns, deletions before payment, drawer openings without a receipt, manual discounts and unconfirmed age checks, by the cashier who performed the action. A cashier is flagged with at least three such events and twice the rate of the other cashiers. A flag is a prompt to check, not proof.",\r
"cancellations, returns, deletions, drawer without receipt, manual discounts and age checks by cashier; manager only",\r
"Cancellations: {0}",\r
"Cancellation, return of goods, \\"Void\\"",\r
"SUMMARY",\r
"The terminal has its own connection; the cash register only records the payment method.",\r
"They need a connection; they resume when the connection is back.",\r
"needs connection",\r
"Device network connection",\r
"optional",\r
"Supplier payment from the till",\r
"Bank deposit",\r
"Takings handover",\r
"Petty expense",\r
"Small change / top-up",\r
"With the reason \\"Other\\", a note is required.",\r
"Return of withdrawn money",\r
"— choose a reason —",\r
"Item not added: the age check was not completed.",\r
"The date is in the future. {0} is still shown.",\r
"The period has been shortened to the last {0} days up to the selected date.",\r
"The exchange check is in progress. The result will be shown as soon as it finishes.",\r
"No reason selected. Choose a reason from the list.",\r
"The exchange has been checked.{0}",\r
"The next day is in the future.",\r
"The exchange has been checked.",\r
"; ahead: {0}",\r
"; steps: {0}",\r
"{0} {1} ms",\r
"waiting for the queue",\r
"Issue receipt of 0.00 €",\r
"database export ({0} KB)",\r
"database export (backup copy)",\r
"bulk change + snapshot",\r
"The money is refunded in cash from the register.",\r
"The money is refunded to the card (no cash from the register).",\r
"The money is refunded by bank transfer (no cash from the register).",\r
"new journal",\r
"The notice “{0}” has been closed. The scanned item is added to the receipt.",\r
"The notice has been closed. The scanned item is added to the receipt.",\r
"The discount equals the value of the goods, so the receipt total is 0.00 €.\\n\\nA receipt with no amount is issued only when the goods are really given free of charge. Otherwise the discount needs to be corrected.",\r
"preparing the write",\r
"database check",\r
"The receipt was paid by more than one method. The whole refund amount is paid out in cash from the register.",\r
"Receipt of 0.00 €",\r
"Receipt of 0.00 € (discount equal to the value of the goods)",\r
"journal row to disk",\r
"database snapshot",\r
"database snapshot (if needed)",\r
"database snapshot (automatic)",\r
"snapshot to disk",\r
"slow write: {0} — waited {1} ms, took {2} ms{3}{4}",\r
"write (transaction)",\r
"For each item, enter the quantity being returned (empty = not returned). The corrective receipt covers only the returned goods; discounts are calculated proportionally.",\r
", Tax Administration test system (TEST)",\r
", entered by {0}",\r
": codes of \\"bag\\" items (comma-separated) for the monthly bag report, due by the 5th (More → Plastic bags). Items in the \\"Plastic bags (fee)\\" group of the item register are counted without being entered here.",\r
". The X report and the daily / periodic report are in the shift window and in the receipts overview.",\r
". A receipt signed with another (earlier) certificate or on another register gives a different IKOF.",\r
". Receipts remain (without phone and name). The Accounting record is deleted by Accounting (the request goes with the register closings). Deletion cannot be undone.",\r
". Loyalty is not used until the customer consents again.",\r
"· days: {0}",\r
"· tobacco without discount",\r
"· business unit code",\r
"· corrective:",\r
"· premises",\r
"· premises {0} · operator {1}. The X report and the daily / periodic report are in the shift window and in the receipts overview.",\r
"· operator",\r
"· total",\r
"( ), notice version",\r
"(approved by {0})",\r
"(Decree, Official Gazette of Montenegro 1/26).",\r
"(Personal Data Protection Act, Official Gazette of Montenegro 133/26): loyalty is used with the customer's recorded consent (notice on screen and on paper); data of a customer with no purchase for longer than the period is deleted automatically, receipts remain. Overview: More → Loyalty customers — data protection.",\r
"{0} — pieces",\r
"{0} Tobacco products in the selection: {1}{2}.",\r
"{0} Fiscal receipts are not issued until a new certificate is imported (Settings → Fiscalization → Import certificate). A new certificate is issued by the authorized issuer at the company's request.",\r
"{0} pcs",\r
"{0} pcs · {1}",\r
"{0} is not in the format assigned by the Tax Administration (ab123cd456).",\r
"{0} The receipt was not issued.",\r
"{0} Consent {1} before loyalty is used.",\r
"{0}: consent was withdrawn on {1}. Loyalty is not used until the customer consents again.\\n\\nRecord new consent?",\r
"📝 Settings change log",\r
"🔎 IKOF check",\r
"🔐 Loyalty customers — data protection",\r
"🖨 Print report",\r
"🖨 Print notice",\r
"🧾 Reports for the inspector",\r
"🛍 Plastic bags",\r
"🛍 Plastic bags (fee)",\r
"Update address",\r
"apoteka.*",\r
"Item not found in the catalogue.",\r
"Items marked as plastic bag",\r
"Automatic update",\r
"No cash.",\r
"Without the customer's consent loyalty is not used.",\r
"deletion (retention period)",\r
"deletion on request",\r
"Deleting customer data is approved by the manager with a PIN. The PIN is not correct.",\r
"Deleting loyalty customer data",\r
"Consent, points and the loyalty customer are deleted for number",\r
"Number of pieces per denomination. The total goes to \\"Counted cash\\"; the breakdown is kept with the shift and printed with the takings.",\r
"The number of pieces for {0} is not valid (whole number, 0 or more).",\r
"Receipt number (ordinal number)",\r
"The receipt number (ordinal number) must be a whole number greater than zero.",\r
"Cash count by denomination",\r
"Count by denomination, breakdown with the takings",\r
"waiting to be sent to the Tax Administration",\r
"The price of a tobacco product is not changed on the register: it is sold at the price list price (Excise Act, Art. 50). The price is changed in Accounting.",\r
"Art. 17",\r
"Art. 25",\r
"COALESCE(ko, '') <> '{0}'",\r
"date(r.datum) <= ?",\r
"date(r.datum) >= ?",\r
"Date and time of issue",\r
"The date and time of issue are not valid (e.g. 21.11.2026 10:15:30 or as in the QR code).",\r
"DAILY TOTALS",\r
"Settings change log",\r
"ELECTRONIC JOURNAL",\r
"electronic journal, offline receipts, corrective receipts, daily totals; print and file (USB)",\r
"ENU",\r
"Request log",\r
"The file is saved to the chosen location (on Windows also to USB); on a phone to Documents/Kasa. Every report carries the ENU code, the business unit code and the operator.",\r
"fiskal.*",\r
"Fiscalization switched off ({0}{1}){2}",\r
"Exchange folder",\r
"Cash limit (€)",\r
"Errors to the publisher",\r
"IKOF IS THE SAME as on the receipt.",\r
"IKOF IS NOT THE SAME as on the receipt.",\r
"IKOF from the receipt (for comparison)",\r
"Switching off fiscalization (PRODUCTION)",\r
"Switching off fiscalization in PRODUCTION requires the manager's PIN and a reason (Fiscalization Act, Art. 11). It is logged and reported to the owner; receipts issued while fiscalization is off carry a note that they are not fiscalized.",\r
"Being switched off:",\r
"retention period of an inactive customer expired",\r
"Settings change: {0}",\r
"Receipt amount",\r
"Item amount",\r
"Calculate IKOF",\r
"Calculated IKOF",\r
"The report on the number of bags is submitted to the Environmental Protection Agency by {0} (Decree, Official Gazette of Montenegro 1/26).",\r
"The report has been submitted",\r
"The plastic bag report for {0}.{1}. is due by {2}.{3}.: {4} pcs (fee {5} €). Report: ⋯ More → Plastic bags.",\r
"Has the report for {0}.{1}. been submitted to the Agency?",\r
"data export",\r
"data export to the customer",\r
"register (automatic)",\r
"The register has no signing key (Settings → Fiscalization).",\r
"The register works in PRODUCTION. Switching off fiscalization is logged and reported to the owner; receipts issued while it is off carry the note \\"RECEIPT NOT FISCALIZED\\" and are not reported to the Tax Administration.",\r
"A register in PRODUCTION works only with a registered manager with a PIN (Settings → Cashiers).",\r
"fiscalization certificate key",\r
"who, when, old → new; manager only",\r
"ENU code",\r
"Business unit code",\r
"The software code is built into the program (Fiscalization Act, Art. 15(4)) and is not entered: PRODUCTION",\r
"pcs ·",\r
"Copy of data (file)…",\r
"Copy of data saved: {0}",\r
"corrective (goods return)",\r
"corrective (cancellation)",\r
"Corrective for",\r
"Corrective",\r
"Customer tax ID",\r
"Loyalty customer",\r
"The customer has received the notice and consents to data processing for the loyalty programme.",\r
"lower(COALESCE(a.grupa, '')) LIKE '%kes%naknad%'",\r
"lower(COALESCE(a.grupa, '')) LIKE '%plasti%kes%'",\r
"lower(COALESCE(a.podgrupa, '')) LIKE '%kes%naknad%'",\r
"lower(COALESCE(a.podgrupa, '')) LIKE '%plasti%kes%'",\r
"The month is not valid.",\r
"monthly total of pieces per premises, report by the 5th",\r
"Discounts, promotions, points and gifts are not allowed on tobacco products (Act on Restricting the Use of Tobacco Products, Art. 12).",\r
"The consent method is not known.",\r
"Fee of 0.05 € per bag thicker than 50 µm (Decree, Official Gazette of Montenegro 1/26). The seller reports the number of bags to the Environmental Protection Agency monthly, by the 5th for the previous month. A bag is an item marked below (or in the \\"Plastic bags (fee)\\" group of the item register).",\r
"Created",\r
"Company name",\r
"No turnover in the period.",\r
"No changes recorded.",\r
"not fiscalized",\r
"not fiscalized (trial mode)",\r
"No item is marked.",\r
"String to sign",\r
"New consent",\r
"e.g. 1001, 1002",\r
"e.g. failure, certificate replacement",\r
"Notice to the customer",\r
"Data processing notice",\r
"Data of {0} loyalty customers with no purchase for more than {1} months has been deleted (retention period, Settings → Add-ons). Receipts remain.",\r
"Delete data",\r
"Delete customer data (manager)…",\r
"From now on loyalty (discount, points) is not used for this number until the customer consents again. The data remains until deleted or until the period expires.",\r
"rejected (Tax Administration)",\r
"approved by {0}",\r
"osjetljivo = 1",\r
"Exemption basis",\r
"Legal basis: the customer's consent. Consent is voluntary and can be withdrawn at any time, without affecting purchases made before withdrawal.",\r
"Mark as bag (manager)",\r
"VAT not charged — {0} of the VAT Act",\r
"VAT not charged (rate 0 %)",\r
"Tax ID (fiscalization)",\r
"Company tax ID",\r
"The tax ID is not valid (8 digits; 13 for a natural person).",\r
"Taxpayer tax ID",\r
"The manager's PIN is required.",\r
"The manager's PIN is not correct. {0}",\r
"BU",\r
"Payments",\r
"placeholder=\\"not required\\"",\r
"placeholder=\\"e.g. 21.11.2026 10:15:30\\"",\r
"Plastic bags",\r
"Plastic bags (fee)",\r
"Plastic bags (codes)",\r
"Plastic bags {0}",\r
"By denomination…",\r
"Data about the loyalty customer kept by this register (Personal Data Protection Act, Official Gazette of Montenegro 133/26, Art. 16 and 21).",\r
"Data of a customer with no purchase for more than {0} months is deleted automatically (once a day). Currently: {1}.",\r
"The customer's data has been deleted.",\r
"Data: phone number, name (if the customer provides it), purchases in the programme (date, amount, discount, points).",\r
"Setting",\r
"Voiding requires the manager",\r
"Tax: CERTIFICATE EXPIRED",\r
"Signature:",\r
"Signature: {0}. A receipt signed with another (earlier) certificate or on another register gives a different IKOF.",\r
"signed consent form",\r
"confirmation on the customer display",\r
"withdrawal of consent",\r
"Withdrawal of consent",\r
"Withdraw consent",\r
"Customer rights: access to data and a copy of data, rectification, erasure, restriction of processing, portability and objection. The request is made at the register or to the controller.",\r
"Counted by denomination: {0}. Print the breakdown?",\r
"Submitted",\r
"Submitted",\r
"leaving PRODUCTION",\r
"switch from PRODUCTION to TEST",\r
"Complaint to the supervisory authority: Agency for Personal Data Protection and Free Access to Information.",\r
"before loyalty is used.",\r
"register test key (without a Tax Administration certificate)",\r
"Tax Administration test system (TEST)",\r
"Seller",\r
"Age check",\r
"r.vrsta = 'storno'",\r
"RECEIPT NOT FISCALIZED",\r
"Receipts are kept under the fiscalization and accounting rules; after deletion the phone number and name are no longer shown on them.",\r
"Reason / approved by",\r
"The reason is required.",\r
"Retention period",\r
"Retention period of an inactive customer (months)",\r
"The retention period is not set (Settings → Add-ons).",\r
"Retention: while consent lasts, at most {0} months after the last purchase in the programme.",\r
"Retention: while consent lasts.",\r
"Report deadline",\r
"roll",\r
"Manual discount without manager (%)",\r
"Data controller: {0}.",\r
"Save to file (CSV)…",\r
"Save to file (JSON)…",\r
"I consent to data processing for the loyalty programme.",\r
"Consent",\r
"Consent given",\r
"Consent given on {0} ({1}), notice version {2}{3}.",\r
"Consent withdrawn",\r
"Consent was withdrawn on {0}. Loyalty is not used until the customer consents again.",\r
"Consent has been withdrawn.",\r
"Consent has been recorded.",\r
"Consent was already withdrawn on {0}.",\r
"Loyalty customer consent",\r
"consent, notice, copy of data, deletion on request",\r
"Send receipts to the Tax Administration (certificate removal)",\r
"sensitive only",\r
"is NOT required",\r
"is required",\r
"The fiscalization certificate expires on {0} ({1} {2} left). A new certificate must be obtained and imported in time (Settings → Fiscalization). After it expires the register does not issue fiscal receipts.",\r
"The fiscalization certificate expired on {0}. Fiscal receipts are not issued until a new certificate is imported (Settings → Fiscalization → Import certificate).",\r
"The fiscalization certificate expired on {0}. The register does not issue fiscal receipts until a new certificate is imported (Settings → Fiscalization → Import certificate). A new certificate is issued by the authorized issuer (CoreIT) at the company's request.",\r
"item code or barcode",\r
"\\"Bag\\" item codes",\r
"Blind count",\r
"Cash breakdown",\r
"st.sifra IN ({0})",\r
"Print after payment",\r
"Old",\r
"VAT rate",\r
"Every change of register settings: who, when, old → new. Sensitive changes (fiscalization, codes, discount and alert limits) also go to the owner as an alert (Manager).",\r
"Purpose: loyalty programme — discount for the loyalty customer and points for purchases.",\r
"customer phone",\r
"No bag was sold in the month.",\r
"There are no such receipts in the period.",\r
"Total receipt amount (€)",\r
"The total receipt amount is not valid.",\r
"TOTAL · discount {0}{1}{2}",\r
"Total: {0}",\r
"Recorded.",\r
"Record consent",\r
"Record consent…",\r
"Enter total",\r
"Alert: deletion (€)",\r
"Alert: discount (%)",\r
"Alert: difference (€)",\r
"verbally, after the notice on screen / paper",\r
"Loyalty only with the customer's consent",\r
"Loyalty: retention period (months)",\r
"Loyalty: consent required",\r
"The value of the points is greater than the amount of goods eligible for a discount (tobacco products have no discount or points).",\r
"No consent is recorded for this number.",\r
"There is no consent record for this number.",\r
"For the tax inspector (Fiscalization functional specification, \\"IKOF verification on the ENU\\"): the IKOF is recalculated from the receipt parameters and this register's digital signature. The same parameters always give the same IKOF.",\r
"for the tax inspector: IKOF from the receipt parameters and comparison with the receipt",\r
"customer request",\r
"Personal Data Protection Act (Official Gazette of Montenegro 133/26, from 19.03.2027): provable consent, notice to the customer, withdrawal of consent, copy of data and deletion on request. Receipts remain; after deletion the phone number and name are no longer shown on them.",\r
"Personal Data Protection Act (Official Gazette of Montenegro 133/26). Notice version: {0}.",\r
"Loyalty customer data protection",\r
"CORRECTIVE RECEIPTS JOURNAL",\r
"JOURNAL OF RECEIPTS ISSUED OFFLINE",\r
"The group of a tobacco product is not changed on the register (discount and price of tobacco are restricted by law). The group is changed in Accounting.",\r
"— within 5 days (Fiscalization Law, Art. 18).",\r
": {0} {1} with deferred payment, total",\r
": voucher sale (More → Gift vouchers) and payment by voucher (More methods → Voucher). A voucher is valid at all registers of the company (exchange via server). The voucher sale is",\r
". A non-cash invoice paid later (bank transfer) carries the company bank account and the payment deadline.",\r
". It is sent to the Tax Administration marked BOUNDBOOK, within 5 days.",\r
"· available",\r
"(ORDER). Payment comes later",\r
"(delivery note to a business customer, round for a table) and",\r
"(order, catering, reservation, service, wholesale) and payment from advance;",\r
"(bank transfer)",\r
"(More → Fiscal documents → Summary invoice).",\r
"(More → Fiscal documents):",\r
"{0} cannot be combined with other payment methods.",\r
"{0}: each voucher is a separate item (quantity 1).",\r
"{0}: a voucher is issued with an advance invoice ([FS] 5.8).",\r
"{0}: the voucher expiry date is not in the format 2026-12-31.",\r
"{0}: voucher serial number “{1}” is not in the format 12-2026-34567890.",\r
"⚠ Correction — invoice in error…",\r
"🧾 Fiscal documents",\r
"ABW AFG AGO AIA ALA ALB AND ARE ARG ARM ASM ATA ATF ATG AUS AUT AZE BDI BEL BEN BES BFA BGD BGR BHR BHS BIH BLM BLR BLZ BMU BOL BRA BRB BRN BTN BVT BWA CAF CAN CCK CHE CHL CHN CIV CMR COD COG COK COL COM CPV CRI CUB CUW CXR CYM CYP CZE DEU DJI DMA DNK DOM DZA ECU EGY ERI ESH ESP EST ETH FIN FJI FLK FRA FRO FSM GAB GBR GEO GGY GHA GIB GIN GLP GMB GNB GNQ GRC GRD GRL GTM GUF GUM GUY HKG HMD HND HRV HTI HUN IDN IMN IND IOT IRL IRN IRQ ISL ISR ITA JAM JEY JOR JPN KAZ KEN KGZ KHM KIR KNA KOR KWT LAO LBN LBR LBY LCA LIE LKA LSO LTU LUX LVA MAC MAF MAR MCO MDA MDG MDV MEX MHL MKD MLI MLT MMR MNE MNG MNP MOZ MRT MSR MTQ MUS MWI MYS MYT NAM NCL NER NFK NGA NIC NIU NLD NOR NPL NRU NZL OMN PAK PAN PCN PER PHL PLW PNG POL PRI PRK PRT PRY PSE PYF QAT REU ROU RUS RWA SAU SDN SEN SGP SGS SHN SJM SLB SLE SLV SMR SOM SPM SRB SSD STP SUR SVK SVN SWE SWZ SXM SYC SYR TCA TCD TGO THA TJK TKL TKM TLS TON TTO TUN TUR TUV TWN TZA UGA UKR UMI RKS URY USA UZB VAT VCT VEN VGB VIR VNM VUT WLF WSM YEM ZAF ZMB ZWE",\r
"adv_iic TEXT",\r
"adv_vrijeme TEXT",\r
"ALB",\r
"Albania",\r
"Item “not a supply within the VAT system”",\r
"Austria",\r
"AUT",\r
"An advance and a gift voucher cannot be used on the same invoice. Two invoices must be issued.",\r
"Advance for an order, catering, hall reservation, service or delivery of goods. On the goods invoice the advance is chosen as the payment method “Advance”; the rest is paid in cash, by card or bank transfer.",\r
"Advance invoice issued: {0}.",\r
"The advance invoice is not cancelled here. The advance is refunded via “Advance refund” (More → Fiscal documents → Advances).",\r
"advance invoice, advance refund, summary invoice for deferred payment, reduction of advance invoices",\r
"Advance invoices",\r
"Advance invoices are not enabled (Settings → Add-ons).",\r
"Without a customer, a label (table, order) is required for the summary invoice.",\r
"no basis (rate 0)",\r
"no label",\r
"non-cash",\r
"Non-cash and cash invoices with deferred payment cannot go into the same summary invoice.",\r
"A non-cash invoice with deferred payment must have a customer (tax ID and name).",\r
"Non-cash invoices with deferred payment are paid together by bank transfer.",\r
"BIH",\r
"Belarus",\r
"BLR",\r
"Voucher {0} is not on this advance invoice.",\r
"A voucher is used once (the remainder lapses)",\r
"BON-",\r
"Bosnia and Herzegovina",\r
"BOUNDBOOK",\r
"no. {0} · {1} · available {2}",\r
"Soc. sec. no.",\r
"The bound book number has at most 20 characters.",\r
"The bound book number is required.",\r
"Card number",\r
"seller card number",\r
"Customer number",\r
"The invoice number from the bound book is required.",\r
"Invoice number in the book",\r
"Social security number",\r
"Pending:",\r
"Pending: {0}",\r
"Czechia",\r
"CHE",\r
"CHN",\r
"COMPANY",\r
"Montenegro",\r
"CZE",\r
"The date and time from the book are not valid (cannot be in the future).",\r
"Issue date",\r
"DEU",\r
"drzava TEXT",\r
"efi_naknadno TEXT",\r
"Fiscal documents",\r
"FRA",\r
"France",\r
"GBR",\r
"h.dok = 'order'",\r
"h.rezervacija IS NULL",\r
"h.soba = ?",\r
"Netherlands",\r
"HRV",\r
"Croatia",\r
"HUN",\r
"and reported",\r
"The IKOF of the advance invoice is not valid (32 characters, 0–9 and A–F).",\r
"correction (ERROR_CORRECTIVE)",\r
"A correction (ERROR_CORRECTIVE) is issued only for a sales invoice.",\r
"Correction of advance, deferred and summary documents is not supported on the register.",\r
"Correction of invoice {0} (error found in subsequent check)",\r
"Correction of invoice no. {0} issued{1}.",\r
"Correction of invoice in error",\r
"correction of invoice in error (ERROR_CORRECTIVE)",\r
"Correction of invoice in error (ERROR_CORRECTIVE)",\r
"A correction of an invoice in error (ERROR_CORRECTIVE) is not cancelled. A new correction is issued for the same invoice.",\r
"A correction of an invoice in error is sent to the Tax Administration, and the register currently cannot send: {0} The correction was not issued.",\r
"A correction of an invoice in error is sent to the Tax Administration, and the register currently cannot send. The correction was not issued.",\r
"The correction cannot be signed (no key). The correction was not issued.",\r
"ISR",\r
"ITA",\r
"Italy",\r
"No more than the amount of the advance invoice can be paid from the advance.",\r
"From book no. {0} · {1} (remove)",\r
"from the bound book",\r
"From the bound book",\r
"From bound book no.",\r
"Issue correction",\r
"Issue summary invoice ({0})",\r
"Advance amount (€)",\r
"The amount paid from the advance must be greater than zero.",\r
"Refund amount (available {0})",\r
"Israel",\r
"When the register or the fiscal service is down, invoices are issued by hand in the",\r
"When an advance or gift voucher is used on an invoice, the advance invoice is reduced by a corrective invoice (so VAT is not charged twice). The register does this itself at shift close.",\r
"When an advance or gift voucher is used on an invoice, the advance invoice is reduced by a corrective invoice (so VAT is not charged twice). The register does this itself at shift close. {0}",\r
"company card",\r
"Company card",\r
"A company card and other non-cash payments are not combined with other payment methods on the same invoice. Two invoices must be issued.",\r
"A company card and other non-cash payments cannot be combined with cash or card on the same invoice. Two invoices must be issued.",\r
"Company card, seller card, other non-cash",\r
"seller card",\r
"Seller card",\r
"China",\r
"Bound book of invoices",\r
"knjiga_broj TEXT",\r
"bound book of invoices",\r
"Voucher advance correction: the total by vouchers does not equal the amount paid by vouchers.",\r
"Kosovo",\r
"Customer — name",\r
"Customer — tax ID / personal ID (required for transfer)",\r
"Customer {0} pays the summary invoice by bank transfer (non-cash)",\r
"Customer / label",\r
"kupac_drzava TEXT",\r
"kupac_vrsta TEXT",\r
"Customer: country “{0}” is not a code from the list (ISO 3166-1, three letters, e.g. MNE, SRB, DEU).",\r
"Customer: unknown number type “{0}” (possible: TIN, ID, PASS, VAT, TAX, SOC).",\r
"Customer: a tax ID has 8 digits and a personal ID 13 (given: “{0}”). For a foreign customer choose the country and number type.",\r
"Customer: a tax ID has 8 digits and a personal ID 13. For a foreign customer choose the country and number type.",\r
"Password of the certificate for non-cash invoices",\r
"Hungary",\r
"MKD",\r
"Available on the advance invoice: {0}.",\r
"Only vouchers sold with the same invoice (same advance invoice) can be used on one invoice. Two invoices must be issued.",\r
"Only vouchers from the same advance invoice (sold with the same invoice) can be used on one invoice. Two invoices must be issued.",\r
"At most 20 vouchers can be used on one invoice.",\r
"Only one seller card can be used on one invoice.",\r
"Only one seller card can be used on one invoice. Two invoices must be issued.",\r
"No discount on a gift voucher: the advance invoice is for the face value of the voucher.",\r
"On the invoice: {0} (advance invoice). The voucher is printed after payment.",\r
"The voucher item {0} has {1} left, and the correction is {2}.",\r
"nacin TEXT",\r
"Some of the selected invoices no longer wait for a summary invoice (already included or cancelled).",\r
"No advance invoices.",\r
"No invoices waiting for a summary invoice.",\r
"Unknown payment method: “{0}” (possible: Cash, Card, Bank transfer, Voucher, Instant, Company card, Seller card, Other non-cash).",\r
"Nothing is pending.",\r
"Germany",\r
"NLD",\r
"NOINTERNET",\r
"New advance invoice…",\r
"e.g. 15/2026",\r
"e.g. Advance — catering 25.11.",\r
"e.g. Table 4",\r
"deferred",\r
"deferred payment",\r
"Deferred payment — summary invoice later",\r
"Deferred payment and summary invoice",\r
"Description (what the advance is for)",\r
"Description / customer",\r
"ORDER",\r
"Exemption basis sent to the Tax Administration for an item marked in Accounting as “not a supply within the VAT system”. Confirmed by the accountant.",\r
"other non-cash",\r
"Other non-cash",\r
"certified by the Tax Administration. Here each such invoice is entered afterwards (same items and payment) and sent to the Tax Administration marked",\r
"This is a correction of an invoice in error. Goods are returned from the original invoice.",\r
"Label (optional)",\r
"Label (table, order)",\r
"VAT number (foreign company)",\r
"pdv REAL",\r
"Tax ID / personal ID",\r
"Payment by voucher or from an advance requires the invoice IKOF (fiscalization is off or there is no certificate). The invoice was not issued.",\r
"Payment by voucher must carry the IKOF of the advance invoice that issued the voucher.",\r
"Payment by voucher must carry the voucher serial number.",\r
"Payment by seller card must carry the card number.",\r
"Payment by seller card: the card number must be entered.",\r
"A gift voucher is not entered from the bound book.",\r
"A gift voucher is paid at purchase (the advance invoice is issued for a received payment).",\r
"A gift voucher is sold with a separate (advance) invoice, without other goods on the same invoice.",\r
"A gift voucher is sold with a separate (advance) invoice. First charge or remove the goods on the screen.",\r
"POL",\r
"Poland",\r
"Tax number (foreign)",\r
"Separate certificate for",\r
"Separate certificate for non-cash invoices",\r
"The seller card number must be entered.",\r
"Advance refund: {0}.",\r
"The refund is from 0.01 to {0}.",\r
"empty = account for instant payments",\r
"sale ({0} items{1}){2}",\r
"sale split into {0} invoices ({1} items{2})",\r
"r.datum <= ?",\r
"r.datum >= ?",\r
"r.kupac_pib = ?",\r
"r.stornirao_uid IS NULL",\r
"r.vrsta = 'racun'",\r
"Invoice no. {0} of {1}, {2}.\\n\\nA correction is issued ONLY for an invoice marked as an error on the Tax Administration portal (SEP → Invoices with errors) after subsequent checks. The same invoice (items, payments, customer) is sent with a correct calculation; turnover and money do not change. Deadline: 8 days from the error being marked.{3}\\n\\nNote (optional):",\r
"The invoice has {0} items, and the Tax Administration accepts at most {1} on one invoice (and at most 150 kB). Only an invoice paid by a single method, without invoice discount, loyalty, voucher, advance or deferred payment is split automatically. Several smaller invoices must be issued.",\r
"The invoice has {0} items, and the Tax Administration accepts at most {1}. The invoice must be split into several invoices.",\r
"The invoice has more than 1000 items and was issued as {0} invoices (total {1}).",\r
"The invoice from the book is older than 5 days: the deadline for electronic delivery (Fiscalization Law, Art. 18) has passed. The invoice is still entered and sent.",\r
"Invoice from the bound book",\r
"The invoice from the bound book is older than 30 days. It cannot be entered on the register; contact the Tax Administration.",\r
"An invoice from the bound book is sent with the subsequent delivery mark BOUNDBOOK.",\r
"An invoice from the bound book is entered with the actual payment method.",\r
"An invoice written by hand in the bound book (register or fiscal service was down) is entered on the sales screen: enter the items, then",\r
"The invoice was issued {0} days ago: the 8-day deadline may have passed.",\r
"The invoice is cancelled; no correction is needed.",\r
"Invoice marked as an error by SEP (Invoices with errors) after subsequent checks",\r
"The invoice is not fiscalized (no JIKR). A correction is issued only for an invoice received by the Tax Administration and marked as an error in a subsequent check.",\r
"An invoice with deferred payment is not paid from an advance.",\r
"The invoice is issued now with the payment method",\r
"invoices",\r
"invoices (bank transfer, company card, deferred company payment): signature of an authorized person, while cash invoices are signed with the company seal. Without this one certificate is used for all.",\r
"Invoices with deferred payment (delivery note to a business customer, round for a table) waiting for payment. A summary invoice is issued to one customer or for one label.",\r
"RKS",\r
"Payment deadline",\r
"Payment deadline (days)",\r
"The payment deadline is from 0 to 365 days.",\r
"The payment deadline cannot be before the invoice issue date.",\r
"The payment deadline is not a valid date.",\r
"Bank transfer payment deadline (days)",\r
"rok_dana INTEGER",\r
"rok_placanja TEXT",\r
"RUS",\r
"Russia",\r
"Part of a voucher advance invoice is not refunded. The whole invoice is cancelled (vouchers not used).",\r
"with deferred payment, total",\r
"Part of the goods was returned from this invoice; a correction is not possible on the register.",\r
"with the serial number of each voucher (FS v5, 3.5 and 5.8); payment by voucher goes to the Tax Administration as “SVOUCHER” with the IKOF of the advance invoice and the voucher number, and the advance invoice is reduced by the used amount at shift close. This method",\r
"USA",\r
"Voucher serial number “{0}” is not in the format 12-2026-34567890.",\r
"Certificate (non-cash)",\r
"The certificate for non-cash invoices was imported{0}",\r
"The certificate for non-cash invoices is deleted from this register. While “Separate certificate for non-cash invoices” is on, the register does not send invoices to the Tax Administration.",\r
"North Macedonia",\r
"Slovenia",\r
"SOC",\r
"SRB",\r
"Serbia",\r
"VAT rate of the future supply",\r
"Switzerland",\r
"Sweden",\r
"SVN",\r
"SVOUCHER",\r
"SWE",\r
"TAX",\r
"tip_racuna TEXT",\r
"TUR",\r
"Turkey",\r
"United Kingdom",\r
"A separate certificate for non-cash invoices is enabled but not imported (Settings → Fiscalization).",\r
"Remove that certificate",\r
"UKR",\r
"Ukraine",\r
"Reduction of advance invoices",\r
"reduction of advance invoices ({0})",\r
"Reduction of advance invoices was not done for: {0}",\r
"Reduction of advance invoice — advance used",\r
"Reduction of advance invoice — gift vouchers used",\r
"Reduction was not done for: {0}",\r
"Advance invoices reduced: {0}.",\r
"Reduce now",\r
"Enter invoice from the bound book…",\r
"USA",\r
"Import certificate for non-cash (.pfx)…",\r
"VAT_CL17 (default)",\r
"vd TEXT",\r
"A bank transfer requires a customer: a summary invoice without a customer is paid in cash or by card.",\r
"More payment methods → Enter invoice from the bound book",\r
"Issue time (hour:minute)",\r
"The issue time from the bound book is in the future.",\r
"The issue time from the bound book is not valid (date and hour).",\r
"Enter the time as hour:minute, e.g. 14:30.",\r
"Number type",\r
"vrsta_avansa TEXT",\r
"vrsta_id TEXT",\r
"vsn TEXT",\r
"A customer (tax ID and company name) must be entered for a company card.",\r
"A correction has already been issued for this invoice.",\r
"for a period; payment methods",\r
"A customer (tax ID and company name) must be entered for payment by company card.",\r
"No invoice with deferred payment is selected for the summary invoice.",\r
"summary invoice",\r
"Summary invoice",\r
"A summary invoice without a customer covers invoices with the same label (table, order).",\r
"Summary invoice issued: {0}.",\r
"Summary invoice later (delivery note, round)…",\r
"A summary invoice is issued to one customer: the selected invoices are for different customers.",\r
"Summary invoice…",\r
"Summary invoices are not enabled (Settings → Add-ons).",\r
"by a summary invoice",\r
"Company bank account (transfer)",\r
"ziro_racun TEXT",\r
"— CALL",\r
", source {0}",\r
"; the course waiting to be called was not sent",\r
"· selected {0}",\r
"· change",\r
"“{0}”: subgroup {1} does not exist.",\r
"“{0}”: VAT rate {1} is not 21, 15, 7 or 0 — the register's default rate applies.",\r
"“Often with this” from this register's sales (register and waiter phone)",\r
"(add-ons: {0} warnings)",\r
"(set in “Hospitality — advanced”).",\r
"(the reservation has a deposit)",\r
"(with add-ons)",\r
"{0} · VAT {1}% · add-on to dish",\r
"{0} (approved by: {1})",\r
"{0}: “{1}” is selected twice.",\r
"{0}: {1} (approved by {2})",\r
"{0}: document {1} has been issued.",\r
"{0}: a choice is required.",\r
"{0}: at most {1} {2}.",\r
"{0}: unknown choice “{1}”.",\r
"{0}: at least {1} must be selected.",\r
"{0}{1} · {2} it.{3}{4}{5}",\r
"{0}{1} (on the table {2})",\r
"{0}at most {1}",\r
"{0}An item goes to the station of its code, subgroup or group; everything else to the default one.",\r
"% · add-on to dish",\r
"+ {0} add-ons",\r
"+ Station",\r
"▶ Call course:",\r
"▶ Call course: {0}",\r
"▶ Call:",\r
"▶ Call: {0}",\r
"⚙ Hospitality — advanced",\r
"🍷 Hospitality expense / on the house / staff meal",\r
"👤 Takings by waiter",\r
"🖨 Print (Bluetooth)",\r
"🧑‍🍳 Kitchen{0}",\r
"1 (the same arrives in the package from Accounting / Manager; description: docs/nove-funkcije/ugostiteljstvo-2.md). Now:",\r
"Allergens",\r
"Allergens from the QR menu: {0} items.",\r
"Allergens by item",\r
"Ground paprika",\r
"Item {0} is not in the register catalogue.",\r
"avans_uid TEXT",\r
"no course",\r
"No course",\r
"No onion",\r
"without VAT",\r
"without VAT",\r
"Bluetooth printer",\r
"Number of guests for equal parts: 2 to 30.",\r
"waiting to be called",\r
"Often with",\r
"Often with {0}:",\r
"Often with it:",\r
"The add-on definition is not valid JSON.",\r
"The add-on definition is not in the expected form.",\r
"Dessert",\r
"part",\r
"up to {0}",\r
"Well done",\r
"DOD-{0}-{1}",\r
"Add-ons",\r
"Dish add-ons",\r
"Add-ons to dish",\r
"Add-ons to dish (doneness, side, cheese…)",\r
"Add{0}",\r
"Add-on “{0}” is not in the register catalogue (code {1}). The add-on definition needs to be checked.",\r
"An add-on is changed through the dish (tap the add-on text under the dish name).",\r
"An add-on is removed together with the dish (or the dish is removed and ordered again with other add-ons).",\r
"Owes",\r
"Screen",\r
"Kitchen screen",\r
"The fiscal receipt is issued by the main register.",\r
"The fiscal receipt is issued by the main register.{0}",\r
"Format",\r
"Format {0} 1 (the same arrives in the package from Accounting / Manager; description: docs/nove-funkcije/ugostiteljstvo-2.md). Now: {1} groups{2}.",\r
"Where is the receipt printed?",\r
"Main course",\r
"guest, occasion, staff name",\r
"Guests have arrived",\r
"Guests have arrived — {0}",\r
"done",\r
"Done for this item",\r
"Grilled vegetables",\r
"Group “{0}” is listed twice; the first one applies.",\r
"Group “{0}” has no options and was skipped.",\r
"Group “{0}”: option “{1}” is listed twice; the first one applies.",\r
"Group “{0}”: an option without a name was skipped.",\r
"A group without an id or name was skipped.",\r
"Groups / subgroups (comma-separated)",\r
"IKOF: {0}",\r
"or: equal parts (number of guests)",\r
"Internal document",\r
"An internal document is approved by the manager.",\r
"Internal documents are not enabled (Settings → Hospitality).",\r
"Internal documents are not enabled (Hospitality — advanced).",\r
"Internal documents enabled (approved by the manager)",\r
"interno TEXT",\r
"Valid: {0} groups.",\r
"choice",\r
"Choice “{0}” does not belong to this item's add-ons.",\r
"choices",\r
"Issue document",\r
"The handover amount is not valid.",\r
"The amount of table {0} is €{1}. The table needs to be refreshed and the payment repeated.",\r
"JIKR: {0}",\r
"The register has not confirmed the payment (connection). The payment needs to be repeated with the same request.",\r
"Delay (red) after minutes",\r
"kgs",\r
"Quantity follows the dish",\r
"The quantity of each item this guest pays stays on screen for payment; the rest goes back to the table. Part of an item: e.g. 0.5 = half a pizza. Dish add-ons go with the dish. For equal parts, enter the number of guests (items are then left empty).",\r
"Waiter",\r
"waiter chooses",\r
"Waiter is required.",\r
"The waiter who served the table (table bill) or the cashier who issued the receipt. “Handed over” = cash the waiter handed over; “owes” = cash collected at the table that has not yet been handed over.",\r
"Waiter takes payment from the phone (this register issues the receipt)",\r
"konobar TEXT",\r
"Waiters",\r
"Rare",\r
"Course",\r
"Course (starter, main, dessert)",\r
"Course {0}",\r
"Course 2 onwards waits for “Call next course”",\r
"Course 4",\r
"Course 5",\r
"course waiting to be called",\r
"The course is not valid.",\r
"Course by item group",\r
"Courses (starter, main course, dessert)",\r
"Courses enabled",\r
"courses, print stations, kitchen screen, dish add-ons, allergens, payment from the phone; manager only",\r
"The MAC address is not valid.",\r
"MAC address of the phone printer (e.g. 00:11:22:33:44:55).",\r
"MAC address of the phone printer.",\r
"molluscs",\r
"1/{0} of the table bill is on screen for payment; the rest ({1} {2}) is on table {3}. For the next guest: equal parts by {4}.",\r
"There is a bill on screen. It must first be returned to the table or paid.",\r
"There are no items on screen.",\r
"At the register",\r
"at this register",\r
"On the house",\r
"on the phone printer (Bluetooth)",\r
"Table {0} has items not sent to the kitchen / bar. The order needs to be sent or the payment confirmed without it.",\r
"Table {0} has no held course.",\r
"The table has no course waiting to be called.",\r
"On the phone",\r
"The payment method is not valid (cash or card).",\r
"at least {0},",\r
"at least {0}, at most {1}",\r
"Order {0} has been sent ({1} {2}){3}. Table {4} is on hold.",\r
"The order was not printed; the course was not called. The printer needs to be checked.",\r
"The order no longer exists.",\r
"Orders from the register and the waiter phones. “Done” (the whole order or item by item) tells the waiter it is ready. Kitchen tablet: the Android app in “Kitchen” mode (paired like a waiter phone).",\r
"Paid.",\r
"Payment",\r
"Payment — waiting for the register…",\r
"Payment — table {0}",\r
"Payment {0} has not been confirmed by the register.",\r
"The payment has not been confirmed by the register. Before cancelling, check at the register that no receipt was issued.",\r
"The payment was not made.",\r
"Payment from the phone is not enabled at the register (Settings → Hospitality).",\r
"Take payment anyway",\r
"Unsent items",\r
"Unknown format “{0}” ({1} expected).",\r
"has not been confirmed by the register.",\r
"new round{0}",\r
"The new items are in a course waiting to be called (“Call course” in the table overview).",\r
"e.g. no salt",\r
"required",\r
"Staff meal",\r
"of which open tables ( )",\r
"of which open tables ({0})",\r
"Approved by (manager)",\r
"Cancel payment",\r
"opis TEXT",\r
"nuts",\r
"Open shift",\r
"Open table",\r
"Paper",\r
"Takings by waiter",\r
"VAT from the selling price (conservative)",\r
"VAT is calculated from the selling price",\r
"VAT treatment",\r
"Doneness",\r
"Pizzas",\r
"French fries",\r
"Retry (same request)",\r
"discount",\r
"Enter who approved it.",\r
"Course “{0}” called (order {1}). Table {2} is on hold.",\r
"empty = by items",\r
"Handover recorded.",\r
"Cash handover — {0}",\r
"waiter cash handover",\r
"Handover…",\r
"Handovers",\r
"Starters:1; Main courses:2; Desserts:3",\r
"Starter",\r
"Import from the QR menu",\r
"Suggestions",\r
"Side dish",\r
"Received by",\r
"Example",\r
"The amount received is less than the receipt amount.",\r
"Received {0} · change {1}",\r
"Received from the guest (cash, optional)",\r
"sales, cash and card by waiter; cash handover; manager only",\r
"Receipt QR (Tax Administration) — the guest scans it with a phone.",\r
"receipt issued",\r
"The receipt was printed at the register.",\r
"The receipt was printed on the phone printer.",\r
"A receipt paid from the phone is printed",\r
"The receipt has no QR code (trial mode).",\r
"The receipt was not issued: {0} The table has been restored.",\r
"The receipt was NOT printed at the register — the printer needs to be checked.",\r
"The receipt is printed at the register.",\r
"The receipt is printed on the phone printer.",\r
"The table receipt carries the operator code of the waiter who served the table (when the waiter has their own code)",\r
"A reason is required (e.g. guest, occasion, staff name).",\r
"One line per item: “code: numbers” (1–14:",\r
"One line per item: “code: numbers” (1–14: {0}).",\r
"Hospitality expense",\r
"Hospitality expense / on the house / staff meal",\r
"Hospitality expense, “on the house”, staff meal",\r
"The reservation does not exist.",\r
"goods on screen without payment, with a reason and manager approval",\r
"The goods on screen are removed from stock without payment. The document is not a fiscal receipt; it appears in reports and in the summary for Accounting separately from sales and write-offs. VAT treatment:",\r
"The goods on screen are removed from stock without payment. The document is not a fiscal receipt; it appears in reports and in the summary for Accounting separately from sales and write-offs. VAT treatment: {0} (set in “Hospitality — advanced”).",\r
"Grill",\r
"The layout from the basic settings (kitchen + bar) applies now. A change here replaces it.",\r
"Codes",\r
"Cheese",\r
"smjena_id = ?",\r
"Salt",\r
"Medium",\r
"Printing on the phone failed: {0}",\r
"Receipt printing",\r
"The printer is not set up.",\r
"The phone printer has been saved.",\r
"The phone printer has been removed.",\r
"Print stations (kitchen, bar, grill, pizza, dessert…)",\r
"An item goes to the station of its code, subgroup or group; everything else to the default one.",\r
"The order item does not exist.",\r
"Table {0} is currently open at the register. Payment is possible once the cashier returns the table.",\r
"Table {0} has no open bill (it may already be paid).",\r
"Table {0}: guests {1}{2}.",\r
"Table {0}: course “{1}” is waiting to be called.",\r
"Table {0}: course “{1}” goes now.",\r
"Table {0}: paid from the phone ({1}), {2} €{3}.",\r
"Table {0}: course “{1}” called.",\r
"Table {0}: receipt {1} issued ({2}, €{3}).{4}",\r
"Ham",\r
"All stations",\r
"The VAT treatment is confirmed by the accountant; the summary for Accounting carries the type, reason, who approved it and VAT by rate.",\r
"Hospitality — advanced",\r
"Hospitality — saved{0}.",\r
"Record handover",\r
"Warning (yellow) after minutes",\r
"upozori",\r
"uz_red INTEGER",\r
"Version {0} is not supported; it is read as version 1.",\r
"vrijeme >= ? AND vrijeme <= ?",\r
"The internal document type is not valid.",\r
"Fries seasoning",\r
"{0} · {1} pers.",\r
"guests: {0}",\r
"res. {0}",\r
"to pay",\r
"· table reservation",\r
"(no. {0})",\r
"15 % (food, service)",\r
"Deposit — reservation {0}",\r
"Deposit — reservation {0}, {1}.{2}. {3}",\r
"deposit {0}",\r
"The advance receipt for the reservation has been issued{0}.",\r
"no. {0} · {1} · available {2}{3}",\r
"An advance receipt (fiscal) is issued. When the table is paid, the amount is deducted via “More payment methods → Deposit”.",\r
"The deposit amount is required.",\r
"Paid",\r
"The reservation already has a deposit.",\r
"Table {0} has a reservation deposit. Payment is taken at the register (paid from the deposit).",\r
"VAT rate",\r
"; receipt copy to customer is not enabled",\r
"; receipt copy to customer: yes",\r
"(ENU {0})",\r
"(when the register connects to the server)",\r
"(kupac vjernosti) | pib:",\r
"(no data)",\r
"(auth. {0})",\r
"(PDF) by e-mail after payment; the paper receipt is issued as before. Without a server connection the copy waits and is sent later.",\r
"{0} · register {1}",\r
"{0} {1} {2} {3} re",\r
"{0} items",\r
"{0} rg {1} {2} {3} {4} re f",\r
"{0} RG {1} w {2} {3} m {4} {5} l S",\r
"{0}, {1} (register {2}). The report is attached (PDF and Excel).",\r
"<?xml version=\\"1.0\\" encoding=\\"UTF-8\\" standalone=\\"yes\\"?>",\r
"<< /Title {0} /Producer (IRIS CORVINA){1} /CreationDate ({2}) >>",\r
"<< /Type /Catalog /Pages 2 0 R >>",\r
"<< /Type /Encoding /BaseEncoding /WinAnsiEncoding /Differences [{0}] >>",\r
"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding 5 0 R >>",\r
"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding 5 0 R >>",\r
"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {0} {1}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {2} 0 R >>",\r
"<< /Type /Pages /Kids [{0}] /Count {1} >>",\r
"✉ {0} (remove)",\r
"✉ E-mail{0}",\r
"✉ By e-mail",\r
"✉ Send receipt copy by e-mail…",\r
"The e-mail address is not valid (e.g. name@example.me).",\r
"The e-mail address is not valid.",\r
"Addresses are in the company mail settings (Manager); the register does not choose the address.",\r
"promotion: {0}, discount",\r
"BT {0} rg /{1} {2} Tf {3} {4} Td ({5}) Tj ET",\r
"BT {0} rg /F1 7.5 Tf {1} {2} Td ({3}) Tj ET",\r
"Cacute",\r
"Ccaron",\r
"Waiting for Tax Administration confirmation (JIKR).",\r
"waiting: {0}",\r
"Dcroat",\r
"Register e-mail",\r
"Customer e-mail",\r
"E-mail is not available on this register.",\r
"E-mail: {0} message(s) not sent (More → E-mail).",\r
"E-receipt",\r
"Electronic receipt copy",\r
"ELECTRONIC RECEIPT COPY — the original is the paper receipt issued at the register.",\r
"Excel",\r
"Excel table saved:",\r
"FEFF",\r
"FISCAL RECEIPT",\r
"Choose the owner or the accountant.",\r
"report",\r
"The report is queued for e-mail.",\r
"Register {0} · {1}{2}",\r
"The register is not paired with the server — messages are waiting.",\r
"The register is not paired with the IRIS CORVINA server — the report can be saved as a file.",\r
"to the accountant",\r
"To",\r
"receipt copy",\r
"The receipt copy goes to {0}{1}.",\r
"receipt copies to customers and reports to the owner/accountant; sending status",\r
"a receipt copy",\r
"CUSTOMER",\r
"The customer receives",\r
"Subtotal (before receipt discount)",\r
"Consent method",\r
"Collected sales",\r
"No items to export.",\r
"No messages.",\r
"No table to export.",\r
"Notice to the customer (storing the address)",\r
"Basis: customer consent. Consent is voluntary and can be withdrawn at any time; the address is then deleted.",\r
"Write-off by item",\r
"Goods write-off (not sales)",\r
"PDF",\r
"PDF saved:",\r
"VAT {0} (base {1})",\r
"pib:",\r
"By payment method",\r
"Data: e-mail address, with the loyalty customer's phone number or the business customer's tax number.",\r
"Retry",\r
"Receipt discount {0}",\r
"Message (optional)",\r
"Send report by e-mail",\r
"Company mail is enabled{0}.",\r
"Company mail is not enabled (Manager → E-mail and reports).",\r
"GOODS RETURN — CORRECTIVE RECEIPT",\r
"Customer rights: access, rectification, erasure, restriction of processing, portability and objection; complaint also to the Agency for Personal Data Protection and Free Access to Information.",\r
"handed to the server",\r
"Receipt verification at the Tax Administration",\r
"Checked {0}.",\r
"RECEIPT",\r
"Racun {0}.pdf",\r
"The receipt was not found on the register.",\r
"Receipts and sales before discount",\r
"Retention: while consent lasts, i.e. while the loyalty customer exists.",\r
"Item",\r
"REVERSAL RECEIPT",\r
"RECEIPT REVERSAL",\r
"page {0} of {1}",\r
"Purpose: sending an electronic copy of the receipt to the customer's address (in addition to the paper receipt).",\r
"tel:",\r
"trailer\\n<< /Size {0} /Root 1 0 R /Info 6 0 R >>\\nstartxref\\n{1}\\n%%EOF",\r
"No owner or accountant addresses are set in the company mail settings (Manager → E-mail and reports).",\r
"TOTAL TO PAY",\r
"to the owner and the accountant",\r
"Address stored with the customer (consent",\r
"Address stored with the customer (consent {0}).",\r
"Store the address with customer {0} (with the customer's consent)",\r
"Bank account",\r
"· card",\r
"· cashiers from Manager:",\r
"· discount up to {0} %",\r
"· linked",\r
"· linked {0} · cashiers from Manager: {1} · list of {2}",\r
"· list of",\r
"{0}\\n\\nAre the goods physically here? The sale continues and the difference shows in the stocktake.",\r
"{0} from phone ({1}): {2}",\r
"{0}: by location stock {1} (data {2}.{3}. {4}).",\r
"{0}: a PIN (or card) is required — approved by {1}.{2}",\r
"{0}{1}: discount without approval (%)",\r
"📱 Request from phone",\r
"administrator",\r
"Printer address (ESC/POS)",\r
"Quick keys",\r
"Awaiting approval",\r
"Cash deposit",\r
"Cash deposit and withdrawal",\r
"Approval log",\r
"Label after price change",\r
"Drawer: address",\r
"fiscal and security settings are not changed remotely",\r
"Fiscal settings are not changed remotely.",\r
"Cash per cashier",\r
"The discount limit is a percentage from 0 to 100.",\r
"The cashier discount limit is a percentage from 0 to 100 (empty = role limit).",\r
"granica_popusta REAL",\r
"HKDF",\r
"{0} left",\r
"from Manager",\r
"choose when printing",\r
"Choose printer at every print",\r
"Price and item changes",\r
"izmjena TEXT",\r
"Reports and control",\r
"card is registered",\r
"The card is not registered to any active cashier.",\r
"kartica_hes TEXT",\r
"kartica_so TEXT",\r
"The register is linked to Manager (company key {0}). Cashiers from Manager: {1}.",\r
"The register is linked neither to the server nor to an exchange folder — the code cannot be checked.",\r
"Cashier \\"{0}\\" is entered in Manager. Changes (PIN, role, locations, revocation) are made in Manager and reach all registers.",\r
"Cashiers from Manager: {0}",\r
"cashiers from Manager: {0} (list {1})",\r
"Cashiers, PINs and roles can be entered in Manager for all registers at once (including revoking employees). The register is linked once, with a code from the Manager administrator device (Register chain → Register code).",\r
"Cashiers, PINs and roles can be entered in Manager for all registers at once (including revoking employees). The register is linked once, with a code from the Manager administrator device (Register chain → Register code).{0}",\r
"Company key:",\r
"The card code has at least {0} characters (the card reader enters it).",\r
"The card code has at least {0} characters (entered by the card reader).",\r
"The code is invalid or expired. A code from the Manager administrator device is required (Register chain → Register code).",\r
"Operator code: {0} · PIN: {1}{2}{3}{4}",\r
"The register code has 12 characters (e.g. AB12-CD34-EF56), from the Manager administrator device.",\r
"The register code is shown on the Manager administrator device (Register chain → Register code). It is entered once; after that cashiers, roles and settings arrive from the server, signed with the company key.",\r
"Printer code page",\r
"Short expiry date",\r
"Register chain: {0}",\r
"Manager (register chain)",\r
"Manager: {0}",\r
"changed in Manager",\r
"The server has the register list of this company — only the code is needed.",\r
"The server has no Manager register list for this company yet (tax ID {0}). The Manager administrator device needs to be online.",\r
"Continue payment",\r
"No approvals in the last 30 days.",\r
"out of stock",\r
"Out of stock by records",\r
"not linked",\r
"New cashier lists, settings and phone approvals will no longer arrive. Manager cashiers remain as they are now (last list).",\r
"required with \\"Other\\"",\r
"objekti TEXT",\r
"rejected",\r
"Rejected from phone: {0}{1}.",\r
"Approvals: {0}",\r
"Approval can also be given by the owner or manager from a phone (Manager).",\r
"Phone approval",\r
"Phone approval is not available (the register is not linked to Manager or it is switched off). A manager PIN is required.",\r
"approved",\r
"Approved from phone: {0}{1}.",\r
"Approved by",\r
"Other actions with approval",\r
"Damaged goods / packaging",\r
"PIN / card",\r
"The PIN is wrong or that person does not approve this action ({0}).",\r
"Start of business day",\r
"settings from Manager: {0}",\r
"Register settings",\r
"Cash withdrawal",\r
"Discount {0} % on receipt {1}{2}{3}",\r
"Discount without approval (%)",\r
"Discount without approval is a percentage from 0 to 100 (empty = role limit).",\r
"Discount over the limit",\r
"popust_odobrio TEXT",\r
"popust_razlog TEXT",\r
"store manager",\r
"Store manager",\r
"linked",\r
"linked to Manager (key {0}){1}",\r
"Link again (new code)",\r
"Link to Manager",\r
"Link to Manager…",\r
"Linking to Manager",\r
"withdrawn",\r
"Role rights",\r
"Role rights saved.",\r
"Role rights…",\r
"empty = \\"Manual discount without manager\\" from settings",\r
"empty = role limit",\r
"Disconnect from Manager",\r
"Disconnect",\r
"Disconnect from Manager",\r
"X report and shift closing (Z)",\r
"Card login too: hold the card to the reader.",\r
"hold the card to the reader while the cursor is in the field; empty = no change",\r
"Sale without stock",\r
"Discount reason ({0} %)",\r
"Discount reason required",\r
"Complaint",\r
"Approval request deadline (min)",\r
"Manual discount {0} % (without approval at most {1} %)",\r
"Manual discount requires a reason",\r
"with a PIN approves voids, returns, write-offs, discounts and prices (Role rights).",\r
"The manager has all rights. An action without the right is done by the cashier with approval (PIN or card of someone with the right, or from a phone via Manager). Manager can send the same rights to all registers.",\r
"a manager",\r
"Roll width (mm)",\r
"The list from Manager is signed with a different company key ({0}; the register is linked to {1}). The register needs to be linked again with a code.",\r
"The list from Manager has no valid company key signature and was not applied.",\r
"The cashier list from Manager has no active manager with a PIN — manager \\"{0}\\" stays active on this register (PRODUCTION does not work without a manager).",\r
"Regular customer / contract",\r
"Kitchen order printer",\r
"Bar order printer",\r
"Receipt printer",\r
"stock {0}",\r
"location stock (data",\r
"location stock (data {0})",\r
"Stock: {0}",\r
"Receipt void and cancellation",\r
"That card is already registered to another cashier.",\r
"phone",\r
"Requested by",\r
"type=\\"password\\" inputmode=\\"numeric\\" maxlength=\\"40\\"",\r
"Remove card",\r
"A note is required with \\"Other\\".",\r
"Register scale",\r
"Scale: weight barcode",\r
"Scale: barcode rules",\r
"Larger quantity (wholesale)",\r
"The connection to Manager is closed.",\r
"connection to Manager closed{0}",\r
"The request is sent to the owner and managers (Manager → Awaiting approval).",\r
"Request valid for {0}:{1}",\r
"The approval request expired without an answer. Approval with a manager PIN is possible.",\r
"shared (opening deposit, payout at Z)",\r
"Employee",\r
"requested from phone: {0}",\r
"Characters per line (ESC/POS)",\r
"{0}: PIN of {1} is required (or a card).{2}",\r
"The PIN is wrong or that person does not approve this action (approved by PIN of {0}).",\r
"store manager",\r
": place the card on the reader.",\r
"{0}: place the card on the reader.",\r
"← Sign in to work",\r
"without this option an unchecked item requires a note",\r
"No events recorded today.",\r
"Card terminal end-of-day completed",\r
"Event",\r
"Arrival / departure",\r
"Arrival / departure: enter PIN",\r
"cashier arrival",\r
"Arrival recorded",\r
"Recording also by card",\r
"Working time record: select the employee, then PIN (or card). The sign-in to the register does not change.",\r
"The working time record is kept in Manager (schedule and actual arrival); the register sends the events.",\r
"Cash in the drawer counted",\r
"Card terminal on and connected",\r
"register closed without sign-out; time of last action",\r
"Register, printer and scanner work; paper roll in place",\r
"Shift checklist",\r
"Checklist: shift opening",\r
"Checklist: shift closing",\r
"Checklist when opening a shift and before the Z report",\r
"Shift checklist",\r
"shift checklist ({0})",\r
"Shift checklist saved.",\r
"Shift checklist…",\r
"Unknown attendance event type.",\r
"required when an item is not checked",\r
"Cashier sign-out from the previous session was not recorded: {0}",\r
"sign-out from register",\r
"cashier departure",\r
"Departure recorded",\r
"Opening cash in the drawer counted",\r
"empty = built-in items",\r
"Sign-in also by card",\r
"sign-in to register",\r
"another cashier signed in",\r
"Attendance today",\r
"attendance not recorded: {0}",\r
"Parked receipts reviewed",\r
"Employee",\r
"Workplace clean and tidy",\r
"Workplace cleaned, devices switched off",\r
"An item that is not in order stays unchecked, with a note.",\r
"Opening items",\r
"items are separated with „;\\"",\r
"Closing items",\r
"All checklist items must be checked.",\r
"All items must be checked",\r
"All items must be checked.",\r
"Recording failed.",\r
"Recording failed. Select the employee again.",\r
"A note is required for unchecked items.",\r
", last",\r
". Quantities below are what has not been returned.",\r
"· register",\r
"· register {0}{1}",\r
"(archive)",\r
"(archive parts: {0})",\r
"(TIN {0}), register {1}, receipts {2}, last {3}.",\r
"(last {0})",\r
"), register",\r
"{0} · {1} · {2} MB",\r
"{0} (older than {1})",\r
"{0} MB",\r
"{0} of {1}, {2}.",\r
"{0} The return was not made.",\r
"{0} receipts · {1} items · {2}",\r
"↩ Receipt from another register",\r
"↩ Receipt from another register or older receipt",\r
"↩ Receipt from another register…",\r
"⇪ Send receipts to the server",\r
"⚙ Archive settings",\r
"✔ Check the archive",\r
"⟲ Restore from backup",\r
"⟲ Restore from backup…",\r
"📷 Scan QR",\r
"🗄 Receipt archive",\r
"🗄 Archive now",\r
"AND id = ?",\r
"archive",\r
"The archive is empty.",\r
"The receipt archive is not available on this device.",\r
"receipt archive: {0}",\r
"receipt archive: {0} receipts, database {1} → {2} MB ({3} ms)",\r
"Archive receipts older than (days, at least {0})",\r
"Receipts archived when older than (days)",\r
"Archiving on the register",\r
"Receipt archiving",\r
"Receipt archiving is turned off (Settings → Receipt archive).",\r
"Archiving of old receipts on the register",\r
"Archiving in progress: {0} of {1} receipts…",\r
"Archiving in progress…",\r
"Archived {0} receipts ({1} items, archive parts: {2}). Database: {3} → {4} MB.",\r
"Receipts archived",\r
"Archive file {0} is missing. It needs to be restored from the copy on the server (More → Receipt archive → Check the archive).",\r
"The archive file was not written correctly (the content read back differs). Archiving stopped; the database was not changed.",\r
"Register database",\r
"The register database was restored from backup {0}. The previous database was kept ({1}). {2}{3}",\r
"the register database could not be opened",\r
"The register database is replaced with the selected backup at the next program start. The current database is not deleted: it is moved to a separate folder „Prije vraćanja\\" in the register data folder. The certificate, server connection and receipt archive remain. The backup is checked first.",\r
"The register database is replaced with the backup at restart. The program now closes and starts again.\\n\\nTo confirm, type the word VRATI.",\r
"The register database is replaced with this backup; the current (damaged) database is not deleted. To confirm, type the word VRATI.",\r
"Receipt number, IKOF or QR code from the receipt",\r
"The receipt counter was set after the last issued number: {0}.",\r
"The receipt counter is already after the last issued number.",\r
"The receipt counter was not set after the restore: {0}",\r
"Receipt counter set ({0}): {1}",\r
"receipt counter set after restore: {0}",\r
"After the restore, receipt counters are set after the last number the register issued (numbers from the current database and the server) — no sequence number is repeated.",\r
"Archive parts",\r
"This archive part is unknown to this database: {0}",\r
"The part can be restored from the copy on the server (button „Obnovi sa servera\\").",\r
"dokumenti:",\r
"The archive file is not readable (JSON).",\r
"Archive file restored from the server ({0} receipts).",\r
"The file is not a register receipt archive.",\r
"Database size limit (MB)",\r
"The database size limit is not valid.",\r
"The selected backup no longer exists. Open the list of backups again.",\r
"the selected file is not a register database",\r
"When the database exceeds (MB, 0 = no limit)",\r
"register {0}",\r
"The register archives on its own, once a day, when idle. When the database exceeds the size limit, receipts are archived when older than",\r
"The register archives on its own, once a day, when idle. When the database exceeds the size limit, receipts older than {0} days are archived.",\r
"the register is not paired with the server",\r
"The register is not paired with the IRIS CORVINA server (Settings → Server).",\r
"of register",\r
"of register {0}",\r
"of register {0}{1} dated {2}, {3}.",\r
"A quantity is required for at least one item (or „Vrati sve\\").",\r
"daily backup (register folder)",\r
"The backup belongs to another company (TIN {0}), while the register works for TIN {1}. Restore is not possible.",\r
"The backup is from another register ({0}), while this register works as {1}.",\r
"The backup has no company data and no receipts (empty register).",\r
"The backup is not a register database: {0}",\r
"The backup is not valid.",\r
"The backup was not read completely ({0} of {1} bytes).",\r
"The backup cannot be opened: {0}",\r
"The backup cannot be read.",\r
"the backup is read-only",\r
"Backup:",\r
"corrective",\r
"Corrective receipts for this receipt (all registers):",\r
"Corrective receipts for this receipt (all registers): {0}. Quantities below are what has not been returned.",\r
"bulk change + compaction + snapshot",\r
"MB",\r
"At least {0} days (the closing file for Accounting carries sales by item for 90 days).",\r
"Invalid archive file name: {0}",\r
"Damaged parts:",\r
"Damaged parts: {0} of {1}.",\r
"No receipts to archive.",\r
"There are no database backups on this device.",\r
"There are no database backups on this device. Contact support.",\r
"Unknown backup.",\r
"Restore from server",\r
"The restored archive file was not written correctly.",\r
"rejected: {0}",\r
"Left to archive: {0} (next round).",\r
"The archive file fingerprint does not match the fingerprint in the register database (this is not the file of this archive part).",\r
"The archive file content fingerprint does not match the recorded fingerprint (the file is damaged or was changed).",\r
"Receipt archive settings",\r
"The Tax Administration rejected this receipt on the register that issued it; the return cannot be reported.",\r
"Sent {0}, confirmed {1}, waiting to be sent {2}.",\r
"Last archiving",\r
"Last receipt in the backup",\r
"Enter the receipt number (e.g. 125 or 125/2026), the IKOF, or scan the QR code from the receipt.",\r
"Confirmation was not entered. The backup was not restored.",\r
"Confirmed on the server",\r
"Return — receipt {0}",\r
"return without server check ({0})",\r
"Return and cancellation of a receipt from another register of the same company or an older receipt (server)",\r
"return and cancellation of a receipt from another register of the same company or an older receipt; number, IKOF or QR from the receipt",\r
"Return and cancellation of a receipt issued by another register of the same company or of an older (archived) receipt. The receipt is searched on the server by number (e.g. 125 or 125/2026), IKOF or the QR code from the customer's receipt. The corrective receipt is issued by this register, with the IKOF of the original.",\r
"A return is possible only from a sales receipt (not from a corrective receipt or correction).",\r
"A return of a receipt from another register or of an older (archived) receipt requires a connection to the IRIS CORVINA server. The return was not made.",\r
"A return from this receipt is in progress on register {0}. Wait until it finishes and try again.",\r
"return from server ({0}{1})",\r
"Return for receipt {0}/{1}{2}{3}",\r
"Return for receipt no.",\r
"Restore from backup works in the installed register (Windows, Android).",\r
"Restore from backup requires register installation 2111 or newer (new Setup).",\r
"reported",\r
"Prije vracanja",\r
"Checking the backup…",\r
"Check in progress…",\r
"checked {0}",\r
"Receipt {0} on the server does not match the register database. The restore was not made.",\r
"receipt {0} is not in the file",\r
"receipt {0}: items in the file do not match the database",\r
"A hotel receipt or a receipt paid from an advance is returned on the register that issued it.",\r
"The receipt was issued by another company (TIN {0}). A return is possible only for receipts of this company.",\r
"The receipt was reported to the Tax Administration in PRODUCTION, while the register now works in the test environment. The return was not made.",\r
"The receipt has not yet been reported to the Tax Administration on the register that issued it (waiting to be sent). A return is possible once it is reported.",\r
"The receipt was not found on the server. The register that issued it may not have sent it yet (no connection to the server).",\r
"The receipt is not in the archive file: {0}",\r
"The receipt is not in its archive part ({0}).",\r
"A receipt with a gift voucher (voucher sold or paid by voucher) is returned by cancellation on the register that issued it.",\r
"Receipts in the database",\r
"Receipts in the register now",\r
"Receipts in the backup",\r
"backup to folder (Google Drive)",\r
"The archive file content is damaged (decompression).",\r
"The archive file content is not readable.",\r
"The archive file content is not valid.",\r
"database compaction (VACUUM)",\r
"The server does not support this action (a newer server version is required).",\r
"The server was not available: if receipts were issued after the backup on another device with the same register code, check the last number (Settings → Fiscalization → „Postavi…\\").",\r
"The server did not return the receipt items.",\r
"Sending failed: {0}",\r
"Sending receipts to the server",\r
"Send receipts to the server (archive on the server, return at another register)",\r
"Ready for archive",\r
"old receipts in the register archive and on the server, archive check, restore from backup",\r
"Older receipts that were reported to the Tax Administration and confirmed on the server go to the archive on the register disk; a short record stays in the database (number, date, amount, IKOF, JIKR, payments, VAT by rate), so reports and journals give the same figures and the register starts faster. Items of an archived receipt are read from the archive (view, receipt copy, inspector journal); returns and cancellations go through the server.",\r
"Items in the archive (total by VAT rate)",\r
"All archive parts are valid ({0}).",\r
"then receipts older than {0} days are archived",\r
"Searching for backups…",\r
"Searching on the server…",\r
"Searching for a receipt from another register requires a connection to the IRIS CORVINA server (Settings → Server).",\r
"The backup has {0} receipts, the register {1}: {2} receipts issued after the backup will not be in the register database (they remain on the server and with the Tax Administration). After the restore, receipt counters are set after the last issued number.",\r
"Restore of the register database from backup {0}",\r
"Return of an archive part to the database",\r
"Restore from backup",\r
"Restore from backup failed: {0} The register works with the current database.",\r
"restore of backup {0}",\r
"vracen",\r
"returned to the database",\r
"Returned to the database: {0} receipts.",\r
"VRATI",\r
"Restore backup",\r
"Restore this backup",\r
"Return everything not yet returned",\r
"Return to database",\r
"— “NLB/Payten — on the same device” (set up in the NLB/Payten section); when the register runs on another device — “NLB/Payten — over the network / Bluetooth”:",\r
"— the receipt is issued with that payment at the next charge of the same amount.",\r
", so the register checks the connection and the amount is keyed in on the terminal (manual confirmation of the approval number).",\r
", version {0}",\r
"(Castles Saturn1000, Android) sends the amount to the NLB “Powered by Payten” app on the same device and reads the result: approval number, masked card, card type. The register does not process cards. Void and slip copy go through the Payten app.",\r
"(Castles)",\r
"(printer)",\r
"{0}\\n\\n(The overview has been copied — it can be forwarded to Payten / Castles.)",\r
"{0} (result received after the register restarted)",\r
"{0}{1}{2} [class {3}]",\r
"978 or EUR",\r
"address (template)",\r
"Action: copy",\r
"Action: refund",\r
"Action: overview",\r
"Action: sale",\r
"Action: void",\r
"Activity (class)",\r
"activities: {0}",\r
"The app {0} is not installed on this device.",\r
"The NLB/Payten app runs on the Android terminal (register installed on the same device).",\r
"The Payten app reported “approved” together with a cancelled activity.",\r
"The Payten app charged a different amount ({0} instead of {1}).",\r
"The Payten app returned the result of a different payment.",\r
"The Payten app closed without a result.",\r
"The Payten app does not accept this action from the register — it is done in the app itself (Void / Copy / Overview).",\r
"The Payten app was not found on this device.",\r
"The Payten app did not return the payment outcome.",\r
"The Payten app did not respond to the register in time.",\r
"Payten app: {0} {1}{2}",\r
"App closed without a result",\r
"Payment apps: {0}",\r
"APPROVED,OK,SUCCESS,00,000",\r
"Bluetooth (paired): {0}",\r
"Bluetooth {0}",\r
"cents (number)",\r
"cents (text)",\r
"DECLINED,REJECTED,DENIED,FAILED,05,51,55",\r
"Direct receipt printing (ESC/POS) is set in Settings → Add-ons. Paper status is checked here: Sunmi through the manufacturer service, other ESC/POS printers with the “DLE EOT 4” query (the printer must answer it). NLB terminal Castles Saturn1000: “Built-in terminal printer” (57 mm roll = 32 characters) — the register looks for a printer the device exposes as a USB or Bluetooth device; the Castles printer SDK is not publicly available, so this is an assumption until verified on the device (“Device overview” button). When direct printing fails, the receipt goes through the Android print system. For wholesale in the field: a 58 mm (32 characters) or 80 mm (48 characters) Bluetooth printer also prints the business customer (name, tax ID, address) and the card approval number.",\r
"until Payten provides the App-to-App specification (not publicly available) — they are entered according to the specification. Package “proba” = simulated Payten app for testing the flow. Terminal type must be “NLB/Payten — on the same device”.",\r
"DRUGA{0}",\r
"“Find Payten app” button or proba",\r
"the bank's ECR specification is not yet available",\r
"The ECR link with the NLB/Payten terminal is awaiting the bank's specification — the amount is not sent to the terminal.",\r
"EUR “12.50” (text)",\r
"EUR (number)",\r
"IP, Bluetooth address, InnerPrinter, USB “vid:pid” (empty = first USB printer; built-in: empty = detected automatically)",\r
"JSON in a single field",\r
"JSON: request field",\r
"Register installed",\r
"The register sends the amount to the terminal, the terminal returns the outcome (approval number, masked card, card type). The receipt is issued only after the terminal approves the payment. NLB terminal (Castles Saturn1000, NLB “Powered by Payten” app): when the register is installed",\r
"Copy",\r
"Copy (test)",\r
"Copy of the last slip",\r
"Slip copy (test).",\r
"Slip copy from the register",\r
"The slip copy has been printed.",\r
"The slip copy is made on the terminal.",\r
"The customer cancelled (test)",\r
"customer cancelled (card not charged)",\r
"Simulated Payten app (test)",\r
"network {0}",\r
"on the NLB terminal",\r
"on the terminal itself",\r
"Payten app found: {0}. Entered in the package field — press “Save” to keep it.",\r
"Several possible apps found ({0}) — enter the package manually.",\r
"Payment in the NLB/Payten app on this device: the customer taps, inserts or swipes the card.",\r
"A payment in the Payten app is already in progress.",\r
"Action and field names (per Payten specification)",\r
"The names below are an assumption",\r
"unclear — the cashier checks the Overview in the app",\r
"Unknown outcome from the Payten app: {0}",\r
"none found (Payten, NLB, Castles).",\r
"The Payten app has not been entered (More → Register devices → NLB/Payten → Find Payten app).",\r
"The Payten app has not been entered.",\r
"Not done.",\r
"NLB/Payten — on the same device (App-to-App)",\r
"NLB/Payten — over the network / Bluetooth (ECR, awaiting specification)",\r
"e.g. sema://pay?amount={centi}&ref={ref}&callback={povratak}",\r
"Amount format",\r
"Payten app package",\r
"PAYTEN-PROBA",\r
"PENDING",\r
"Intent fields",\r
"Terminal ID field",\r
"Charged amount field",\r
"Return address field",\r
"Transaction type field",\r
"port {0}",\r
"A new version of the register app is required (NLB/Payten).",\r
"A new version of the register app is required.",\r
"Refund to card from the register",\r
"register return address (iriskasa://placanje/…)",\r
"The register return address is not available in this app version.",\r
"The return address did not carry the reference of this payment.",\r
"empty = same",\r
"empty = not sent",\r
"empty = by action",\r
"empty = app start screen",\r
"empty = result in fields",\r
"Overview (end of day) from the register",\r
"Device overview",\r
"The device overview works on an Android device.",\r
"Test app on the device",\r
"Find Payten app",\r
"PT{0}",\r
"Done in the Payten app.",\r
"REFUND",\r
"REPORT",\r
"REPRINT",\r
"Result",\r
"activity result",\r
"Result: JSON field",\r
"Address template",\r
"SALE",\r
"Android print services: {0}",\r
"services: {0}",\r
"Manufacturer system libraries: {0}",\r
"Void from the register (same day)",\r
"Void: approval number field",\r
"Void: original reference field",\r
"Void: RRN field",\r
"terminal: slip copy {0}",\r
"terminal: result after restart {0}",\r
"Built-in terminal printer (Castles Saturn1000 and similar)",\r
"built-in terminal printer (Castles Saturn1000)",\r
"The test Payten app on this device has been entered (activity in the register: Approve / Decline / Cancel / No result). Press “Save”, then “Test payment”.",\r
"Done.",\r
"Device: {0} {1}, Android {2}{3}",\r
"USB devices: {0}",\r
"The connection to the terminal works ({0}). {1}",\r
"VOID",\r
"Values for declined",\r
"Type: copy",\r
"Type: refund",\r
"Type: overview",\r
"Type: sale",\r
"Type: void",\r
"An address request requires an address template (NLB/Payten → Address template).",\r
"Request",\r
"— no performer —",\r
"— other time —",\r
"— none (name only) —",\r
"; the advance is selected in “More payment methods”",\r
"· advance {0}",\r
"· advance {0} · to collect",\r
"· warranty {0} mo.",\r
"· limit {0}",\r
"· performer {0}",\r
"· paid",\r
"· PIB {0}",\r
"· reminder sent",\r
"· account {0}",\r
"· to collect",\r
"(after the quote)",\r
"{0} · {1} · {2} min",\r
"{0} · {1} min",\r
"{0} · VAT {1}% · {2}",\r
"{0} {1}: reason for cancellation",\r
"{0} mo.",\r
"{0} months after the appointment",\r
"{0} processes the client's name, phone number and e-mail to schedule appointments, notify of appointment changes and, with separate consent, send e-mail reminders before the appointment. The data is not given to third parties except the processor (IRIS CORVINA, program server). Phone and e-mail are deleted {1}; the client may at any time request access, correction or deletion of the data and withdraw consent.",\r
"{0}: the price on the order ({1}) is higher than the register price list ({2})",\r
"{0}: no register item code",\r
"{0}: the VAT rate in the catalogue ({1} %) differs from the order ({2} %)",\r
"{0}Client",\r
"% requires written consent (Consumer Protection Act, Art. 21).",\r
"% requires the client's prior written consent. The accepted quote is signed by the service and the client; one copy is handed to the client.",\r
"+ New appointment",\r
"+ Device / vehicle intake",\r
"+ Item (labour, part, material)",\r
"⚙ Services — settings",\r
"✍ signature",\r
"✍ Client signature",\r
"👤 Sales by performer",\r
"📅 Appointments",\r
"📅 Appointments{0}",\r
"📷 Device photo",\r
"🔧 Work orders",\r
"🔧 Service work orders",\r
"🔧 Work orders{0}",\r
"🖨 Quote",\r
"🖨 Intake receipt",\r
"🖨 Work order",\r
"The item is not in the register catalogue.",\r
"Advance — order {0}, {1}",\r
"Advance — appointment {0} {1}, {2}",\r
"The advance invoice has been issued ({0}).",\r
"none",\r
"without IKOF",\r
"No performer",\r
"Colour (#RRGGBB, optional)",\r
"Deleting client data",\r
"Deleting client data (personal data protection)",\r
"Deleting the client's phone and e-mail on request",\r
"number, client, serial number, registration",\r
"waiting for a part",\r
"Waiting for a part",\r
"awaiting consent",\r
"Waiting for a part is a phase of an approved order or an order in progress.",\r
"Price excl. VAT",\r
"The price exceeds the client's consent: written consent is required before payment.",\r
"The price has increased by more than {0} % compared to the consent ({1} € → {2} €): the order is not completed until the client's written consent is recorded ({3} para. 2).",\r
"The day is not valid.",\r
"Date ({0}) is before the intake date {1}",\r
"Date ({0}) is in the future.",\r
"Date ({0}) is not valid.",\r
"Date or time is not valid.",\r
"The pick-up date is before the completion date.",\r
"Intake date",\r
"Diagnosis",\r
"Diagnosis is a phase of a received order (before the client's consent).",\r
"dish add-on",\r
"Second service",\r
"Other time (HH:MM)",\r
"electronic (e-mail, message)",\r
"en-GB",\r
"The file is not an image.",\r
"Warranty on work",\r
"Warranty on work (months)",\r
"Warranty: number of months.",\r
"Also on all other appointments with the same phone / e-mail",\r
"Client's full name",\r
"The client's name is not entered.",\r
"Edit appointment",\r
"Above",\r
"Above {0} consent is a signed quote; an increase of more than {1} % requires written consent (Consumer Protection Act, Art. 21).",\r
"The advance amount is not valid.",\r
"Amount incl. VAT, after discount; voids reduce sales. “—” = items without a performer (goods, non-service items).",\r
"performer",\r
"Performer",\r
"Performer (name)",\r
"performer (person)",\r
"Performer / place",\r
"Performer / place: no longer active",\r
"izvrsilac TEXT",\r
"Service performer",\r
"Performer:",\r
"Performers are entered in Services → Settings (register or Manager).",\r
"performers, places, service duration and materials; manager only",\r
"calendar by performer and place, booking, appointment → receipt, advance",\r
"Client",\r
"Client (full name or company name)",\r
"The client declined the quote and the device is returned unrepaired?",\r
"client has arrived",\r
"The client is not entered.",\r
"The client confirms handing over the device and the intake receipt data.",\r
"Collected by client",\r
"The client picks up a completed device (now: {0}). A device with a rejected quote is returned with the action \\"rejected\\".",\r
"The client wants an e-mail reminder",\r
"Who is collecting the device ({0})?",\r
"Cashier / operator code (optional)",\r
"Quantity (labour: hours)",\r
"Contact",\r
"Contact (phone, e-mail)",\r
"Buyer (company)",\r
"Company buyer {0}: enter the buyer on the receipt (Buyer button) if the receipt is issued to the company.",\r
"Company buyer: name",\r
"Company buyer: tax ID (optional)",\r
"Fault / request",\r
"Material “{0}”: catalogue code and quantity per service.",\r
"Charged material (code:quantity, …)",\r
"Material is not in the register catalogue: {0}",\r
"Material included in the price (code:quantity, …)",\r
"service material",\r
"Service material follows the service quantity.",\r
"place (chair, box, room)",\r
"Place (chair, bay, room)",\r
"A receipt is being entered on screen: it must be paid or put on hold.",\r
"at the client's request",\r
"Type of consent",\r
"The client's consent method has not been selected.",\r
"Order {0}",\r
"Order {0} is on screen{1}.",\r
"Order {0} has been charged; only the pick-up can be changed.",\r
"Order {0} has been charged; items cannot be changed.",\r
"Order {0} has been received.",\r
"Order {0} is closed ({1}); items cannot be changed.",\r
"Order {0}: client signature at intake and print the intake receipt?",\r
"The order has no items of work performed, parts and material.",\r
"The order has no items: consent is given to a quote with work, parts and material.",\r
"The order was not found.",\r
"The order cannot be paid at the register: {0}. Use an Accounting invoice or correct the items.",\r
"The name is not entered.",\r
"No longer active",\r
"Unknown order phase.",\r
"Unknown work order action.",\r
"did not show up",\r
"Did not show up",\r
"Not in the register catalogue (not on the receipt): {0}",\r
"New performer",\r
"New performer (hairdresser, technician, doctor)",\r
"New appointment — services and performer",\r
"New place",\r
"New place (chair, bay, room)",\r
"e.g. Dell 5420 laptop, Golf 7",\r
"Delete phone and e-mail",\r
"A quote or price increase is rejected (now: {0}).",\r
"Declined / returned",\r
"Fault description / request",\r
"Fault description / client request",\r
"The fault description is not entered.",\r
"Equipment",\r
"Equipment handed over with the device",\r
"Base {0} · VAT {1} ·",\r
"Cancel appointment",\r
"Appointment cancellation",\r
"Break after the service (min)",\r
"written consent by e-mail or message",\r
"written consent handed over in person",\r
"written (signature)",\r
"by item (service = labour, goods = part)",\r
"Client data has been deleted (appointments: {0}).",\r
"Service settings",\r
"The reminder is sent by e-mail: enter the client's e-mail.",\r
"Client reminder, working hours and data retention: Manager → Services → Settings.",\r
"Quote",\r
"quote issued",\r
"Quote to client",\r
"The quote has no items: enter work, parts and material with prices.",\r
"Quote with specification of work, materials and parts (Consumer Protection Act, Art. 21). A price increase of more than",\r
"Quote with specification of work, materials and parts (Consumer Protection Act, Art. 21). A price increase of more than {0} % requires the client's prior written consent. The accepted quote is signed by the service and the client; one copy is handed to the client.",\r
"A quote is issued for a received order or an order awaiting consent to a price increase (now: {0}).",\r
"REPAIR QUOTE",\r
"Separate receipt item with the service.",\r
"Deducted from stock after payment (consumption, not on the receipt).",\r
"Signature and print",\r
"The signature is empty.",\r
"The signature has been saved with the order.",\r
"Client signature —",\r
"Client signature — {0}",\r
"signed quote (both parties)",\r
"confirmed",\r
"Suggested appointment advance (€)",\r
"Subject",\r
"Item (device, vehicle)",\r
"The item is not entered.",\r
"Collected by",\r
"Picked up",\r
"Collection",\r
"Intake",\r
"Device / vehicle intake",\r
"device or vehicle intake, status, parts and labour, quote and consent, payment",\r
"Intake receipt",\r
"INTAKE RECEIPT",\r
"The attachment cannot be displayed.",\r
"Attachments",\r
"Receive",\r
"Consent",\r
"consent is a signed quote; an increase of more than",\r
"Client consent",\r
"Consent is recorded for an order with a quote or for a price increase (now: {0}).",\r
"Sales by performer",\r
"Sales by performer {0} – {1}",\r
"Receipt {0} — material included in the service price",\r
"Work starts after the client's consent (now: {0}).",\r
"Work order",\r
"WORK ORDER",\r
"Work order {0} — {1}",\r
"Work orders",\r
"Service work orders",\r
"Server queue:",\r
"Server queue: {0} entry not accepted — {1}",\r
"RN-{0}-{1}",\r
"Save signature",\r
"Client consent (phone, e-mail)",\r
"Serial number / registration",\r
"The server does not have services yet (older server version).",\r
"Service",\r
"the service issues a written quote before work. The device is collected with this intake receipt.",\r
"Item code or barcode (from the catalogue)",\r
"The photo has been added to the order.",\r
"The image cannot be read.",\r
"What to set",\r
"Print the quote for the client's signature?",\r
"Condition at intake",\r
"Condition at intake (damage)",\r
"Item \\"{0}\\": price is not valid.",\r
"Item \\"{0}\\": quantity must be greater than zero.",\r
"Item \\"{0}\\": VAT rate is 21, 15, 7 or 0 %.",\r
"Item \\"{0}\\": type is work, part or material.",\r
"Order item",\r
"The item has no name.",\r
"Arrived",\r
"Service VAT rate",\r
"All (30 days)",\r
"The client's phone and e-mail are deleted from the server; the name remains as initials. Deletion cannot be undone.",\r
"Phone and e-mail are entered only with the client's consent (select the type of consent).",\r
"Appointment {0} ({1}) is on screen{2}.",\r
"The appointment has been changed.",\r
"The appointment is booked: {0} {1}.",\r
"Appointment: {0}",\r
"Appointments",\r
"Appointments —",\r
"Appointments — {0}",\r
"Appointments and work orders require the register to be connected to the server (Settings → Server).",\r
"Duration (min)",\r
"Service duration and material",\r
"Duration: at least 5 minutes.",\r
"Requires a place (chair, bay, room)",\r
"requires a written quote",\r
"Third service",\r
"There are no services in the register catalogue (group “Services” in the Accounting catalogue).",\r
"in progress",\r
"In progress",\r
"Remove from calendar",\r
"Total {0}",\r
"Total incl. VAT",\r
"entry not accepted —",\r
"Record consent",\r
"Service",\r
"Service from the catalogue",\r
"The service has been set up.",\r
"Services — settings",\r
"Services (appointments, work orders, performer)",\r
"services by performer for a period; manager only",\r
"The appointment services are not in the register catalogue: {0}",\r
"Services: {0} server entry not accepted (Services → Appointments → Server queue).",\r
"oral (up to the written quote threshold)",\r
"oral (in person or by phone)",\r
"Material consumption was not recorded: {0}",\r
"material consumed for a service",\r
"return",\r
"Back to scheduled",\r
"The repair value is {0} €, higher than {1} €: a written quote specifying work, material and parts, signed by the service and the client, is required ({2} para. 1 and 3).",\r
"The repair value is {0} €, higher than {1} €: before consent, a written quote specifying work, material and parts is issued ({2} para. 1).",\r
"Time (available)",\r
"Appointment time: HH:MM.",\r
"For a company: receipt or invoice to the company.",\r
"For a repair above {0} €, the accepted quote is signed by the service and the client; one copy is given to the client ({1} para. 3).",\r
"For a repair worth more than",\r
"For a repair worth more than {0} the service issues a written quote before work. The device is collected with this intake receipt.",\r
"For a price increase above {0} %, the client's prior written consent is required, given in person or by means of distance communication ({1} para. 2).",\r
"Schedule",\r
"Consumer Protection Act (\\"Official Gazette of MNE\\" 12/26), Art. 21",\r
"An order in progress is completed (now: {0}).",\r
"completed (charged)",\r
"Completed",\r
"completion",\r
"The sum of items ({0} €) exceeds the issued quote ({1} €) by more than {2} %: issue a new quote.",\r
", stock {0}",\r
"· difference {0}.",\r
"(or card)",\r
"(cash receipts + deposits − withdrawals).",\r
"{0}\\n\\nConfirm that the goods are physically here? The sale is recorded and the difference shows at stocktaking.",\r
"{0}: PIN of {1} is required{2}.{3}",\r
"📣 Notify manager: item running out",\r
"Item “{0}” is not in the register catalogue.",\r
"item running out fast (today / tomorrow); goes to alerts and the location's replenishment proposal",\r
"No item selected.",\r
"Advance invoice to a business customer (invoice fiscalization)",\r
"Without handover",\r
"Non-cash invoice to a business customer (invoice fiscalization)",\r
"Count by denominations",\r
"another item — code or barcode",\r
"Invoice fiscalization",\r
"and enters the replenishment and order proposal. Without a connection it waits and is sent with the next register file.",\r
"off = login with name and PIN",\r
"Notify manager: item running out",\r
"The cashier enters the counted cash of their part; the difference per cashier is in X and Z",\r
"The manager has been notified: {0} — {1}.",\r
"No open shift or logged-in cashier.",\r
"optional when an item is selected",\r
"running out today",\r
"running out tomorrow",\r
"running out in the coming days",\r
"not a legal requirement (the Consumer Protection Act requires the price, percentage and amount of the discount on the receipt)",\r
"e.g. 3 pieces left, customers asking",\r
"Expected for",\r
"Expected for {0}:",\r
"A store manager adds and edits only cashiers and waiters. Supervisors and store managers are added by a supervisor.",\r
"An item must be selected or a code entered.",\r
"The counted cash must be entered (e.g. 125.50).",\r
"I confirm the sale",\r
"Counted cash of my part (€)",\r
"Hand over",\r
"Cash handover — {0}",\r
"Cash handover by cashier {0}: counted {1} €, expected {2} €",\r
"Cash handover: {0} {1}{2}",\r
"Hand over my cash…",\r
"Cash handover is done by the logged-in cashier.",\r
"handed over {0}",\r
"Cashier login with card",\r
"Code or barcode (another item)",\r
"Enter the cash the cashier received in this shift (their part of the drawer).",\r
"Enter the total",\r
"The alert goes to the manager for the location",\r
"Summary invoice (invoice fiscalization)",\r
", overdue {0}",\r
", debt collection",\r
", due {0}",\r
"· excl. VAT",\r
"· excl. VAT {0}{1} · base {2} · VAT {3}{4}",\r
"· limit {0}",\r
"· base",\r
"· discount {0} %",\r
"( ) as payment of debt .",\r
"({0}) as payment of debt{1}.",\r
"(no invoice — payment on account)",\r
"(limit {0}, debt {1}).",\r
"(oldest from {0} UTC)",\r
"(balance from Accounting)",\r
"{0} — goods condition",\r
"{0} — return to warehouse (available {1})",\r
"{0} — receipt {1}",\r
"{0} — damaged",\r
"{0} · TIN {1}{2}",\r
"{0} (at customer {1})",\r
"{0} (requested {1}, available {2})",\r
"{0} fiscal receipts have been waiting for Tax Administration confirmation (JIKR) for more than 36 h (oldest from {1}). The delivery deadline is two days (Law on Fiscalization, Art. 17). Connect the register to the internet as soon as possible; if that is not possible before the deadline, the Tax Administration must be notified.",\r
"{0} Cash payment is not allowed (register setting). Payment is possible by card or bank transfer.",\r
"{0} Cash payment is not possible.",\r
"{0} of {1}{2} — open {3}",\r
"{0} Selling above the vehicle stock is not allowed.",\r
"{0}: packaging quantity must be a whole number of pieces.",\r
"{0}: in the vehicle {1}.",\r
"{0}: requested {1}, available {2}",\r
"♻ Packaging return",\r
"💶 Debt collection",\r
"📋 Driver settlement",\r
"📶 Receipts without Tax confirmation",\r
"🖨 A4 receipt",\r
"🚚 Vehicle stock",\r
"Packaging",\r
"Packaging is not a supply and is not part of the VAT base; it is returned or charged at its value.",\r
"Packaging is not a supply and is not part of the VAT base.",\r
"Not issued without approval",\r
"No check",\r
"No warning on Sundays and holidays",\r
"BLOCKED",\r
"blocked for deferred payment",\r
"Number {0}",\r
"Number of pieces the customer returns. Packaging is recorded for evidence only (VAT Act Art. 20(13)).",\r
"register price",\r
"price list {0}",\r
"crveno",\r
"Date {0}",\r
"Date and time",\r
"Debt",\r
"debt {0}",\r
"Debt {0}{1}{2}{3} (balance from Accounting)",\r
"Record-only document",\r
"crates, bottles, pallets from a business customer; packaging balance at the customer",\r
"Cash from customer {0} with server warning (total ≥ €10,000), approved by {1}: {2}",\r
"Cash from customer above €10,000 total (linked transactions)",\r
"Cash from sales",\r
"Cash from sales {0}, debt collection {1}.{2}",\r
"Cash not accepted",\r
"URGENT: {0} fiscal receipts have been waiting for Tax Administration confirmation (JIKR) for more than 48 h (oldest from {1}). The deadline for delivering receipts issued offline is two days (Law on Fiscalization, Art. 17). Connect the register to the internet immediately; if that is not possible, the Tax Administration must be notified of the reason for the delay.",\r
"Good (returns to stock)",\r
"from vehicle",\r
"Select",\r
"Issued",\r
"Issued to customers",\r
"The amount exceeds the open part of invoice {0} ({1} €).",\r
"The payment amount is not valid.",\r
"Receipt amount {0} exceeds the customer's available limit {1}{2}",\r
"Amount incl. VAT",\r
"Same as in Accounting. Cash and card receipts are issued without a limit check.",\r
"card",\r
"Register (ENU) {0}",\r
"register without approver",\r
"COPY",\r
"CORRECTIVE RECEIPT (RETURN)",\r
"Customer {0} is blocked for deferred payment{1}.",\r
"The customer is not in the business customer list.",\r
"Customer required before payment",\r
"a business customer pays an open invoice or debt; payment slip (not a fiscal receipt), cash into the register",\r
"limit {0}",\r
"Customer limit and block (transfer, deferred)",\r
"Customer limit",\r
"Not enough goods in the vehicle: {0}. The receipt was not issued.",\r
"Maximum item quantity",\r
"At most {0} (open part of the invoice).",\r
"Debt collection",\r
"Debt collection (cash)",\r
"Debt collected in cash with approval ({0}) — {1}",\r
"Payment recorded: {0} ({1}).",\r
"Collected in the field.",\r
"Continue",\r
"Not issued",\r
"No business customer with that TIN or name. Business customers come from Accounting (register package).",\r
"Unknown packaging item: {0}",\r
"Net at customers",\r
"Not a fiscal receipt",\r
"No packaging quantity entered.",\r
"This register's site is wholesale. The \\"Wholesale\\" mode is selected in Settings → Operating mode.",\r
"This register's site is a vehicle (mobile business premises). The \\"Field\\" mode is selected in Settings → Operating mode.",\r
"In Accounting this register's site is {0}.",\r
"Site: {0}",\r
"Deferred payment above limit / to a blocked customer with approval ({0}) — {1}, receipt {2}",\r
"Deferred payment above limit or to a blocked customer",\r
"A new shift (#{0}) was opened for cash debt collection.",\r
"Packages: {0} (e.g. \\"3 {1}\\")",\r
"PDF (A4)",\r
"PDF saved: {0}",\r
"VAT rate",\r
"TIN or name of the business customer:",\r
"for receipt / invoice no.",\r
"According to the vehicle stock there are not enough goods:\\n{0}\\n\\nContinue?",\r
"Enter at least one quantity.",\r
"A customer (TIN and name) must be entered — \\"Wholesale\\" / \\"Field\\" mode.",\r
"Packaging return",\r
"PACKAGING RETURN",\r
"Packaging return recorded.",\r
"goods returned to warehouse, damaged goods, handover of cash and packaging",\r
"Return to warehouse",\r
"Return to warehouse is the counted goods being returned; the difference to the vehicle stock is a shortage (or surplus).",\r
"Returnable packaging",\r
"Returnable packaging — record only (VAT Act Art. 20(13))",\r
"Returnable packaging is not set up in Accounting (the register package has no packaging).",\r
"Returnable packaging is recorded for evidence only (VAT Act Art. 20(13)) and is not a supply.",\r
"Returnable packaging with sales to business customers",\r
"Payment reference",\r
"Payment reference:",\r
"Handed over (customer)",\r
"Handed over (driver)",\r
"Cash handed over (€) — to hand over {0}",\r
"Cash handed over cannot be negative.",\r
"Cash handed over is not valid.",\r
"Received by ({0})",\r
"Received by (warehouse / cashier)",\r
"Payment slip",\r
"PAYMENT SLIP",\r
"Payment slip {0}",\r
"A payment slip is not a fiscal receipt (an already issued receipt is being paid). Cash goes into the register (shift).",\r
"The slip confirms payment of an already issued receipt and does not replace a fiscal receipt. Cash is deposited to the company account (takings handover).",\r
"The slip confirms payment of an already issued receipt and does not replace a fiscal receipt. Cash is deposited to the company account (takings handover).{0}",\r
"Trial mode — the receipt was not reported to the Tax Administration.",\r
"Sale from a vehicle (mobile business premises).",\r
"Selling above vehicle stock (field)",\r
"Sold",\r
"No.",\r
"Discount",\r
"Discount %",\r
"customer discount",\r
"Receipt / invoice",\r
"A4 receipt {0}",\r
"The receipt was issued at register",\r
"The receipt was issued at register {0}. {1}",\r
"A deferred-payment receipt is issued only with approval. Cash and card receipts are issued without approval.",\r
"Receipts without Tax Administration confirmation:",\r
"Receipts without Tax Administration confirmation: {0}.",\r
"Receipts waiting for Tax Administration confirmation:",\r
"Available",\r
"Settlement recorded.",\r
"Settlement recorded. Difference for {0} items.",\r
"Driver settlement",\r
"DRIVER SETTLEMENT",\r
"Settle",\r
"Goods issued by",\r
"Goods received by (customer signature and stamp)",\r
"term {0} d.",\r
"Damaged",\r
"Damaged (not for sale)",\r
"Packaging balance at the customer after the return:",\r
"Vehicle stock",\r
"VEHICLE STOCK",\r
"Field (sales from a vehicle)",\r
"In \\"Wholesale\\" / \\"Field\\" mode a customer (TIN and name) must be entered before payment. The receipt was not issued.",\r
"contract price{0}",\r
"Total to hand over",\r
"Record return",\r
"Payer",\r
"Paid by",\r
"Warning",\r
"Warning with approval",\r
"Warn (above limit); block requires approval",\r
"Loading (data)",\r
"loading, sold, available; print vehicle stock sheet",\r
"Loaded",\r
"For receipt",\r
"Wholesale (cash & carry, business customers)",\r
"Wholesale and field",\r
"wholesale — the \\"Wholesale\\" mode is suggested",\r
"Driver",\r
"Vehicle",\r
"a vehicle (mobile business premises) — the \\"Field\\" mode is suggested",\r
"Returned by customers",\r
"There is no loading data for this vehicle (vehicle stock comes from Accounting with the register package).",\r
"The Sunday trading ban (Law on Internal Trade, Art. 35b) applies to retail trade. If the site also sells to individuals, turn this off.",\r
"Vehicle stock",\r
"The customer's cash total reaches €10,000 (Art. 65(2)).",\r
"Customer cash total on server ≥ €10,000",\r
"The total with other registers and Accounting was not checked (no connection to the server).",\r
"Customer limit and block",\r
"Field sales: selling beyond vehicle stock",\r
"— waiting for confirmation from the register…",\r
"Payment {0} — waiting for confirmation from the register…",\r
"A receipt without a subsequent delivery mark must have the send time equal to the issue time (otherwise the Tax Administration rejects it, error 11).",\r
"Saving the database… Issued receipts are saved; the register will continue in a moment.",\r
"The device did not start printing within 30 seconds. Printing needs to be repeated."\r
]\r
`;export{e as default};
