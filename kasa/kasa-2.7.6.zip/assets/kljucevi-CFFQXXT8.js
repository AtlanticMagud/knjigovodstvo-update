const a=`[\r
"-Command",\r
"-ExecutionPolicy",\r
"-NonInteractive",\r
"-NoProfile",\r
"— (do registracije kase kod Poreske uprave)",\r
"— (računar nije na lokalnoj mreži)",\r
"— (upisuje se u Podešavanjima → Fiskalizacija)",\r
"— {0}+{1} gratis",\r
"— bez stola —",\r
"— cijene su ažurirane.",\r
"— izdaje se propisani lijek —",\r
"— kartica (POS)",\r
"— kasa registrovana kao kiosk (npr. ispred prodavnice). Radi i nedjeljom i praznikom, samo sa robom dozvoljenom za kiosk.",\r
"— kasa unutar prodavnice. Nedjeljom i praznikom ne radi (čl. 35b Zakona o unutrašnjoj trgovini).",\r
"— od {0} kom {1}",\r
"— plaća virmanom",\r
"— PONOVLJEN",\r
"— račun sobe",\r
", a kasa radi sa",\r
", ali ne u cijelosti. Potrebno je javiti se održavanju.",\r
", iskorišćeno",\r
", kasir {0}",\r
", licenca {0}",\r
", lot {0}",\r
", naplaćeno {0} od {1}{2}",\r
", od {0}",\r
", odobrenje {0}",\r
", odobreno bez računa:",\r
", pa je vraćena prethodna . Potrebno je obavijestiti održavanje.",\r
", pa je vraćena prethodna{0}. Potrebno je obavijestiti održavanje.",\r
", PIB {0}",\r
", plaćanje karticom (POS)",\r
", pop.",\r
", Poreska",\r
", poziv na broj",\r
", preskočeno {0}",\r
", račun {0}",\r
", storno računa, podešavanja, kasiri i promjena kase traže njegov PIN.",\r
", važi do",\r
", važi do {0}{1}.",\r
", vraćeno {0}",\r
", vrijednost robe po cijenama kataloga",\r
"; artikal se više ne prodaje",\r
"; cijene: {0}",\r
"; do tada: „Ručna potvrda\\" ili „Terminal za probu\\".",\r
"; na čekanju: {0} poruka.",\r
"; ostatak je na stolu {0}",\r
"; svi upisi su sačuvani.",\r
": artikli na mjerenje (kg) sa cijenom po kg i PLU brojem, za uvoz u softver vage.",\r
": dostava (narudžba kao sto „Wolt 123\\"), ekran kuhinje (tablet u režimu „Kuhinja\\" ili Više → Ekran kuhinje), rezervacije i raspored sale (pregled stolova).",\r
": iznos",\r
": iznos {0}, iskorišćeno {1},",\r
": otvara se pri naplati gotovinom i dugmetom „Otvori fioku\\" (uz razlog, koji se bilježi). Fioka je obično priključena na termalni štampač.",\r
": potvrda terminala prije izdavanja računa (za odbijenu karticu račun se ne izdaje); na Androidu i aplikacija banke za naplatu telefonom (SoftPOS; naziv paketa je u Google Play adresi aplikacije banke). Instant: kupac plaća iz svoje banke na račun firme; Poreskoj ide kao „OTHER-CASH\\" (potrebna je provjera na probnom sistemu).",\r
": pravila barkoda sa vage u obliku „prefiksi:vrsta:cifara artikla:cifara vrijednosti:decimala\\", odvojena tačka-zarezom; vrsta: tezina | iznos | komad. Primjer: „27,28:iznos:5:5:2; 2:tezina:5:5:3\\". Prazno = podrazumijevano pravilo (prefiksi 20–29, težina).",\r
": prodaja bona (Više → Poklon-bonovi) i plaćanje bonom (Više načina → Bon). Bon važi na svim kasama firme (razmjena preko servera). Prodaja bona je fiskalni račun sa PDV-om (jednonamjenski bon), a plaćanje bonom ide Poreskoj kao „SVOUCHER\\". Ovaj način",\r
": račun i bon idu direktno na termalni štampač, bez drajvera (brže, sa sječenjem papira i QR kodom). Na Androidu i na Bluetooth štampač i ugrađeni štampač Android kase („InnerPrinter\\").",\r
": tabela svih artikala sa cijenom, cijenom po kg / l i prethodnom najnižom cijenom pri akciji, za uvoz u softver etiketa.",\r
": tabela svih artikala sa cijenom, cijenom po kg / l i prethodnom najnižom cijenom pri akciji, za uvoz u softver etiketa. {0}",\r
": u katalogu {0}",\r
". Ako je kasa u {0}. izdavala račune u drugom programu na ovom kodu, potrebno je upisati njen posljednji broj računa (Podešavanja → Fiskalizacija → „Postavi…\\").",\r
". Fiskalni račun se izdaje pri plaćanju.",\r
". Kasa ovaj fiskalni podatak ne mijenja automatski (kasa je kod Poreske prijavljena u svom poslovnom prostoru). Tačan kod se provjerava u SEP-u: ako je tačan kod iz cjenovnika, upisuje se u polje „Kod poslovnog prostora\\" (Fiskalizacija) i čuva; ako je tačan kod na kasi, ispravka se radi u Knjigovodstvu (Cjenovnik kasa → Kase i marketi).",\r
". Kod ENU iz spiska je kod ranije prijavljene kase. Kasa ne šalje račune Poreskoj dok se ne upiše nov kod ENU (prijava kase) ili šef ne potvrdi postojeći kod uz posljednji broj računa dosadašnje kase (Podešavanja → Fiskalizacija).",\r
". Ostaju u telefonu i šalju se poslije prijave. Odjaviti se?",\r
". Ostali artikli su dostupni pretragom.",\r
". Poslije unosa stavki: „Pošalji nalog\\" ili „Na sto\\"; naplata zatvara sto.",\r
". QR kod važi 10 minuta i samo za jedan telefon.",\r
". Račun se izdaje kad novac stigne.",\r
". Sada je upisano:",\r
". Štampa A4 sa 4 kartice A6 (stalak ili nalijepnica).",\r
"… i još",\r
"… i još {0}",\r
"· {0} artikala · {1} stolova · kasa {2} · naručivanje {3}",\r
"· {0} čeka",\r
"· © 2026 Dragomir Dačević, autor i nosilac prava. Sva prava zadržana.",\r
"· akcija do {0}.{1}.",\r
"· akcija: {0}",\r
"· antibiotik (recept važi 3 dana)",\r
"· barkod {0}{1}",\r
"· bodova: {0}",\r
"· bodovi +{0}{1} = {2}",\r
"· br. {0}",\r
"· čeka: {0}",\r
"· cijena na kasi {0} €",\r
"· cijene provjerene {0}{1}",\r
"· dodato u etikete",\r
"· dolazak {0}",\r
"· GREŠKA",\r
"· grupa {0}",\r
"· IKOF {0}",\r
"· kasa {0}",\r
"· kasa nije uparena sa serverom",\r
"· kasni od {0}",\r
"· konobar {0}",\r
"· Lista FZO: {0}",\r
"· nije na Listi FZO",\r
"· nije na meniju kase",\r
"· nije provjereno",\r
"· odlazak {0}",\r
"· odlazak je bio {0}",\r
"· odobrenje {0}",\r
"· plaćen avans",\r
"· popust {0}",\r
"· popust {0} %",\r
"· Poreskoj upravi će biti prijavljeno kad kasa bude spremna za slanje.",\r
"· povrat {0}",\r
"· pozivi: {0}",\r
"· preskočeno {0} (cijena bi bila ispod 0,01 € ili iznad {1} €)",\r
"· račun je storniran",\r
"· računi br. {0}",\r
"· redoslijed {0}",\r
"· sertifikat još {0} {1}",\r
"· smjena #{0}",\r
"· u kasi {0}",\r
"· uparen {0} · {1}",\r
"· uparena sa serverom",\r
"› pretraga „{0}\\"",\r
"„{0}\\" ne štampa nego snima u fajl. Izaberi pravi štampač u Podešavanjima.",\r
"„Na sobu\\": račun gosta u sobi se ne naplaćuje odmah, nego ulazi u račun sobe i plaća se pri odjavi (sumarni račun). Traži vezu sa serverom.",\r
"„Počni kao nova kasa\\" radi od instalacije kase 1.8.0 (nov Setup).",\r
"„Počni kao nova kasa\\" radi u instaliranoj kasi (Windows, Android).",\r
"„Počni kao nova kasa\\" traži instalaciju kase 1.8.0 ili noviju (nov Setup).",\r
"„Počni kao nova kasa\\": kasa počinje kao poslije prve instalacije (povezivanje sa firmom, bez računa, kasira i podešavanja) — npr. kasa za drugu firmu. Dosadašnji podaci se ne brišu: premještaju se u poseban folder sa datumom u folderu podataka kase, uz rezervnu kopiju baze. Samo šef, poslije zaključka smjene.",\r
"„Poništi\\" posljednjeg računa {0} ({1})",\r
"„Poništi\\" posljednji račun traži PIN šefa",\r
"„Skeniraj QR sa kase\\"",\r
"„Važi do\\" je prije „važi od\\".",\r
"„Važi do\\" ne može biti u prošlosti.",\r
"„Važi od\\" ne može biti u prošlosti.",\r
"( , pros.",\r
"({0} ili noviji)",\r
"({0} osoba-noćenja)",\r
"({0} rač.)",\r
"({0} već postoji)",\r
"({0}) AND {1}",\r
"(bez nadgrupe)",\r
"(bez oznake se preskaču)",\r
"(bez podgrupe)",\r
"(bez prijave)",\r
"(dugme „Nove cijene\\").",\r
"(ENU kase, market). Kodom se kasa povezuje sa firmom preko servera, automatski preuzima cijene i šalje izmjene i zaključke u Knjigovodstvo.",\r
"(Google Drive za računar; folder koji dijele Knjigovodstvo i Menadžer).",\r
"(i još {0})",\r
"(i ranije uklonjeno sa ovog računa: {0})",\r
"(isteklo prije {0})",\r
"(izbor pri svakoj štampi)",\r
"(još {0})",\r
"(kupci vjernosti po telefonu): kupac skuplja bodove i troši ih kao popust; važe na svim kasama firme.",\r
"(lokalni server)",\r
"(neaktivna)",\r
"(nema PIN)",\r
"(nema; sve na jedan nalog)",\r
"(nije izabrana iz spiska).",\r
"(nije promet)",\r
"(nije u zbiru)",\r
"(nije upisan: Podešavanja → Dodaci)",\r
"(novih art. {0})",\r
"(novih artikala {0})",\r
"(odobrenje {0})",\r
"(odobrio šef{0})",\r
"(osn.",\r
"(osnovica",\r
"(osnovica {0})",\r
"(p.broj = ?{0})",\r
"(PIB {0})",\r
"(podfolder u „Dokumenti\\" koji puni sinhronizacija, podrazumijevano „KnjigSync\\").",\r
"(popust {0})",\r
"(Poreska)",\r
"(prazna šifra)",\r
"(račun {0})",\r
"(rolna)",\r
"(skriven iz prodaje; vraća se skidanjem kvačice)",\r
"(slaže se)",\r
"(štampač računa)",\r
"(stornirano)",\r
"(uklonjeno ranije)",\r
"(ušteda",\r
"(ušteda {0} po komadu)",\r
"(uvijek)",\r
"(već ima račune)",\r
"(verzija {0})",\r
"(Više → Upozorenja; Menadžer): storno, poništavanje, fioka bez računa i gotovina preko granice prijavljuju se uvijek; za ostala upozorenja važe granice ispod.",\r
"(vjernost)",\r
"(zauzet, spajanje)",\r
"), prenosi na kasu (USB, mail, Drive) i učitava ovdje.",\r
"). Detalji su u napomeni u odjeljku „Kasa\\".",\r
"[DllImport(\\"winspool.drv\\", CharSet = CharSet.Unicode, SetLastError = true)] public static extern bool OpenPrinter(string p, out IntPtr h, IntPtr d);",\r
"[DllImport(\\"winspool.drv\\", CharSet = CharSet.Unicode, SetLastError = true)] public static extern int StartDocPrinter(IntPtr h, int l, DI d);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool ClosePrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool EndDocPrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool EndPagePrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool StartPagePrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool WritePrinter(IntPtr h, byte[] b, int n, out int w);",\r
"[KasaRaw]::Posalji($env:KASA_RAW_STAMPAC, [Convert]::FromBase64String([IO.File]::ReadAllText($env:KASA_RAW_FAJL)))",\r
"[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] public class DI { public string n; public string o; public string t; }",\r
"{0}\\n\\nDa li kupac ima 18 ili više godina?",\r
"{0}\\n\\nDok je „Šalji račune Poreskoj upravi\\" uključeno, a ovo nije ispravljeno, kasa ne izdaje račune.\\n\\nIsključiti slanje (probni rad) do ispravke?",\r
"{0}\\n\\nIzdavanje računa van radnog vremena traži potvrdu.",\r
"{0}\\n\\nIznos {1} je potrebno ukucati na terminalu. Račun se izdaje tek kad terminal odobri plaćanje. Broj odobrenja sa slipa:",\r
"{0}\\n\\nPlaćanje {1}{2} je potrebno otkazati na samom terminalu. Transakcija ostaje u pregledu „Transakcije terminala\\" dok se ne razriješi.",\r
"{0}\\n(npr. bez leda, sa mlijekom, dobro pečeno)",\r
"{0}\\n{1} kg = {2}\\n\\nPotvrditi količinu?",\r
"{0} — {1} EUR",\r
"{0} — {1} EUR {2}",\r
"{0} — {1} EUR. Stavka se zatvara bez naplate i ne ulazi u saldo.",\r
"{0} — fajlovi čekaju u kasi.",\r
"{0} — račun sobe {1}",\r
"{0} — štampa je ranije prekinuta jer je ponestalo memorije: zatvori kasu i pokreni je ponovo.",\r
"{0} · {1} – {2} · {3} noći{4}",\r
"{0} · {1} (ne ograničava rad)",\r
"{0} · {1} EUR (slobodno {2})",\r
"{0} · do {1} · saldo {2} EUR",\r
"{0} · do {1}{2}{3}",\r
"{0} · PDV {1}%",\r
"{0} · PIB {1}",\r
"{0} · popust {1} %",\r
"{0} · stolovi",\r
"{0} · traženo: {1}",\r
"{0} · vjernost {1} %",\r
"{0} (bez sobe)",\r
"{0} (na stolu {1})",\r
"{0} (najviše {1})",\r
"{0} (nema u katalogu)",\r
"{0} (nije pronađen)",\r
"{0} (PIB {1})",\r
"{0} {1} prijavu",\r
"{0} AND {1}",\r
"{0} art.",\r
"{0} artikala ({1})",\r
"{0} artikala{1}",\r
"{0} bez pakovanja (na etiketi bez cijene po kg / l)",\r
"{0} br. {1}",\r
"{0} čeka{1}",\r
"{0} danas nema",\r
"{0} Detalji: klik na oznaku.",\r
"{0} Dok se ovo ne ispravi, računi se ne izdaju.",\r
"{0} etiketa",\r
"{0} etikete",\r
"{0} EUR",\r
"{0} EUR {1}",\r
"{0} fajl(ova)",\r
"{0} fajl(ova) čeka slanje",\r
"{0} firme na računu ({1}) i za fiskalizaciju ({2}) moraju biti isti.",\r
"{0} ima {1} bodova (vrijednost {2}). Broj bodova za ovaj račun (najviše {3}):",\r
"{0} Izbor je sačuvan na kasi.",\r
"{0} je izdat u probnom radu (nije prijavljen Poreskoj), pa se stvarni dokument ne može na njega pozvati.",\r
"{0} je još probni ({1}). Potreban je kôd koji je dodijelila Poreska uprava.",\r
"{0} je na računu koji čeka (na čekanju ili na stolu). Jedinica i PDV se mogu mijenjati tek kad se taj račun naplati ili obriše.",\r
"{0} je na računu na ekranu. Jedinica i PDV mogu se promijeniti kad se račun naplati ili obriše.",\r
"{0} je Poreska uprava odbila. Prvo ga je potrebno poslati ponovo (Računi → Neposlati).",\r
"{0} je prazna.",\r
"{0} je prevelik.",\r
"{0} je veći od {1} × {2} piksela.",\r
"{0} je veći od {1} KB.",\r
"{0} kg · {1}",\r
"{0} min",\r
"{0} nema PIN. PIN se upisuje na kasi (Podešavanja → Kasiri).",\r
"{0} nije broj.",\r
"{0} nije obrisan nijedan račun.",\r
"{0} nije poslato",\r
"{0} nije u obliku 2026-07-31T07:01:00+02:00 (dato: „{1}\\").",\r
"{0} nije u obliku ab123ab123 (dato: „{1}\\").",\r
"{0} nije u obliku ab123ab123 (upisano: {1}).",\r
"{0} nije upisan.",\r
"{0} nijedna stavka nije uklonjena sa računa koji je izdat.",\r
"{0} Ništa nije izdato.",\r
"{0} noći",\r
"{0} Nova smjena se ne može otvoriti.",\r
"{0} od {1}",\r
"{0} odbijeno",\r
"{0} Povraćaj je potrebno uraditi na terminalu.",\r
"{0} recepata",\r
"{0} se više ne prodaje. Artikal je potrebno ukloniti sa računa ili otpisati (Više → Otpis robe).",\r
"{0} se više ne prodaje. Artikal je potrebno ukloniti sa računa.",\r
"{0} se više ne prodaje. Račun sa ovim artiklom se ne može naplatiti; moguć je samo otpis (Više → Otpis robe).",\r
"{0} st.",\r
"{0} Štampa zato ide kroz prozor za izbor štampača; za štampu bez tog prozora potrebno je izabrati štampač računa.",\r
"{0} stavka",\r
"{0} stavke",\r
"{0} stavki",\r
"{0} veća od 3× (označeno)",\r
"{0} više nije u prodaji",\r
"{0} Za potvrdu: Sačuvaj (Enter) još jednom.",\r
"{0}, od toga {1} sa cijenom ovog mjesta",\r
"{0}, sve po opštim cijenama",\r
"{0}: {1} (novi pokušaj za {2} min)",\r
"{0}: artikal oslobođen PDV-a mora imati stopu 0 (data je {1} %).",\r
"{0}: broj računa mora biti pozitivan cijeli broj.",\r
"{0}: čas u obliku 14:00",\r
"{0}: cijena ne može biti negativna (na stornu je negativna količina).",\r
"{0}: datum ili null.",\r
"{0}: firma nije u sistemu PDV-a, a stavka nosi PDV.",\r
"{0}: izaberite datum.",\r
"{0}: između 0 i 100 %",\r
"{0}: količina je nula.",\r
"{0}: lijek na recept. Izdavanje je moguće samo uz recept (Izdavanje na recept).",\r
"{0}: naziv je obavezan.",\r
"{0}: negativna količina je moguća samo na korektivnom računu (storno).",\r
"{0}: neispravan broj",\r
"{0}: neispravna cijena.",\r
"{0}: neispravna količina.",\r
"{0}: neispravna stopa PDV-a.",\r
"{0}: nepoznat osnov oslobođenja od PDV-a „{1}\\".",\r
"{0}: osnov oslobođenja ide samo uz stopu 0 (data je {1} %).",\r
"{0}: oznaka izuzeća „{1}\\" nije poznata ili stopa nije 0 %.",\r
"{0}: pakovanje od {1} kom. Dodato {2} kom.",\r
"{0}: podaci su sačuvani{1}.",\r
"{0}: popust ne može biti negativan.",\r
"{0}: potreban je PIN šefa.",\r
"{0}: rok ističe {1}.",\r
"{0}: rok je istekao {1}. Artikal nije dodat.",\r
"{0}: stopa PDV-a {1} % nije moguća.",\r
"{0}: upišite cio broj.",\r
"{0}. Fiskalni račun se izdaje pri plaćanju.",\r
"{0}{1} — {2}, {3}.\\nBrisanje ostaje u evidenciji obrisanih (Više → Obrisani računi), odakle se račun može vratiti.",\r
"{0}{1} · {2} st.{3}{4}",\r
"{0}{1} · {2} znakova",\r
"{0}{1} {2} je odštampan.",\r
"{0}{1} nije odštampan (štampač). Kasa je obaviještena; potrebno je ponovo poslati kad štampač proradi.",\r
"{0}a.sifra IN ({1})",\r
"{0}fajlovi čekaju u kasi i šalju se kad se veza uspostavi.",\r
"{0}Nije izdat {1}: {2} Ostatak naplatite ponovo; izdati dokumenti se ne izdaju drugi put.",\r
"{0}Nije poslato: kasa je prešla na PRODUKCIJU prije slanja probnom servisu.",\r
"{0}Paket iz fajla (bez interneta)",\r
"{0}Servis Poreske uprave {1} puta nije primio ovu poruku i nije naveo razlog (druge poruke je primao). Posljednji odgovor: {2} Potrebno je provjeriti {3} i poslati ponovo.",\r
"{0}Sve sa stola {1} je već poslato.",\r
"{mjesto}: {naziv} · {stara} → {nova}",\r
"*izbor-pri-svakoj-stampi*",\r
"&amp;",\r
"&gt;",\r
"&lt;",\r
"&quot;",\r
"%\\"kljuc\\":\\"{0}\\"%",\r
"%\\"tip\\":\\"korekcija\\"%",\r
"%\\"tip\\":\\"namjera\\"%",\r
"%\\"tip\\":\\"prijava\\"%",\r
"%\\"uid\\":\\"{0}\\"%",\r
"•••••••• (sačuvana; prazno = bez izmjene)",\r
"← Drugi kasir",\r
"← Nazad na spisak",\r
"↩ Povrat {0} robe…",\r
"＋ {0} na ovom mjestu{1}",\r
"+ Nov artikal sa ovim kodom",\r
"± iznos (€)",\r
"± procenat (%)",\r
"<!doctype html>",\r
"= U KASI",\r
"★ Brze",\r
"⚠ Upozorenja (30 dana)",\r
"⟳ Objavi meni sada",\r
"🍽 Podijeli račun stola",\r
"🏢 {0} · PIB {1}",\r
"🏢 Dodaj kupca…",\r
"💳 Uređaji kase",\r
"💳 Uređaji kase{0}",\r
"📝 Sadržaj menija",\r
"📝 Sadržaj menija (nazivi, opisi, slike, jezici)",\r
"📤 Izvoz cijena",\r
"📱 Konobari: {0}",\r
"📱 QR meni na stolovima",\r
"📱 QR meni na stolovima{0}",\r
"📱 QR meni{0}{1}{2}",\r
"📷 Skeniraj QR sa kase",\r
"🔍 Pretraga po nazivu ili šifri (svi artikli)…",\r
"🔍 Pretraga: mjesto ili kod kase…",\r
"🖨 A4 / PDF",\r
"🖨 Rolna",\r
"🖨 Štampaj (Z)",\r
"🖨 Štampaj dokument",\r
"🖨 Štampaj kopiju",\r
"🖨 Štampaj presjek (X)",\r
"🧑‍🍳 Ekran kuhinje",\r
"🧑‍🍳 Kuhinja",\r
"🧾 Gost traži račun",\r
"🧾 Račun{0}",\r
"🙋 Zove konobara",\r
"🚫 Nema danas",\r
"🚫 Nema danas{0}",\r
"🛟 Podrška: nov odgovor",\r
"🛟 Podrška{0}",\r
"$ErrorActionPreference = \\"Stop\\"",\r
"0 = bez ograničenja",\r
"0 = bez ograničenja.",\r
"0 = bez poruke",\r
"0 = samo istekla",\r
"1. Kod iz Knjigovodstva (preporučeno)",\r
"28 osim 288",\r
"2D barkod (GS1 DataMatrix / QR)",\r
"4–8 cifara; prazno = bez izmjene",\r
"4–8 cifara; prazno = bez PIN-a",\r
"40 sem 400 i 404",\r
"58 mm (32 znaka)",\r
"6A4D-92DE-B3DB-A31D",\r
"80 mm (42 znaka)",\r
"80 mm (48 znakova)",\r
"a.naziv_n LIKE ?",\r
"ABSOLUT",\r
"ACCOUNT",\r
"ACTIMEL",\r
"ACTIVIA",\r
"Add-Type -TypeDefinition @\\"",\r
"admin",\r
"Adresa",\r
"Adresa FZO WebService-a",\r
"Adresa IRIS-a (radi odmah): {0}",\r
"Adresa kase",\r
"Adresa kase: {0}",\r
"Adresa kupca",\r
"Adresa lokalnog servera je upisana. Uparivanje: kod za uparivanje, pa „Poveži\\" / „Upari\\".",\r
"Adresa menija za goste",\r
"Adresa servera",\r
"Adresa servera mora počinjati sa „https://\\".",\r
"Adresa servera nije https.",\r
"Adresa servera nije ispravna.",\r
"Adresa servera, API ključ i API tajna su obavezni.",\r
"Adresa uređaja nije ispravna (IP:port).",\r
"Adresa uređaja nije ispravna. Upisati IP adresu i port (npr. 192.168.1.60:8888).",\r
"Adresa za ažuriranje",\r
"Adresa za ažuriranje nije ispravna.",\r
"Adresa za ažuriranje nije podešena.",\r
"Adresa za preuzimanje nove verzije nije dostupna.",\r
"Adresa za tablet:",\r
"ADVANCE",\r
"AES-GCM",\r
"Agencija",\r
"AJVAR",\r
"Akcija",\r
"akcija ·",\r
"akcija · {0}",\r
"Akcija „{0}\\": {1}{2}",\r
"Akcija (Intent)",\r
"AKCIJA −",\r
"AKCIJA −{0}",\r
"akcija TEXT",\r
"akcija: {0}",\r
"Akcije i vjernost",\r
"akcijska cijena",\r
"Ako je sat sada tačan (ranije je bio pogrešno pomjeren unaprijed), šef to potvrđuje PIN-om. U suprotnom je potrebno podesiti datum i vrijeme na uređaju. Do tada se račun ne može izdati.",\r
"Ako je sat uređaja bio pogrešno pomjeren unaprijed pa ispravljen, kasa odbija izdavanje računa (sat vraćen unazad). Ovim dugmetom šef potvrđuje da je sat sada tačan.",\r
"Ako vrsta nije poznata, izbor je Market; vrstu je potrebno upisati i u Knjigovodstvu.",\r
"aktivan",\r
"Aktivan",\r
"Aktivan ENU se ne može mijenjati.",\r
"aktivna",\r
"aktivni",\r
"alergeni",\r
"Alergeni (Uredba o informisanju potrošača o hrani)",\r
"ALEVA",\r
"alkohol",\r
"Alkoholna – Pivo",\r
"Alkoholna – Vino",\r
"Alkoholna – Žestoko",\r
"ALU FOLIJ",\r
"AMARETTO",\r
"AMARO",\r
"AMEX",\r
"AMSTEL",\r
"analitika",\r
"Analiza",\r
"Analiza {0} – {1}",\r
"AND {0}",\r
"AND client_uid=?",\r
"AND id=?",\r
"AND kasa_id = ?",\r
"AND p.godina = ?",\r
"AND rezervacija = {0}",\r
"Andrijevica",\r
"Android",\r
"Antibiotik",\r
"AnyDesk / RustDesk",\r
"APEROL",\r
"API ključ",\r
"API tajna",\r
"Aplikacija banke (SoftPOS paket)",\r
"Aplikacija banke je vratila nejasan rezultat.",\r
"Aplikacija banke na ovom uređaju (Android)",\r
"Aplikacija banke ne prima iznos od kase.",\r
"Aplikacija nema spisak kasa. Potrebno je uvesti paket podataka (fajl).",\r
"Apoeni bona (€, zarezom)",\r
"Apoteka — podešavanja",\r
"application/json; charset=utf-8",\r
"APPROVED",\r
"APPROVED,OK,0,00",\r
"april",\r
"aprila",\r
"AQUA",\r
"AQUA VIVA",\r
"AQUAFRESH",\r
"Arapski",\r
"ARASID",\r
"ARAŠID",\r
"ARIEL",\r
"AROXOL",\r
"Artikal",\r
"Artikal „ \\" nije pronađen.",\r
"Artikal „{0}\\" nema barkod {1}.",\r
"Artikal „{0}\\" nije pronađen.",\r
"Artikal „{0}\\" već ima barkod {1}.",\r
"Artikal {0} nije na ovom računu.",\r
"Artikal {0} nije u katalogu.",\r
"Artikal bona nije napravljen. Potrebno je provjeriti apoene (Podešavanja → Dodaci).",\r
"Artikal je dodat: {0}, {1}, šifra {2}.",\r
"Artikal je već u spisku.",\r
"Artikal može imati najviše {0} barkodova.",\r
"Artikal nije dodat: prodaja maloljetnim licima nije dozvoljena.",\r
"Artikal nije dozvoljen za prodaju nedjeljom i praznikom (čl. 35b).",\r
"Artikal nije pronađen.",\r
"Artikal nije u katalogu: {0}",\r
"Artikal nije u katalogu.",\r
"Artikal sa tom šifrom, barkodom ili nazivom nije pronađen.",\r
"artikal se dodaje u „Nove cijene\\" za etikete",\r
"artikal TEXT",\r
"Artikal ulazi u katalog ove kase sa cijenom za ovo prodajno mjesto i šalje se Knjigovodstvu i Menadžeru. Šifru dodjeljuje program.",\r
"Artikal već ima ovu cijenu.",\r
"Artikal više nije u katalogu i uklonjen je iz spiska.",\r
"Artikala",\r
"Artikala iz kataloga koji se nisu prodali",\r
"Artikala koji čekaju novu etiketu: {0}.\\nSkinuti ih sa spiska bez štampe (etikete su već na policama)?",\r
"Artikala sa oznakom „trenutno nema\\": {0}.",\r
"artikala više nema u katalogu",\r
"Artikala više nema u katalogu",\r
"artikala; štampa i tabela sadrže sve.",\r
"artikala. Uvoz zamjenjuje sve artikle i cijene; izdati računi se ne mijenjaju. Fajl može biti katalog jedne kase ili paket sa cijenama po marketima.",\r
"Artikla „{0}\\" nema u katalogu.",\r
"Artikla „{0}\\" više nema u katalogu kase. Potrebno je osvježiti katalog.",\r
"Artikla sa šifrom „{0}\\" nema u katalogu. Za nov artikal obavezan je i naziv.",\r
"Artikla više nema u katalogu: {0}. Potrebno ga je ukloniti sa ekrana.",\r
"Artikle i cijene mijenja samo šef. Potrebno je upisati šefa sa PIN-om (Podešavanja → Kasiri).",\r
"Artikle i cijene mijenja šef na ekranu „Artikli i cijene\\" (Više → Artikli i cijene): promjena cijene, nov artikal, izmjena podataka, grupna promjena. Izmjene se bilježe i šalju Knjigovodstvu i Menadžeru; fajlovi izmjena (format „kasa-cijene\\") se mogu prenijeti i ručno.",\r
"Artikle na kasi može mijenjati samo šef. Potrebno je upisati šefa sa PIN-om (Podešavanja → Kasiri).",\r
"Artikli",\r
"Artikli bez barkoda (hljeb, kese, voće) kao dugmad iznad polja za šifru; dodir na dugme dodaje artikal na račun. Najviše 24.",\r
"Artikli i cijene",\r
"Artikli i cijene (šef)…",\r
"Artikli i cijene na ovoj kasi zamjenjuju se onima iz posljednjeg paketa firme primljenog iz Knjigovodstva (cijene prodajnog mjesta ove kase), i kada su na kasi novije cijene. Izdati računi se ne mijenjaju.",\r
"Artikli i cijene na ovoj kasi zamjenjuju se sadržajem fajla „{0}\\". Izdati računi se ne mijenjaju.",\r
"Artikli kojih više nema u katalogu nisu vraćeni: {0}.",\r
"artiklu",\r
"ATLANTIC INVESTMENT D.O.O.",\r
"AUTIĆ",\r
"Automatska štampa poslije naplate je isključena jer štampač nije izabran. Štampač se bira u Podešavanjima (Račun i štampa); račun se do tada štampa dugmetom „Zadnji\\".",\r
"Automatski „Gost nije došao\\"",\r
"Automatsko preuzimanje ažuriranja",\r
"Automatsko slanje tehničkih grešaka je isključeno (Podešavanja → Podrška i greške). Ni ova prijava se ne šalje dok se slanje ne uključi.",\r
"Automatsko slanje tehničkih grešaka je uključeno (Podešavanja → Podrška i greške).",\r
"Automatsko slanje tehničkih grešaka je uključeno (Podešavanja → Podrška i greške).{0}",\r
"avans",\r
"Avans",\r
"Avans — {0}",\r
"Avans {0} EUR je naplaćen.",\r
"Avans {0} EUR je vraćen.",\r
"Avans i otkaz",\r
"Avans pri otkazu",\r
"Avans za smještaj",\r
"Avans za smještaj {0} – {1}",\r
"Avansi",\r
"Avansi iskorišćeni",\r
"Avansi primljeni",\r
"Avansi vraćeni",\r
"avansni račun",\r
"Avansni račun",\r
"AVANSNI RAČUN",\r
"Avansni račun IKOF",\r
"Avansni račun IKOF {0}",\r
"Avansni račun je izdat (IKOF {0}), ali upis na server nije uspio. Ponovite upis; račun se ne izdaje ponovo.",\r
"Avansni račun je Poreska uprava odbila. Prvo ga je potrebno poslati ponovo.",\r
"Avansni račun je za ovaj račun već korigovan.",\r
"Avansni račun ne može istovremeno biti korektivni račun.",\r
"Avansni račun ne postoji na ovoj kasi.",\r
"Avansni račun nema IKOF.",\r
"Avansni račun nije izdat na ovoj kasi, a podaci avansnog računa nisu upisani na serveru.",\r
"Avansni račun sa stopom PDV-a {0} %.",\r
"Avansni račun se izdaje za primljenu uplatu: način plaćanja ne može biti avans ni odloženo plaćanje.",\r
"Avansni račun se ne poziva na druge račune.",\r
"Avansni račun se ne stornira ovdje. Avans se vraća kroz „Povrat avansa\\" na računu sobe.",\r
"avgust",\r
"avgusta",\r
"AXE",\r
"Ažuriranje iz programa nije podržano u pregledaču; dostupno je u kasi na Windowsu i Androidu.",\r
"Ažuriranje je dozvoljeno samo preko HTTPS veze.",\r
"Ažuriranje je preuzeto",\r
"Ažuriranje je već u toku — sačekaj da se završi.",\r
"Ažuriranje nije uspjelo ({0}). Ništa nije promijenjeno.",\r
"Ažuriranje nije uspjelo.",\r
"Ažuriranje programa",\r
"Ažuriranje se prima samo sa zvanične adrese objave kase ({0}).",\r
"ažuriranje: {0}",\r
"azuriranje: odbijeno brisanje van foldera Verzije: {0}",\r
"azuriranje: userData mora biti puna putanja",\r
"BABY",\r
"BACARDI",\r
"Backspace",\r
"BADEM",\r
"BAGET",\r
"BAILEYS",\r
"BAJADER",\r
"BALLANTIN",\r
"BALLANTINES",\r
"BALON",\r
"BANINI",\r
"Bar",\r
"BARILLA",\r
"Barkod",\r
"Barkod „{0}\\" nije ispravan (cifre, slova, crtica i tačka, najviše 32 znaka).",\r
"barkod {0} povezan sa artiklom {1}{2}",\r
"Barkod {0} već ima drugi artikal. Potreban je izbor ispod polja barkoda.",\r
"Barkod {0} već imaju artikli {1}.",\r
"Barkod {barkod} je povezan sa artiklom „{naziv}\\".",\r
"Barkod {barkod} već ima artikal „{naziv}\\".",\r
"Barkod je obavezan.",\r
"Barkod nije ispravan (cifre, slova, crtica i tačka, najviše 32 znaka).",\r
"Barkod nije primljen jer je pitanje otvoreno. Potrebno je zatvoriti pitanje, pa ponovo očitati barkod.",\r
"Barkod nije vezan ni za jedan artikal.",\r
"Barkod premješta samo šef. Potrebno je upisati šefa sa PIN-om (Podešavanja → Kasiri).",\r
"Barkod sa artikla uklanja samo šef. Potrebno je upisati šefa sa PIN-om (Podešavanja → Kasiri).",\r
"barkod se dodaje postojećem artiklu koji ga nema; naziv i cijena se ne mijenjaju",\r
"Barkod se dodaje postojećem artiklu. Naziv i cijena artikla se ne mijenjaju.",\r
"Barkod, šifra ili dio naziva",\r
"barkod, zatim Enter",\r
"Barkodova",\r
"Barkodovi",\r
"BATAK",\r
"BATERIJ",\r
"Baza artikala nije učitana: {0}",\r
"Baza je pri čitanju javila grešku, a provjera cijele baze je prošla; moguća je greška memorije računara. Ako se greška ponavlja, potreban je pregled računara.",\r
"Baza kase je oštećena i ne može se otvoriti (ni posljednji ni prethodni snimak). Fajlovi baze nisu mijenjani.",\r
"Baza kase još nije snimljena na disk — pokušaj ponovo za minut.",\r
"Baza nije sačuvana ({0}). Instalacija je otkazana.",\r
"Baza nije sačuvana ({0}). Ponovno pokretanje je otkazano.",\r
"Baza u memoriji kase je oštećena (greška memorije računara) i nije upisana na disk. Izdati računi su sačuvani. Potrebno je zatvoriti i ponovo pokrenuti kasu.",\r
"BB",\r
"Bearer {0}",\r
"BEBETO",\r
"BEBI",\r
"Bebi program",\r
"bečići",\r
"BECK",\r
"BEEFEATER",\r
"BEER",\r
"BELVEDERE",\r
"Berane",\r
"Bez „Računaj IKOF i QR\\" slanje Poreskoj upravi nije moguće: računi se izdaju bez IKOF-a i QR koda, kao nefiskalni.\\n\\nIsključiti i fiskalizaciju i slanje (probni rad)?",\r
"Bez barkoda",\r
"Bez bodova",\r
"Bez dodijeljene sobe",\r
"Bez glutena",\r
"bez grupe",\r
"Bez izbora važi način poslovanja upisan na serveru; ako ga nema, kasa prikazuje sve.",\r
"Bez kamere: unos teksta QR koda",\r
"bez kupca",\r
"Bez kupca",\r
"Bez kupca. Za predračun na firmu potrebno je izabrati kupca (PIB i naziv).",\r
"bez kvačica (c c z s dj)",\r
"Bez laktoze",\r
"bez licence (rad bez ograničenja)",\r
"bez novih podataka",\r
"bez odgovora",\r
"bez pakovanja (na etiketi bez cijene po kg / l)",\r
"Bez partnera",\r
"Bez prometa u periodu",\r
"bez računa",\r
"bez računa, uz razlog; otvaranje se evidentira",\r
"Bez rasporeda (mreža)",\r
"bez razloga",\r
"bez recepta",\r
"bez roka",\r
"Bez slike",\r
"bez sobe",\r
"Bez sobe",\r
"Bez štampe",\r
"Bez takse poslije noći",\r
"bez takse: {0}",\r
"Bez ugovora sa FZO (samo privatni recepti)",\r
"Bez upisanih kasira kasa radi bez prijave. Kad je upisan bar jedan kasir, kasa pri pokretanju traži prijavu, a ime kasira se štampa na računu.",\r
"bez veze",\r
"Bez veze",\r
"Bez veze od {0}",\r
"Bez veze od {0}:{1}",\r
"bez veze od pokretanja kase",\r
"Bez veze sa serverom {0} {1} (dozvoljeno {2}). Samo čitanje i izvoz do uspostavljanja veze sa serverom.",\r
"Bez vjernosti",\r
"Bezalkoholna – Energetska",\r
"Bezalkoholna – Gazirana",\r
"Bezalkoholna – Sok/Nektar",\r
"Bezalkoholna – Voda",\r
"BIBER",\r
"Bijelo Polje",\r
"Bilans stanja, Bilans uspjeha, Pojednostavljene napomene, Statistički aneks",\r
"Biranje artikala za grupnu promjenu:",\r
"BISCUIT",\r
"BISKVIT",\r
"Bitova",\r
"BITTER",\r
"Bluetooth",\r
"Bluetooth (Android)",\r
"Bodova po euru (0 = isključeno)",\r
"Bodovi se ne mogu potrošiti uz popust u %.",\r
"Bodovi se troše samo uz kupca vjernosti (Kupac → Telefon).",\r
"Bodovi vjernosti",\r
"Boja",\r
"BOMBAY",\r
"BOMBON",\r
"Bon",\r
"Bon {0} je istekao {1}.",\r
"Bon {0} nije poznat ovoj kasi. Ako je kupljen danas na drugoj kasi, potrebno je sačekati razmjenu sa serverom (Podešavanja → Server).",\r
"Bon {0} sa ovog računa je već korišćen ({1} €). Račun se ne može stornirati.",\r
"Bon je istekao {0}.",\r
"Bon nije poznat ovoj kasi (možda još nije stigao sa druge kase).",\r
"Bon se koristi u svim našim prodavnicama, u jednoj ili više kupovina, do iznosa bona. Ne mijenja se za gotovinu.",\r
"Bon se može koristiti u svim našim prodavnicama, u jednoj ili više kupovina, do iznosa bona. Ne mijenja se za gotovinu.",\r
"Bon važi (dana)",\r
"BON-{0}",\r
"Borac / ratni vojni invalid",\r
"Boravak",\r
"Boravak duži od {0} dana",\r
"Boravak duži od 30 dana",\r
"Boravišna taksa",\r
"Boravišna taksa ({0}{1}",\r
"Boravišna taksa (EUR po osobi i noćenju)",\r
"Boravišna taksa (procjena)",\r
"Boravišna taksa (van računa)",\r
"Boravišna taksa nije prihod; sumarni računi nisu promet (promet je na pojedinačnim računima).",\r
"Boravišna taksa po mjesecima",\r
"Boravišna taksa za opštinu {0} je {1} EUR; u pravilima objekta je {2} EUR.",\r
"Boravišna taksa{0}",\r
"BOUNTY",\r
"br",\r
"BR",\r
"Br.",\r
"br. {0}",\r
"br. {0} ·",\r
"BRANDY",\r
"BRASNO",\r
"BRAŠNO",\r
"BRAVO",\r
"BREF",\r
"BRENDI",\r
"BRIJAC",\r
"BRIJAČ",\r
"Brisanja sa datumom u budućnosti ({0}; pomjeren sat uređaja)",\r
"Brisanja:",\r
"Brisanje",\r
"Brisanje posljednje stavke",\r
"Brisanje računa koji se kuca (kupac odustao, nema novca); ostaje u evidenciji obrisanih",\r
"Brisanje se pamti: ko, kad, koliko, zašto. Šef vidi sve obrisane račune.",\r
"Brisanje starog koda sa artikla",\r
"Brisanje stavke",\r
"Broj",\r
"Broj dokumenta",\r
"broj isprave",\r
"Broj isprave",\r
"Broj je već {0}. Nema izmjene.",\r
"Broj kase za terminal",\r
"Broj knjižice",\r
"Broj koji pokazuje program {0} na ovom računaru. Bez tog programa polje ostaje prazno.",\r
"Broj komada u pakovanju mora biti veći od nule.",\r
"Broj licence mora biti oblika L-2026-0001.",\r
"Broj narudžbe",\r
"Broj nije ispravan (cio broj, npr. 1250).",\r
"Broj osoba nije ispravan.",\r
"Broj računa",\r
"Broj recepta",\r
"Broj recepta nije upisan.",\r
"Broj soba",\r
"Broj telefona je obavezan.",\r
"Broj vize",\r
"Broj zdravstvene knjižice ili JMBG",\r
"Broj zdravstvene knjižice ili JMBG nije ispravan.",\r
"Brojač računa ove kase ({0}) je iza posljednjeg broja iz foldera razmjene ({1}). Kasa je vraćena iz kopije ili ponovo instalirana. Račun nije izdat. Potrebno je upisati posljednji izdati broj, najmanje {2} (Podešavanja → Fiskalizacija → „Postavi…\\").",\r
"Brojač računa ove kase ({0}/{1}) je iza broja iz foldera razmjene ({2}). Kasa je vraćena iz kopije ili ponovo instalirana. Dok se ne postavi posljednji izdati broj, najmanje {3} (Podešavanja → Fiskalizacija → „Postavi…\\"), kasa ne izdaje račune za Poresku.",\r
"BRUT",\r
"Bruto",\r
"BRUTO",\r
"bruto REAL",\r
"Brze tipke (šifre, zarezom)",\r
"Brzi izbor",\r
"Brzina",\r
"Brzina (serijski)",\r
"Budva",\r
"BUDWEIS",\r
"BUREK",\r
"BURN",\r
"button",\r
"BUTTON",\r
"Bypass",\r
"Byte",\r
"CABERNET",\r
"CACKALIC",\r
"ČAČKALIC",\r
"CAJ",\r
"ČAJ",\r
"CAMEL",\r
"CAMPARI",\r
"cancel",\r
"CANCELED",\r
"CANCELED,CANCELLED,ABORTED",\r
"CAPPUC",\r
"CAPTAIN MORGAN",\r
"Čas (0–23) dana poslije planiranog dolaska.",\r
"CAS (ST/US,GS)",\r
"CASH",\r
"CAST(ROUND({0} * 100) AS INTEGER)",\r
"CAST(ROUND(COALESCE({0}, 0) * 100) AS INTEGER)",\r
"CEDEVIT",\r
"čeka",\r
"čeka (sto na kasi)",\r
"Čeka da Poreska prvo primi {0}.",\r
"Čeka da Poreska prvo primi račun koji se stornira.",\r
"Čeka ponovni pokušaj preuzimanja",\r
"čeka Poresku",\r
"čeka potvrdu Poreske uprave",\r
"Čeka se cjenovnik iz Knjigovodstva (glavni računar: Cjenovnik kasa → „Razmijeni sada\\"). Kasa preuzima cjenovnik automatski.",\r
"Čeka slanje",\r
"Čeka slanje na server",\r
"čeka sumarni",\r
"Čeka: {0}.",\r
"Čekaju Poresku",\r
"Čekanja",\r
"Čekanje ishoda (s)",\r
"Čekanje mirne težine (ms)",\r
"Celer",\r
"Centralnom serveru računa čeka slanje: {0}.",\r
"čet",\r
"Cetinje",\r
"CETKIC",\r
"ČETKIC",\r
"četvrtak",\r
"CEVAP",\r
"ĆEVAP",\r
"CHAMPAGNE",\r
"CHANDON",\r
"CHARDON",\r
"checked",\r
"CHESTERFIELD",\r
"CHIO",\r
"chip",\r
"chip veza",\r
"CHIPS",\r
"CHIPSY",\r
"CHIVAS",\r
"CIF",\r
"CIGARE",\r
"CIGARET",\r
"CIGARETA",\r
"cigarete",\r
"CIGARETE",\r
"cijela grupa",\r
"cijelo",\r
"Cijena",\r
"cijena · šifra",\r
"Cijena (EUR sa PDV-om)",\r
"Cijena {0} € je prevelika (najviše {1} €).",\r
"Cijena {nova} je niža od nabavne cijene ({nabavna}). Upisati cijenu?",\r
"Cijena {nova} je veća od najviše dozvoljene cijene lijeka ({max}).",\r
"cijena i akcija artikla, bez unosa na račun",\r
"cijena i cijena po kg / l",\r
"cijena i cijena po kg / l, štampa",\r
"cijena i cijena po kg / l, štampa{0}",\r
"Cijena i plaćanje",\r
"Cijena je prevelika.",\r
"Cijena je u međuvremenu promijenjena. Poništavanje nije moguće.",\r
"Cijena mora biti veća od nule.",\r
"Cijena noći",\r
"Cijena noći (EUR)",\r
"Cijena noći nije ispravna.",\r
"Cijena noći sa PDV-om po periodu. Period za vrstu sobe ima prednost nad periodom za sve vrste; van perioda važi osnovna cijena vrste.",\r
"Cijena po jedinici",\r
"Cijena po noćima",\r
"Cijena sa PDV",\r
"Cijena sa PDV-om (EUR)",\r
"Cijena se mijenja dodirom na cijenu artikla i važi za ovo prodajno mjesto. Izmjene se šalju Knjigovodstvu i Menadžeru.",\r
"cijena u jedan dodir, nov artikal, izmjena artikla, grupna promjena; samo šef, prenosi se Knjigovodstvu i Menadžeru",\r
"cijena upisana za ovo prodajno mjesto",\r
"cijena_utc TEXT",\r
"cijena_vrijeme TEXT",\r
"Cijene iz paketa firme",\r
"Cijene koje su stigle iz kancelarije i čekaju novu etiketu",\r
"Cijene na kasi može mijenjati samo šef. Potrebno je upisati šefa sa PIN-om (Podešavanja → Kasiri).",\r
"Cijene na kasi su iz novijeg paketa ({0}) nego što je paket u programu ({1}). Potrebno je prvo učitati noviji fajl sa cijenama („Učitaj paket iz fajla…\\").",\r
"Cijene su ažurirane.",\r
"Cijene u katalogu su promijenjene; iznos je potrebno provjeriti.",\r
"Cijene u katalogu su promijenjene. Potrebno je provjeriti iznos i ponoviti naplatu.",\r
"cijene za „{0}\\"",\r
"Cijene: {0}.",\r
"Cijenu mijenja korisnik sa ovlašćenjem.",\r
"CIMET",\r
"CINZANO",\r
"Cio katalog se zamjenjuje artiklima i cijenama sa servera.",\r
"CIPS",\r
"ČIPS",\r
"Čišćenje",\r
"Čišćenje starih obrisanih računa nije uspjelo: {0}",\r
"Čišćenje u toku",\r
"Čista",\r
"Čitač barkoda se preuzima (Google Play usluge). Ponovni pokušaj je moguć za pola minuta.",\r
"Čitač isprave upisuje zonu ovdje; može i ručno, red po red.",\r
"Čitaj težinu iz barkoda (vaga)",\r
"Cjenovnik",\r
"Cjenovnik iz Knjigovodstva za ovu kasu navodi kod poslovnog prostora",\r
"Cjenovnik je druge firme (PIB {0}) i nije primijenjen.",\r
"Cjenovnik kasa → „Sačuvaj cjenovnik u fajl\\"",\r
"Cjenovnik navodi drugi kod poslovnog prostora (",\r
"Cjenovnik nije primijenjen: {0}",\r
"Cjenovnik se ne može pročitati: {0}",\r
"Cjenovnik u folderu je druge firme (PIB {0}).",\r
"čl. {0}",\r
"čl. 26",\r
"čl. 27",\r
"CLIPSY",\r
"COALESCE(p.kupac_pib, '') LIKE ?",\r
"COALESCE(podgrupa,'') = ?",\r
"COALESCE(r.popust, 0)",\r
"COALESCE(r.popust, 0) <> 0",\r
"COALESCE(r.vrsta, 'racun') <> 'otpis'",\r
"COALESCE(st.popust, 0)",\r
"COALESCE(vrsta, 'racun') <> 'otpis'",\r
"COCA",\r
"COCKTA",\r
"COGNAC",\r
"COINTREAU",\r
"COKOLAD",\r
"ČOKOLAD",\r
"COLA",\r
"COLGATE",\r
"Concert ne zna radnju: {0}",\r
"Concert: odgovor neočekivane dužine ({0})",\r
"Concert: poruka nije dužine 34",\r
"Content-Type, {0}",\r
"CORNFLAKE",\r
"CORONA",\r
"CORRECTIVE",\r
"CP852 (č ć ž š đ)",\r
"Crnogorski",\r
"CROCKY",\r
"CROISS",\r
"CUBA",\r
"CUCLA",\r
"čuva se maskiran",\r
"Čuvanje ličnih podataka (godina)",\r
"Čuvanje ličnih podataka: najmanje 1 godina",\r
"Da",\r
"Dalje",\r
"dan",\r
"Dan",\r
"Dan / od",\r
"Dan izvještaja: od 1 do 31",\r
"dana",\r
"Dana po isteku svakih 15 dana u mjesecu.",\r
"danas",\r
"Danas",\r
"Danas je {0}. Za ovaj kiosk nije upisano koja se roba smije prodavati nedjeljom i praznikom (čl. 35b). Prodaja nije ograničena.\\n\\nSpisak dozvoljenih grupa artikala upisuje se u Knjigovodstvu (Cjenovnik kasa → kasa).",\r
"Dani",\r
"Danilovgrad",\r
"DATA",\r
"data-rn=\\"smjena\\" data-id=\\"{0}\\" title=\\"Ponovna štampa zaključka (Z) ove smjene\\"",\r
"datalist",\r
"Datum",\r
"Datum „do\\" je prije „od\\".",\r
"Datum „do\\" mora biti GGGG-MM-DD ili null (bez roka).",\r
"Datum „od\\" je poslije datuma „do\\".",\r
"Datum „od\\" mora biti GGGG-MM-DD.",\r
"Datum „važi do\\" je prije datuma „važi od\\".",\r
"Datum „važi do\\" nije u obliku 2026-07-31 (dato: „{0}\\").",\r
"Datum „važi od\\" nije u obliku 2026-07-31 (dato: „{0}\\").",\r
"Datum nije ispravan.",\r
"Datum propisivanja",\r
"Datum propisivanja je u budućnosti.",\r
"Datum propisivanja nije upisan.",\r
"Datum rezervacije nije ispravan.",\r
"datum rođenja",\r
"Datum rođenja",\r
"datum u budućnosti",\r
"Datum ulaska u Crnu Goru",\r
"Datum uređaja ({0}) je raniji od datuma posljednjeg računa ({1}). Računi se ne izdaju dok sat i datum uređaja ne budu tačni.",\r
"Davalac organa / krvi (više od 10 puta)",\r
"DAVIDOFF",\r
"DAYS",\r
"Deaktiviran ENU se ne može mijenjati.",\r
"decembar",\r
"decembra",\r
"DECLINED",\r
"DEFGHIJKLMNOPQRSTUVWXYZ",\r
"DEO",\r
"Depozit",\r
"Depozit — novac u kasu",\r
"depozit / podizanje",\r
"Depozit je upisan:",\r
"DEPOZIT…",\r
"Depoziti",\r
"Depoziti i podizanja",\r
"DETERDZ",\r
"DETERDŽ",\r
"DEZINF",\r
"DEZODOR",\r
"Dibal (kao Toledo)",\r
"DIGESTIV",\r
"dijela",\r
"dijeli ga i",\r
"dijeli ga i {0}",\r
"Dijete",\r
"Dijete do {0} godina",\r
"Dijete do 12 godina",\r
"Dimenzije slike nisu čitljive.",\r
"DINERS",\r
"Dio gosta ({0} EUR)",\r
"Dio gosta (saldo)",\r
"Dio pacijent",\r
"Dio partnera ({0} EUR)",\r
"Dio partnera (saldo)",\r
"Dio računa partnera ostaje za fakturu.",\r
"Dio robe je već vraćen; ostatak se vraća povratom, ne stornom.",\r
"Dio robe sa ovog računa je već vraćen. Ostatak se vraća kroz „Povrat dijela robe\\".",\r
"dio stavki na naplatu, ostatak ostaje na stolu",\r
"Direktna štampa",\r
"Direktna štampa (ESC/POS)",\r
"Direktna štampa nije dostupna. Potrebna je nova verzija aplikacije (1.5).",\r
"Direktna štampa nije uspjela: {0}. Štampa ide kroz drajver štampača.",\r
"Direktna štampa računa",\r
"Direktna štampa računa (ESC/POS) se podešava u Podešavanjima → Dodaci. Ovdje se provjerava stanje papira: Sunmi kroz servis proizvođača, ostali štampači ESC/POS upitom „DLE EOT 4\\" (štampač mora odgovarati na upit). Za veleprodaju na terenu: Bluetooth štampač 58 mm (32 znaka) ili 80 mm (48 znakova) štampa i kupca-firmu (naziv, PIB, adresa) i broj odobrenja kartice.",\r
"Direktna štampa radi samo u instaliranoj kasi (Windows / Android).",\r
"Direktno slanje",\r
"Direktno slanje: dostupno po dobijanju tehničkog uputstva Uprave policije.",\r
"direktor",\r
"disabled",\r
"disabled title=\\"Kod je šifra artikla; premještanje nije moguće.\\"",\r
"disabled title=\\"Lijek nije u šifarniku kase\\"",\r
"DISARONNO",\r
"Disk je pun — fajl nije sačuvan. Oslobodi prostor pa pokušaj ponovo. (ENOSPC)",\r
"Disk je pun — fajl razmjene nije upisan. (ENOSPC)",\r
"Disk je pun — oslobodi prostor (npr. stare rezervne kopije u Dokumenti\\\\Kasa), pa pokušaj ponovo. (ENOSPC)",\r
"Disk je pun — rezervna kopija nije upisana. (ENOSPC)",\r
"div",\r
"Djece",\r
"Djelatnosti firme",\r
"DJELIMICNO",\r
"Dnevni izvještaj",\r
"Dnevni izvještaj za ovaj dan",\r
"Dnevni pregled",\r
"dnevnik",\r
"Dnevnik je veći od {0} MB.",\r
"Dnevnik se vodi automatski i čuva koliko i podaci o prijavi gostiju.",\r
"Dnevnik u prilogu: niz do {0} redova teksta (red do {1} znakova).",\r
"Dnevnik: nedostaju upisi {0}–{1}; oporavak je stao (kopija dnevnika je sačuvana).",\r
"Dnevnik: red {0} je oštećen; oporavak je stao na tom mjestu (kopija dnevnika je sačuvana).",\r
"Dnevnik: upis {0} se nije mogao primijeniti ({1}) i preskočen je; kasniji upisi su primijenjeni. Kopija dnevnika je sačuvana. Potrebno je javiti se održavanju.",\r
"do",\r
"Do",\r
"Do (uključeno)",\r
"Do {0}",\r
"Do kada gost napušta sobu na dan odlaska.",\r
"dobavljač",\r
"Dobavljaci",\r
"dobavljaču",\r
"dobro",\r
"Dobro došli",\r
"DOCUMENTS",\r
"Dodaci (1.5)",\r
"Dodaj",\r
"Dodaj gosta",\r
"Dodaj i ovom artiklu",\r
"Dodaj kao nov artikal",\r
"Dodaj način plaćanja",\r
"Dodaj objekat",\r
"Dodaj recept",\r
"Dodaj sobe",\r
"Dodaj uslugu",\r
"Dodaj vrstu sobe",\r
"dodati u etikete",\r
"Dodatne kase ili uređaji, produženje probnog perioda, dodatni modul (Knjigovodstvo, Menadžer) ili drugo. Izdavač odgovara ovdje (odobreno / odbijeno, sa obrazloženjem).",\r
"Dodatni modul (Knjigovodstvo, Menadžer…)",\r
"Dodatnih ležaja",\r
"Dodato na sto {0}.",\r
"Dodato soba: {0}{1}.",\r
"Dodato u spisak: {0} sa novim cijenama.",\r
"Dodato: {0}",\r
"Dodato.",\r
"Dodavanje — sto {0}",\r
"Dodavanje više soba",\r
"Dodir na cijenu otvara tastaturu za novu cijenu. Cijena važi za ovo prodajno mjesto, bilježi se (ko, kad, stara → nova) i šalje Knjigovodstvu i Menadžeru.",\r
"Dogovorena cijena noći (EUR)",\r
"Dok kasa nema ENU, računi su",\r
"dok nema sertifikat i kodove Poreske uprave ili dok je okruženje TEST. Na računu ispod naslova piše „PROBNI REŽIM — NIJE PRIJAVLJEN PORESKOJ UPRAVI\\".",\r
"dok račun nije izdat",\r
"Dok se ovo ne ispravi, računi se ne izdaju.",\r
"dok.,",\r
"Dokazi",\r
"Dokumenata otpisa:",\r
"Dokument",\r
"Dokument br.",\r
"Dokument dobija svoj broj (O-1, O-2…), štampa se i vidi se u pregledu računa pod „Otpisi\\".",\r
"Dokument iz reda ne postoji na ovoj kasi ili nema IKOF.",\r
"Dokument je izdat bez IKOF-a.",\r
"Dokument je prevelik za štampu ({0} MB). Suzi period ili izbor i štampaj u dijelovima (izvještaj se može sačuvati i kao tabela).",\r
"Dokument nije fiskalni i ne ulazi u promet. Roba se skida sa stanja kao da je prodata. Namjena: roba kojoj je istekao rok, oštećena ili neupotrebljiva roba koju dobavljač ne uzima nazad.",\r
"Dokument otpisa",\r
"Dokument otpisa nije račun. Povrat nije moguć.",\r
"Dokument otpisa se ne stornira. Otpis robe je evidencioni dokument, nije račun.",\r
"Dokument otpisa se ne stornira. Otpis robe nije račun.",\r
"Dokument se ne može izdati bez IKOF-a (fiskalizacija nije uključena ili nema sertifikata). Ništa nije izdato.",\r
"Dokumenti su izdati. Upis na račun sobe čeka vezu sa serverom.",\r
"Dolasci",\r
"Dolasci i noćenja po državi (TU-11)",\r
"Dolasci i noćenja po državi i mjesecu",\r
"Dolasci od danas",\r
"Dolazak",\r
"Dolazak (prva noć)",\r
"dolazak {0}",\r
"dolazak danas",\r
"Dolazak danas",\r
"Dolazak je prijavljen.",\r
"Dolazak kasni ({0})",\r
"Dolazak od",\r
"Dolazak od (čas)",\r
"Domaće",\r
"domaći",\r
"Domaći gost",\r
"Domaći gost (državljanin Crne Gore)",\r
"Domaći: {0} dolazaka, {1} noćenja · strani: {2} dolazaka, {3} noćenja.",\r
"DOMACIC",\r
"DOMAĆIC",\r
"Domen {0} je upisan. QR kodovi sa tim domenom se štampaju na glavnoj kasi (QR meni → Podešavanja → sopstveni domen).",\r
"Domen je uklonjen. QR kodovi vode na adresu menija IRIS-a.",\r
"DOMESTOS",\r
"ĐON",\r
"Doplata",\r
"doplata {0}",\r
"Doplate",\r
"DORINA",\r
"DORITOS",\r
"Doručak, polupansion, pansion.",\r
"Dostava",\r
"Dostupna je nova verzija kase {0} (Podešavanja → Ažuriranje).",\r
"Dostupna je nova verzija:",\r
"Dostupna je nova verzija: {0}",\r
"dot",\r
"DOVE",\r
"Dozvola je izdata za kasu {0}, a ovo je kasa {1}.",\r
"Dozvola važi samo {0}. Potrebna je nova dozvola za današnji dan.",\r
"Dozvoli pristup",\r
"dozvoljen",\r
"Dr Proba (faksimil 0000)",\r
"DRAZE",\r
"DRAŽE",\r
"DRESING",\r
"DRINA",\r
"Droga",\r
"droga (PRp)",\r
"Droge i psihotropne supstance se u privatnoj apoteci ne izdaju na teret FZO-a.",\r
"Druga isprava",\r
"druga kasa",\r
"Druga kasa",\r
"Druge vrste",\r
"Drugi prozor sa stavkama i iznosom računa; na drugom monitoru se otvara preko cijelog ekrana. Važi od sljedećeg računa.",\r
"drugo",\r
"Drugo",\r
"Drugo (napomena)",\r
"Drugo (opis u napomeni)",\r
"Država",\r
"Država izdavanja",\r
"Država izdavanja isprave",\r
"država koja je izdala ispravu",\r
"država rođenja",\r
"Država rođenja",\r
"Drzavljanstvo",\r
"državljanstvo",\r
"Državljanstvo",\r
"ĐUBR",\r
"DUEL",\r
"Dug korektivnog računa nema dokument.",\r
"dugme",\r
"Dugme „↩ Poništi\\" na glavnom ekranu poništava posljednji račun (kupac nije platio, greška u unosu) do 30 min poslije izdavanja; bez ove kvačice kasir koji je izdao račun poništava ga bez odobrenja šefa. Storno starijih računa (Računi) uvijek traži šefa.",\r
"DUHAN",\r
"DUNHILL",\r
"duplikat ali nije nadjen",\r
"Duvan",\r
"DUVAN",\r
"Dvokrevetna soba",\r
"Dvostruka naplata",\r
"Dvostruka naplata ({0}): {1} Pregled računa → storno.",\r
"Dvostruka naplata: {0} — račun treba stornirati",\r
"DZAK",\r
"DŽAK",\r
"DZEM",\r
"DŽEM",\r
"E-kopija: QR računa na ekranu kupca (sekundi)",\r
"E-pošta",\r
"e-recept FZO (servis)",\r
"e-recept FZO, recept FZO (aplikacija Fonda / ručni), privatni recept; farmaceut",\r
"E-recepti pacijenta",\r
"e.g. The kitchen is open until 11 pm",\r
"EACCES",\r
"EADDRINUSE",\r
"EAN-13",\r
"EAN-8",\r
"EBUSY",\r
"EC",\r
"ECDSA",\r
"EDAMER",\r
"efi_uuid TEXT",\r
"efi_zadnji TEXT",\r
"ekran je javio: {0}",\r
"Ekran je prazan.",\r
"Ekran kuhinje (nalozi i na ekran)",\r
"Ekran kuhinje nije uključen na kasi (Podešavanja → Dodaci).",\r
"Ekran kupca",\r
"Ekran kupca na drugom ekranu Android kase (Sunmi T2, D2s i slične kase sa dva ekrana).",\r
"Ekran kupca preko mreže nije uključen na kasi.",\r
"Ekran kupca uključen",\r
"Ekran kupca: prozor na drugom monitoru ovog računara i/ili tablet u lokalnoj mreži (pregledač na tabletu otvara adresu ispod). Tablet traži uključen server telefona konobara (Podešavanja → Konobari).",\r
"Ekran računa nije spreman.",\r
"ekran se nije učitao ({0})",\r
"ekran se srušio ({0})",\r
"Ekran za kupca (drugi monitor)",\r
"ekran: {0}",\r
"Elektronska kopija računa: skenirajte QR telefonom",\r
"Elektronske etikete",\r
"Email",\r
"ENERG",\r
"Engleski",\r
"ENOENT",\r
"ENOSPC",\r
"Enter",\r
"enu TEXT",\r
"EPERM",\r
"ERDINGER",\r
"Esc",\r
"Escape",\r
"ESPRESSO",\r
"ESSE",\r
"Etiketa",\r
"Etiketa sa cijenom i cijenom po kg / l",\r
"Etikete",\r
"Etikete sa cijenama",\r
"EUR",\r
"EUR · saldo",\r
"EUR · uplaćeno",\r
"EUROCREM",\r
"EUROKREM",\r
"Evidencija se čuva godinu dana; stariji zapisi se brišu automatski.",\r
"Evidencija se čuva godinu dana. Najstariji dostupan datum je {0}.",\r
"Evidencioni dokument (nije fiskalni račun). Roba je skinuta sa stanja; ne ulazi u promet i ne prijavljuje se Poreskoj upravi.",\r
"ex TEXT",\r
"F-tasteri",\r
"F-tasteri na glavnom ekranu (rad bez miša). F5 i F12 se ne koriste. Taster radi kad nije otvoren nijedan prozorčić.",\r
"FA",\r
"FAIRY",\r
"Fajl",\r
"Fajl „{0}\\" sadrži katalog jedne kase, a ne paket sa spiskom kasa. Cio katalog se zamjenjuje sadržajem fajla; spisak kasa ostaje isti. Izdati računi se ne mijenjaju.",\r
"fajl {0} je oštećen",\r
"fajl {0} je oštećen i nije čitljiv",\r
"fajl {0} je prazan",\r
"fajl {0} ne može da se pročita ({1})",\r
"fajl {0} se ne može raspakovati",\r
"Fajl izmjena cijena je druge firme (PIB {0}).",\r
"fajl je veći od {0} MB i ne šalje se na server.",\r
"Fajl ne liči na config.json kase (nema oznake kase, firme ni adrese servera).",\r
"Fajl nije čitljiv (očekuje se fajl podešavanja config.json).",\r
"Fajl nije čitljiv (očekuje se JSON katalog kase).",\r
"Fajl nije čitljiv (očekuje se JSON).",\r
"Fajl nije dozvola za poništavanje PIN-a.",\r
"Fajl nije fajl izmjena cijena (format „kasa-cijene\\").",\r
"Fajl nije fajl izmjena cijena (očekuje se format „kasa-cijene\\").",\r
"Fajl nije katalog kase (očekuje se format „kasa-katalog\\").",\r
"Fajl nije mijenjan; kasa radi u probnom režimu. Potrebno je ponovo pokrenuti kasu. Ako se greška ponovi (npr. podaci su preneseni sa drugog računara), nečitljivi ključevi se odbacuju dugmetom ispod, a sertifikat se uvozi ponovo.",\r
"Fajl nije paket podataka kase (očekuje se format „kasa-paket\\").",\r
"Fajl nije upisan u cijelosti.",\r
"Fajl nije upisan u cijelosti. Potrebno je ponoviti radnju.",\r
"Fajl sa sertifikatom, ključem i lozinkom servera se premješta u stranu (ne briše se), a kasa nastavlja bez njih, kao nova.\\n\\nPoslije toga potrebno je ponovo uvesti sertifikat (.pfx) i upisati lozinku servera.\\n\\nOvaj korak je predviđen samo kada ponovno pokretanje kase nije otklonilo grešku. Nastaviti?",\r
"Fajl se pravi u Knjigovodstvu (",\r
"Fajl sertifikata je prazan.",\r
"fajl tajne.json je nestao, a postoji njegova prethodna kopija tajne.json.stari — treba je vratiti ručno",\r
"fajl tajne.json je oštećen — prazan je ili nečitljiv",\r
"fajl tajne.json ne može da se otvori — drži ga drugi program ili mu je pristup zabranjen ({0})",\r
"fajl tajne.json nije u obliku koji kasa poznaje",\r
"Fajl zaključaka kase {0} u folderu razmjene piše drugi uređaj (napravljen {1}). Ako kasa nije upravo ponovo instalirana ili vraćena iz kopije, dva uređaja rade kao ista kasa. Na jednom od njih potrebno je izabrati pravu kasu (Podešavanja → Promijeni kasu).",\r
"fajlova izmjena: {0}, primijenjeno {1}{2}",\r
"Fajlova kase koji čekaju slanje na server: {0}.",\r
"Fajlove sa servera i svoje fajlove razmjene kasa čuva u svom prostoru (ne u folderu razmjene), pa za razmjenu nisu potrebni ni Autosync ni dozvola „pristup svim fajlovima\\".",\r
"Fajlovi ažuriranja su zauzeti (antivirus?). Ništa nije promijenjeno — pokušaj ponovo za minut.",\r
"Fajlovi kase čekaju slanje na server.",\r
"Fajlovi ove kase koji nisu stigli na server: {0}. Ostaju samo u folderu razmjene.",\r
"FANTA",\r
"Farmaceut:",\r
"Farmaceut: {0}",\r
"februar",\r
"februara",\r
"Feed",\r
"Feed ima neispravnu najmanju verziju Setup-a (minSetup).",\r
"Feed ima neispravnu oznaku verzije Android paketa.",\r
"Feed ima neispravnu oznaku verzije.",\r
"Feed nema ispravan kontrolni zbir (sha256) — paket se ne može prihvatiti.",\r
"Feed nema polja \\"verzija\\" i \\"url\\".",\r
"Feed nije ispravan JSON.",\r
"FETA",\r
"fic IS NOT NULL",\r
"FIDE",\r
"FINLANDIA",\r
"Fioka",\r
"Fioka je otvorena (zabilježeno).",\r
"Fioka otvorena bez računa: {0}",\r
"Fioka se nije otvorila: {0}",\r
"Fioka se otvara preko",\r
"Fioka za novac",\r
"firma",\r
"Firma",\r
"Firma / paket",\r
"firma isključena na serveru",\r
"firma je kod izdavača isključila prijem tehničkih grešaka",\r
"Firma je kod izdavača isključila prijem tehničkih grešaka. Prijava nije poslata; podršci je moguće pisati porukom (kartica Poruke).",\r
"Firma je kod izdavača isključila prijem tehničkih grešaka. Prijava se ne šalje; podršci je moguće pisati porukom (kartica Poruke).",\r
"Firma je privremeno isključena na serveru. Fajlovi ove kase čekaju i šalju se automatski kad firma bude ponovo uključena (pokušaj na svakih 15 minuta). Ponovno uparivanje nije potrebno.",\r
"Firma na računu",\r
"Firma ne postoji u Registru poreskih obveznika.",\r
"Firma nije aktivna u Registru poreskih obveznika.",\r
"Firma nije u sistemu PDV-a (Podešavanja), a na računu je stavka sa PDV-om. Potrebno je ispraviti stope artikala ili PDV status firme.",\r
"Firma nije u sistemu PDV-a, a na računu je stavka sa PDV-om.",\r
"Firmi:",\r
"fiscal_error LIKE ?",\r
"Fiskalizacija",\r
"Fiskalizacija je isključena u podešavanjima.",\r
"fiskalizovano",\r
"Fiskalni dokumenti pri odjavi",\r
"Fiskalni podaci",\r
"Fiskalni račun",\r
"Fiskalni račun se izdaje pri plaćanju.",\r
"Fiskalni servis je odgovorio HTTP {0} bez čitljivog odgovora.",\r
"Fiskalni servis nije prepoznao poruku. Mogući uzrok: pogrešna adresa servisa (Podešavanja → Fiskalizacija) ili greška u programu.",\r
"Fiskalno",\r
"FLASIC",\r
"FLAŠIC",\r
"FLIPS",\r
"Folder (Google Drive)",\r
"Folder (Google Drive) nije podešen.",\r
"folder podataka kase nije poznat",\r
"Folder razmjene ne postoji ili nije dostupan: {0}",\r
"Folder razmjene nije podešen (Podešavanja → Razmjena sa Knjigovodstvom).",\r
"Folder razmjene sa Knjigovodstvom (Google Drive)",\r
"Folder služi za rezervnu kopiju baze kase: jednom dnevno, posljednjih 7 dana, u podfolderu „Kasa rezerva\\".",\r
"Folder za automatski upis nije podešen (Podešavanja → Dodaci).",\r
"Folder za elektronske etikete",\r
"formula",\r
"FRUCTAL",\r
"FRUVITA",\r
"FZO",\r
"FZO (aplikacija Fonda)",\r
"FZO {0}",\r
"FZO ručni recept",\r
"FZO servis (nije podešen)",\r
"FZO WebService (po specifikaciji Fonda)",\r
"GARNIER",\r
"GAUDA",\r
"GAULOISES",\r
"GAZIRAN",\r
"GEL ZA TUS",\r
"GEL ZA TUŠ",\r
"GET",\r
"GILLETTE",\r
"GIN",\r
"GLADE",\r
"glavni",\r
"glavno",\r
"glavnoj kasi",\r
"GLO",\r
"godina",\r
"Google Drive",\r
"Google Drive (Autosync)",\r
"Google Drive (rezervna kopija)",\r
"GORDON",\r
"GORDONS",\r
"GORKI LIST",\r
"GORSKA",\r
"gost",\r
"Gost",\r
"Gost — {0} {1}",\r
"Gost (QR meni)",\r
"Gost (QR){0}",\r
"gost čeka",\r
"Gost je ipak stigao",\r
"Gost je obrisan.",\r
"Gost je odjavljen.{0}",\r
"Gost je premješten.",\r
"Gost je sačuvan.",\r
"Gost nije došao",\r
"gost odlazi danas",\r
"Gost poništava svoju narudžbu",\r
"Gost poništio narudžbu (QR meni)",\r
"Gost skenira QR kod na stolu, vidi meni na svom jeziku i naruči — narudžba ide pravo na sto i u kuhinju / šank (konobar ne potvrđuje). Gost može poništiti narudžbu dok račun nije izdat, pozvati konobara i tražiti račun (kartica na POS terminalu ili gotovina). Fiskalni račun izdaje ova kasa kad konobar naplati sto.",\r
"Gost traži račun. Kasa je obaviještena.",\r
"Gost traži račun{0}",\r
"gost u sobi",\r
"Gost u sobi",\r
"gost zove",\r
"Gost zove konobara",\r
"Gost: {0}",\r
"gosta čekaju",\r
"Gosti",\r
"gosti naručuju sa telefona, poziv konobara, račun karticom / gotovinom; QR kodovi, jezici, slike",\r
"Gosti naručuju sami (bez ovoga: samo meni, poziv konobara i račun)",\r
"gosti nisu upisani",\r
"Gosti nisu upisani.",\r
"gostiju u objektu",\r
"gotov",\r
"gotovina",\r
"Gotovina",\r
"GOTOVINA",\r
"Gotovina istom kupcu",\r
"Gotovina istom kupcu u danu: {0} (granica 10.000 €, čl. 65 st. 2) — {1}",\r
"Gotovina od 10.000 € naviše nije dozvoljena (Zakon o sprečavanju pranja novca i finansiranja terorizma, čl. 65). Račun nije izdat. Naplata je moguća karticom ili virmanom.",\r
"Gotovina u kasi",\r
"Gotovina u kasi najviše (€)",\r
"Gotovinski promet",\r
"gotovo",\r
"Gotovo",\r
"Gotovo ({0})",\r
"Grad",\r
"GRAH",\r
"GRAND KAF",\r
"GRANINI",\r
"GRASAK",\r
"GRAŠAK",\r
"gratis (N+M)",\r
"greska",\r
"greška",\r
"Greška",\r
"Greška kase (šifra {0}).",\r
"Greška na ekranu",\r
"Greška na kasi: {0}",\r
"Greška na kasi.",\r
"Greška na strani fiskalnog servisa. Slanje se ponavlja kasnije.",\r
"Greška pri čitanju elektronskog potpisa.",\r
"Greška pri čitanju elementa potpisa.",\r
"Greška pri naplati",\r
"greška pri pokretanju",\r
"greška radnika",\r
"Greška servera.",\r
"greška u kucanju",\r
"Greška u kucanju",\r
"Greška: {0}",\r
"GREY GOOSE",\r
"Grickalice",\r
"GRISIN",\r
"GRIZ",\r
"grupa",\r
"Grupa",\r
"Grupa je prazna.",\r
"grupa_id INTEGER",\r
"grupa_id, proizvodjac, neto, neto_jm, pakovanje, max_zaliha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",\r
"Grupe (kategorije)",\r
"Grupe koje idu na šank",\r
"Grupna promjena",\r
"Grupna promjena cijena",\r
"GST PLUS",\r
"GUARANA",\r
"GUMENE",\r
"Gusinje",\r
"GUSTIN",\r
"H:TAKSA",\r
"HALLS",\r
"HARIBO",\r
"HAVANA CLUB",\r
"HEETS",\r
"HEINEKEN",\r
"HELJD",\r
"HELL",\r
"hemija",\r
"HEMIJSK OL",\r
"HENNESSY",\r
"Herceg Novi",\r
"hidden",\r
"higijena",\r
"Higijena i hemija",\r
"Hitno (cito)",\r
"HLEB",\r
"HLJEB",\r
"HMAC",\r
"Hostel",\r
"Hotel",\r
"hotel: {0}{1}",\r
"Hotelijerstvo (hoteli, apartmani, sobe)",\r
"Hrana uz smještaj",\r
"HRENOVK",\r
"Hronična bolest iz čl. 17 (maligna, dijabetes, epilepsija, MS, HIV, hepatitis…)",\r
"http",\r
"HTTP {0}",\r
"HTTP {0}: {1}",\r
"https",\r
"https://… ili http://…:8080",\r
"Humanitarna pomoć",\r
"Hvala na kupovini",\r
"i da li je račun poslije naplaćen.",\r
"i ne šalju se Poreskoj upravi. ENU se upisuje poslije registracije kase (Podešavanja → Fiskalizacija).",\r
"i ne ulazi u promet; roba se skida sa stanja.",\r
"i ne ulazi u promet; roba se skida sa stanja.{0}",\r
"ICE TEA",\r
"ICE-TEA",\r
"ID",\r
"ID programa ({0})",\r
"iframe",\r
"IGRACK",\r
"IGRAČK",\r
"IHDR",\r
"IKOF",\r
"IKOF {0}",\r
"IKOF {0}{1}",\r
"IKOF avansnog računa nije ispravan („{0}\\").",\r
"IKOF avansnog računa nije ispravan.",\r
"IKOF računa sa odloženim plaćanjem nije ispravan.",\r
"IKOF se ne slaže sa svojim potpisom (IKOF mora biti MD5 potpisa). Račun je pogrešno upisan.",\r
"ili",\r
"ili iznos €",\r
"ILUMA",\r
"ima",\r
"Ime",\r
"ime {0} je rezervisano",\r
"ime fajla izlazi iz foldera: {0}",\r
"ime fajla sa slovima koja kasa ne umije da pročita",\r
"Ime gosta je obavezno.",\r
"ime i prezime",\r
"Ime i prezime",\r
"Ime kasira je obavezno.",\r
"Ime telefona (vidi se na kasi)",\r
"img",\r
"INDIJSK",\r
"informativno: pazari uneseni OCR-om često nemaju „ukupno bez PDV\\"; nalog uzima sa PDV − PDV",\r
"Ingenico Telium (Concert)",\r
"input",\r
"INPUT",\r
"inputmode=\\"decimal\\" placeholder=\\"0 = bez ograničenja\\"",\r
"inputmode=\\"numeric\\" placeholder=\\"8765\\"",\r
"inputmode=\\"url\\" placeholder=\\"https://…\\"",\r
"INSEKT",\r
"Instalacija je moguća nakon zaključenja smjene.",\r
"Instalacija se ne može pokrenuti.",\r
"Instalira se preko postojeće verzije; podaci ostaju sačuvani.",\r
"Instalira se preko postojeće verzije; podaci ostaju sačuvani.{0}",\r
"Instaliraj sada",\r
"Instant",\r
"Instant plaćanje",\r
"Instant plaćanje (prenos na račun)",\r
"Instant plaćanje nije uključeno (Podešavanja → Dodaci).",\r
"Instant prenos",\r
"INTEGRAL",\r
"IntPtr h; if (!OpenPrinter(stampac, out h, IntPtr.Zero)) throw new Exception(\\"KASA_NEMA_STAMPACA\\");",\r
"Invaliditet",\r
"INVOICE",\r
"IP (192.168.1.50), ime Windows štampača ili Bluetooth adresa",\r
"IP, Bluetooth adresa, InnerPrinter, USB „vid:pid” (prazno = prvi USB štampač)",\r
"IP, ime Windows štampača, Bluetooth adresa ili InnerPrinter",\r
"IPv4",\r
"IQOS",\r
"IRIS",\r
"IRIS CORVINA",\r
"IRIS CORVINA Kasa",\r
"IRIS CORVINA Kasa {0} · © 2026 Dragomir Dačević, autor i nosilac prava. Sva prava zadržana.",\r
"IRIS ECR (JSON, most ka terminalu)",\r
"IRIS Kasa",\r
"IRIS Kasa — ekran za kupca",\r
"IRIS Server",\r
"IRIS Server nije nađen u ovoj mreži. Adresa se može upisati ručno (ekran „Pregled\\" programa IRIS Server), ili se kod za uparivanje upisuje kao link iz IRIS Admina.",\r
"Ishod",\r
"Ishod plaćanja nije poznat",\r
"Isječak za potpis gosta",\r
"Isključen",\r
"isključena na serveru",\r
"isključeno",\r
"Isključeno: računi se izdaju bez PDV-a.",\r
"Isključi",\r
"Isključi oboje",\r
"Isključi slanje",\r
"Isključi vezu",\r
"Isključivanje fiskalizacije",\r
"Isključivanje slanja",\r
"Isključivanje veze sa serverom",\r
"Iskorišćeno",\r
"Iskorišćeno bodova: {0}, popust {1}.",\r
"Iskoristi",\r
"Iskustvo",\r
"Isplaceno",\r
"isplata pri zaključku",\r
"Isprava",\r
"Isprava važi do",\r
"Ispravka podataka",\r
"Ispravke i poboljšanja.",\r
"Ispravlja avansni račun IKOF",\r
"Ispravlja avansni račun IKOF {0}{1}",\r
"Ispravu izdao",\r
"Ista prijava je već poslata u posljednjih 10 minuta.",\r
"istekao",\r
"istekao rok",\r
"Istekao rok trajanja",\r
"Isteklo vrijeme preuzimanja.",\r
"Isti račun je naveden dva puta među referentnim računima.",\r
"Isti račun je naveden dva puta.",\r
"isto ime je i fajl i folder: {0}",\r
"isto ime se javlja dvaput: {0}",\r
"Item",\r
"Item Price",\r
"Item Tax",\r
"ITF",\r
"iz aplikacije dostave (ili ime kupca)",\r
"Iz avansa",\r
"iz avansa {0}",\r
"Iz avansa se ne može platiti više od iznosa računa ({0}).",\r
"Iz avansa se ne može platiti više od iznosa računa.",\r
"Iz fajla „{0}\\" se preuzima nov spisak kasa i učitavaju se {1}. Izdati računi se ne mijenjaju.",\r
"Iz fajla „{0}\\" se preuzimaju adresa servera, štampa i slična podešavanja.\\n\\nOznaka kase, prodajno mjesto, firma, svi kodovi za Poresku, okruženje i prekidači slanja se ne mijenjaju (kasa je izabrana iz spiska kasa).",\r
"Iz fajla „{0}\\" se preuzimaju i oznaka kase, market, firma i kodovi za Poresku, pored servera i štampe. Okruženje (TEST/PRODUKCIJA) i prekidači slanja se ne preuzimaju.",\r
"Iz isprave se čitaju samo podaci; slika se ne snima.",\r
"iz naziva",\r
"iz specifikacije FZO",\r
"Izaberi artikle u spisku…",\r
"Izaberi fajl…",\r
"Izaberi kasu iz spiska…",\r
"Izaberi sliku…",\r
"Izaberi…",\r
"Izaberite avansni račun.",\r
"Izaberite datum.",\r
"Izaberite ispravan period.",\r
"Izaberite izvještaj i period, pa „Prikaži\\".",\r
"Izaberite posljednju noć u istom redu.",\r
"Izaberite vrstu sobe.",\r
"izabran",\r
"Izabran je isti sto.",\r
"izabrana",\r
"Izabrani",\r
"izabrani artikli ( )",\r
"izabrani artikli ({0})",\r
"izabrano. Artikli se označavaju u spisku.",\r
"Izbor artikla sa liste otvara naziv i opis na jezicima, alergene, oznake i sliku.",\r
"Izbor grupe sa liste otvara naziv na jezicima, redoslijed na meniju i sliku pločice.",\r
"Izbor kase",\r
"Izbor kase nije dostupan.",\r
"Izbor po grupi ili pretraga po nazivu.",\r
"Izbor radnog marketa",\r
"Izbor sa spiska otvara izmjenu; „Novi unos\\" dodaje novi.",\r
"Izbor sa spiska prikazuje podatke.",\r
"Izbor se kasnije mijenja u podešavanjima (Podešavanja → Kasa).",\r
"Izdaj — gotovina",\r
"Izdaj — kartica",\r
"Izdaj avansni račun",\r
"Izdaj račun",\r
"Izdaje se storno račun, a ovaj ostaje u evidenciji kao storniran. Poništavanje je nepovratno.",\r
"Izdao",\r
"Izdao (organ)",\r
"Izdat je",\r
"Izdati su",\r
"Izdato po receptu. Račun: {0} ({1}).",\r
"Izdato: {0}.",\r
"izdavac",\r
"izdavač: {0}",\r
"izdavač: zahtjev za pristup ekranu",\r
"Izdavanje na recept",\r
"Izjasnjenje",\r
"Izmijeni",\r
"Izmijeni podatke artikla",\r
"Izmjena",\r
"Izmjena artikla",\r
"Izmjena je poništena. Cijena je vraćena na {stara}.",\r
"Izmjena kasira",\r
"Izmjena nije pronađena.",\r
"Izmjena podataka artikla se ne poništava ovdje. Podaci se mijenjaju u obrascu artikla.",\r
"Izmjene cijena su sačuvane: {0}",\r
"Izmjene cijena: primijenjeno {0}{1}, preskočeno {2}, za druge kase {3}.",\r
"Izmjene menija nisu sačuvane",\r
"Izmjene nisu sačuvane. Napustiti ih?",\r
"Izmjene ove kase nisu upisane u folder: {0}",\r
"Izmjene ove kase su upisane.",\r
"izmjene ove kase upisane",\r
"Izmjene sadržaja menija nisu sačuvane i biće odbačene.",\r
"Izmjene u verziji {0}",\r
"Iznos",\r
"IZNOS",\r
"Iznos (EUR)",\r
"Iznos avansa mora biti veći od nule.",\r
"Iznos avansnog računa mora biti veći od nule.",\r
"Iznos depozita ne može biti negativan.",\r
"Iznos gotovine u kasi na početku smjene (€).\\nPrazno ili 0 = bez depozita.",\r
"Iznos je obavezan.",\r
"Iznos je poslat na terminal. Kupac plaća karticom na terminalu.",\r
"Iznos je prevelik.",\r
"Iznos je veći od najvećeg koji terminal prima ({0} €).",\r
"Iznos je veći od slobodnog dijela avansa.",\r
"Iznos korekcije avansa mora biti veći od nule.",\r
"Iznos mora biti veći od nule.",\r
"Iznos na terminalu: {0}. Račun se izdaje tek kad terminal odobri plaćanje. Broj odobrenja sa slipa (neobavezno):",\r
"Iznos naknade mora biti veći od nule.",\r
"Iznos nije ispravan",\r
"Iznos nije ispravan. Primjer: 1250,50 (bez tačke za hiljade, najviše dvije decimale).",\r
"Iznos obrisanog računa ne može biti negativan.",\r
"Iznos plaćanja nije ispravan.",\r
"Iznos podizanja gotovine mora biti veći od nule.",\r
"Iznos podizanja gotovine ne može biti nula.",\r
"Iznos popusta nije ispravan.",\r
"Iznos povrata (EUR)",\r
"Iznos povrata je 0.",\r
"Iznos povrata mora biti veći od nule.",\r
"Iznos prelazi dozvoljeni dug sobe.",\r
"Iznos računa ({0}) je veći od zbira njegovih stavki ({1}).",\r
"Iznos se nudi po opštini; za ostale opštine upisati iznos iz odluke opštine.",\r
"Iznos storna sumarnog računa mora biti manji od nule.",\r
"Iznos sumarnog računa mora biti veći od nule.",\r
"Iznos sumarnog računa nije jednak zbiru pojedinačnih računa.",\r
"Iznos takse",\r
"Iznos takse (EUR po osobi i noćenju)",\r
"Iznos takse je sačuvan.",\r
"Iznos takse je veći od 10 EUR",\r
"Iznos takse nije ispravan.",\r
"Iznos u centima (inače u eurima)",\r
"Iznos u poruci ({0}) nije iznos računa ({1}).",\r
"Iznos za „{0}\\" nije ispravan.",\r
"Iznos za plaćanje nije ispravan.",\r
"Iznos za terminal nije ispravan.",\r
"Izvještaj",\r
"Izvještaj o taksi za prethodni mjesec.",\r
"Izvještaji",\r
"Izvještaji nisu dostupni.",\r
"Izvor",\r
"izvor TEXT",\r
"IZVORSKA",\r
"Izvoz",\r
"Izvoz CSV",\r
"j4sVG68Z6QZGUfZ64qBQSMeUiLa8LQYOxzMKIXC-Pmg",\r
"Jacina",\r
"Jačina",\r
"JACK",\r
"JACK DANIELS",\r
"JACOBS",\r
"JAFA",\r
"JAFFA",\r
"JAGER",\r
"JÄGER",\r
"JAGERMAISTER",\r
"JAGERMEIJSTER",\r
"JAGERMEISTER",\r
"JÄGERMEISTER",\r
"JAGNJET",\r
"Jaja",\r
"JAMESON",\r
"JANA",\r
"januar",\r
"januara",\r
"JAR",\r
"JCB",\r
"je {0} računa",\r
"je 1 račun",\r
"je na ekranu.",\r
"je otvoren.",\r
"je preuzeta i postavljena.",\r
"je preuzeta i primjenjuje se pri sljedećem pokretanju.",\r
"je preuzeta i provjerena.",\r
"Jedan šef nema PIN i ne može da odobrava (traži se PIN drugog šefa). PIN se upisuje dugmetom „Izmijeni\\".",\r
"Jedinica mjere",\r
"Jedinica mjere nije sa spiska.",\r
"Jedinica neto količine mora biti jedna od: {0}.",\r
"Jedinica pakovanja mora biti kg, l ili kom.",\r
"jedno",\r
"jednokratno",\r
"Jednokrevetna soba",\r
"JELEN",\r
"Jezik",\r
"Jezik natpisa na ekranu ove kase; važi odmah. Fiskalni računi, štampa, etikete i izvozi ostaju na crnogorskom jeziku.",\r
"Jezik natpisa na ekranu ovog uređaja. Izvozi (Excel, PDF), štampa i etikete ostaju na crnogorskom jeziku.",\r
"Jezik natpisa na ekranu ovog uređaja. Izvozi (PDF, Excel, XML), štampa, fiskalni računi i obrasci za Poresku upravu ostaju na crnogorskom jeziku.",\r
"Jezik nije promijenjen: {0}",\r
"Jezik programa",\r
"Jezik: {0}{1}",\r
"JIKR",\r
"JIM BEAM",\r
"JM",\r
"JM neto",\r
"jm TEXT",\r
"JMB",\r
"JOGURT",\r
"JOHNNIE",\r
"JOHNNIE WALKER",\r
"još {0}",\r
"Još kasa / uređaja",\r
"Još nema narudžbi gostiju.",\r
"još nije bilo",\r
"Juče",\r
"JUICE",\r
"jul",\r
"jula",\r
"jun",\r
"juna",\r
"JUNEC",\r
"JUNEĆ",\r
"JUNETINA",\r
"Kad",\r
"Kad je uključeno, računi, storna, depoziti i podizanja idu Poreskoj upravi čim je internet dostupan. Potrebni su sertifikat i ispravni kodovi. Promjena važi tek poslije „Sačuvaj\\". Dok je uključeno, a kasa nije spremna (nema sertifikata, kod nije ispravan), računi se ne izdaju.",\r
"Kad je upisan",\r
"KAFA",\r
"Kafa i čaj",\r
"KAHLUA",\r
"KAHVA",\r
"KAJMAK",\r
"KAKAO",\r
"Kako se izdaju računi kad gost odlazi.",\r
"Kalendar",\r
"Kamp",\r
"Kanal",\r
"Kanal mora biti probni ili stabilni.",\r
"Kanali dostave (zarezom)",\r
"Kanali dostave nisu upisani (Podešavanja → Dodaci).",\r
"KAPUCIN",\r
"KARLOV",\r
"Kartica",\r
"KARTICA",\r
"Kartica / instant",\r
"Kartica: potvrda „Odobreno na terminalu?\\"",\r
"Kasa",\r
"KASA",\r
"Kasa (ENU)",\r
"Kasa {0} · {1} · uparena sa serverom{2}",\r
"Kasa {0} je počela naplatu. Oslobađa se samo ako ta kasa ne radi.",\r
"Kasa ↔ terminal",\r
"Kasa automatski šalje tehničke greške izdavaču (pad ekrana, greška sa serverom, odbijanje Poreske), bez sadržaja računa; lični podaci (imena, telefoni, iznosi) se brišu prije slanja. Ovdje se opisuje ono što kasa ne bilježi: koja radnja je rađena, šta se očekivalo i šta se desilo.",\r
"Kasa i terminal se slažu.",\r
"Kasa izabrana iz spiska kasa firme dobija i cijene svog prodajnog mjesta.",\r
"Kasa izdaje korektivni račun avansnog računa.",\r
"Kasa je automatski upisuje u folder „{0}\\" (esl_cijene.json) pri svakoj promjeni cijena.",\r
"Kasa je na vezi sa serverom i razmjena je ažurna.",\r
"Kasa je na vezi sa serverom i razmjena je ažurna.{0}",\r
"Kasa je obaviještena: sto {0} traži račun.",\r
"Kasa je počela kao nova. Dosadašnji podaci su sačuvani u folderu: {0}.",\r
"Kasa je postavljena: {0} · {1}, {2}{3}{4}",\r
"Kasa je postavljena: {0} · oznaka {1}, {2}",\r
"Kasa je povezana sa firmom",\r
"Kasa je povezana sa firmom {0} (PIB {1})",\r
"Kasa je povezana sa firmom {0}. Preuzimanje cijena…",\r
"Kasa je povezana. Cjenovnik firme nije na serveru (Knjigovodstvo: Cjenovnik kasa → „Razmijeni sada\\").",\r
"Kasa je u probnom režimu",\r
"Kasa je uparena sa serverom: {0} ({1}).",\r
"Kasa je uparena sa serverom. Razmjena sa Knjigovodstvom i Menadžerom ide isključivo preko servera, bez ovog foldera. {0}",\r
"Kasa je već uparena. Novo uparivanje je moguće poslije „Isključi vezu\\".",\r
"Kasa je vratila nečitljiv odgovor.",\r
"kasa još nije izabrana",\r
"Kasa još nije spremna za uparivanje.",\r
"Kasa ne odgovara — pokušaj ponovo.",\r
"Kasa ne prepoznaje ovaj telefon. Potrebno je ponovno uparivanje.",\r
"Kasa nema paket firme. Kasa se povezuje sa Knjigovodstvom kodom ili paketom iz fajla.",\r
"Kasa nema ulogu „{0}\\". Na kasi postoje samo uloge šef kase (sef-kase) i kasir. Nalog nije izvršen.",\r
"kasa nije izabrana",\r
"Kasa nije izabrana",\r
"Kasa nije povezana sa serverom (Podešavanja → Server) — QR meni ide preko servera.",\r
"Kasa nije povezana sa serverom IRIS CORVINA i nema razmjene sa Knjigovodstvom.",\r
"Kasa nije spremna (prozor kase nije otvoren).",\r
"Kasa nije spremna za Poresku",\r
"Kasa nije spremna za prijem sa servera (nije uparena ili nema folder razmjene).",\r
"Kasa nije spremna.",\r
"kasa nije uparena (odjeljak Server)",\r
"Kasa nije uparena sa serverom (Podešavanja → Server). Prijava se ne može poslati.",\r
"Kasa nije uparena sa serverom IRIS CORVINA (Podešavanja → Server). Podrška kroz program radi samo za uparenu kasu.",\r
"Kasa nije uparena sa serverom IRIS CORVINA. Poruke, zahtjevi i prijave grešaka idu kroz server. Uparivanje: kodom koji daje izdavač (Podešavanja → Server IRIS CORVINA).",\r
"Kasa nije uparena sa serverom IRIS CORVINA. Uparivanje radi šef kodom koji izdaje administrator (Podešavanja → „Server IRIS CORVINA (razmjena)\\"); razmjena tada ide preko servera, za nekoliko sekundi.",\r
"Kasa nije uparena sa serverom, a folder nije podešen.{0}",\r
"Kasa nije uparena sa serverom, pa razmjena ide kroz ovaj folder{0}Poslije uparivanja sa serverom (odjeljak iznad) razmjena ide preko servera, bez čekanja, a folder služi za rezervnu kopiju. Prazno = isključeno.",\r
"Kasa nije uparena sa serverom. Izmjene čekaju na kasi do uparivanja (Podešavanja → Server IRIS CORVINA).",\r
"Kasa nije uparena.",\r
"Kasa ostaje na kodu ENU {0} (kod ranije prijavljene kase) i računi se šalju Poreskoj pod tim kodom. Potvrda je dozvoljena samo uz dogovor sa Poreskom upravom; u suprotnom se upisuje nov kod ENU.",\r
"Kasa počinje kao nova. Program se zatvara i pokreće ponovo…",\r
"Kasa počinje kao poslije prve instalacije: ekran za povezivanje sa firmom, bez računa, kasira, podešavanja i veze sa serverom. Program se zatvara i pokreće ponovo.\\n\\nDosadašnji podaci se ne brišu: premještaju se u poseban folder sa datumom u folderu podataka kase, uz rezervnu kopiju baze{0}.\\n\\nZa potvrdu je potrebno upisati riječ NOVA.",\r
"Kasa prestaje da razmjenjuje fajlove sa serverom i zaboravlja svoj token (uređaj na serveru isključuje administrator). Razmjena kroz folder (Google Drive) radi i dalje, kao prije uparivanja. Za ponovno uparivanje potreban je nov kod.{0}",\r
"Kasa preuzima podatke firme, prodajna mjesta, artikle i cijene iz Knjigovodstva.",\r
"Kasa prima narudžbe gostiju sa QR menija.",\r
"Kasa prima narudžbe sa telefona konobara ({0}). Povezano u posljednjih 90 s: {1}.",\r
"Kasa prima telefone na:",\r
"Kasa Racun",\r
"Kasa radi i bez servera. Kad je server upisan, svaki račun se šalje automatski čim je internet dostupan.",\r
"Kasa radi i kao recepcija",\r
"Kasa sada ne može početi kao nova:\\n\\n· {0}",\r
"Kasa šalje iznos terminalu, terminal vraća ishod (broj odobrenja, maskirana kartica, vrsta kartice). Račun se izdaje tek kad terminal odobri plaćanje. Za NLB terminal vrstu i način veze određuje aplikacija banke na terminalu —",\r
"Kasa se na ovom uređaju ne može pokrenuti: „Android System WebView\\" je prestar{0}.\\n\\nPotrebno je ažurirati „Android System WebView\\" u Play prodavnici (verzija {1} ili novija) i ponovo pokrenuti kasu. Ako ažuriranje nije moguće, uređaj ne podržava kasu.\\n\\nPodaci nisu dirani.",\r
"Kasa se nije mogla pokrenuti.\\n\\n{0}\\n\\nPodaci nisu dirani. Potrebno je zatvoriti i ponovo pokrenuti program. Ako se greška ponovi, potrebno je sačuvati folder sa podacima i obratiti se održavanju.",\r
"Kasa se povezuje sa serverom.",\r
"kasa upisuje esl_cijene.json kad se cijene promijene",\r
"Kasa upravo radi iz verzije {0}, a njeni fajlovi nisu ispravni. Zatvori kasu, otvori je ponovo, pa ponovi ažuriranje.",\r
"Kasa-Azuriranje",\r
"Kasa: {0}{1}",\r
"Kasa: karticom",\r
"Kase i marketi → Dodaj kasu i napravi kod",\r
"kasir",\r
"Kasir",\r
"Kasir · razlog · šta",\r
"Kasir · šta je uklonjeno",\r
"Kasir / operater",\r
"Kasir je sačuvan: {0}",\r
"Kasir je sačuvan: {0}. Prijava kasira slijedi po zatvaranju podešavanja.",\r
"Kasir ne postoji.",\r
"kasir po imenu",\r
"kasir potvrdio sa terminala",\r
"kasir potvrdio: nije odobreno",\r
"Kasir pri zaključku smjene upisuje prebrojani iznos; očekivani iznos i razlika vide se tek na zaključku (Z). Šef sa PIN-om vidi sve i na presjeku (X).",\r
"Kasir sa imenom „{0}\\" već postoji.",\r
"kasir TEXT",\r
"kasir_id INTEGER",\r
"Kasiri",\r
"Kasiri se upisuju u odjeljku „Kasiri\\": ime, PIN i kod operatera. Poslije toga kasa pri pokretanju pita ko radi, a ime kasira ide na račun.",\r
"kasni",\r
"Kasnije",\r
"Katalog je prazan.",\r
"Katalog je sačuvan: {0}",\r
"Katalog je uvezen: {0}, {1} barkodova",\r
"Katalog sa servera",\r
"katalog: —",\r
"katalog: {0}",\r
"Katalog: {0} artikala.",\r
"Kategorija",\r
"Kategorije",\r
"KECAP",\r
"KEČAP",\r
"KEFIR",\r
"KEKS",\r
"KESA ZA",\r
"kg",\r
"KG",\r
"KIFL",\r
"Kikiriki",\r
"KIKIRIKI",\r
"KILLA",\r
"kilogram (na mjerenje)",\r
"KINDER",\r
"kiosk",\r
"Kiosk",\r
"Kiosk — nedjeljni režim",\r
"Kiosk — radi i nedjeljom i praznikom",\r
"Kiosk (radi i nedjeljom i praznikom)",\r
"Kiosk (radi i nedjeljom)",\r
"KISELO ML",\r
"KISJEL",\r
"KIT KAT",\r
"KITKAT",\r
"KLAMERIC",\r
"klasa",\r
"klik na sto otvara njegov račun na ekranu",\r
"Ključ je u starom formatu (RSA PRIVATE KEY). Potreban je PKCS#8 („BEGIN PRIVATE KEY\\").",\r
"Ključ je uvezen",\r
"Ključ je zaštićen lozinkom. Potreban je nezaštićen PKCS#8.",\r
"Ključ ne pripada uvezenom sertifikatu. Potrebno je uvesti sertifikat (.pfx), koji sadrži i ključ, ili prvo ukloniti postojeći sertifikat.",\r
"Ključ za potpis",\r
"kljuc=vrijednost; kljuc2=vrijednost2",\r
"Ključevi su čitljivi. Ništa nije premješteno.",\r
"Ključevi su sklonjeni, ali se fajl i dalje ne može pročitati ({0}). Potrebno je ponovo pokrenuti kasu.",\r
"KNJAZ",\r
"Knjiga domaćih gostiju",\r
"Knjiga gostiju",\r
"Knjiga stranih gostiju",\r
"Knjigovodstvo",\r
"Knjigovodstvo-sync",\r
"Ko",\r
"KOBASIC",\r
"Kod {0} je ENU registrovan sa drugim programom i ne smije se koristiti.",\r
"Kod {0} je ENU registrovan sa drugim programom i ne smije se koristiti. Potreban je nov ENU ove kase (Knjigovodstvo → Kase i marketi) ili izbor „Druga kasa na ovom mjestu\\".",\r
"Kod {0} je šifra artikla „{1}\\" i ne može se ukloniti.",\r
"Kod {0} je šifra artikla „{1}\\". Premještanje nije moguće.",\r
"Kod {stari} je i barkod artikla „{drugi}\\". Obrisati ga sa ovog artikla?",\r
"Kod ENU (kase)",\r
"Kod ENU iz spiska",\r
"Kod ENU je potvrđen.",\r
"Kod ENU je preuzet iz spiska kasa i pripada ranije prijavljenoj kasi. Za ovaj program Poreska uprava dodjeljuje nov kod ENU (prijava kase), koji se upisuje ovdje i čuva. Do tada kasa ne šalje račune Poreskoj. Ako kasa po dogovoru sa Poreskom ostaje na ovom kodu, šef to potvrđuje dugmetom ispod i upisuje posljednji broj računa dosadašnje kase („Postavi…\\").",\r
"Kôd ENU nije registrovan, nije aktivan ili ne pripada ovoj firmi.",\r
"Kôd ENU nije u obliku ab123ab123 (dato: „{0}\\").",\r
"Kod izdaje administrator servera (važi 48 sati; jedan kod može važiti za sve kase firme, i tada se naziv uređaja dopisuje iza naziva koda). Dok kasa nije uparena, razmjena ide samo kroz folder (Google Drive, odjeljak ispod).",\r
"Kod kase",\r
"Kod kase (ENU)",\r
"Kôd kase (ENU) {0} je preuzet iz spiska kasa i pripada ranije prijavljenoj kasi. Za ovaj program Poreska dodjeljuje nov kôd ENU (Podešavanja → Fiskalizacija → Kod ENU). Ako kasa po dogovoru sa Poreskom zadržava ovaj kôd, potvrdu daje šef („Potvrdi ENU iz spiska…\\").",\r
"Kôd održavaoca ne odgovara aktivnom održavaocu.",\r
"Kôd održavaoca softvera",\r
"Kod operatera",\r
"kod operatera kod Poreske uprave",\r
"Kod operatera nije ispravan: 10 znakova, redom 2 slova, 3 cifre, 2 slova, 3 cifre (npr. ab123cd456). Polje može ostati prazno.",\r
"Kod operatera nije u obliku koji dodjeljuje Poreska uprava (ab123cd456: dva slova, tri cifre, dva slova, tri cifre). Ako ga kasir još nema, polje ostaje prazno.",\r
"Kod operatera važi za račune kasira koji nema svoj kod (Kasiri → Izmijeni).",\r
"Kod operatera: {0} · PIN: {1}{2}",\r
"Kod poslovnog prostora",\r
"Kôd poslovnog prostora ne pripada aktivnoj poslovnoj jedinici.",\r
"Kod registra domena (npr. domen.me) napravite DNS zapis CNAME: ime „meni\\" (ili koje želite) → vrijednost {0}.",\r
"Kod sa težinom (etiketa sa vage) nije barkod artikla.",\r
"Kod sa težinom (etiketa sa vage) se ne povezuje sa artiklom.",\r
"Kod se pravi u Knjigovodstvu:",\r
"Kod softvera",\r
"Kôd softvera ne odgovara aktivnom softveru (Podešavanja → Fiskalizacija).",\r
"Kod vodi na:",\r
"Kod vodi na: {0}. Štampa A4 sa 4 kartice A6 (stalak ili nalijepnica).",\r
"Kod za uparivanje",\r
"Kod za uparivanje je istekao ili je već iskorišćen. Potreban je nov kod (na kasi: „Upari telefon\\").",\r
"Kod za uparivanje je obavezan (daje ga administrator servera).",\r
"Kod za uparivanje je obavezan (izdaje ga administrator servera).",\r
"Kod za uparivanje je obavezan (Knjigovodstvo: Kase i marketi → Dodaj kasu i napravi kod).",\r
"Kod za uparivanje nije sa ove kase (ili je zamijenjen novim).",\r
"kod za uparivanje, npr. ABCD-EFGH-IJKL",\r
"Kodovi u obrascu nisu ispravni i nisu sačuvani. {0}",\r
"Koeficijent",\r
"KOKIC",\r
"KOKTEL",\r
"Kol.",\r
"Kolašin",\r
"Kolicina",\r
"Količina",\r
"Količina (kg)",\r
"Količina (pakovanja)",\r
"Količina je obavezna bar uz jednu stavku.",\r
"Količina je obavezna uz najmanje jednu stavku.",\r
"količina nije ispravna",\r
"Količina nije ispravna.",\r
"Količina posljednje stavke",\r
"Količina svake stavke koju plaća ovaj gost ostaje na ekranu za naplatu; ostatak se vraća na sto.",\r
"Količina za „{0}\\" je prevelika ({1}, najviše {2}).",\r
"Količina za „{0}\\" mora biti od 0 do {1}.",\r
"Količina za „{0}\\" nije ispravna.",\r
"količinska cijena",\r
"koliko",\r
"Kom",\r
"KOM",\r
"Komada u pakovanju",\r
"Komanda (\\\\r, \\\\n, \\\\x05)",\r
"Kompenzacija",\r
"kompenzovano",\r
"KOMPLET",\r
"KONJAK",\r
"konobar",\r
"Konobar (i telefon konobara)",\r
"Konobar na telefonu (Android, Kasa u režimu „Telefon konobara\\") bira sto, unosi narudžbu i šalje je; nalog štampa ova kasa, a račun se izdaje na ovoj kasi. Konobar se prijavljuje imenom i PIN-om (Kasiri → uloga „Konobar\\"). Računaru kase je potrebna stalna adresa na ruteru (poslije promjene adrese telefon se ponovo uparuje). Pri prvom uključivanju Windows traži dozvolu pristupa na privatnoj mreži; dozvola je neophodna.",\r
"Konobar više nije aktivan na kasi.",\r
"Konobari: greška",\r
"Kontakti",\r
"Kontakti gostiju traže pravo „Recepcija (lični podaci gostiju)\\".",\r
"Kontakti za obavještenja i ponude",\r
"Kontekst „{0}\\": nedozvoljeno polje ili predugačak tekst.",\r
"Kontekst u prilogu mora biti objekat {program, verzija, uloga, ekran}.",\r
"Kontrolni broj barkoda nije ispravan. Potrebno je provjeriti upisane cifre.",\r
"Kontrolni broj se ne slaže. Provjerite podatke prema ispravi.",\r
"Kontrolni zbir paketa se ne poklapa — preuzimanje je odbijeno.",\r
"KONZERV",\r
"konzervirano",\r
"Kopiraj",\r
"Kopiraj cijelu prijavu",\r
"Kopiranje nije uspjelo.",\r
"Kopirano",\r
"korekcija avansnog računa",\r
"Korekcija avansnog računa — iskorišćen avans",\r
"korektivni račun avansnog",\r
"Korektivni račun avansnog nije izdat{0} Kasa će ga izdati sama pri sljedećem pokušaju.",\r
"KOREKTIVNI RAČUN AVANSNOG RAČUNA",\r
"Korektivni račun avansnog računa mora navesti račune plaćene iz tog avansa.",\r
"Korektivni račun avansnog računa: iznos korekcije nije jednak zbiru iznosa plaćenih iz avansa na navedenim računima.",\r
"Korektivni račun avansnog za prethodnu naplatu nije izdat{0} {1} kad se izda.",\r
"Korektivni račun je izdat (IKOF {0}), ali upis na server nije uspio. Ponovite upis.",\r
"Korektivni račun ne može biti izdat prije računa koji ispravlja.",\r
"Korektivni račun se poziva na sopstveni IKOF umjesto na IKOF originalnog računa.",\r
"Korisnik",\r
"Korisnik najniže penzije",\r
"Korisnik nema pravo izmjene cijena za {mjesto}.",\r
"Korisnik socijalne zaštite",\r
"Koristi se samo za prijavu.",\r
"KOTANYI",\r
"Kotor",\r
"Kraj perioda je prije početka.",\r
"kratki kod",\r
"KREMA",\r
"Kriptografski potpis nije ispravan. Potrebno je provjeriti sertifikat.",\r
"KROASAN",\r
"KROISAN",\r
"Kroz aplikaciju banke kasa šalje samo plaćanje; otkazivanje i povrat se rade u aplikaciji banke.",\r
"kroz drajver / prozor za štampu",\r
"kroz folder (Google Drive)",\r
"KRSTAC",\r
"krug INTEGER",\r
"krug razmjene sa serverom",\r
"KRUH",\r
"KRUSKOVAC",\r
"KRUŠKOVAC",\r
"Kuća i razno",\r
"Kuća ili stan",\r
"Kućna hemija",\r
"KUHINJA",\r
"KUKURUZ",\r
"KUMOVA",\r
"Kupac",\r
"Kupac (firma) na računu",\r
"Kupac (firma) na računu ili kupac vjernosti (telefon)",\r
"Kupac / kasir",\r
"Kupac ima {0} bodova i ne može potrošiti {1}.",\r
"Kupac na računu",\r
"Kupac na računu mora imati i PIB i naziv.",\r
"Kupac na računu: {0}{1}.",\r
"kupac nema novca",\r
"Kupac nema novca",\r
"kupac nije platio",\r
"Kupac nije platio",\r
"kupac odustao",\r
"Kupac odustao",\r
"Kupac plaća iz aplikacije svoje banke na račun",\r
"Kupac uplaćuje {0} na račun {1}, poziv na broj {2}.\\n\\nDa li je uplata stigla (provjera u aplikaciji banke)?",\r
"kupac vjernosti",\r
"Kupac vjernosti — telefon",\r
"kupac vjernosti · {0}",\r
"Kupac vjernosti: {0}{1}{2}",\r
"kupac_adresa TEXT",\r
"kupac_grad TEXT",\r
"kupac_naziv TEXT",\r
"kupac_pib TEXT",\r
"Kupac: država mora biti oznaka od tri velika slova, npr. MNE, SRB (dato: „{0}\\").",\r
"Kupac: naziv je obavezan.",\r
"Kupac: nepoznata vrsta identifikacionog broja „{0}\\".",\r
"Kupac: PIB je obavezan (za fizičko lice JMBG ili broj isprave).",\r
"Kupac: PIB nije ispravan (5–20 cifara/slova, bez razmaka).",\r
"Kupaca vjernosti:",\r
"KVASAC",\r
"Kvota {0} mora biti cio broj ≥ 0 ili null (neograničeno).",\r
"Kvote su obavezne.",\r
"label",\r
"LAK ZA",\r
"lanac ne počinje sertifikatom veze",\r
"lanac sertifikata nije ispravan",\r
"LAV",\r
"LAVAZZA",\r
"LAY",\r
"LEDEN",\r
"LEDENI CAJ",\r
"LEDENI ČAJ",\r
"left",\r
"LEIBNIZ",\r
"LESNIK",\r
"LEŠNIK",\r
"ležaja",\r
"Ležaja",\r
"li",\r
"Lice sa teškim čulnim ili tjelesnim smetnjama",\r
"Lice starije od 65 godina",\r
"Licenca",\r
"Licenca {0} (paket „{1}\\") ne uključuje modul Kasa. Nova smjena se ne može otvoriti; proširenje licence daje izdavač.",\r
"Licenca {0} ističe {1} (za {2} {3}).",\r
"Licenca {0} je istekla {1} Program radi još {2} {3}. Potrebno je produženje licence.",\r
"Licenca {0} je istekla {1} Program radi samo za čitanje i izvoz podataka. Potrebno je produženje licence.",\r
"Licenca {0} je opozvana {1} Program radi samo za čitanje i izvoz podataka.",\r
"Licenca {0} je suspendovana od {1} Program radi samo za čitanje i izvoz podataka do ukidanja suspenzije.",\r
"Licenca {0} ne važi.",\r
"Licenca {0} važi bez roka.",\r
"Licenca {0} važi do {1}",\r
"Licenca farmaceuta — {0}",\r
"Licenca firme ne važi. Nova smjena se ne može otvoriti.",\r
"Licenca nije ispravna: {0}",\r
"Licenca nije objekat.",\r
"Licenca sa servera",\r
"Licence korišćenih biblioteka",\r
"Lična higijena",\r
"Lična karta",\r
"Lične podatke gostiju vidi i upisuje recepcija.",\r
"Lične podatke gostiju vidi korisnik sa tim ovlašćenjem.",\r
"Lični podaci",\r
"Lični podaci su obrisani po isteku roka čuvanja.",\r
"Lijek",\r
"Lijek na recept izdaje farmaceut. Na kasi nije prijavljen farmaceut.",\r
"Lijek nije na Listi ljekova FZO.",\r
"LIKER",\r
"LILY",\r
"LIMIT {0}",\r
"LIMONCELLO",\r
"LINDT",\r
"LION",\r
"LIQUEUR",\r
"LIZALIC",\r
"Ljekar (faksimil)",\r
"LJESNIK",\r
"LJEŠNIK",\r
"Ljuto",\r
"LOGEX",\r
"Logo",\r
"Logo · {0} × {1}",\r
"Logo firme",\r
"Logo i znak firme postavlja Knjigovodstvo (Podešavanja → Firma); kasa ih preuzima sa servera i čuva, pa se vide i bez interneta. Logo se štampa iznad zaglavlja računa (na termalnom štampaču crno-bijelo), a znak je u zaglavlju kase i na prijavi kasira.",\r
"Logo i znak firme postavlja Knjigovodstvo (Podešavanja → Firma); kasa uparena sa serverom ih preuzima sama. Do tada račun nema logo.",\r
"Logo na računu",\r
"Lokalni IRIS server",\r
"Lokalni IRIS server (program IRIS Server na računaru u radnji): adresa iz ekrana „Pregled\\" tog programa ili iz traženja u mreži; u polje za kod može se upisati i link za uparivanje iz IRIS Admina (iris://upari…). Kasa prihvata samo sertifikat CA tog servera; ništa se ne upisuje u Windows.",\r
"Lokalni IRIS server (računar u radnji): adresa sa ekrana „Pregled\\" programa IRIS Server ili iz traženja u mreži. Umjesto koda može se upisati link za uparivanje iz IRIS Admina (iris://upari…).",\r
"Lokalni IRIS server (sertifikat sopstvenog CA) na Androidu još nije podržan; kasa na telefonu radi preko api.iriscorvina.me.",\r
"lokalno",\r
"lom",\r
"LOPTA",\r
"LOREAL",\r
"lose",\r
"LOT",\r
"LOVOR",\r
"lower(COALESCE(p.kupac_naziv, '')) LIKE ?",\r
"LOZA",\r
"Lozinka",\r
"Lozinka dobijena uz sertifikat.",\r
"Lozinka sertifikata",\r
"LOZOVACA",\r
"LOZOVAČA",\r
"LUCKY",\r
"LUCKY STRIKE",\r
"Lupina",\r
"LYFT",\r
"MAC adresa ili ime uparenog terminala",\r
"MAESTRO",\r
"MAGUD COMPANY D.O.O.",\r
"maj",\r
"maja",\r
"MAJONEZ",\r
"MAKARON",\r
"Mali hotel",\r
"MALIBU",\r
"Maloprodaja (market, kiosk)",\r
"manjak",\r
"Manje",\r
"MARABU",\r
"MARAMIC",\r
"MARGARIN",\r
"MARINAD",\r
"market",\r
"Market",\r
"Market — ne radi nedjeljom i praznikom",\r
"Market (ne radi nedjeljom i praznikom)",\r
"Market (ne radi nedjeljom)",\r
"Market nedjeljom ne radi. Kasa ispred radnje koja je registrovana kao kiosk radi i nedjeljom.",\r
"marketu",\r
"MARLBOR",\r
"MARLBORO",\r
"MARMELAD",\r
"MARS",\r
"mart",\r
"marta",\r
"MARTINI",\r
"Marza {0}",\r
"MASKA",\r
"MASLAC",\r
"MASLINOVO",\r
"MASTERCARD",\r
"MAX FACTOR",\r
"max_zaliha REAL",\r
"MED",\r
"MEDENJ",\r
"MEDOVACA",\r
"MEDOVAČA",\r
"Međuzbir",\r
"Mekušci",\r
"Memorija uređaja je puna. Potrebno je osloboditi prostor (stare rezervne kopije u Dokumenti/Kasa, nepotrebne fotografije) i ponoviti radnju. ({0})",\r
"menadzer",\r
"Menadžer",\r
"Meni",\r
"Meni je objavljen. Narudžbe ovog mjesta prima ova kasa.",\r
"Meni još nije objavljen ni sa jedne kase.",\r
"Meni još nije objavljen.",\r
"Meni još nije objavljen. QR meni se uključuje na glavnoj kasi objekta.",\r
"Meni nije objavljen. QR meni se uključuje u podešavanjima.",\r
"Meni: {0} {1}, {2} artikala",\r
"MENTOL",\r
"MENTOS",\r
"MERLOT",\r
"MESO",\r
"Meso i prerađevine",\r
"METAXA",\r
"METLA",\r
"Mettler Toledo 8217",\r
"MIKRO",\r
"MILK",\r
"MILKA",\r
"MILKY WAY",\r
"milostDana: 0–90.",\r
"MINERALNA",\r
"minmax(46px, 1fr)",\r
"minmax(92px, max-content) repeat({0}, {1})",\r
"minus",\r
"Mjera",\r
"Mjesec",\r
"Mjesečni izvještaj do (dan u mjesecu)",\r
"Mješovito",\r
"mjesta",\r
"Mjesta i stolovi",\r
"mjesto",\r
"Mjesto",\r
"Mjesto izdavanja vize",\r
"mjesto rođenja",\r
"Mjesto rođenja",\r
"Mjesto ulaska",\r
"mjesto_id INTEGER",\r
"MKB-10",\r
"ML",\r
"Mlađi od ovoliko godina ne plaćaju taksu.",\r
"Mlađi od ovoliko godina plaćaju umanjen iznos.",\r
"MLEKO",\r
"Mliječni proizvodi",\r
"Mlijeko",\r
"MLIJEKO",\r
"Mlijeko i proizvodi",\r
"MNE",\r
"Moduli: bar jedan od {0}.",\r
"MOET",\r
"MOËT",\r
"MOGYI",\r
"Moj disk",\r
"Moje izmjene danas",\r
"Mojkovac",\r
"MONSTER",\r
"MONTE CARLO",\r
"MORTADEL",\r
"Motel",\r
"Može se potrošiti od {0} do {1} bodova.",\r
"MOZZAR",\r
"Mreža (LAN / Wi-Fi): IP:port",\r
"mrežni štampač",\r
"Mrežni štampač (IP, port 9100)",\r
"MULTIVIT",\r
"muški",\r
"MUSLI",\r
"My Drive",\r
"Na Androidu se nova verzija instalira preuzimanjem APK-a (adresa je u provjeri: urlAndroid).",\r
"Na Androidu vraćanje prethodne verzije nije moguće bez brisanja podataka, jer sistem ne dozvoljava instalaciju starije verzije preko novije. Ispravka se objavljuje kao nova verzija.",\r
"Na avansnom računu je ostalo {0}, a korekcija je {1}.",\r
"Na avansnom računu je slobodno {0}, a traži se {1}.",\r
"Na bonu {0} je ostalo {1} €. Plaćanje {2} € nije moguće.",\r
"Na bonu je ostalo {0}.",\r
"Na čekanje",\r
"Na čekanju",\r
"Na čekanju {0}. Potrebno ih je naplatiti ili obrisati.",\r
"Na čemu se štampaju etikete",\r
"Na disku nema dovoljno mjesta za ažuriranje (slobodno {0} MB, treba najmanje {1} MB). Ništa nije promijenjeno.",\r
"Na disku nema dovoljno mjesta za ažuriranje. Ništa nije promijenjeno.",\r
"Na druge račune se poziva samo sumarni račun i korektivni račun avansnog računa.",\r
"Na ekran je vraćen račun koji je bio otkucan pri gašenju kase{0}. Račun je potrebno naplatiti ili obrisati.{1}",\r
"na ekranu",\r
"Na ekranu je dio računa za naplatu{0}.",\r
"Na ekranu je drugi račun. Staviti ga na čekanje i vratiti izabrani?",\r
"Na ekranu je otvoren drugi račun. Staviti ga na čekanje i učitati predračun?",\r
"Na ekranu je otvoren drugi račun. Staviti ga na čekanje i vratiti obrisani račun?",\r
"Na ekranu je prvih",\r
"Na ekranu je prvih {0} artikala; štampa i tabela sadrže sve.",\r
"Na ekranu je račun bez stola. Staviti ga na sto {0}?",\r
"Na ekranu je račun stola. Potrebno ga je vratiti na sto ili naplatiti, pa učitati predračun.",\r
"Na ekranu je račun u toku (stavki: {0}). Ostaje na ekranu i ulazi u sljedeću smjenu.",\r
"Na ekranu je sto",\r
"Na ekranu nema računa stola.",\r
"Na fakturi {n} artikala nema barkod.",\r
"Na fiskalnim računima",\r
"Na glavnoj kasi: Podešavanja → QR meni → Adresa u QR kodu: „Sopstveni domen\\", pa odštampajte kodove stolova ponovo.",\r
"na kasi",\r
"Na kasi je",\r
"na mjerenje",\r
"Na ovoj kasi nema kasira „{0}\\".",\r
"na ovom mjestu",\r
"Na ovom uređaju je otvorena smjena sa računima, pa izbor kase sada nije moguć. Redoslijed: „Probna kasa\\", zaključak smjene (Z), zatim izbor kase (Podešavanja → Kasa).",\r
"Na ovom uređaju je pronađen folder {0}. Potrebno ga je upisati u polje „Folder\\" i sačuvati.",\r
"Na ovom uređaju nema načina veze sa terminalom.",\r
"Na ovom uređaju se nečitljivi ključevi ne mogu odbaciti iz programa.",\r
"Na ovom uređaju vaga nije dostupna.",\r
"Na računaru nije nađen nijedan serijski port (ili ljuska ne podržava izbor porta — potreban je nov Setup).",\r
"Na računu je artikal kojeg više nema u katalogu. Artikal je potrebno ukloniti sa računa.{0}",\r
"Na računu nema kodova sa kojima je izdat (QR adresa je nepotpuna).",\r
"Na računu sobe nema stavki za naplatu.",\r
"Na računu: {0}. Bon se štampa poslije naplate.",\r
"na recept",\r
"Na receptu je oznaka „Ne zamjenjuj!\\".",\r
"Na server IRIS CORVINA čeka slanje: {0} fajl(ova) (zaključci, cijene). Potrebna je veza sa serverom („Razmijeni sada\\").",\r
"Na sobu",\r
"Na sobu — potpis gosta",\r
"na sobu {0}",\r
"Na sobu / odloženo",\r
"Na sto",\r
"Na sto bez naloga",\r
"na stolu",\r
"Na stolu ima stavki koje nisu poslate kuhinji / šanku. Sačuvati ih bez naloga?",\r
"Na stolu je manja količina te stavke od tražene. Potrebno je osvježiti sto.",\r
"Na stolu:",\r
"Na stolu: {0}",\r
"Na telefonu folder služi samo za prelazni režim.",\r
"Na telefonu: Kasa →",\r
"Na terminalu je u {0} odobreno {1}{2}, a račun nije izdat. Račun se izdaje uz to plaćanje, bez nove naplate.",\r
"Na vagi nema robe.",\r
"na vezi",\r
"Na vezi · ažurno{0}",\r
"Nab. cijena",\r
"Nab. vrijednost",\r
"Nabavna",\r
"Nacin",\r
"Način",\r
"Način iskazivanja takse na računu odjave.",\r
"Način plaćanja",\r
"Način poslovanja",\r
"Način poslovanja firme (neobavezno)",\r
"Način povrata",\r
"Način prijave",\r
"nacrt računa je prevelik",\r
"nacrti",\r
"Nadgrupa",\r
"Nađi",\r
"Nadredjeno",\r
"najave gostiju po danu i stolu",\r
"NAJLEPŠE",\r
"Najmanje bodova za trošenje",\r
"najmanje noći",\r
"Najmanje noći",\r
"Najmanje se troši {0} bodova.",\r
"Najprodavaniji artikli (po iznosu)",\r
"Najveća zaliha",\r
"Najveća zaliha ne može biti manja od nule.",\r
"Najveći dug po sobi",\r
"Najveći dug po sobi (EUR)",\r
"Najveći ručni popusti (kontrola — bez akcija i vjernosti)",\r
"Najviše {0} stavki u jednoj narudžbi.",\r
"Naknada",\r
"Naknada apoteci po receptu na teret FZO-a (€)",\r
"Naknada na računu",\r
"nalog",\r
"Nalog",\r
"NALOG",\r
"Nalog „{0}\\" nije podržan u ovoj verziji programa ({1} {2}).",\r
"Nalog „poruka\\" nema tekst.",\r
"Nalog „reset-pin\\" nema ulogu osobe (vlasnik/admin/sef-kase ili kasir). Nalog nije izvršen.",\r
"Nalog {0} {1}{2}",\r
"Nalog {0} je poslat ({1} {2}). Sto {3} je na čekanju.",\r
"Nalog br.",\r
"Nalog kuhinji / šanku za ono što još nije poslato",\r
"Nalog nije odštampan; stavke nisu označene kao poslate. Potrebno je provjeriti štampač.",\r
"Nalog nije odštampan.",\r
"nalog nije poslat",\r
"Nalog sa telefona ({0}, sto {1}) nije odštampan. Potrebno je provjeriti štampač i ponovo poslati nalog.",\r
"nalozi i „gotovo\\"",\r
"Nalozi sa kase i telefona konobara. „Gotovo\\" javlja konobaru da je spremno. Tablet u kuhinji: Android aplikacija u režimu „Kuhinja\\" (uparuje se kao telefon konobara).",\r
"Namjenska aplikacija FZO (recept se realizuje u aplikaciji Fonda)",\r
"naplaceno REAL",\r
"Naplaćeno sumarnim računima",\r
"Naplata — soba {0}",\r
"Naplata — više načina plaćanja",\r
"Naplata „Na sobu\\"",\r
"Naplata gotovinom",\r
"Naplata je moguća",\r
"Naplata je oslobođena.",\r
"Naplata je u toku na kasi {0}.",\r
"Naplata je upisana.",\r
"Naplata karticom",\r
"Naplata karticom — ručno",\r
"Naplata karticom na Android telefonu (Tap to Phone): kasa šalje iznos aplikaciji banke i čita rezultat. Kasa ne procesira kartice. Nazivi polja zavise od banke (NLB Smart POS, OTP mPOS, Hipotekarna MojPOS) — upisuju se po specifikaciji banke. Paket „proba\\" = lažna aplikacija banke za probu. Vrsta terminala mora biti „Aplikacija banke na ovom uređaju\\".",\r
"Naplata karticom na telefonu (SoftPOS) radi na Android uređaju.",\r
"Naplata preko terminala nije dostupna.",\r
"Naplata računa sobe",\r
"Naplata telefonom (SoftPOS) radi na Android uređaju.",\r
"Naplata u aplikaciji banke: kupac prislanja karticu ili telefon.",\r
"Naplata u toku na kasi {0}",\r
"Naplati",\r
"Naplati gotovinom",\r
"Naplati i izdaj račun",\r
"Naplati sve noći",\r
"NAPOLITAN",\r
"Napomena",\r
"Napomena — {0}",\r
"Napomena je obavezna.",\r
"Napomena kuhinji / šanku",\r
"Napomena mora biti tekst (može biti prazna).",\r
"napomena TEXT",\r
"Napomena: {0}",\r
"Napravi NOV kod za izabrani sto (stari QR prestaje da radi — npr. ako se zloupotrebljava)",\r
"Napravi objekat i sobe",\r
"Napravi rezervnu kopiju baze",\r
"Napravi rezervnu kopiju u folder sada",\r
"Napredno: adresa servera, lokalni IRIS server u radnji",\r
"Naprijed ›",\r
"Napusti izmjene",\r
"Narudžba „{0}\\" je otvorena.",\r
"Narudžba dostave je „sto\\" sa imenom kanala i brojem: unos stavki, „Pošalji nalog\\" kuhinji, naplata kad dostavljač preuzme. U izvještajima se vidi po imenu.",\r
"Narudžba gosta za sto „{0}\\" je odbijena: sto nije upisan na kasi.",\r
"Narudžba je prazna.",\r
"Narudžba nije primljena: {0}. Pozovite konobara.",\r
"Narudžba za dostavu",\r
"Narudžbe gostiju (posljednjih 6 sati)",\r
"Narudžbe za ovo mjesto prima druga kasa. Prijem na ovoj kasi: QR meni → Objavi meni sada.",\r
"Narudžbi koje nisu stigle do kase:",\r
"Narudžbi koje nisu stigle do kase: {0}. Ostaju u telefonu i šalju se poslije prijave. Odjaviti se?",\r
"Narudžbu je poništio konobar.",\r
"Naša slova na štampaču",\r
"Naslov",\r
"naSobu.limit",\r
"naSobu.potpis",\r
"naSobu.ukljuceno",\r
"Nastavi grupnu promjenu",\r
"Nastavi uređivanje",\r
"nav",\r
"Nazad",\r
"Nazad na artikle",\r
"naziv",\r
"Naziv",\r
"Naziv artikla",\r
"Naziv artikla je obavezan.",\r
"Naziv firme je obavezan.",\r
"Naziv grupe može imati najviše 60 znakova.",\r
"Naziv grupe po jezicima",\r
"Naziv i opis po jezicima (* obavezno; prazno = osnovni naziv / engleski)",\r
"Naziv ili INN (najmanje 2 slova)",\r
"Naziv ili šifra artikla",\r
"Naziv je predug (najviše 120 znakova).",\r
"naziv nove grupe",\r
"Naziv nove grupe je obavezan.",\r
"Naziv objekta",\r
"Naziv objekta, opština i broj soba po vrsti. Sobe se kasnije mijenjaju u Podešavanjima.",\r
"Naziv perioda",\r
"Naziv prodavca",\r
"Naziv prodavca je obavezan.",\r
"Naziv uređaja",\r
"naziv_n LIKE ?",\r
"naziv_n TEXT",\r
"Nazive na jezicima, opise, alergene i slike unose Kasa (📝 Sadržaj menija), Menadžer i Knjigovodstvo — isti sadržaj na serveru. Cijene su uvijek cijene ove kase.",\r
"ne",\r
"Ne",\r
"ne — samo konobar",\r
"Ne (gotovinom)",\r
"Ne dozvoli",\r
"Ne prikazuj na meniju za goste (kasa ga i dalje prodaje)",\r
"ne prodaje se",\r
"Ne prodaje se više",\r
"ne ulazi u promet i ne prijavljuje se Poreskoj upravi.",\r
"ne uzimaju u obzir",\r
"Ne zamjenjuj!",\r
"neaktivan",\r
"Nečitljivi fajl tajne.json se ne može skloniti ({0}).",\r
"Nečitljivi ključevi su premješteni. Potrebno je ponovo uvesti sertifikat.",\r
"nečitljivo ime fajla",\r
"NECTAR",\r
"ned",\r
"nedjelja",\r
"Nedjelja",\r
"NEDJELJA",\r
"NEDJELJA · market",\r
"Nedolazak dan poslije dolaska u (sati)",\r
"Nedolazak: čas od 0 do 23",\r
"nedolazak.doSati",\r
"Nedostaje",\r
"Nedostaje broj izdatog računa.",\r
"Nedostaje: {0}",\r
"Nedostaje: {0}.",\r
"Nedozvoljeno ime fajla razmjene: {0}",\r
"nedozvoljeno ime fajla: {0}",\r
"neg",\r
"Neispravan iznos plaćanja ({0}).",\r
"Neispravan ključ zapisa ažuriranja.",\r
"Neispravan zapis.",\r
"Neispravna količina za: {0}",\r
"Nejasan ishod",\r
"Nejasan ishod na terminalu ({0}, {1}) — potrebno je provjeriti terminal",\r
"nejasnih ishoda {0}",\r
"nejasno (istek)",\r
"NEKTAR",\r
"nema",\r
"nema (kartica bez terminala)",\r
"nema (pravi se pri prvom računu)",\r
"nema adrese na lokalnoj mreži",\r
"Nema artikala bez barkoda. Artikal se traži po nazivu ili šifri.",\r
"Nema artikala za čuvanje.",\r
"Nema artikala za ovaj izbor.",\r
"Nema artikala za ovu pretragu.",\r
"Nema artikala za štampu.",\r
"Nema artikla sa barkodom",\r
"nema barkoda",\r
"nema cjenovnika u folderu",\r
"Nema danas — meni za goste",\r
"Nema depozita ni podizanja u ovoj smjeni.",\r
"Nema dolazaka danas.",\r
"Nema dovoljno slobodne memorije za otvaranje baze (baza ima {0} MB). Potrebno je zatvoriti druge programe ili ponovo pokrenuti računar, pa pokrenuti kasu. Podaci nisu mijenjani.",\r
"Nema fajla {0} (ni na serveru ni među fajlovima kase).",\r
"Nema gostiju u objektu.",\r
"Nema grupa — grupe dolaze iz šifarnika artikala (Knjigovodstvo).",\r
"Nema ispravnog kontrolnog zbira (SHA-256) — paket se ne prihvata.",\r
"Nema izmjena cijena ni artikala.",\r
"Nema kase za „ \\".",\r
"Nema kase za „{0}\\".",\r
"Nema ključa ili sertifikata za potpis.",\r
"Nema kupca vjernosti sa tim brojem. Kupci se upisuju u Knjigovodstvu (Cjenovnik kasa → Kupci).",\r
"Nema naloga.",\r
"Nema naziva stola.",\r
"Nema novih cijena za etikete.",\r
"Nema novije verzije.",\r
"Nema novije verzije. Na kasi je posljednja verzija ( ).",\r
"Nema novije verzije. Na kasi je posljednja verzija ({0}).",\r
"Nema objekta.",\r
"Nema odgovora lokalnog servera.",\r
"Nema odlazaka danas.",\r
"nema opis ažuriranja",\r
"Nema otpisa robe u ovom periodu.",\r
"Nema otvorene smjene.",\r
"Nema otvorenih predračuna.",\r
"Nema paketa podataka sa cijenama.",\r
"nema paketa sa cijenama",\r
"Nema papira u štampaču.",\r
"Nema podataka o paketu. Potrebno je prvo provjeriti ažuriranje.",\r
"Nema podataka za period.",\r
"Nema podataka za štampu (ili su preveliki).",\r
"Nema podataka.",\r
"Nema poruka koje čekaju slanje.",\r
"Nema poruka za slanje. Ranije odbijeno: {0}.",\r
"Nema poruka. Podrška odgovara u programu.",\r
"Nema povezanih barkodova.",\r
"Nema predračuna za ovu pretragu.",\r
"Nema predračuna.",\r
"Nema privatnog ključa za potpis.",\r
"Nema prodaje u ovom periodu.",\r
"Nema prodatih bonova.",\r
"Nema računa",\r
"Nema računa {0}.",\r
"Nema računa na čekanju.",\r
"Nema računa u ovom periodu.",\r
"Nema računa u periodu.",\r
"Nema računa za ovu pretragu.",\r
"Nema računa za štampu.",\r
"Nema ranijeg kupca sa tim PIB-om ili nazivom.",\r
"Nema ranijih kupaca.",\r
"Nema rezervacija za ovaj izbor.",\r
"Nema rezultata",\r
"Nema sertifikata za potpis.",\r
"Nema šifre artikla.",\r
"Nema slobodne sobe ove vrste u tom periodu.",\r
"Nema slobodne sobe za taj period.",\r
"Nema soba za čišćenje.",\r
"Nema stavki za otpis.",\r
"Nema stavki.",\r
"Nema stranice ekrana kupca.",\r
"Nema takvih računa u ovom periodu.",\r
"Nema transakcija terminala.",\r
"Nema unosa.",\r
"Nema uparenih Bluetooth uređaja. Štampač se uparuje u podešavanjima telefona.",\r
"Nema upisanih kasira.",\r
"Nema upisanih kasira. Upisani kasir se prijavljuje PIN-om i njegovo ime je na računu.",\r
"Nema uplata.",\r
"Nema upozorenja.",\r
"Nema veze",\r
"Nema veze sa fiskalnim servisom{0}.",\r
"Nema veze sa kasom (Wi-Fi mreža radnje).",\r
"Nema veze sa Poreskom upravom. Slanje se nastavlja kad se veza uspostavi.",\r
"nema veze sa serverom",\r
"Nema veze sa serverom ({0}).",\r
"Nema veze sa serverom.",\r
"Nema veze sa serverom. {0} traži vezu. Ništa nije izdato.",\r
"Nema veze sa serverom. Naplata računa sobe traži vezu.",\r
"Nema veze sa serverom. Plaćanje na sobu nije dostupno.",\r
"Nema veze sa serverom. Povrat avansa traži vezu.",\r
"Nema veze sa serverom. Storno računa na sobu traži vezu (provjera sumarnog računa).",\r
"Nema zahtjeva sa ove kase.",\r
"Nema zakazanih cijena.",\r
"nema, sve je poslato",\r
"neobavezno",\r
"neobavezno (obavezno za „Drugo\\")",\r
"neobavezno (rok isporuke, način plaćanja…)",\r
"Neobavezno; za razlog „Drugo\\" obavezno.",\r
"neobrađeno odbijanje",\r
"neparan (odd)",\r
"nepodržano",\r
"neposlato",\r
"Nepoznat barkod {barkod}",\r
"Nepoznat kod ishoda: {0}",\r
"Nepoznat način plaćanja: „{0}\\" (moguće: Gotovina, Kartica, Virman, Bon, Instant).",\r
"Nepoznat način plaćanja: {0}",\r
"Nepoznat način povrata: {0}",\r
"Nepoznat nalog.",\r
"Nepoznat prikaz boravišne takse: {0}",\r
"nepoznat razlog",\r
"Nepoznat zahtjev.",\r
"nepoznata greška",\r
"Nepoznata greška",\r
"Nepoznata operacija depozita: „{0}\\".",\r
"Nepoznata radnja.",\r
"Nepoznata verzija licence.",\r
"Nepoznata vrsta kase: „{0}\\".",\r
"Nepoznata vrsta naknade: „{0}\\" (moguće: PACK, COMMISSION, OTHER).",\r
"Nepoznata vrsta naknadne dostave: „{0}\\".",\r
"Nepoznata vrsta zahtjeva.",\r
"Nepročitani odgovori podrške",\r
"Neradni",\r
"NESCAFE",\r
"NESKAF",\r
"NESQUIK",\r
"NESTLE",\r
"Neto količina",\r
"Neto količina mora biti veća od nule.",\r
"Neto količina, komada u pakovanju i najveća zaliha upisuju se kao broj.",\r
"neto REAL",\r
"neto_jm TEXT",\r
"neuhvaćena greška",\r
"Neupotrebljivo",\r
"🆕 Nove cijene ({0})",\r
"NEXT",\r
"NFC",\r
"NFD",\r
"nije",\r
"nije fiskalni račun",\r
"Nije izabrana nijedna stavka za povrat.",\r
"Nije još",\r
"Nije kopirano",\r
"Nije moguće napraviti šifru bona. Potrebno je pokušati ponovo.",\r
"NIJE na vezi (narudžbe se ne primaju)",\r
"Nije naplaćeno:",\r
"nije obrisan nijedan račun.",\r
"Nije odobreno",\r
"nije platio · račun br. {0}",\r
"Nije podešeno gdje je štampač (Podešavanja → Dodaci).",\r
"nije poslato",\r
"Nije povezan sa serverom",\r
"nije poznat ovoj kasi (bon sa druge kase možda još nije stigao razmjenom sa serverom).",\r
"nije se upalila u {0} pokretanja zaredom",\r
"nije spremno",\r
"Nije stigla",\r
"nije u katalogu",\r
"Nije upisan serijski port (npr. COM3).",\r
"Nije upisana aplikacija banke za naplatu telefonom (Podešavanja → Uređaji kase → SoftPOS).",\r
"nije upisano",\r
"Nije uvezen sertifikat za fiskalizaciju (.pfx). Kasa radi sa probnim ključem.",\r
"Nijedan artikal ne odgovara upisanom nazivu ili šifri.",\r
"Nijedan artikal nije izabran.",\r
"Nijedan recept nije dodat.",\r
"Nijedan telefon nije uparen.",\r
"nijedna stavka nije uklonjena sa računa koji je izdat.",\r
"Nijednog artikla sa ovog predračuna više nema u katalogu. Predračun se ne može učitati.",\r
"Nijednog artikla sa tog računa više nema u katalogu ({0}). Račun nije vraćen i ostaje u evidenciji obrisanih.",\r
"Nijednog artikla sa tog računa više nema u katalogu ({0}). Vraćanje na ekran nije moguće; zapis ostaje u evidenciji.",\r
"Nijednom artiklu se cijena ne bi promijenila.",\r
"NIKOTIN",\r
"NIKSIC",\r
"NIKŠIC",\r
"Nikšić",\r
"ništa",\r
"Ništa nije promijenjeno.",\r
"nisu došli",\r
"NIVEA",\r
"Njemački",\r
"noć",\r
"Noćenja",\r
"Noćenje — {0}",\r
"Noćenje i doplate uz smještaj koje nisu hrana.",\r
"noći",\r
"Noći",\r
"NONCASH",\r
"noopener noreferrer",\r
"nosi rok trajanja: istekla roba se prodaje samo uz odobrenje šefa (uz upozorenje), a za robu pred istekom roka prikazuje se upozorenje.",\r
"Nosilac rezervacije",\r
"nov artikal",\r
"Nov artikal",\r
"nov cjenovnik iz Knjigovodstva ({0} artikala, {1})",\r
"nov cjenovnik od {0} ({1} art.)",\r
"Nov kod stola je napravljen. Prethodni QR kod više ne važi.",\r
"nov odgovor",\r
"Nov odgovor podrške IRIS CORVINA (Više → Podrška)",\r
"nov odgovor podrške:",\r
"nov odgovor podrške: {0}",\r
"Nov predračun",\r
"Nov QR kod stola",\r
"Nov zahtjev izdavaču",\r
"nova",\r
"Nova",\r
"NOVA",\r
"nova cijena (€)",\r
"Nova cijena bi bila ispod 0,01 € ili iznad {0} € (artikala: {1}). Cijene se ne mijenjaju.",\r
"Nova cijena mora biti veća od nule.",\r
"Nova grupa",\r
"Nova naplata",\r
"Nova naplata {0} na terminalu (prethodno odobrena nije iskorišćena)",\r
"Nova poruka podršci",\r
"Nova rezervacija",\r
"Nova rezervacija: izaberite prvu i posljednju noć u redu sobe.",\r
"Nova smjena",\r
"nova tura",\r
"Nova verzija {0}",\r
"Nova verzija se preuzima sama dok kasa miruje i primjenjuje se pri sljedećem pokretanju programa. Dok je smjena otvorena, ponovno pokretanje se ne nudi.",\r
"Nova verzija se preuzima sama samo preko Wi-Fi veze; na mobilnim podacima preuzimanje se pokreće dugmetom „Preuzmi sada\\". Instalacija počinje tek na „Instaliraj sada\\".",\r
"Novac koji se iznosi iz kase (predaja pazara, plaćanje iz kase).{0}",\r
"Novac koji se unosi u kasu mimo prodaje (sitniš, dopuna).",\r
"Nove cijene",\r
"Nove cijene su već u spisku.",\r
"nove cijene za etikete:",\r
"nove cijene za etikete: {0}",\r
"nove cijene za etikete: {0} (Više → Etikete sa cijenama)",\r
"novembar",\r
"novembra",\r
"Novi gost",\r
"Novi kasir",\r
"Novi objekat",\r
"Novi unos",\r
"Novih cijena iz kancelarije za etikete:",\r
"Novih cijena iz kancelarije za etikete: {0} (dugme „Nove cijene\\").",\r
"novo",\r
"Novo",\r
"npr. 0,5",\r
"npr. 067 123 456",\r
"npr. 1, 2, 3, 4, Šank, Terasa 1",\r
"npr. 10",\r
"npr. 10 ili -5",\r
"npr. 1001, 1002, 4475",\r
"npr. 101-110, 201",\r
"npr. 19:30",\r
"npr. 24",\r
"npr. 250 g",\r
"npr. 4*",\r
"npr. bez leda, dobro pečeno",\r
"npr. COCA COLA 0,5L",\r
"npr. dobavljač, serija, šta se desilo",\r
"npr. G:\\\\My Drive\\\\Knjigovodstvo-sync",\r
"npr. gost otkazao telefonom",\r
"npr. Kuhinja radi do 23h",\r
"npr. me.banka.pos",\r
"npr. me.banka.softpos ili proba",\r
"npr. meni.vasrestoran.me",\r
"npr. MNE",\r
"npr. neispravna roba",\r
"npr. Poslije storna račun ostaje u „zadnjim računima“ bez oznake…",\r
"npr. predaja pazara",\r
"npr. sitniš",\r
"npr. vraća se za 10 min",\r
"NRp",\r
"NT",\r
"Nude se pri upisu gosta; jedan osnov u redu.",\r
"NUDLE",\r
"NUTELLA",\r
"NUTRINO",\r
"O programu",\r
"Oba datuma su obavezna.",\r
"Obavezan je razlog brisanja računa.",\r
"Obavezan je razlog otpisa.",\r
"Obavještenja izdavača (od pokretanja kase)",\r
"Objekat",\r
"Objekat je dodat.",\r
"Objekat je sačuvan.",\r
"Objekat je u upotrebi",\r
"Objekat je unesen.",\r
"Objekat još nije unesen. Unos radi korisnik sa ovlašćenjem za podešavanja.",\r
"Objekat nema soba.",\r
"Objekat nema soba. Sobe se unose u Podešavanjima.",\r
"Objekat nema vrsta soba. Vrste se unose u Podešavanjima.",\r
"Oblik",\r
"Obnovljivi recept se izdaje najviše 3 puta.",\r
"Obračun",\r
"Obračunato",\r
"obrisan",\r
"Obrisan račun",\r
"Obrisan račun prije naplate ({0})",\r
"Obrisan račun vrijedan od (€)",\r
"obrisan sa čekanja",\r
"Obrisan sa čekanja",\r
"Obrisani prije naplate ({0}{1})",\r
"Obrisani račun je nečitljiv.",\r
"Obrisani računi",\r
"Obrisani računi — stariji",\r
"Obrisani računi, otpis robe, etikete sa cijenama",\r
"Obrisano.",\r
"Obrisati gosta {0} {1}?",\r
"Obrisati ovaj unos?",\r
"Obriši",\r
"Obriši cifru",\r
"Obriši račun",\r
"Obriši račun sa čekanja",\r
"Obriši stari kod sa ovog artikla",\r
"Obveznik PDV-a",\r
"Očekivano u kasi: {0}",\r
"Očisti",\r
"Očisti spisak",\r
"Očitaj ispravu (mašinski čitljiva zona)",\r
"Očitaj težinu",\r
"Očitana je etiketa sa vage (kod sa težinom), a ne barkod artikla. Artikal na mjerenje se upisuje sa jedinicom kilogram.",\r
"Očitana je etiketa sa vage (kod sa težinom). Takav kod se ne povezuje sa artiklom.",\r
"Očitani kod nije QR za uparivanje sa kasom (na kasi: Podešavanja → Telefoni konobara → „Upari telefon\\").",\r
"Očitavanje barkoda ili unos šifre artikla…",\r
"Očitavanje barkoda kamerom",\r
"od",\r
"Od",\r
"od {0}",\r
"od {0} —",\r
"od {0} ({1})",\r
"od {0} ({1}){2}{3}",\r
"od {0}, {1}.",\r
"Od avansa je slobodno {0} EUR. Povrat nije moguć.",\r
"Od avansa je slobodno {0}. Povrat od {1} nije moguć.",\r
"Od kada je soba spremna za gosta.",\r
"Od ovog časa teče rok prijave.",\r
"od toga preko terminala",\r
"Odakle",\r
"Odbaci",\r
"Odbaci izmjene",\r
"Odbaci nečitljive ključeve…",\r
"Odbacivanje nečitljivih ključeva",\r
"odbijen",\r
"Odbijeno",\r
"Odbijeno (proba)",\r
"Odbijeno (proba).",\r
"Odbijeno obećanje bez poruke",\r
"Odgovor fiskalnog servisa se ne može pročitati.",\r
"Odgovor izdavača",\r
"Odgovor izdavača{0}: {1}",\r
"Odgovor je poslat.",\r
"Odgovor kase nije čitljiv (šifra {0}).",\r
"odgovor podršci",\r
"Odgovor Poreske uprave se ne može pročitati.",\r
"Odgovor servera je prevelik.",\r
"Odgovor servera nije ispravan (sabijanje).",\r
"Odgovor terminala nije čitljiv.",\r
"Odgovor terminala nije jasan. Ishod je potrebno provjeriti na terminalu.",\r
"Odgovor u ovoj niti",\r
"Odgovori",\r
"Odjava",\r
"Odjava policiji",\r
"Odjava policiji {0}",\r
"odjava.vrijemeDolaska",\r
"odjava.vrijemeOdlaska",\r
"Odjavi",\r
"Odjavi uz dug",\r
"Odjaviti gosta? Soba prelazi u stanje „za čišćenje\\".",\r
"Odjavljena",\r
"Odjavljeno policiji",\r
"Odjavljeno turističkoj organizaciji",\r
"Odjavu gostiju policiji označite u kartici Gosti.",\r
"Odlaganje računa i naplata sljedećem kupcu",\r
"Odlasci",\r
"Odlazak",\r
"odlazak {0}",\r
"Odlazak danas",\r
"Odlazak do",\r
"Odlazak do (čas)",\r
"Odlazak je planiran za {0} Skratiti boravak na {1}?",\r
"Odlazak mora biti poslije dolaska.",\r
"Odlazak: {0}",\r
"Odloženi računi nisu naplaćeni. Naplata je moguća poslije vraćanja na ekran.",\r
"Odloženo",\r
"Odloženo plaćanje (ORDER) se ne može kombinovati sa drugim načinom plaćanja na istom računu.",\r
"Odloženo plaćanje se ne kombinuje sa drugim načinom plaćanja.",\r
"odobren",\r
"odobrene",\r
"Odobrenje",\r
"Odobrenje šefa",\r
"Odobreno — izdaj račun",\r
"Odobreno (proba)",\r
"Odobreno (proba).",\r
"Odobreno {0}{1}{2}",\r
"Odobreno bez računa",\r
"odobreno bez računa {0}",\r
"Odobreno je",\r
"Odobreno na terminalu bez računa ({0}{1})",\r
"Odobreno na terminalu bez računa: {0}{1}",\r
"Odobreno.",\r
"Odobri",\r
"Odraslih",\r
"Određuje opština, od 0,10 do 1,00 EUR.",\r
"Odspajanje telefona",\r
"Odspoji",\r
"Odštampati etiketu sa novom cijenom (i cijenom po kg / l)?",\r
"Odštampati etiketu za nov artikal?",\r
"Odustani",\r
"off",\r
"offline",\r
"offline: {0}",\r
"offlineDana: 1–365.",\r
"ok",\r
"okruženje",\r
"Okruženje",\r
"okruženje {0}",\r
"Okruženje je PRODUKCIJA i kasa šalje račune Poreskoj upravi. Računi su fiskalni.",\r
"oktobar",\r
"oktobra",\r
"ol",\r
"OL",\r
"OLOVK",\r
"OMEKSIV",\r
"OMEKŠIV",\r
"on",\r
"online",\r
"Operater",\r
"operater_kod TEXT",\r
"Opis",\r
"Opis (neobavezno), npr. ime kupca. Račun čeka dok se ne vrati na ekran.",\r
"opis (sastojci, gramaža…)",\r
"opis ažuriranja nije čitljiv",\r
"opis ažuriranja nije potpun",\r
"Opis greške je obavezan.",\r
"Opis na računu",\r
"Opis problema je obavezan.",\r
"Opis zahtjeva i razlog (npr. još jedna kasa u marketu Bečići od 1. decembra)…",\r
"Opis zahtjeva je obavezan.",\r
"Opojna droga se izdaje samo na poseban recept (PRp).",\r
"Oporeziva",\r
"Oporezivi promet po stopi od 0% (čl. 25 Zakona o PDV) (pazari po osnovu artikla + fakture sa osnovom čl. 25 + ručno)",\r
"Oporezivi promet po stopi od 15% — osnovica (pazari + izdate fakture)",\r
"Oporezivi promet po stopi od 21% — osnovica (pazari + izdate fakture)",\r
"Oporezivi promet po stopi od 7% — osnovica (pazari + izdate fakture)",\r
"opšta",\r
"opšta cijena",\r
"Opšta cijena",\r
"opšta cijena firme (nije upisana za ovo mjesto)",\r
"Opšta cijena važi na {n} mjesta koja nemaju svoju cijenu. Promijeniti opštu cijenu?",\r
"opšte cijene",\r
"opšte cijene (probna kasa)",\r
"Opšti oblik",\r
"Opstina",\r
"Opština",\r
"Opštu cijenu mijenjaju administrator i direktor.",\r
"optgroup",\r
"option",\r
"OPTIONS",\r
"ORAL",\r
"Orašasti plodovi",\r
"ORBIT",\r
"OREO",\r
"org_stavka INTEGER",\r
"organ koji je izdao ispravu",\r
"ORp",\r
"Oslobođen participacije",\r
"Oslobođen po međunarodnom sporazumu",\r
"Oslobođeni do",\r
"Oslobođeni do (godina)",\r
"Oslobođeni promet — isporuke (čl. 26 i 27) (pazari po osnovu artikla + fakture sa tim osnovom + ručno)",\r
"Oslobođeno",\r
"Oslobodi naplatu",\r
"Oslobodjen",\r
"Oslobodjeno",\r
"Osnov",\r
"Osnov oslobađanja, ako postoji.",\r
"osnov0 TEXT",\r
"osnov0_clan TEXT",\r
"Osnovi oslobađanja",\r
"Osnovica",\r
"Osnovna cijena noći (EUR sa PDV-om)",\r
"Osnovne namirnice",\r
"Osnovnih ležaja",\r
"osoba",\r
"Osoba",\r
"Osoba „{0}\\" je na kasi kasir, a nalog navodi ulogu „{1}\\". Nalog nije izvršen.",\r
"Osoba „{0}\\" je na kasi šef, a nalog navodi ulogu „{1}\\". Nalog nije izvršen.",\r
"Osoba-noćenja",\r
"osobe",\r
"Ostaje dug partnera {0} EUR za fakturu. Odjaviti gosta?",\r
"ostalo",\r
"Ostalo",\r
"ostatak",\r
"Ostatak",\r
"ostatak {0}",\r
"ostatak naplate",\r
"ostatka",\r
"Ostavi uključeno",\r
"oštećeno",\r
"Oštećeno (lom, kvar, pokvareno)",\r
"OSVEZIV",\r
"Osvježi",\r
"Osvježi katalog",\r
"OSVJEŽIV",\r
"OTHER",\r
"Otisak CA koji server javlja nije u njegovom sertifikatu. Veza nije uspostavljena.",\r
"Otisak CA lokalnog servera",\r
"otisak CA nije ispravan",\r
"Otisak sertifikata iz linka za uparivanje ne odgovara sertifikatu servera na adresi {0}. Veza nije uspostavljena.",\r
"Otisci su isti",\r
"otkaz",\r
"Otkaz",\r
"OTKAZ",\r
"Otkaz je poslat kuhinji / šanku.",\r
"Otkaz rezervacije",\r
"otkaz.stopaNaknade",\r
"otkaz.zadrzaniAvans",\r
"Otkazana",\r
"otkazane",\r
"otkazano",\r
"otkazano ({0}) / povrat ({1})",\r
"Otkazano je",\r
"otkazano na terminalu (ručno)",\r
"Otkaži",\r
"Otkaži na terminalu",\r
"Otkaži rezervaciju",\r
"Otkazivanje",\r
"Otkazivanje na terminalu",\r
"Otkazivanje na terminalu nije uspjelo ({0}): {1}{2}",\r
"Otkazivanje nije uspjelo",\r
"Otkazivanje plaćanja",\r
"Otkazivanje plaćanja na terminalu",\r
"Otkazivanje plaćanja na terminalu…",\r
"otpis",\r
"Otpis",\r
"Otpis {0}",\r
"Otpis je upisan: {0}, vrijednost {1}. Dokument nije fiskalni račun.",\r
"Otpis robe",\r
"Otpis robe br.",\r
"Otpis robe br. {0}",\r
"otpis robe:",\r
"otpis robe: {0} dok., {1} (nije u zbiru)",\r
"Otpisana roba (istekao rok, oštećeno…), vrijednost po cijenama kataloga. Nije promet i nije u prodaji.",\r
"Otpisana roba po artiklima",\r
"otpisano",\r
"Otpisi",\r
"Otpiši",\r
"Otpiši stavku",\r
"Otvaranje baze…",\r
"Otvaranje fioke bez računa",\r
"Otvaranje je zabilježeno. Fioka nije podešena za otvaranje iz kase (Podešavanja → Dodaci).",\r
"otvoren",\r
"otvorena",\r
"Otvorena",\r
"Otvorena je nova smjena bez početnog depozita (#{0}). Gotovina zatečena u kasi upisuje se kao depozit (Smjena → DEPOZIT).",\r
"Otvorena od",\r
"otvorene",\r
"Otvoreni",\r
"Otvori",\r
"Otvori fioku",\r
"Otvori folder sa podacima",\r
"Otvori narudžbu",\r
"Otvori novu smjenu…",\r
"Otvori račun ›",\r
"Otvori račun za storno",\r
"Otvori smjenu",\r
"Otvori storno ›",\r
"Otvori taj račun ›",\r
"OUZO",\r
"Ova godina",\r
"Ova instalacija kase nema ažuriranje iz programa. Potrebno je instalirati noviji Setup.",\r
"Ova instalacija kase nema ponovno pokretanje iz programa. Program je potrebno zatvoriti i ponovo otvoriti.",\r
"ova kasa",\r
"Ova kasa",\r
"Ova kasa je upisana kao market, a danas je {0}. Marketi nedjeljom i praznikom ne rade; tada se izdaje sa kase registrovane kao kiosk (čl. 35b).\\n\\nAko je ova kasa registrovana kao kiosk, vrstu kase je potrebno ispraviti (Podešavanja → Kasa).",\r
"Ova kasa je već izabrana. Cijene se učitavaju ponovo.",\r
"ova kasa{0}",\r
"Ova radnja nije dozvoljena na ovom uređaju.",\r
"Ova verzija programa ({0}) više nije podržana na serveru. Potrebno je ažuriranje na verziju {1} ili noviju — upis na server čeka ažuriranje.",\r
"ovaj",\r
"Ovaj ENU je registrovan sa drugim programom. Potreban je nov ENU ove kase, registrovan za ovaj program.",\r
"Ovaj kod softvera je registrovan sa drugim programom. Upisuje se kod softvera ovog programa (dodjeljuje se pri upisu programa na portalu Poreske uprave).",\r
"Ovaj mjesec",\r
"Ovaj način štampe ne postoji na Windowsu (Bluetooth štampa je za Android).",\r
"Ovaj potpisan nalog je na ovoj kasi već izvršen — ponovljeni nalog se ne izvršava; izdaj nov.",\r
"Ovaj uređaj nema generator slučajnih brojeva (WebCrypto).",\r
"Ovaj uređaj nema kriptografiju (WebCrypto).",\r
"Ovaj uređaj nema kriptografiju za potpis (WebCrypto).",\r
"Ovaj uređaj nema kriptografiju za potpis računa (WebCrypto).",\r
"ovdje",\r
"Ovdje se poništava samo posljednji izdati račun, do 30 minuta poslije izdavanja. Stariji račun se stornira u pregledu računa (Računi → račun → „Storniraj račun…\\").",\r
"Ovih artikala više nema u katalogu: {0}.",\r
"Ovo je korektivni račun. Povrat robe sa njega nije moguć.",\r
"Ovo je storno račun i ne može se stornirati.",\r
"Ovo je storno sumarnog računa i ne može se stornirati.",\r
"Ovo nije fiskalni račun.",\r
"Ovom kupcu je danas na ovoj kasi već naplaćeno gotovinom {0}. Sa ovim računom ({1}) to je {2}.\\n\\nZakon ne dozvoljava ni povezane gotovinske uplate koje zajedno iznose 10.000 € ili više (čl. 65 st. 2). Ako su ovi računi dio istog posla, naplata ide karticom ili virmanom.",\r
"OVSEN",\r
"Označeni artikli ostaju na meniju sa oznakom „trenutno nema\\" i gost ih ne može naručiti. Kasa ih i dalje prodaje.",\r
"oznaceno",\r
"Označiti da gost nije došao? Soba se oslobađa.",\r
"Oznaka",\r
"Oznaka izuzeća stavke takse",\r
"Oznaka kase",\r
"Oznaka kase (redni broj kase u poslovnom prostoru) je obavezna.",\r
"Oznaka poslovnog prostora kojem objekat pripada; prazno = nije povezan.",\r
"Oznaka sobe",\r
"Oznaka verzije nije ispravna — paket se ne prihvata.",\r
"Oznake na meniju",\r
"Oznake soba",\r
"OZUJSK",\r
"OŽUJSK",\r
"p.id, p.uid, p.niz, p.godina, p.broj, p.datum, p.vazi_do, p.kasa_id, p.market, p.enu, p.kasir, p.kupac_pib, p.kupac_naziv, p.kupac_adresa, p.kupac_grad, p.napomena, p.bruto, p.popust, p.ukupno, p.status, p.racun_uid, p.pretvoren, p.ponisten, p.ponistio, p.razlog, r.client_uid r_uid, r.ord_num r_ord, r.issue_dt r_issue, r.datum r_datum, r.fiscal_status r_fs, r.vrsta r_vrsta, r.iic r_iic, r.ukupno r_ukupno, r.stornirao_uid r_storn",\r
"p.status = ?",\r
"Pacijent nema važećih e-recepata.",\r
"Pacijent plaća:",\r
"pacijent pristaje",\r
"Pad ekrana, greška razmjene sa serverom i odbijanje Poreske šalju se izdavaču IRIS CORVINA preko servera, bez sadržaja računa; JMBG, žiro račun, email, telefoni, iznosi i imena kasira i kupaca uklanjaju se prije slanja. Isključeno = ništa se ne šalje (ni ručna prijava iz Podrške).",\r
"PAGO",\r
"PAHULJIC",\r
"PAK",\r
"Paket",\r
"Paket aplikacije banke",\r
"Paket iz fajla (bez interneta)",\r
"Paket je prevelik.",\r
"Paket je učitan: {0}, {1}",\r
"Paket je učitan. Potrebno je izabrati kasu iz spiska.",\r
"Paket je učitan. Potrebno je izabrati kasu.",\r
"Paket mora biti: {0}.",\r
"Paket ne sadrži index.html — nije ispravan paket kase.",\r
"Paket nema nijedan artikal.",\r
"Paket nije ispravan paket kase ({0}).",\r
"Paket nije ispravan ZIP (odsječen ili oštećen fajl).",\r
"Paket nije ispravno upisan na disk. Ništa nije promijenjeno — pokušaj ponovo.",\r
"Paket nije za kasu — ne prihvata se.",\r
"Pakovanje",\r
"Pakovanje artikla upisuje šef (potreban je PIN šefa). Bez odobrenja važi samo za štampu koja je u toku.",\r
"Pakovanje mora biti veće od nule (npr. 250 g, 0,5 l, 10 kom).",\r
"Pakovanje nije razumljivo. Primjeri: 250 g, 0,5 l, 6x0,33 l, 10 kom.",\r
"pakovanje nije upisano (npr. 250 g); bez njega nema cijene po kg / l",\r
"pakovanje REAL",\r
"pakovanje u nazivu nije jasno",\r
"Pakovanje važi samo za ovu štampu. Trajan upis odobrava šef.",\r
"Pakovanje: 250 g, 0,5 l, 6x0,33 l, 10 kom",\r
"PALL MALL",\r
"PALMOLIVE",\r
"PALOMA",\r
"PANCET",\r
"PANFLEX",\r
"Pansion",\r
"PANTENE",\r
"Papir je pri kraju.",\r
"PAPIRIC",\r
"PAPIRIĆ",\r
"PAPIRN",\r
"Papirna galanterija",\r
"PAR",\r
"PARADAJZ",\r
"paran (even)",\r
"PARFEM",\r
"Paritet",\r
"PARIZER",\r
"PARLIAMENT",\r
"PARMEZ",\r
"part. {0}% {1}{2}",\r
"Particip.",\r
"Participacija",\r
"Participacija po receptu (€)",\r
"Partner",\r
"Partner: {0}{1}{2}.",\r
"Partneri",\r
"Partneri (firme i agencije)",\r
"Partnerski",\r
"Pasoš",\r
"PASS",\r
"PASTA",\r
"PASTA ZA ZUB",\r
"PASTET",\r
"PAŠTET",\r
"PASULJ",\r
"PAUŠAL",\r
"Paušalna nadoknada isplaćena poljoprivredniku po stopi od 8% (ručno)",\r
"Paušalno plaćanje",\r
"Paušalno plaćanje takse",\r
"Pauze: niz {od, do} datuma.",\r
"PAVLAKA",\r
"paznja",\r
"PDV",\r
"PDV {0}",\r
"PDV {0}{1}",\r
"PDV na domaći promet po stopi od 15% (pazari + izdate fakture)",\r
"PDV na domaći promet po stopi od 21% (pazari + izdate fakture)",\r
"PDV na domaći promet po stopi od 7% (pazari + izdate fakture)",\r
"PDV na prodaji bona",\r
"PDV na promet gasa, el. energije i grijanja/hlađenja (prenos obaveze) (ručno)",\r
"PDV na usluge inostranih lica (usluge stranih lica (Uvoz i ino usluge) + ručno)",\r
"PDV plaćen na uvoz (carinske deklaracije (Uvoz i ino usluge) + ručno)",\r
"PDV po stopama",\r
"PDV status firme se ne slaže sa onim što je poslato na računu.",\r
"PDV stopa mora biti jedna od: {0} %.",\r
"PECIVO",\r
"Pekara i žitarice",\r
"PEKMEZ",\r
"PELAT",\r
"PELENE",\r
"PELINKOV",\r
"PELINKOVAC",\r
"pending",\r
"PEPSI",\r
"PERECE",\r
"PERFEX",\r
"Period",\r
"Period {0} – {1}",\r
"Period: {0}",\r
"Periodični",\r
"Periodični izvještaj",\r
"PERSIL",\r
"pet",\r
"petak",\r
"PETIT",\r
"Petnjica",\r
"PFANNER",\r
"PIB",\r
"PIB (prodavac)",\r
"PIB {0}",\r
"PIB {0}{1}",\r
"PIB / telefon",\r
"PIB firme ({0}) nije u sertifikatu (u sertifikatu: {1}).",\r
"PIB firme mora imati 8 cifara ili 13 za JMB (dato: „{0}\\").",\r
"PIB firme na računu ({0}) i PIB za fiskalizaciju ({1}) se razlikuju. Potrebno je uskladiti PIB (Podešavanja → Firma na računu / Fiskalizacija).",\r
"PIB firme nije upisan ili nije ispravan (8 cifara).",\r
"PIB i naziv kupca su obavezni.",\r
"PIB ima 8 cifara (13 za fizička lica).",\r
"PIB kupca",\r
"PIB mora imati 8 ili 13 cifara.",\r
"PIB u sertifikatu se ne slaže sa PIB-om firme na računu.",\r
"PIB, grad (opština) sjedišta, bar jedan objekat (market, lokal, kancelarija)",\r
"PIB: {0}",\r
"Pića",\r
"Pića, Kafa i čaj",\r
"PILEC",\r
"PILEĆ",\r
"PIN",\r
"PIN — {0}",\r
"PIN ima najmanje 4 cifre.",\r
"PIN je obavezan.",\r
"PIN je poništen. Potrebno je upisati novi PIN (Podešavanja → Kasiri).",\r
"PIN je upisan",\r
"PIN mora imati 4 do 8 cifara.",\r
"PIN nije ispravan.",\r
"PIN se poništava dozvolom (fajl) koju izdaje održavanje. Dozvola važi samo danas i samo za ovu kasu. Poništava se PIN šefa, a kad šef nije upisan, PIN svih kasira.\\n\\nOznaka kase za održavanje:\\n{0}\\n\\nFajl dozvole se bira u sljedećem koraku.",\r
"PIN šefa",\r
"PIN šefa nije ispravan.",\r
"PIRE",\r
"PIRINAC",\r
"PIRINAČ",\r
"PISKOT",\r
"PIŠKOT",\r
"PIŠTOLJ",\r
"Pitaj za godine pri prodaji alkohola i duvana",\r
"Pitanje o pristupu ekranu nije moguće na ovom ekranu kase. Nalog nije izvršen.",\r
"pitanje za etiketu",\r
"Pitanje, zahtjev ili opis problema. Odgovor stiže ovdje (oznaka „nov odgovor“ u zaglavlju kase).",\r
"pitati za etiketu",\r
"PIVO",\r
"PJURE",\r
"Plaća",\r
"Plaća (po godinama)",\r
"Plaća virmanom",\r
"Plaćanja karticom na računima (sa stornom i povratima) poređena sa transakcijama terminala za isti dan. Ručne potvrde (bez veze sa terminalom) kasa ne može provjeriti — porede se sa izvodom banke.",\r
"Plaćanje",\r
"Plaćanje „Na sobu\\"",\r
"Plaćanje {0} je otkazano na terminalu.",\r
"Plaćanje {0}{1} je potrebno otkazati na samom terminalu / u aplikaciji banke. Da li je otkazano?",\r
"Plaćanje bonom nije uključeno (Podešavanja → Dodaci).",\r
"Plaćanje bonom: potrebno je upisati šifru bona.",\r
"plaćanje gotovinom",\r
"Plaćanje gotovinom",\r
"Plaćanje gotovinom od 10.000 € naviše drugom licu (dobavljač, pozajmica, isplata) zakon ne dozvoljava (čl. 65). Takvo plaćanje ide preko računa u banci.\\n\\nPredaja pazara banci nije obuhvaćena zabranom.\\n\\nUpisati podizanje?",\r
"Plaćanje iz avansa mora nositi IKOF avansnog računa.",\r
"Plaćanje je odbijeno.",\r
"Plaćanje je odobreno.",\r
"Plaćanje je prekinuto na terminalu.",\r
"Plaćanje je već odobreno",\r
"Plaćanje karticom (konobar donosi POS terminal)",\r
"plaćanje karticom (POS)",\r
"Plaćanje virmanom traži kupca sa PIB-om.",\r
"Plaćanje virmanom traži partnera sa PIB-om na rezervaciji.",\r
"placeholder=\\"https://… ili http://…:8080\\" inputmode=\\"url\\"",\r
"placeholder=\\"npr. 1, 2, 3, 4, Šank, Terasa 1\\"",\r
"placeholder=\\"npr. 1001, 1002, 4475\\"",\r
"placeholder=\\"Pića, Kafa i čaj\\"",\r
"placeholder=\\"XXXX-XXXX-XXXX ili link iris://upari…\\" autocapitalize=\\"characters\\"",\r
"Plaćen avans",\r
"plaćeno",\r
"Plaćeno avansom",\r
"Planirani odlazak",\r
"PLANTAZE",\r
"PLANTAŽE",\r
"Plav",\r
"PLAZMA",\r
"Pljevlja",\r
"Plužine",\r
"PNG",\r
"po cjenovniku",\r
"Po danima",\r
"Po danu u sedmici",\r
"Po evidenciji je sada u kasi",\r
"Po evidenciji je u kasi {0}, a podizanje iznosi {1}.\\n\\nUpisati podizanje?",\r
"Po evidenciji je u kasi {0}. Unosi se iznos prebrojane gotovine.",\r
"Po isteku roka od odjave lični podaci gosta se brišu.",\r
"Po kasiru",\r
"po kg",\r
"po komadu)",\r
"Po kupcima",\r
"Po mjesecima",\r
"po nazivu",\r
"po noći",\r
"Po opštini se nudi iznos boravišne takse.",\r
"po osobi i noći",\r
"Po ovom predračunu je izdat račun. Predračun se ne može poništiti.",\r
"Po ovom predračunu je već izdat račun.",\r
"Po uključivanju",\r
"početni depozit",\r
"Početni depozit",\r
"Početni depozit je već prijavljen Poreskoj upravi (ili je slanje već pokušano). Razlika se upisuje kao DEPOZIT ili PODIZANJE.",\r
"Početni depozit ne može biti negativan.",\r
"Početni depozit se upravo šalje Poreskoj upravi. Ispravku je potrebno ponoviti za nekoliko sekundi.",\r
"Početni depozit: {0}",\r
"Početni depozit: iznos gotovine u kasi na početku smjene (€).\\nPrazno ili 0 = bez depozita.",\r
"Početni gotovinski depozit je već prijavljen za danas.",\r
"Početni gotovinski depozit za danas nije prijavljen. Potrebno je prvo prijaviti depozit, pa poslati račun.",\r
"Počni",\r
"Počni kao nova kasa",\r
"Podaci",\r
"podaci artikla",\r
"Podaci gosta — {0} {1}",\r
"Podaci iz isprave su upisani. Provjerite ih i dopunite.",\r
"Podaci računa se ne slažu sa njegovim QR kodom. Račun je mijenjan poslije izdavanja.",\r
"Podaci su izmijenjeni na drugom uređaju. Sačuvajte ili odustanite od izmjena, pa osvježite.",\r
"Podaci za prijavu su potpuni.",\r
"Podaci za prijavu Upravi policije i turističkoj organizaciji.",\r
"podaci_upijeni TEXT",\r
"Podatke je u međuvremenu izmijenio drugi korisnik. Podaci su osvježeni; ponovite izmjenu.",\r
"Podešavanja",\r
"Podešavanja → Telefoni konobara → „Upari telefon\\"",\r
"Podešavanja apoteke",\r
"Podešavanja apoteke su sačuvana.",\r
"Podešavanja iz fajla",\r
"Podešavanja QR menija",\r
"Podešavanja QR menija su sačuvana.",\r
"Podešavanja su sačuvana.",\r
"Podešavanja uređaja kase",\r
"Podešavanja uređaja su sačuvana.",\r
"Podgorica",\r
"Podgrupa",\r
"Podijeli",\r
"Podijeli račun stola {0}",\r
"Podijeli račun stola…",\r
"Podizanja",\r
"Podizanje",\r
"Podizanje — novac iz kase",\r
"Podizanje je upisano:",\r
"Podizanje od 10.000 € naviše",\r
"Podizanje veće od stanja",\r
"PODIZANJE…",\r
"Podkategorije",\r
"Podrazumijevani štampač (Windows){0}",\r
"Podrazumijevani štampač u Windowsu („{0}\\") ne štampa nego snima u fajl.",\r
"podrazumijevani u Windowsu",\r
"Podrška",\r
"Podrška i greške (IRIS CORVINA)",\r
"Podrška IRIS CORVINA traži pristup ekranu ove kase radi pomoći.",\r
"Podrška IRIS CORVINA traži pristup ekranu ove kase.",\r
"Podrška kroz program radi u instaliranoj kasi (Windows, Android), ne u pregledaču.",\r
"Podrška nije dostupna u ovoj kasi.",\r
"Podrška: poruke, prijava greške, zahtjevi…",\r
"POGAC",\r
"POGAČ",\r
"pogrešan kontrolni broj",\r
"Pogrešan kontrolni broj",\r
"Pogrešan PIN.",\r
"Pogrešna lozinka sertifikata (ili fajl nije .pfx/.p12).",\r
"Pogrešna metoda kanonizacije.",\r
"Pogrešna metoda potpisa.",\r
"Pogrešna metoda sažetka.",\r
"poIsteku mora biti „citanje\\".",\r
"poklon bon {0}",\r
"Poklon bon {0}",\r
"POKLON BON {0} €",\r
"Poklon-bon je odštampan: {0} ({1} kom.).",\r
"Poklon-bon se ne kupuje drugim bonom.",\r
"Poklon-bon se prodaje na komad (1–50 komada na računu).",\r
"Poklon-bonovi",\r
"Poklon-bonovi nisu uključeni. Uključuje ih šef (Podešavanja → Dodaci: apoeni, PDV, rok važenja).",\r
"Poklon-bonovi uključeni",\r
"pokrenuta: {0}",\r
"Pol",\r
"Policija",\r
"Polja pogrešnog oblika (provjera šeme Poreske): {0}.",\r
"Polje „izdao\\" je obavezno.",\r
"Polje „izdato\\" mora biti ISO vrijeme.",\r
"Polje „Popust\\" je prazno. Za procenat se upisuje broj, zatim %.",\r
"Polje broja odobrenja",\r
"Polje format mora biti „iris-licenca\\".",\r
"Polje ishoda",\r
"Polje iznosa",\r
"Polje kartice",\r
"Polje poruke",\r
"Polje reference",\r
"Polje RRN",\r
"Polje valute",\r
"Polje vraćene reference",\r
"Polje vrste kartice",\r
"POMFRIT",\r
"Pomocni",\r
"pon",\r
"Ponavljanje (ORp)",\r
"ponedjeljak",\r
"poništava",\r
"poništava se",\r
"Poništava se samo izmjena nastala na ovoj kasi.",\r
"Poništava se samo otvoren predračun.",\r
"ponistava TEXT",\r
"Poništavanje",\r
"Poništavanje izmjene cijene",\r
"Poništavanje posljednjeg računa (kupac nije platio, greška u kucanju); stavke mogu na čekanje",\r
"Poništavanje predračuna",\r
"Poništavanje računa",\r
"Poništavanje veze barkoda",\r
"poništen",\r
"Poništen",\r
"Poništen {0}{1}{2}.",\r
"poništena",\r
"Poništeni",\r
"Poništenje narudžbe gosta",\r
"poništeno",\r
"Poništi",\r
"Poništi izbor",\r
"Poništi posljednji račun",\r
"Poništi račun",\r
"Poništi sve",\r
"Poništio konobar.",\r
"Ponovi upis na server",\r
"ponovni prijem cjenovnika (servis)",\r
"Ponovni prijem sa servera: {0}",\r
"Ponovno pokretanje je moguće nakon zaključenja smjene.",\r
"Ponovno pokretanje nije uspjelo. Program je potrebno zatvoriti i ponovo otvoriti.",\r
"Ponovno slanje odbijenih poruka…",\r
"ponovo obrisao",\r
"ponovo obrisao {0} {1} {2}{3}",\r
"Ponovo pokreni",\r
"Ponovo pokreni sada",\r
"ponovo_kasir TEXT",\r
"ponovo_kasir_id INTEGER",\r
"ponovo_razlog TEXT",\r
"ponovo_vrijeme TEXT",\r
"Ponuđena verzija {0} je starija od one koja je već na kasi ({1}).",\r
"Popunjenost",\r
"Popunjenost i prihod",\r
"Popust",\r
"Popust {0} % na računu {1}",\r
"popust %",\r
"Popust i kupac sa ekrana se za otpis",\r
"Popust i kupac sa ekrana se za otpis ne uzimaju u obzir.",\r
"Popust je uklonjen (cijena se promijenila) sa: {0}.",\r
"Popust kupca vjernosti ide na cio račun (ako nema ručnog popusta). Spisak kupaca stiže iz Knjigovodstva.",\r
"Popust na cijenu noći (%)",\r
"Popust na posljednju stavku",\r
"Popust na račun",\r
"Popust na račun ne može biti negativan.",\r
"Popust na stavku",\r
"Popust ne može biti veći od iznosa stavke ({0}).",\r
"Popust nije ispravan.",\r
"Popust od {0} je uklonjen sa stavke „{1}\\" jer nije manji od novog iznosa stavke.",\r
"Popust u % mora biti broj od 0 do 100.",\r
"Popust u procentima: broj, zatim %",\r
"popust_pct REAL",\r
"Popust: između 0 i 100 %.",\r
"Popusti",\r
"PORCIJA",\r
"Poreska je odbila poruku",\r
"Poreska je odbila: {0} (Podešavanja → Fiskalizacija).",\r
"Poreska ne prima sertifikat ove kase. Slanje čeka ispravan sertifikat.",\r
"Poreska odbila",\r
"Poreska uprava je odbila ({0}): {1}",\r
"Poreska uprava je odbila {0}, pa se ni ovaj dokument ne može prijaviti. Nakon otklanjanja uzroka: „Pošalji ponovo odbijene\\".",\r
"Poreska uprava je odbila poruka: {0}. Potrebno ih je riješiti (Podešavanja → Fiskalizacija).",\r
"Poreska uprava je odbila račun",\r
"Poreska uprava je odbila račun koji se stornira, pa ni storno ne može biti primljen. Nakon otklanjanja uzroka: „Pošalji ponovo odbijene\\" (original ide prvi, storno za njim).",\r
"Poreska za ovaj dan već ima prijavljen početni depozit (kôd 56). Ovaj unos se ne vodi posebno.",\r
"Poreska: {0} čeka · slanje ISKLJUČENO",\r
"Poreska: {0}{1}",\r
"Poreska: NIJE SPREMNO",\r
"Poreska: SERTIFIKAT ISTEKAO{0}",\r
"Poreski tretman naknade provjeriti sa Poreskom upravom.",\r
"Poreskoj upravi čeka slanje: {0}. Potrebna je veza sa internetom i slanje (oznaka Poreska u zaglavlju).",\r
"Port",\r
"Port {0} je zauzet (radi li još jedna kasa?) — izaberi drugi port.",\r
"Port {0} nije nađen na ovom računaru (priključen uređaj, drajver).{1}",\r
"Port {0} se ne može otvoriti (zauzet drugim programom ili isključen): {1}",\r
"Port / adresa",\r
"Port je potrebno prvo povezati dugmetom „Proba\\" u Podešavanjima.",\r
"Portal",\r
"PORTO",\r
"Poruka gostima (crnogorski)",\r
"Poruka gostima (engleski)",\r
"Poruka izdavača",\r
"Poruka je poslata podršci.",\r
"Poruka je prevelika (najviše 150 kB). Potrebno je podijeliti račun na više računa.",\r
"Poruka koje čekaju slanje Poreskoj upravi: {0}. Dok je slanje isključeno, poruke se ne šalju (rok dostave je 48 sati od izdavanja računa).\\n\\nIsključiti slanje?",\r
"Poruka koje čekaju slanje Poreskoj upravi: {0}. Ostaju u redu i šalju se tek kad se sertifikat ponovo uveze.",\r
"Poruka nije mogla biti pročitana (provjera veličine).",\r
"Poruka nije mogla biti pročitana pri provjeri po XSD šemi.",\r
"Poruka nije prošla provjeru šeme: neko polje je pogrešnog oblika ili PDV na računu ne odgovara PDV statusu firme.",\r
"poruka podršci",\r
"poruka podršci IRIS CORVINA, prijava greške, zahtjev (još kasa, produženje, modul)",\r
"Poruka podrške:",\r
"Poruka za Poresku ima {0} kB, a dozvoljeno je najviše 150 kB. Potrebno je podijeliti račun na više računa.",\r
"Poruka za uređaj je prevelika.",\r
"poruka: {0}",\r
"Poruke",\r
"Poruke koje je Poreska uprava odbila ({0}) ne šalju se ponovo automatski. Po otklanjanju uzroka šalju se dugmetom „Pošalji ponovo odbijene\\".",\r
"Poruke{0}",\r
"pos",\r
"POS terminal",\r
"POS terminal banke, naplata telefonom, vaga, F-tasteri, ekran kupca; transakcije terminala i usklađivanje sa kasom",\r
"POS terminal: {0}{1}{2}. Pregled: Više → Uređaji kase → Transakcije terminala.",\r
"Pošalji",\r
"Pošalji ponovo odbijene",\r
"Pošalji poruku",\r
"Pošalji sada",\r
"Pošalji zahtjev",\r
"Pošalji{0}",\r
"Posao",\r
"Posebna stavka bez PDV-a",\r
"poslat",\r
"poslate",\r
"Poslati",\r
"poslato",\r
"Poslato",\r
"Poslato je više podataka o ključu nego što treba.",\r
"Poslato je više potpisa nego što smije.",\r
"Poslato na štampu: {0}{1}",\r
"Poslato Poreskoj upravi: {0}.",\r
"poslije",\r
"Poslije ovoliko uzastopnih noći taksa se ne obračunava; 0 = ne primjenjuje se.",\r
"Poslije promjene cijene",\r
"Poslije promjene cijene: {0}.",\r
"Posljednja dva dana. Žuto: traži pažnju — nejasan ishod (provjeriti terminal) ili odobreno bez računa (izdati račun istog iznosa ili otkazati). Nejasnih:",\r
"Posljednja greška:",\r
"Posljednja greška: {0}",\r
"Posljednja izmjena kataloga nije dovršena ({0}). Potrebno je provjeriti cijene i ponovo ih uvesti (Podešavanja → Artikli i cijene).",\r
"Posljednja izmjena kataloga nije dovršena. Cijene su ponovo učitane iz programa za „{0}\\". Ako postoji noviji fajl sa cijenama, potrebno ga je ponovo uvesti (Podešavanja → Artikli i cijene).",\r
"Posljednja napomena: {0}",\r
"Posljednja provjera",\r
"Posljednja razmjena",\r
"Posljednja rezervna kopija u folder",\r
"posljednja veza {0}",\r
"Posljednje izmjene",\r
"Posljednje preuzimanje nije uspjelo: {0} Novi pokušaj je pri sljedećoj provjeri.",\r
"Posljednje slanje",\r
"Posljednji broj",\r
"Posljednji izdati broj je {0}. Sljedeći račun dobija broj {1}.",\r
"Posljednji izdati broj postaje {0}, pa sljedeći račun dobija broj {1}.\\n\\nVraćanje brojača unazad kasnije nije moguće.",\r
"Posljednji izdati broj računa",\r
"Posljednji izdati broj računa ({0})",\r
"Posljednji izdati račun više ne blokira izdavanje zbog vremena. Potvrda je dozvoljena samo kada su datum i vrijeme na uređaju sada tačni.",\r
"Posljednji račun je od {0}, a danas je {1} ({2} dana). Ako kasa nije toliko stajala, potrebno je provjeriti datum i godinu na uređaju prije prvog računa.",\r
"Posljednji snimak baze je bio oštećen. Baza je vraćena iz prethodnog snimka i dnevnika{0}",\r
"Posljednjih {0} h",\r
"Posljednjih 48 h",\r
"poslovodja",\r
"POST",\r
"POST, GET",\r
"Postavi",\r
"Postavi {0} EUR",\r
"Postoji verzija {0}, ali feed nema ispravnu (HTTPS) adresu Android paketa.",\r
"Potpis dozvole nije ispravan. Dozvolu izdaje samo održavanje.",\r
"Potpis gosta",\r
"Potpis naloga ne odgovara ključu izdavača. Nalog nije izvršen.",\r
"Potpis u cjelini nije ispravan.",\r
"Potpis zahtjeva nije ispravan.",\r
"Potpisan je pogrešan dio poruke.",\r
"Potpisan nalog je stariji od 7 dana (ili bez ispravnog vremena) — nije izvršen; izdaj nov nalog.",\r
"Potpisuje se samo zahtjev koji je sastavio ovaj modul (racunXml / depozitXml / enuXml).",\r
"Potrazuje",\r
"Potreban je bar jedan način plaćanja.",\r
"potrebna je ECR specifikacija banke",\r
"Potrebna je nova verzija aplikacije (1.5).",\r
"Potrebna je nova verzija aplikacije (SoftPOS sa iznosom).",\r
"Potrebna je nova verzija aplikacije.",\r
"Potrebna je ponovna prijava (konobar i PIN).",\r
"Potrebna je ponovna prijava.",\r
"Potrebno je izabrati:",\r
"Potrebno je ponovo pokrenuti program.",\r
"Potrebno je provjeriti podatke o kasi i ponovo potvrditi.",\r
"Potrebno je provjeriti podatke o prodajnom mjestu i ponovo potvrditi.",\r
"Potrebno je unijeti šifru bona.",\r
"Potrebno je upariti kasu sa serverom (odjeljak Server IRIS CORVINA).",\r
"Potrošnja na sobu",\r
"Potrošnja na sobu{0}",\r
"Potvrda",\r
"Potvrda broja",\r
"Potvrda kase",\r
"Potvrda nije upisana (NOVA). Ništa nije promijenjeno.",\r
"Potvrda o participaciji",\r
"POTVRDA O PLAĆENOJ PARTICIPACIJI",\r
"Potvrda pakovanja",\r
"Potvrda prodajnog mjesta",\r
"Potvrda sata uređaja",\r
"potvrda: račun van radnog vremena",\r
"Potvrđena",\r
"Potvrđena (zauzima sobu)",\r
"Potvrdi",\r
"Potvrdi ENU iz spiska…",\r
"Potvrdi povrat",\r
"Potvrdi sat uređaja",\r
"Potvrdio",\r
"potvrđuje knjigovođa",\r
"povezan",\r
"Povezani barkodovi",\r
"Povezano",\r
"Poveži",\r
"Poveži barkod sa artiklom",\r
"Poveži sa artiklom",\r
"Poveži sa postojećim artiklom",\r
"Povezivanje",\r
"Povezivanje kase sa firmom",\r
"Povezivanje sa firmom",\r
"Povezivanje sa serverom…",\r
"Povezuje se…",\r
"Povraćaj {0} na karticu se radi na terminalu / u aplikaciji banke.",\r
"Povraćaj na karticu",\r
"Povraćaj na karticu nije uspio ({0}): {1}",\r
"Povrat",\r
"povrat ({0} st.{1})",\r
"povrat avansa",\r
"Povrat avansa",\r
"POVRAT AVANSA — KOREKTIVNI RAČUN AVANSNOG RAČUNA",\r
"Povrat avansa traži odobrenje šefa. Povrat nije urađen.",\r
"Povrat bi premašio iznos računa ({0}; već vraćeno {1}). Povrat nije urađen.",\r
"Povrat dijela robe",\r
"Povrat dijela robe: korektivni račun br.",\r
"Povrat izdatog lijeka nije dozvoljen. Greška pri izdavanju se ispravlja stornom računa uz razlog.",\r
"Povrat je moguć",\r
"Povrat je moguć samo sa izdatog računa koji nije storniran.",\r
"Povrat je upisan: korektivni račun {0}.",\r
"POVRAT KUPCU (kusur)",\r
"Povrat na karticu",\r
"Povrat na karticu: kupac prislanja istu karticu na terminal.",\r
"Povrat na terminalu",\r
"povrat REAL",\r
"Povrat robe",\r
"Povrat uz račun {0}",\r
"Povrat virmanom traži partnera sa PIB-om na rezervaciji.",\r
"Povratak na prethodnu verziju nije uspio.",\r
"Povratak na prethodnu verziju postoji samo na Windows kasi.",\r
"Povratak računa na njegov sto (bez naloga)",\r
"Povreda",\r
"Povuci",\r
"Povuci katalog sa servera",\r
"Poziv gosta je riješen.",\r
"Pozivi gostiju",\r
"pozivi: {0}",\r
"PRAŠAK ZA PEC",\r
"Pravila barkoda vage",\r
"Pravila i takse",\r
"Pravila objekta su sačuvana.",\r
"prazan je",\r
"Prazan račun.",\r
"Prazna polja koja moraju imati vrijednost: {0}.",\r
"Praznik",\r
"PRAZNIK",\r
"Praznika",\r
"prazno = aplikacija se samo otvara",\r
"Prazno = bez vize.",\r
"prazno = ćirilica od crnogorskog",\r
"prazno = kod rezultata aktivnosti",\r
"prazno = ne provjerava se",\r
"prazno = nije farmaceut",\r
"Prazno = po cjenovniku.",\r
"prazno = podrazumijevana",\r
"prazno = prvi USB uređaj ili vid:pid",\r
"prazno = prvi USB uređaj, ili Bluetooth adresa",\r
"Prazno = stopa smještaja.",\r
"Prazno = stopa smještaja. Naknada nikad ne nosi boravišnu taksu.",\r
"prazno ili predugo ime fajla",\r
"prebivalište",\r
"Prebivalište",\r
"Prebrojana gotovina (€)",\r
"Prebrojana gotovina je obavezna prije zaključka.",\r
"Prebrojana gotovina nije ispravna (npr. 125,50).",\r
"Prebrojano",\r
"Prebrojano: {0}",\r
"Prebrojano: {0}. Razlika se vidi na zaključku (Z).",\r
"Prebrojano: nije upisano",\r
"Predračun",\r
"PREDRAČUN — nije fiskalni račun. Ne ulazi u promet i ne prijavljuje se Poreskoj upravi.",\r
"Predračun {0}",\r
"Predračun {0} je poništen.",\r
"Predračun {0} je sačuvan ({1}).",\r
"Predračun {0} je učitan bez artikala kojih više nema u katalogu: {1}. Iznos: {2}.",\r
"Predračun {0} je učitan na ekran ({1}).",\r
"Predračun {0} je učitan. Iznos po sadašnjim cijenama je {1}, na predračunu {2}.",\r
"Predračun {0} od {1}, {2}.\\nPoništen predračun se ne može učitati u korpu.\\n\\nRazlog (neobavezno):",\r
"Predračun je poništen.",\r
"Predračun je učitan na ekran računa. Prije poništavanja potrebno ga je skloniti sa ekrana.",\r
"Predračun je već na čekanju.",\r
"Predračun je već poništen.",\r
"Predračun nije nađen.",\r
"Predračun od računa na ekranu (nije fiskalni račun); spisak predračuna",\r
"Predračun se ne pravi za sto. Račun stola se naplaćuje fiskalnim računom.",\r
"Predračun se pravi od računa na ekranu (stavke, popusti, kupac). Poslije čuvanja račun se skida sa ekrana; predračun se kasnije učitava u korpu i naplaćuje kao fiskalni račun.",\r
"predračuna. Za starije je potrebna pretraga.",\r
"Predugačka polja: {0}.",\r
"predugo ime fajla: {0}",\r
"Pregled",\r
"Pregled obrisanih računa",\r
"Pregled se upisuje u dnevnik pristupa (korisnik, vrijeme, razlog).",\r
"Pregled svih brisanja prije naplate za izabrani period: obrisani računi i stavke uklonjene sa računa (ko, kad, šta, koliko, zašto i da li je račun poslije naplaćen).",\r
"Pregled: {0} od {1} artikala{2}{3}",\r
"Pregled. Izmjene radi korisnik sa ovlašćenjem za podešavanja.",\r
"pregledač",\r
"pregledač (IndexedDB)",\r
"prekinut upis u fajl {0} se ne može dovršiti ({1})",\r
"Prekinuto na terminalu (proba).",\r
"Prekinuto.",\r
"preko Wi-Fi mreže radnje. Uparivanje: QR kod sa glavne kase (",\r
"Prekoračenje: {uredjaja, dana} cijeli brojevi ≥ 0.",\r
"prelazni režim (server + folder)",\r
"prelazni režim: preko servera i kroz folder",\r
"Prelazni režim: razmjena i kroz folder",\r
"prema prethodnih 7",\r
"Prema upisanom radnom vremenu kasa danas ne radi.",\r
"premješta se",\r
"Premještanje / spajanje — sto {0}",\r
"Premještanje / spajanje stola",\r
"Premještanje barkoda na drugi artikal",\r
"Premještanje u drugu sobu",\r
"premješten",\r
"Premjesti",\r
"Premjesti / spoji",\r
"Premjesti / spoji sto…",\r
"Prenos pakovanja artikala nije uspio: {0}",\r
"Prenos pakovanja artikala: {0}",\r
"Preostalo",\r
"Preostalo je {0} za raspoređivanje.",\r
"Prepis u aplikaciju organa",\r
"Prepis: prijava se priprema ovdje i unosi u aplikaciju organa.",\r
"Prepiska",\r
"Preporuka",\r
"Presjek",\r
"presjek (X)",\r
"PRESJEK | Kasa:{0} | {1}..{2} | Racuna:{3} | Promet:{4} EUR | Got:{5} | Kar:{6} | Popust:{7}",\r
"Presjek u",\r
"Preskače se promjena veća od 3×: {0} (nije označeno „Uključiti i promjene veće od 3×\\").",\r
"Preskoči",\r
"Prethodni dan",\r
"Prethodni podaci",\r
"Prethodni upis je u toku.",\r
"Pretraga",\r
"Pretraga (naziv ili šifra)",\r
"Pretraga artikla",\r
"Pretraga artikla: naziv ili šifra…",\r
"Pretraga po barkodu, šifri ili dijelu naziva.",\r
"Pretraga po dobavljaču, broju i izvoru",\r
"Pretraga po nazivu",\r
"Pretraga: broj, iznos, kupac, kasir, IKOF…",\r
"Pretraga: broj, kupac, PIB…",\r
"Pretraga: ime, soba",\r
"Pretraga: ime, telefon, soba",\r
"pretvoren u račun",\r
"Pretvoreni u račun",\r
"Preuzeta je i provjerena verzija {0}. Instalacija je moguća nakon zaključenja smjene; podaci ostaju sačuvani.",\r
"Preuzeta je i provjerena verzija {0}. Instalira se preko postojeće verzije; podaci ostaju sačuvani.",\r
"Preuzeta je i provjerena verzija {0}. Nova verzija se primjenjuje pri sljedećem pokretanju kase, nakon zaključenja smjene.",\r
"Preuzeta je i provjerena verzija {0}. Nova verzija se primjenjuje pri sljedećem pokretanju programa.{1}",\r
"preuzeta verzija {0}{1}",\r
"Preuzeta verzija nije ispravna na disku, pa radi verzija iz instalacije. Potrebno je ponovo preuzeti ažuriranje.",\r
"Preuzeta verzija traži noviji Setup ({0} ili noviji). Do tada radi sadašnja verzija.",\r
"Preuzeto podešavanja: {0}.",\r
"Preuzeto: {0} artikala (marža {1} %)",\r
"Preuzimanje je već u toku.",\r
"Preuzimanje kataloga…",\r
"Preuzimanje nije uspjelo.",\r
"Preuzimanje nove verzije je u toku.",\r
"Preuzimanje nove verzije nije moguće na ovom uređaju.",\r
"Preuzimanje verzije {0}…",\r
"preuzimanje: {0}",\r
"Preuzmi",\r
"Preuzmi e-recepte",\r
"Preuzmi i pošalji",\r
"Preuzmi i postavi",\r
"Preuzmi novu verziju",\r
"Preuzmi sada",\r
"Preuzmi sto",\r
"previše fajlova",\r
"Previše pogrešnih PIN-ova zaredom. Ponovni pokušaj je moguć za {0}.",\r
"Previše preusmjeravanja na adresi za ažuriranje.",\r
"Prezime",\r
"Prezime i ime",\r
"pri zaključku",\r
"Pricing Rule",\r
"Prihod po izvoru rezervacije",\r
"Prihod po raspoloživoj sobi",\r
"Prihod smještaja",\r
"prijava",\r
"Prijava",\r
"Prijava dolaska",\r
"Prijava gosta — {0} {1}",\r
"Prijava gostiju",\r
"Prijava greške u programu",\r
"Prijava je kopirana.",\r
"Prijava je poslata izdavaču.",\r
"Prijava je sačuvana i šalje se kad se veza sa serverom uspostavi.",\r
"Prijava kasira",\r
"Prijava korisnika: {0}",\r
"Prijava nije uspjela.",\r
"Prijava nije uspjela. Potrebno je ponovo izabrati kasira.",\r
"Prijava organima",\r
"Prijava policiji",\r
"Prijava turističkoj organizaciji",\r
"Prijava za prepis",\r
"prijava.cuvanjeGodina",\r
"prijava.rokPolicijaSati",\r
"prijava.rokToSati",\r
"prijava.turistickaOrganizacija",\r
"Prijave gostiju",\r
"Prijavi",\r
"Prijavi dolazak",\r
"Prijavi grešku",\r
"prijavljeni kasir nije upisan kao farmaceut",\r
"Prijavljeno policiji",\r
"Prijavljeno turističkoj organizaciji",\r
"prije",\r
"prije {0} d",\r
"prije {0} dana",\r
"prije {0} h",\r
"prije {0} min",\r
"prije {0} s",\r
"Prijedlog naziva: {naziv}",\r
"Prijem narudžbi sa telefona konobara nije uključen (Podešavanja → Telefoni konobara).",\r
"Prijem tehničkih grešaka je kod izdavača isključen za ovu firmu. Greške iz reda se ne šalju.",\r
"Prikaz dijela FZO-a na fiskalnom računu: račun glasi na iznos koji plaća pacijent (dio FZO je popust stavke). Ovaj način treba potvrditi sa knjigovođom i Upravom prihoda i carina.",\r
"Prikazano 500 od {0} — suzite pretragu.",\r
"Prikazano je posljednjih",\r
"Prikazano je posljednjih {0} predračuna. Za starije je potrebna pretraga.",\r
"Prikazano je prvih",\r
"Prikazano je prvih {0} računa. Za ostale je potrebno suziti period ili pretragu.",\r
"Prikazano je prvih {0}. Ostali artikli su dostupni pretragom.",\r
"Prikazano mjesta: {0} od {1}",\r
"Prikazano:",\r
"Prikaži",\r
"Prikaži {0}",\r
"Prikaži podatke",\r
"Prikaži sve kase",\r
"Prikazuju se samo dijelovi kase za izabrane djelatnosti. Bez izbora se prikazuje sve. Uparena kasa izbor upisuje i na server, za sve programe firme.",\r
"PRIL",\r
"Prilog „{0}\\" nije dozvoljen (dozvoljeni: dnevnik, slika, kontekst).",\r
"Prilog mora biti objekat.",\r
"prilog: slika ekrana (ovog prozora)",\r
"prilog: tehnički dnevnik kase (posljednjih 200 radnji, bez iznosa i računa)",\r
"Priloženi sertifikat nije X.509.",\r
"Primaj narudžbe sa telefona konobara",\r
"primary",\r
"Primijeni",\r
"Primijeni ({0})",\r
"Primijeni i na…",\r
"Primjena stopa PDV-a po datumu nije uspjela: {0}",\r
"Primjena zakazanih cijena nije uspjela: {0}",\r
"Primjenjuje se pri sljedećem pokretanju programa.",\r
"Primljena gotovina je manja od iznosa koji se plaća gotovinom.",\r
"Primljena gotovina nije ispravan iznos.",\r
"Primljeno",\r
"Primljeno (prazno = tačan iznos)",\r
"primljeno {0} izmj. cijena{1}",\r
"Primljeno {0}, povrat {1}.\\n\\nPotvrditi iznos povrata?",\r
"Primljeno gotovine",\r
"primljeno REAL",\r
"PRINCES",\r
"PRINGLES",\r
"Priprema probne kase…",\r
"Priprema reda za Poresku nije uspjela: {0}",\r
"Pristup ekranu — podrška IRIS CORVINA",\r
"Pristup ekranu je dozvoljen. Podrška je obaviještena.",\r
"pristup ekranu: {0}",\r
"Pristup je moguć samo uz saglasnost. Bez saglasnosti podrška ne vidi ekran i ništa se ne mijenja. Svaki pristup se bilježi kod izdavača.",\r
"Pristup podacima gostiju",\r
"Privatni ključ ne odgovara sertifikatu.",\r
"privatni prostor aplikacije na uređaju",\r
"privatni prostor aplikacije, folder {0}",\r
"privatni recept",\r
"privremeni fajl nije upisan u cijelosti",\r
"PROBA",\r
"Proba ekrana kupca",\r
"PROBA EKRANA KUPCA",\r
"Proba je poslata na ekran kupca.",\r
"Proba naplate 1,00 €",\r
"Proba veze (status)",\r
"PROBA-{0}-{1}",\r
"PROBA-POTVRDA-{0}",\r
"Probna kasa",\r
"Probna kasa (bez prodajnog mjesta)",\r
"Probna kasa je postavljena{0}",\r
"Probna kasa nije vezana ni za jedno prodajno mjesto (proba, obuka): {0} i sa oznakom upisanom u podešavanjima.\\n\\nKasa iz spiska se može izabrati kasnije (Podešavanja → Kasa).",\r
"probni",\r
"probni (napravljen na ovom uređaju)",\r
"Probni FZO (obuka — izmišljeni e-recepti)",\r
"Probni FZO (obuka)",\r
"PROBNI FZO (obuka)",\r
"probni INTEGER",\r
"PROBNI REŽIM",\r
"PROBNI REŽIM — RAČUN NIJE PRIJAVLJEN PORESKOJ UPRAVI",\r
"PROBNI REŽIM · TEST",\r
"Procenat ima prednost. Oba prazna = bez popusta.",\r
"procjena",\r
"Procjena",\r
"PROD",\r
"Prodaja",\r
"prodaja ({0} st.{1})",\r
"Prodaja = računi i storna; Otpis = otpisana roba (nije promet)",\r
"Prodaja alkohola / duvana",\r
"Prodaja artikla sa isteklim rokom ({0}, rok {1})",\r
"prodaja bona (apoen na račun), provjera stanja bona, spisak",\r
"Prodaja po kupcima {0}",\r
"Prodaja poklon-bonova nije uključena (Podešavanja → Dodaci).",\r
"Prodaja: izbor iznosa dodaje bon na račun kao stavku; poslije naplate kasa štampa bon sa šifrom. Plaćanje bonom: „Više načina\\" → Bon (šifra).",\r
"Prodajna mjesta",\r
"Prodajnih mjesta: {0} · kasa u paketu: {1}",\r
"Prodajno mjesto",\r
"Prodajno mjesto firme",\r
"PRODUKCIJA",\r
"Produženje probnog perioda",\r
"Produži za noć",\r
"Program je ažuriran",\r
"Program je ažuriran na verziju {0}.",\r
"Program je potrebno zatvoriti i ponovo otvoriti.",\r
"Program nema bazu artikala za učitavanje.",\r
"Program nema dnevnik za slanje.",\r
"Program nije povezan sa serverom (Podešavanja → Server).",\r
"Program nije povezan sa serverom.",\r
"Program nije povezan sa serverom. Uređivanje menija radi uz vezu sa serverom (Podešavanja → Server).",\r
"Proizvođač",\r
"Proizvođač može imati najviše 80 znakova.",\r
"Proizvodjac",\r
"proizvodjac TEXT",\r
"promet",\r
"Promet",\r
"PROMET",\r
"Promet gasa, el. energije i grijanja/hlađenja sa prenosom poreske obaveze (ručno)",\r
"Promet po artiklima",\r
"Promet po satu",\r
"Promijeni cijene",\r
"Promijeni cijenu",\r
"Promijeni kasira",\r
"Promijeni kasu…",\r
"Promijeni market",\r
"Promijeni opštu cijenu",\r
"Promijeniti cijenu za {0} artikal(a)?{1}",\r
"Promijenjeno cijena: {0}{1}.",\r
"Promjena",\r
"Promjena kase",\r
"PRONTO",\r
"Propisano",\r
"propisanog lijeka nema",\r
"PROPOLIS RAK",\r
"PROSEC",\r
"PROSECCO",\r
"Prosječan račun",\r
"Prosječna cijena",\r
"Prosjek",\r
"Prošli mjesec",\r
"Prostor razmjene",\r
"Provjera automatske štampe nije uspjela: {0}",\r
"Provjera ažuriranja…",\r
"provjera baze nije prošla",\r
"Provjera bona",\r
"Provjera cijene",\r
"Provjera cijene ne dodaje artikal na račun.",\r
"Provjera cjenovnika firme…",\r
"Provjera novca",\r
"Provjera podataka",\r
"Provjera veze…",\r
"provjera: {0}",\r
"Provjereno sa serverom",\r
"Provjereno…",\r
"Provjeri",\r
"Provjeri ažuriranje",\r
"Provjeri cijene sada",\r
"Provjeri folder sada",\r
"Provjeri papir",\r
"Provjeri ponovo",\r
"Provjeri sada",\r
"Provjeri vezu",\r
"Provjerite količinu, cijenu i stopu.",\r
"Prozor na drugom monitoru",\r
"PRp",\r
"PRSUT",\r
"PRŠUT",\r
"Prvo unesite vrste soba.",\r
"public class KasaRaw {",\r
"public static void Posalji(string stampac, byte[] b) {",\r
"PUEBLO",\r
"PUEBLO TEQUILA",\r
"pulsira",\r
"Puni iznos",\r
"PUT",\r
"PUTER",\r
"QR kodovi i domen",\r
"QR kodovi stolova",\r
"QR kodovi vode na sopstveni domen firme (upisuje se u urednik → „QR kodovi i domen\\")",\r
"QR meni — podešavanja",\r
"QR meni — sadržaj menija",\r
"QR meni radi u ugostiteljskom režimu (Podešavanja → Ugostiteljstvo).",\r
"R. br.",\r
"r.datum >= ? AND r.datum <= ?",\r
"r.fic IS NOT NULL",\r
"r.fiscal_status IN ('ceka', 'error')",\r
"r.smjena_id = ?",\r
"r.smjena_id = ? AND date(r.datum) = ?",\r
"r.vrsta = 'otpis'",\r
"rač.)",\r
"račun",\r
"Račun",\r
"račun {0}",\r
"Račun {0}",\r
"Račun {0} je već obuhvaćen sumarnim računom.",\r
"Račun {0} se ne može obračunati po stopama PDV-a.",\r
"Račun {0}:",\r
"Račun {0}…: zbir po stopama ({1}) nije jednak iznosu računa ({2}).",\r
"račun {0}{1}",\r
"Račun br.",\r
"Račun br. {0} je poništen (storno).{1}",\r
"Račun br. {0} je storniran.",\r
"Račun br. {0} od {1}, {2}.\\n\\nIzdaje se storno račun; ovaj račun ostaje u evidenciji kao storniran. Storno se ne može poništiti.\\n\\nRazlog storna:",\r
"Račun gosta nije naplaćen ({0} EUR). Naplatite ga prije odjave.",\r
"račun hotela",\r
"Račun i štampa",\r
"Račun ide direktno na izabrani štampač, bez prozora za izbor. „Podrazumijevani štampač (Windows)\\" je štampač koji je u Windowsu postavljen kao podrazumijevani. Prozor za izbor štampača otvara se samo uz „(izbor pri svakoj štampi)\\". Dokumenti se štampaju redom, jedan po jedan.",\r
"Račun ima {0} različitih stopa/oslobođenja, a Poreska prima najviše 20.",\r
"Račun ima {0} stavki, a Poreska prima najviše 1000. Potrebno je podijeliti račun na više računa.",\r
"Račun izdat po ovom predračunu nije u bazi ove kase.",\r
"Račun je ispražnjen i ostaje u evidenciji obrisanih (Više → Obrisani računi).",\r
"Račun je izdat bez IKOF-a.",\r
"Račun je izdat dok je kasa radila u drugom okruženju (TEST / PRODUKCIJA) i ne šalje se ovom servisu.",\r
"Račun je izdat na sobu {0}. Upis na račun sobe čeka vezu sa serverom.",\r
"Račun je izdat prije više od 6 sati. Potrebno je poslati ga kao naknadnu dostavu.",\r
"Račun je na čekanju.",\r
"Račun je obrisan i ostaje u evidenciji obrisanih (Više → Obrisani računi).",\r
"Račun je obrisan sa čekanja.",\r
"Račun je plaćen iz avansa, a avansni račun je za taj iznos već korigovan. Storno nije urađen.",\r
"Račun je plaćen karticom preko terminala{0}. {1} {2} na terminalu?",\r
"Račun je prazan.",\r
"Račun je prijavljen Poreskoj upravi u PRODUKCIJI, a kasa sada radi u probnom okruženju. Povrat nije urađen. Za povrat je potrebno vratiti okruženje na PRODUKCIJU (Podešavanja → Fiskalizacija).",\r
"Račun je prijavljen Poreskoj upravi u PRODUKCIJI, a kasa sada radi u probnom okruženju. Storno nije urađen. Za storno je potrebno vratiti okruženje na PRODUKCIJU (Podešavanja → Fiskalizacija).",\r
"Račun je prijavljen Poreskoj upravi, pa i povrat mora biti prijavljen, a kasa trenutno ne može da šalje: {0} Povrat nije urađen.",\r
"Račun je prijavljen Poreskoj upravi, pa i storno mora biti prijavljen, a kasa trenutno ne može da šalje: {0} Storno nije urađen.",\r
"Račun je sačuvan: {0} ({1}){2}{3}",\r
"RAČUN JE STORNIRAN (storno br.",\r
"Račun je storniran: storno račun br.",\r
"Račun je storniran.",\r
"Račun je već obuhvaćen sumarnim računom (izdat na drugoj kasi). Storno nije urađen.",\r
"Račun je već obuhvaćen sumarnim računom.",\r
"Račun je već obuhvaćen sumarnim računom. Storno nije urađen.",\r
"Račun je već storniran u cijelosti.",\r
"Račun je već storniran.",\r
"Račun je već vraćen na ekran i nalazi se na čekanju („Čekanja\\").",\r
"Račun je vraćen na ekran bez artikala kojih više nema u katalogu: {0}.",\r
"Račun je vraćen na ekran.",\r
"Račun koji ide na sobu ne može imati drugi način plaćanja.",\r
"Račun koji je bio otkucan pri gašenju kase nije mogao da se vrati (zapis je oštećen). Račun je potrebno ponovo otkucati.",\r
"Račun koji je bio otkucan pri gašenju kase nije vraćen na ekran: nijednog njegovog artikla više nema u katalogu ({0}). Upisan je u obrisane račune (Više → Obrisani računi).",\r
"Račun koji se stornira izdat je u drugom okruženju (TEST / PRODUKCIJA), pa se ni storno ne šalje ovom servisu.",\r
"Račun koji se stornira nema IKOF, pa se storno ne može prijaviti.",\r
"Račun koji se stornira nije prijavljen Poreskoj upravi (izdat je u probnom radu), pa se ni storno ne šalje.",\r
"Račun kojim je vraćen ne postoji.",\r
"Račun može nositi samo jedan avansni račun, pa se slobodan avans ne može cio iskoristiti u ovoj naplati. Naplatite dio drugim načinom ili posebno. Ništa nije izdato.",\r
"Račun može nositi samo jedan avansni račun. Dio avansa nije iskorišćen; naplatite ostatak posebno.",\r
"Račun na čekanje",\r
"Račun na čekanju je nečitljiv.",\r
"Račun na ekranu",\r
"Račun na ekranu je prazan.",\r
"Račun na ekranu je prazan. Predračun se pravi od stavki računa na ekranu: artikli se otkucaju kao za račun, zatim se pritisne „Predračun\\".",\r
"Račun na ekranu je prazan. Predračun se pravi od stavki računa.",\r
"Račun na ekranu se u međuvremenu promijenio. Otpis nije upisan.",\r
"Račun na koji se poziva još nije prijavljen Poreskoj upravi. Pokušajte kasnije.",\r
"Račun na sobu gosta…",\r
"Račun na sobu ne postoji na ovoj kasi ili nema IKOF.",\r
"Račun na sobu se ne može izdati bez IKOF-a (fiskalizacija nije uključena ili nema sertifikata). Račun nije izdat.",\r
"Račun na sobu traži rezervaciju.",\r
"Račun ne postoji.",\r
"Račun nema IKOF (nije potpisan pri izdavanju).",\r
"Račun nema nijedan način plaćanja.",\r
"Račun nema stavki.",\r
"Račun nije izdat",\r
"Račun nije izdat{0}, a plaćanje {1} je odobreno na terminalu. Plaćanje se otkazuje na terminalu, ili ostaje za ponovni pokušaj izdavanja računa (sljedeća naplata istog iznosa ga koristi, bez nove naplate).",\r
"Račun nije nađen.",\r
"Račun nije plaćen iz ovog avansa.",\r
"Račun nije sumarni račun.",\r
"Račun od {0} je vraćen na ekran.",\r
"račun plaćen iz avansa",\r
"Račun plaćen iz avansa",\r
"Račun plaćen iz avansa je storniran. Avansni račun se za njega ne koriguje.",\r
"Račun plaćen iz avansa se ne stornira na kasi: avans na računu sobe ostaje iskorišćen. Storno nije urađen.",\r
"Račun plaćen karticom bez veze sa terminalom (ručna potvrda)",\r
"Račun sa ekrana je na narudžbi „{0}\\".",\r
"račun sa odloženim plaćanjem",\r
"Račun sa odloženim plaćanjem",\r
"RAČUN SA ODLOŽENIM PLAĆANJEM",\r
"račun sa odloženim plaćanjem {0}",\r
"Račun sa odloženim plaćanjem ne može imati drugi način plaćanja.",\r
"Račun sa odloženim plaćanjem ne može nositi naknadu ni taksu van računa: sumarni račun pokriva samo iznose računa.",\r
"Račun sa odloženim plaćanjem ne može nositi naknadu: sumarni račun pokriva samo iznose računa.",\r
"Račun sa odloženim plaćanjem nema IKOF, pa ne može u sumarni račun.",\r
"Račun sa poklon-bonom (prodat bon ili plaćeno bonom) se vraća samo stornom cijelog računa. Iznos se tada vraća na bon.",\r
"Račun se kao na avansni račun poziva na sopstveni IKOF.",\r
"Račun se među referentnim računima poziva na sopstveni IKOF.",\r
"Račun se ne može potpisati ({0}). Račun nije izdat. Potrebno je provjeriti sertifikat (Podešavanja → Fiskalizacija).",\r
"Račun se ne naplaćuje i ne šalje Poreskoj. Obrisan račun se može vratiti na ekran i naplatiti (Više → Obrisani računi).",\r
"Račun se poziva na {0} računa, a Poreska prima najviše 1000. Potrebno je izdati više sumarnih računa.",\r
"Račun sobe",\r
"Račun sobe {0}",\r
"Račun sobe je upravo izmijenjen. Ništa nije izdato.",\r
"Račun sobe nije nađen na serveru.",\r
"Račun sobe se upravo naplaćuje na drugoj kasi.",\r
"Račun stola je nečitljiv.",\r
"Račun više nije posljednji izdati ili je prošlo više od {0} min. Storno je moguć iz pregleda računa (Računi → račun → Storniraj).",\r
"Račun za smještaj i sumarni račun za potrošnju na sobu",\r
"racun_uid TEXT",\r
"Račun: {0} · {1}",\r
"Računa",\r
"Računa sa popustom",\r
"Računa se od časa dolaska gosta.",\r
"računa. Za ostale je potrebno suziti period ili pretragu.",\r
"Računaj IKOF i QR",\r
"Računar nije povezan na lokalnu mrežu (Wi-Fi / kabl). Telefoni ga ne mogu pronaći.",\r
"računi",\r
"Računi",\r
"računi bez kupca",\r
"Računi br.",\r
"Računi i izvještaji",\r
"Računi na čekanju",\r
"Računi na čekanju ( ) — nisu naplaćeni",\r
"Računi na čekanju ({0}) — nisu naplaćeni",\r
"Računi na čekanju ({0}) ostaju sačuvani i poslije zaključka.",\r
"računi obrisani i stavke uklonjene prije naplate, posljednjih 48 h ; starije vidi šef",\r
"računi obrisani i stavke uklonjene prije naplate, posljednjih 48 h; starije vidi šef",\r
"računi obrisani i stavke uklonjene prije naplate, posljednjih 48 h{0}; starije vidi šef",\r
"Računi obrisani prije naplate, sa svim otkucanim stavkama. Svako brisanje se pamti: ko, kad, šta, koliko, zašto{0}",\r
"Računi obuhvaćeni sumarnim računom",\r
"Računi plaćeni iz avansa",\r
"Rad",\r
"RAD",\r
"Rad preko lokalnog IRIS servera (sertifikat sopstvenog CA) traži instalaciju kase 1.8.0 ili noviju (nov Setup). Na Androidu lokalni server još nije podržan.",\r
"Rad preko lokalnog IRIS servera traži nov Setup kase (1.8.0 ili noviji).",\r
"Radi —",\r
"Radi — {0} stolova na meniju, narudžbe stižu na ovu kasu",\r
"radi sa opštim cijenama",\r
"RADLER",\r
"Radni market",\r
"Radnja",\r
"Radnja je već obrađena.",\r
"Radnja nema ispravan broj.",\r
"Radnja sa tim brojem već postoji (drugi telefon).",\r
"Radno mjesto",\r
"Radno vrijeme kase danas: {0}–{1}.",\r
"RAKIJA",\r
"RAKIJA DUNJA",\r
"RAKIJE",\r
"Rakovi",\r
"RAMAZZOTTI",\r
"Raniji kupci",\r
"Raniji odlazak",\r
"raspakovan bi bio veći od {0} MB",\r
"Raspoloživo (sobe-noći)",\r
"Raspon ili spisak, odvojeno zarezom.",\r
"Raspored sale",\r
"Raspored sale je sačuvan.",\r
"Raspoređeno",\r
"Raspoređeno je {0} više od iznosa računa.",\r
"RAUCH",\r
"Razduženje robe 134000 — nalozi PAZ+IZF vs pazari sa PDV (fakture robe dodaju svoj iznos)",\r
"Razlika",\r
"Razlika (terminal − kasa)",\r
"Razlika iznosa: terminal − kasa (bez ručnih potvrda)",\r
"Razlika na zaključku od (€)",\r
"Razlika na zaključku smjene: {0} {1} €",\r
"Razlika se vidi na zaključku (Z).",\r
"Razlika: {0}",\r
"Razlog",\r
"Razlog (npr. gost odustao)",\r
"Razlog brisanja je obavezan (npr. „gost odustao\\").",\r
"Razlog otpisa",\r
"Razlog otvaranja fioke je obavezan.",\r
"Razlog povrata",\r
"Razlog povrata je obavezan.",\r
"Razlog pregleda",\r
"Razlog storna",\r
"razlogu",\r
"Razmijeni sada",\r
"Razmijenjeno sa serverom: poslato {0}, primljeno {1}{2}",\r
"Razmjena",\r
"Razmjena ide preko foldera (Google Drive); kasa nije povezana sa serverom IRIS CORVINA.",\r
"Razmjena kroz folder (Google Drive)",\r
"Razmjena kroz folder (Google Drive){0} · kasa nije uparena sa serverom",\r
"Razmjena preko foldera",\r
"Razmjena preko servera:",\r
"Razmjena preko servera: {0}{1}",\r
"Razmjena sa Knjigovodstvom i Menadžerom ide preko servera: kasa šalje zaključke smjena, izmjene cijena i nove artikle, a preuzima cjenovnik i izmjene cijena, za nekoliko sekundi čim je internet dostupan. Uparenoj kasi folder razmjene nije potreban; {0}služi samo za rezervnu kopiju (odjeljak ispod). Prodaja i štampa ne zavise od servera.",\r
"Razmjena sa Knjigovodstvom nije podešena. Potrebno je upariti kasu sa serverom (Podešavanja → Server IRIS CORVINA) ili podesiti folder razmjene (Podešavanja → Google Drive).",\r
"Razmjena sa serverom je u toku.",\r
"Razmjena sa serverom: {0}",\r
"Razmjena sa serverom…",\r
"Razmjena: nema novih izmjena.{0}",\r
"Recepcija",\r
"Recepcija (lični podaci gostiju)",\r
"Recepcija hotela",\r
"Recepcija traži vezu kase sa serverom i uključen hotel (Podešavanja → Način poslovanja).",\r
"Recept",\r
"Recept {0}: {1}",\r
"Recept {0}: lijek nije na računu.",\r
"Recept je istekao {0}.",\r
"Recept je već realizovan.",\r
"RED BULL",\r
"REDBULL",\r
"Redni broj",\r
"Redni broj mora biti nula ili pozitivan cio broj.",\r
"Redni broj računa mora biti pozitivan cijeli broj (dato: {0}).",\r
"Redoslijed",\r
"Redoslijed na meniju",\r
"Redoslijed u grupi",\r
"Redova",\r
"ref TEXT",\r
"Referentni račun {0}…: vrijeme izdavanja nije u obliku 2026-07-31T07:01:00+02:00.",\r
"Referentni račun: IKOF nije ispravan („{0}\\").",\r
"RELKON",\r
"REMY MARTIN",\r
"reset PIN (servis): {0}, kasira: {1}",\r
"Reset PIN-a šefa kase traži nalog POTPISAN ključem izdavača — u IRIS Adminu izdaj nalog sa ulogom admin/vlasnik (potpisan). Nalog nije izvršen.",\r
"REXONA",\r
"rez. {0} · {1} os.",\r
"REZANC",\r
"Rezervacija",\r
"Rezervacija je otkazana.",\r
"Rezervacija je ponovo potvrđena. Prijavite dolazak gosta.",\r
"Rezervacija je sačuvana.",\r
"Rezervacija je upisana.",\r
"Rezervacija je zatvorena: gost nije došao.",\r
"Rezervacija nije pronađena.",\r
"Rezervacije",\r
"Rezervaciju je u međuvremenu izmijenio drugi korisnik. Prikaz je osvježen.",\r
"Rezervisana vrsta",\r
"Rezervisano",\r
"Rezervna kopija baze u ovaj folder radi od instalacije kase 1.3.6 (novi Setup). Do tada kasa pravi dnevne kopije u svom folderu podataka (Kopije).",\r
"Rezervna kopija u folder zahtijeva instalaciju kase 1.3.6 ili novije (nov Setup).",\r
"Rezervna kopija u folder: {0}",\r
"Rezervna kopija: {0}",\r
"Rezim",\r
"Režim",\r
"Režim {0} se u privatnoj apoteci ne izdaje na teret FZO-a.",\r
"Režim Apoteka (lijek na recept samo uz recept i farmaceuta, zabrana povrata ljekova)",\r
"Režim Apoteka nije uključen (⋯ Više → Apoteka — podešavanja).",\r
"režim Apoteka, veza sa FZO, participacija, farmaceuti",\r
"Režim rada",\r
"Rezultati",\r
"Riba",\r
"RIBLJI ŠTAP",\r
"RIFF",\r
"right",\r
"Riješeno",\r
"RIZA",\r
"RIŽA",\r
"RIZLA",\r
"Rječnik jezika nije ispravan.",\r
"roba koja se ne može prodati ni vratiti; skida se sa stanja, dokument nije fiskalni",\r
"Roba za otpis se otkucava (skenira) na ekranu kao za prodaju, zatim se ponovo bira otpis (Više → Otpis robe).",\r
"robe",\r
"Rok",\r
"rok je prošao prije {0}",\r
"Rok policiji: {0}",\r
"Rok prijave policiji",\r
"Rok prijave policiji (sati)",\r
"Rok prijave turističkoj organizaciji",\r
"Rok prijave turističkoj organizaciji (sati)",\r
"Rok uplate (dana)",\r
"rok važenja isprave",\r
"Rok važenja može biti najviše {0} dana.",\r
"Rok važenja ne može biti prije dana izrade predračuna.",\r
"Rok važenja predračuna nije ispravan datum.",\r
"Rok za dostavu računa Poreskoj upravi je 48 sati od izdavanja. Potrebno je provjeriti vezu sa internetom; slanje: klik na oznaku.",\r
"ROL",\r
"ROSA",\r
"ROSE",\r
"ROSTILJ",\r
"ROŠTILJ",\r
"ROTHMANS",\r
"Rožaje",\r
"ROZE",\r
"ručna potvrda",\r
"Ručna potvrda",\r
"ručna potvrda kasira",\r
"Ručna potvrda sa slipa",\r
"ručna prijava",\r
"Ručni izbor artikla (kad barkod nije čitljiv)",\r
"Ručni popust {0} % (bez šefa najviše {1} %)",\r
"Ručni popust bez PIN-a šefa najviše (%)",\r
"Ručni popust kasira (na stavke bez akcije i na cio račun) veći od ovog procenta vrijednosti robe traži PIN šefa pri naplati. Akcije i kupci vjernosti se ne broje. 0 ili prazno = bez ograničenja.",\r
"Ručni popust veći od (%)",\r
"Ručni popusti",\r
"Rucno",\r
"ručno",\r
"RUKAVIC",\r
"RUM",\r
"Ruski",\r
"Sa cijenom ili prometom na ovom mjestu",\r
"Sa ovog računa je već vraćen dio robe (povrat). Storno nije urađen. Ostatak se vraća kroz „Povrat dijela robe\\".",\r
"Sa PDV-om",\r
"Sa posljednjih faktura",\r
"Sa računa hotela se ne vraća dio robe. Stornira se cio račun, pa se izdaje nov.",\r
"Sa računa plaćenog iz avansa se ne vraća dio robe. Stornira se cio račun, pa se izdaje nov.",\r
"Sa računa sa odloženim plaćanjem se ne vraća dio robe. Stornira se cio račun, pa se izdaje nov.",\r
"Sa stola",\r
"Sa sumarnog računa se ne vraća dio. Stornira se cio sumarni račun.",\r
"sabijen je na način koji kasa ne čita",\r
"sablon",\r
"Sačuvaj",\r
"Sačuvaj artikle za vagu (CSV)",\r
"Sačuvaj bez naloga",\r
"Sačuvaj domen",\r
"Sačuvaj gosta",\r
"Sačuvaj izmjene",\r
"Sačuvaj izmjene sa ove kase u fajl",\r
"Sačuvaj kao tabelu (CSV)",\r
"Sačuvaj katalog u fajl",\r
"Sačuvaj pravila",\r
"Sačuvaj predračun",\r
"Sačuvaj raspored",\r
"Sačuvaj tabelu za etikete (CSV)",\r
"Sačuvana grupa {0}.",\r
"Sačuvano: {0}",\r
"Sačuvano: {0}.",\r
"Sačuvano.",\r
"Sada",\r
"sada {0}{1} · {2} cijena · šifra {3}",\r
"Sada: probna kasa",\r
"sadržaj fajla tajne.json je oštećen",\r
"sadržaj je oštećen u prenosu",\r
"Sadržaj je u međuvremenu izmijenjen u drugom programu. Učitano je novo stanje; izmjena nije sačuvana.",\r
"sadrži prečice (linkove)",\r
"Saglasan sa obavještenjima i ponudama",\r
"Saglasnost data {0}{1}.",\r
"Saglasnost od",\r
"Saglasnost povučena {0}.",\r
"Sajt",\r
"Sakrij cijelu grupu sa menija",\r
"sakriven",\r
"sakrivena",\r
"Sala",\r
"SALAMA",\r
"Saldo",\r
"Saldo {0} EUR",\r
"saldo {0} EUR{1}",\r
"Saldo računa sobe je {0} EUR. Odjaviti gosta uz neizmiren saldo?",\r
"Saldo računa sobe nije izmiren: {0} EUR.",\r
"Šalje {0}…",\r
"šalje se",\r
"Šalje se Poreskoj upravi: preostalo {0}",\r
"Šalji račune Poreskoj upravi",\r
"Šalji tehničke greške izdavaču",\r
"SALVET",\r
"SAMBUCA",\r
"samo bez engleskog",\r
"Samo ekran kuhinje (bez papira)",\r
"Samo lokalna mreža radnje.",\r
"Samo nosioci koji su dali saglasnost i nisu je povukli. Svaki izvoz se upisuje u dnevnik pristupa.",\r
"samo preko servera",\r
"samo preko servera (folder se ne koristi za razmjenu)",\r
"Samo sobe za čišćenje",\r
"SAMPANJAC",\r
"ŠAMPANJAC",\r
"ŠAMPANJCA",\r
"SAMPON",\r
"ŠAMPON",\r
"ŠANK",\r
"SAPUN",\r
"SARDIN",\r
"SAT",\r
"Sat je potvrđen. Naplatu je potrebno ponoviti.",\r
"Sat telefona i kase se razlikuju više od 10 minuta. Potrebno je uključiti automatsko vrijeme na telefonu i provjeriti sat kase.",\r
"sat TEXT",\r
"Sat u pozadini nije pokrenut: {0}",\r
"Sat u pozadini: {0}",\r
"Sat u pozadini: nečitljiva poruka radnika",\r
"Sat uređaja",\r
"sat uređaja je pokazivao {0}.{1}. {2}",\r
"Sat uređaja je potvrđen.",\r
"sat uređaja je pri brisanju bio pomjeren unaprijed",\r
"Sat uređaja je vraćen unazad: posljednji račun je izdat {0}, a sat sada pokazuje ranije vrijeme. {1}",\r
"Sat uređaja je vraćen unazad: šef je potvrdio sat {0}, a sat sada pokazuje ranije vrijeme. {1}",\r
"Sat uređaja pokazuje vrijeme ranije od posljednjeg računa (ili od posljednje potvrde sata). Moguće je da je sat bio pomjeren unaprijed, pa ispravljen.\\n\\nAko je sat sada tačan, šef to potvrđuje i kasa nastavlja da izdaje račune. Ako nije, potrebno je podesiti datum i vrijeme uređaja.",\r
"SAUVIGNON",\r
"SAVANNA",\r
"Šavnik",\r
"Sažetak (digest) se ne slaže sa sadržajem poruke.",\r
"Scan for the menu & ordering",\r
"SCHWEPP",\r
"se na ovoj kasi nije pokrenula",\r
"SECER",\r
"ŠECER",\r
"ŠEĆER",\r
"šef",\r
"Šef",\r
"šef ga ima uvijek",\r
"Šef nema PIN, pa se odobrenje šefa ne traži. PIN se upisuje dugmetom „Izmijeni\\".",\r
"šef sa PIN-om",\r
"šef-kase",\r
"select",\r
"selected",\r
"Senf",\r
"SENF",\r
"SENSATION",\r
"septembar",\r
"septembra",\r
"Serija",\r
"Serija {0} je povučena iz prometa ({1}). Lijek iz te serije se ne izdaje.",\r
"serija je povučena iz prometa",\r
"serija TEXT",\r
"Serijski / USB port (COM)",\r
"Serijski port je zatvoren.",\r
"Serijski port traži nov Setup kase (ljuska 2111).",\r
"Serijski portovi: {0}",\r
"Serijski portovi…",\r
"Sertifikat",\r
"Sertifikat i ključevi kase se pri pokretanju nisu mogli pročitati, pa se ni veza sa serverom ne može upisati. Potrebno je ponovo pokrenuti kasu. Ako se greška ponovi: Podešavanja → Fiskalizacija → „Odbaci nečitljive ključeve…\\".",\r
"Sertifikat i ključevi nisu čitljivi",\r
"Sertifikat i ključevi nisu čitljivi (odjeljak Fiskalizacija). Dok se to ne riješi, upis veze sa serverom nije moguć.",\r
"Sertifikat i ključevi NISU sačuvani — fajl tajne.json se ne može upisati ({0}). Dosadašnji fajl nije diran.",\r
"Sertifikat i ključevi nisu upisani u cijelosti; dosadašnji fajl je ostao nepromijenjen.",\r
"Sertifikat i ključevi se čitaju ispravno, pa nema šta da se odbaci.",\r
"Sertifikat i ključevi se pri pokretanju nisu mogli pročitati, pa se sada ne mogu ni mijenjati. Potrebno je ponovo pokrenuti kasu. Ako se greška ponovi: Podešavanja → Fiskalizacija → „Odbaci nečitljive ključeve…\\".",\r
"Sertifikat i njegov ključ se brišu sa ove kase. Kasa prelazi na probni ključ i prestaje da šalje račune Poreskoj upravi.\\n\\nZa ponovno slanje potrebno je ponovo uvesti sertifikat iz fajla.{0}",\r
"Sertifikat je istekao {0}. Potreban je nov sertifikat.",\r
"Sertifikat je istekao. Potreban je nov sertifikat.",\r
"Sertifikat je izdat za PIB {0}, a PIB firme u podešavanjima je {1}. Potreban je sertifikat ove firme. Ako kasa pripada drugoj firmi, potrebno je promijeniti firmu (Podešavanja → Firma na računu) i izabrati kasu iz cjenovnika te firme.",\r
"Sertifikat je opozvan.",\r
"Sertifikat je uklonjen",\r
"Sertifikat je uvezen{0}",\r
"sertifikat lokalnog servera je istekao (provjeriti datum na računaru)",\r
"sertifikat lokalnog servera još ne važi (provjeriti datum na računaru)",\r
"Sertifikat nije izdao registrovani izdavalac (CA). Potreban je sertifikat za fiskalizaciju (CoreIT ili Pošta CG).",\r
"Sertifikat nije važeći.",\r
"Sertifikat se ne može pročitati ili nije RSA (X.509).",\r
"Sertifikat se ne može pročitati: {0}",\r
"Sertifikat servera ne odgovara zapamćenom otisku CA lokalnog servera — veza je prekinuta",\r
"sertifikat servera ne potpisuje zapamćeni CA lokalnog servera",\r
"sertifikat servera nije čitljiv",\r
"sertifikat servera nije potpisan zapamćenim CA lokalnog servera",\r
"Sertifikat važi tek od {0}.",\r
"Sertifikat za fiskalizaciju je istekao {0}. Računi se izdaju, ali ne mogu biti poslati Poreskoj dok se ne uveze nov sertifikat (Podešavanja → Fiskalizacija). Rok za naknadnu dostavu je 48 sati.",\r
"Sertifikat za fiskalizaciju važi do {0}. Potrebno je na vrijeme uvesti nov sertifikat (Podešavanja → Fiskalizacija).",\r
"Sertifikat, ključ za potpis i lozinka servera se nisu mogli pročitati ({0}). Podaci nisu mijenjani. Potrebno je ponovo pokrenuti kasu. Ako se greška ponovi, ključeve je moguće odbaciti i sertifikat ponovo uvesti (Podešavanja → Fiskalizacija). Do tada kasa radi u probnom režimu, bez slanja podataka.",\r
"Server",\r
"Server IRIS CORVINA (razmjena)",\r
"Server javlja drugi otisak CA nego link za uparivanje. Veza nije uspostavljena.",\r
"Server je odbio ovu kasu (uređaj je isključen na serveru). Kasa pokušava ponovo na svakih 15 minuta. Za nastavak rada potrebno je isključiti vezu („Isključi vezu\\") i upariti kasu novim kodom.",\r
"Server je odbio ovu kasu.",\r
"Server je odbio upis: {0}",\r
"Server je odgovorio greškom {0}.",\r
"Server je vratio odgovor koji nije JSON.",\r
"Server na adresi {0} ne odgovara{1}.",\r
"Server ne odgovara ({0} s). Razmjena se nastavlja u pozadini; fajlovi kase čekaju u redu za slanje.{1}",\r
"Server ne odgovara (isteklo vrijeme).",\r
"Server ne vraća kasi stanje zahtjeva. Odgovor izdavača (odobreno / odbijeno) stiže kroz poruke podrške (kartica Poruke).",\r
"Server ne zna storno sumarnog računa (stara verzija servera). Stavke na serveru nisu vraćene na čekanje; potrebna je nadogradnja servera.",\r
"Server nije dostupan",\r
"Server nije dostupan — ponovni prijem nije urađen.",\r
"Server nije dostupan. Fajlovi kase čekaju u redu i šalju se kad se veza uspostavi.{0}",\r
"Server nije dostupan. Ishodi naloga čekaju slanje.",\r
"Server nije podešen.",\r
"server nije poslao sertifikat",\r
"Server nije primio",\r
"Server nije primio izmjenu sa ove kase: {0}",\r
"Server nije vratio nijedan artikal sa cijenom. Katalog nije mijenjan.",\r
"Server odbio",\r
"Server odbio izmjenu",\r
"Server odbio izmjenu: {0}",\r
"Server ovu kasu vodi pod drugom oznakom ({0}), a kasa sada radi kao {1}, pa server odbija njene fajlove (izmjene cijena, zaključke). Potrebno je ponovo upariti kasu (Podešavanja → Server: „Isključi vezu\\", pa „Upari\\" novim kodom) ili zatražiti promjenu oznake od izdavača (Podrška → Zahtjev).",\r
"Server ovu kasu vodi pod drugom oznakom.",\r
"Server telefona konobara nije uključen — tablet se ne može povezati.",\r
"Server za ažuriranje je odgovorio greškom (HTTP {0}).",\r
"Server za ažuriranje nije dostupan ({0}).",\r
"Server za ažuriranje nije dostupan. Moguće je da nema veze sa mrežom.",\r
"Server za račune — ERPNext (staro, neobavezno)",\r
"Server za telefone se nije pokrenuo: {0}",\r
"Server{0} na adresi {1}.\\n\\nOtisak sertifikata (CA):\\n{2}\\n\\nOtisak je potrebno uporediti sa otiskom na ekranu „Pregled\\" programa IRIS Server na računaru u radnji. Kasa poslije uparivanja prihvata samo sertifikat ovog CA.",\r
"SERVICE",\r
"Servis Poreske uprave trenutno ne radi. Slanje se automatski ponavlja.",\r
"servisni nalozi: izvršeno {0}, greške {1}",\r
"SET",\r
"Sezonska pauza od {0} do {1} Program radi samo za čitanje i izvoz podataka.",\r
"Sezonski radnik sa prijavljenim boravkom",\r
"SHA-256",\r
"show",\r
"Sifra",\r
"šifra",\r
"Šifra",\r
"Šifra {0} · cijena {1} (cijena se mijenja dodirom na cijenu u spisku).",\r
"šifra {0} · PDV {1} %{2}{3}",\r
"šifra {0}{1}",\r
"šifra {0}{1} · {2} · PDV {3} %{4}",\r
"Šifra {0}{1}{2}",\r
"Šifra / barkod (npr. 3*7613…)",\r
"Šifra / barkod / dio naziva",\r
"sifra = ?",\r
"Šifra artikla je obavezna.",\r
"šifra bona",\r
"Šifra bona",\r
"Šifra ne smije imati razmake.",\r
"Šifra nije pronađena. Prikazani su rezultati pretrage.",\r
"sifra, naziv, cijena, pdv_stopa, jm, grupa, podgrupa, svoja, cijena_vrijeme, cijena_utc, grupa_id, proizvodjac, neto, neto_jm, pakovanje, max_zaliha",\r
"SIGNAL",\r
"SIJALIC",\r
"Sinhronizujem…",\r
"sintetika",\r
"Sintetika",\r
"SIR",\r
"SIRCE",\r
"SIRĆE",\r
"Širina rolne",\r
"Sirova štampa nije uspjela: {0}",\r
"sivo",\r
"Skenirajte — meni i narudžba",\r
"Skeniran artikal sa isteklim rokom: {0} (rok {1}{2})",\r
"Skidanje sa spiska čekanja bez štampe (etikete su već na policama)",\r
"Skini 1",\r
"Skinuti jedan komad sa stola?",\r
"Skrati boravak",\r
"Skrati za noć",\r
"SLADOLED",\r
"SLANINA",\r
"Slanje dnevnika nije podržano u ovoj verziji programa.",\r
"Slanje je isključeno. Kasa radi u probnom režimu.",\r
"Slanje je isključeno. Potrebno je uključiti „Šalji račune Poreskoj upravi\\" i sačuvati podešavanja.",\r
"Slanje je završeno.",\r
"Slanje Poreskoj nije podešeno.",\r
"Slanje Poreskoj upravi je isključeno, a ima neposlatih poruka. Slanje se uključuje u Podešavanjima → Fiskalizacija.",\r
"Slanje Poreskoj upravi je isključeno{0} Uključivanje: Podešavanja → Fiskalizacija → „Šalji račune Poreskoj upravi\\", zatim „Sačuvaj\\".",\r
"Slanje Poreskoj upravi je uključeno, ali kasa nije spremna: {0} Račun nije izdat. Potrebno je otkloniti uzrok (Podešavanja → Fiskalizacija / Kasiri) ili isključiti slanje.",\r
"Slanje Poreskoj upravi još čeka ({0}). Prelazak na probno okruženje nije moguć dok sve ne bude poslato.",\r
"Slanje Poreskoj upravi nije podešeno.",\r
"Slanje Poreskoj upravi nije uključeno.",\r
"Slanje Poreskoj upravi…",\r
"Slanje slike nije podržano u ovom programu.",\r
"Slanje slike…",\r
"Slanje tehničkih grešaka izdavaču je isključeno (Podešavanja → Podrška i greške).",\r
"slanje tehničkih grešaka je isključeno (Podešavanja → Podrška i greške)",\r
"Slatkiši",\r
"SLATKO",\r
"SLAUF",\r
"Slijepo / gluvonijemo lice, lice sa autizmom",\r
"Slijepo brojanje pazara (kasir ne vidi očekivano)",\r
"Slijepo brojanje: koliko bi trebalo biti u kasi vidi šef i zaključak (Z).",\r
"Slijepo brojanje: prebrojana gotovina se upisuje ispod. Očekivano stanje i razlika vide se poslije zaključka; šef ih vidi i prije.",\r
"slika",\r
"Slika je manja od {0} × {1} piksela.",\r
"Slika je oštećena u prenosu.",\r
"Slika je poslata. Izmjena još nije sačuvana.",\r
"Slika je prazna.",\r
"Slika je prevelika i ne može se dovoljno smanjiti.",\r
"Slika je veća od {0} KB.",\r
"Slika mora biti u formatu PNG, JPEG ili WebP.",\r
"Slika nije dostupna",\r
"Slika nije pronađena.",\r
"Slika u prilogu mora biti data-URL PNG ili JPEG (base64).",\r
"Sljedeće izdavanje po obnovljivom receptu je moguće od {0}.",\r
"Sljedeći dan",\r
"Sljedeći račun dobija broj za jedan veći.",\r
"SLJIVOVICA",\r
"ŠLJIVOVICA",\r
"slobodan",\r
"Slobodan avans",\r
"Slobodan avans {0} EUR je uračunat u uplate.",\r
"Slobodna",\r
"Slobodna, čista",\r
"slobodnih soba",\r
"Slobodnih soba ove vrste u periodu: {0}.",\r
"Slobodno",\r
"small",\r
"SMASH",\r
"SMINK",\r
"ŠMINK",\r
"SMIRNOFF",\r
"Smjena",\r
"Smjena #{0}",\r
"Smjena #{0} je otvorena (depozit {1}).{2}",\r
"Smjena #{0} je zaključena (Z).",\r
"Smjena #{0} se zaključuje i poslije toga se više ne može mijenjati.",\r
"Smjena je još otvorena. Presjek (X) je pod „Smjena\\".",\r
"Smjena je otvorena {0} i ima {1} računa ({2}).\\n\\nPotreban je zaključak (Z) prije današnje prodaje: pazar se vodi na dan zaključka, pa bi promet ranijeg dana bio upisan pod današnji datum.",\r
"Smjena je otvorena i ima račune. Druga kasa se može izabrati tek poslije zaključka smjene (Z).",\r
"Smjena je otvorena i ima račune. Promjena kase je moguća tek poslije zaključka smjene (Z).",\r
"Smjena je otvorena i ima račune. Promjena koda kase (ENU) je moguća tek poslije zaključka smjene (Z).",\r
"Smjena je otvorena. Potreban je zaključak smjene (Z).",\r
"Smjena je već otvorena i ima račune. Početni depozit nije promijenjen.",\r
"Smjena nije nađena.",\r
"Smjena od ranijeg dana",\r
"smjena otvorena{0}",\r
"Smjena se u međuvremenu promijenila. Prikazano je trenutno stanje.",\r
"Smjena već ima račune. Početni depozit se ne može mijenjati; razlika se upisuje kao depozit ili podizanje.",\r
"smjena: {0} · {1}",\r
"Smjene",\r
"Smještaj",\r
"Smještaj (sa PDV-om)",\r
"Smještaj plaća",\r
"SMOKI",\r
"SMOOTHIE",\r
"SMRZNUT",\r
"Smrznuti program",\r
"smrznuto",\r
"SNICKERS",\r
"snimak baze nije pročitan u cijelosti ({0} od {1} bajtova)",\r
"snimak baze nije upisan u cijelosti",\r
"snimak baze nije započet",\r
"Snimak baze pri pokretanju nije uspio ({0}). Računi su sačuvani u dnevniku. Potrebno je osloboditi prostor na uređaju.",\r
"Snimanje baze nije uspjelo: {0}",\r
"SO",\r
"Soba",\r
"soba {0}",\r
"Soba {0}",\r
"Soba {0} — {1}",\r
"Soba {0} — {1}{2}",\r
"Soba {0} — zauzeta u tom periodu",\r
"Soba {0} · {1}\\nPlaćanje na sobu je dozvoljeno. Iznos {2}.",\r
"Soba {0} · {1}: plaćanje na sobu je odbijeno. {2}",\r
"Soba {0} nije zauzeta.",\r
"Soba {0}: {1}.",\r
"Soba {0}{1}",\r
"Soba je zauzeta u tom periodu: {0}",\r
"Soba je zauzeta: {0}",\r
"Soba nije označena kao čista.",\r
"Soba sa oznakom {0} već postoji.",\r
"soba za čišćenje",\r
"Sobe",\r
"Sobe za čišćenje",\r
"sobe, rezervacije, gosti, račun sobe, avans i naplata",\r
"Sobe: {0} ukupno, {1} zauzeto, {2} slobodno, {3} za čišćenje, {4} van upotrebe.",\r
"SOBRANIE",\r
"SODA BIKARB",\r
"Soja",\r
"SOK",\r
"SOMERSBY",\r
"Sopstveni domen firme: {0}",\r
"Sopstveni domen: nije upisan.",\r
"SOS",\r
"SPAGET",\r
"ŠPAGET",\r
"spajanje",\r
"span",\r
"Specifikaciju servisa i sertifikat dostavlja FZO ugovornoj apoteci.",\r
"Spisak etiketa je prazan.",\r
"Spisak ima {0} artikala; traka će biti duga.\\nZa kraći spisak potrebno je suziti period ili pretragu.",\r
"Spisak je prazan. Artikli se dodaju barkodom, šifrom ili dijelom naziva.",\r
"Spisak predračuna",\r
"Sprat",\r
"Sprat {0}",\r
"Sprema",\r
"spremno",\r
"Spremno: {0}",\r
"SPRITE",\r
"SPUMANTE",\r
"sri",\r
"srijeda",\r
"Srpski (ćirilica)",\r
"ST",\r
"Šta biva sa uplaćenim avansom kad gost otkaže.",\r
"Šta se naplaćuje",\r
"Stalna polja",\r
"Štampa",\r
"Štampa čeka: otvoren je prozor za izbor štampača. Sljedeći dokumenti se štampaju redom, poslije zatvaranja tog prozora.",\r
"Štampa je prekinuta — računaru je ponestalo memorije za ovaj dokument. Zatvori kasu i pokreni je ponovo (do tada štampa ne radi); dugačak izvještaj štampaj u dijelovima.",\r
"Štampa nije dostupna na ovom uređaju.",\r
"Štampa nije uspjela: {0}",\r
"Štampa otpisane robe po artiklima",\r
"Štampa posljednjeg računa",\r
"Štampa prometa po artiklima",\r
"Stampac",\r
"Štampač",\r
"Štampač „{0}\\" ne prima sirov posao (ESC/POS) — izaberi mrežni način ili drugi štampač.",\r
"Štampač „{0}\\" nije nađen u Windowsu (provjeri tačno ime u Podešavanjima).",\r
"Štampač „{0}\\" nije primio sve podatke — provjeri vezu i papir.",\r
"Štampač „{0}\\" nije pronađen u Windowsu. Potrebno je izabrati štampač u Podešavanjima (Račun i štampa).",\r
"Štampač {0}:{1} ne odgovara.",\r
"Štampač {0}:{1}: {2}",\r
"Štampač fioke",\r
"Štampač je spreman.",\r
"Štampač nije izabran (izbor pri svakoj štampi). Poslije svake naplate otvara se prozor za izbor štampača, koji preuzima fokus sa kase; dokumenti se štampaju redom, tek kad se prethodni prozor zatvori. Za štampu bez tog prozora potrebno je izabrati štampač ili „Podrazumijevani štampač (Windows)\\".",\r
"Štampač nije javio stanje.",\r
"štampač nije odgovorio u 60 sekundi",\r
"Štampač za nalog (kuhinja)",\r
"Štampač za šank",\r
"Štampaj",\r
"Štampaj etiketu",\r
"Štampaj odmah poslije naplate",\r
"štampanje je odbijeno",\r
"Štampano",\r
"Standard Buying",\r
"Stanje",\r
"Stanje kase",\r
"stanje na početku dana",\r
"Stanje rezervacije",\r
"Stanje slanja nije moguće pročitati:",\r
"Stanje slanja nije moguće pročitati: {0}",\r
"STAPIC",\r
"ŠTAPIĆ",\r
"Stara",\r
"stara_svoja INTEGER",\r
"Stari kod",\r
"Stari QR kodovi sa adresom IRIS-a i dalje rade.",\r
"Stariji (šef)…",\r
"STARK",\r
"ŠTARK",\r
"STAROPRAMEN",\r
"StartPagePrinter(h); int w; bool ok = WritePrinter(h, b, b.Length, out w); EndPagePrinter(h); EndDocPrinter(h);",\r
"Status",\r
"status = 'obrisan'",\r
"status = 'otvoren'",\r
"Status sertifikata je nepoznat.",\r
"Stavi na čekanje",\r
"Stavi na sto {0}",\r
"stavka",\r
"stavka {0}",\r
"Stavka {0} („{1}\\"): iznos {2} je veći od količina × cijena ({3}).",\r
"Stavka {0} nije artikal {1}.",\r
"Stavka {0} nije na ovom računu.",\r
"Stavka {0}{1}",\r
"Stavka je otpisana.",\r
"Stavka je stornirana.",\r
"Stavka je već poslata kuhinji / šanku. Brisanje odobrava šef: potrebni su PIN šefa i razlog.",\r
"Stavka je već poslata kuhinji / šanku. Skidanje odobrava šef (PIN i razlog); kuhinji ide OTKAZ.",\r
"stavke",\r
"Stavke",\r
"Stavke na čekanje (kupac ide po novac)",\r
"Stavke narudžbe se skidaju sa stola; za poslate stavke kuhinji / šanku ide otkaz.",\r
"Stavke su na čekanju (Čekanja → Vrati na ekran).",\r
"Stavke su već naplaćene drugim računom. Ovaj račun treba stornirati.",\r
"Stavke uklonjene prije naplate ({0})",\r
"Stavke uklonjene sa računa prije naplate (uklanjanje stavke ili smanjenje količine), a račun je poslije toga izdat. Svako brisanje se pamti: ko, kad, šta, koliko.",\r
"stavki",\r
"Stavki",\r
"STELLA",\r
"Stigao je cjenovnik iz Knjigovodstva. Potrebno je izabrati koja je ovo kasa.",\r
"stigle",\r
"STIKS",\r
"ŠTIPALJK",\r
"Sto",\r
"Sto „{0}\\" ne postoji. Stolovi se upisuju na kasi (Podešavanja → Ugostiteljstvo).",\r
"sto {0}",\r
"Sto {0}",\r
"sto {0} ({1})",\r
"Sto {0} je na čekanju.",\r
"Sto {0} je prazan.",\r
"Sto {0} je premješten na {1}.",\r
"Sto {0} je preuzet.",\r
"Sto {0} je slobodan.",\r
"Sto {0} je spojen sa stolom {1}.",\r
"Sto {0} je trenutno otvoren na kasi. Izmjena je moguća kad kasir vrati sto.",\r
"Sto {0} vodi {1}. Sto je moguće preuzeti.",\r
"Sto {0} vodi {1}. Za spajanje je potrebno preuzeti taj sto.",\r
"Sto {0}: gost je poništio narudžbu (QR meni). Sto je otvoren na kasi; stavke se skidaju kad se sto vrati (Na sto).",\r
"Sto {0}: gost je poništio narudžbu (QR meni).{1}",\r
"Sto {0}: gost traži račun ({1}).",\r
"Sto {0}: gost traži račun{1}.",\r
"Sto {0}: gost zove konobara.",\r
"Sto {0}: nalog za narudžbu gosta nije odštampan. Štampač nije dostupan.",\r
"Sto {0}: narudžba gosta (QR meni) čeka. Sto je otvoren na kasi; narudžba se dodaje kad se sto vrati (Na sto).",\r
"Sto {0}: narudžba gosta (QR meni), stavki: {1}, iznos {2} €.{3}",\r
"Sto {0}: narudžba gosta je odbijena ({1}).",\r
"Sto {0}: narudžba gosta nije obrađena ({1}).",\r
"Sto {0}: otkaz (narudžba gosta poništena) nije odštampan.",\r
"Sto {0}: otkaz nije odštampan ({1}). Potrebno je obavijestiti kuhinju / šank.",\r
"Sto {0}: otkaz poslate stavke ({1}).",\r
"Sto {0}{1}",\r
"Sto je na ekranu. Potrebno ga je prvo vratiti na čekanje („Na sto\\").",\r
"Sto je otvoren na kasi (naplata). Izmjena sa telefona nije moguća.",\r
"Sto je prazan.",\r
"Sto je u međuvremenu zatvoren.",\r
"Sto je već zatvoren na kasi — pozovite konobara.",\r
"Sto nije izabran (dugme „Stolovi\\").",\r
"sto TEXT",\r
"Sto više ne postoji na kasi — pozovite konobara.",\r
"Sto vodi",\r
"STOCK",\r
"stolova na meniju, narudžbe stižu na ovu kasu",\r
"Stolovi",\r
"Stolovi (imena, zarezom)",\r
"Stolovi (konobar)",\r
"Stolovi moraju biti različiti.",\r
"Stolovi nisu upisani (Podešavanja → Ugostiteljstvo, npr. „1, 2, 3, Šank\\").",\r
"Stolovi nisu upisani (Podešavanja → Ugostiteljstvo).",\r
"Stolovi se prevlače na mjesto kako stoje u sali. Pregled stolova ih prikazuje po tom rasporedu.",\r
"Stolovi se prikazuju u mreži.",\r
"Stolovi: sto na ekran, premještanje, podjela računa",\r
"Stopa",\r
"Stopa na avansnom računu",\r
"Stopa na hranu",\r
"Stopa na hranu uz smještaj (%)",\r
"Stopa na naknadu za otkaz",\r
"Stopa na smještaj",\r
"Stopa PDV-a (%)",\r
"Stopa PDV-a na avansnom računu (%)",\r
"Stopa PDV-a na naknadu za otkaz (%)",\r
"stopa smještaja",\r
"Storna",\r
"storna {0}",\r
"Storniraj",\r
"Storniraj račun…",\r
"storniran",\r
"Storniran",\r
"Stornirani",\r
"stornirao_uid TEXT",\r
"storno",\r
"Storno",\r
"Storno ({0})",\r
"Storno dokumenta hotela se ne može izdati bez IKOF-a (fiskalizacija nije uključena ili nema sertifikata). Storno nije urađen.",\r
"storno račun",\r
"Storno račun",\r
"Storno račun se ne može stornirati.",\r
"Storno računa",\r
"Storno računa {0}",\r
"Storno računa {0}{1}",\r
"Storno računa br.",\r
"Storno računa na kasi",\r
"Storno računa sa receptom traži razlog (npr. greška pri izdavanju).",\r
"Storno računa: povraćaj na karticu",\r
"Storno stavke",\r
"STORNO SUMARNOG RAČUNA — KOREKTIVNI SUMARNI RAČUN",\r
"Storno sumarnog računa mora imati negativan iznos (računi iz sumarnog sa minusom).",\r
"Storno sumarnog računa se ne može izdati bez IKOF-a (fiskalizacija nije uključena ili nema sertifikata). Storno nije urađen.",\r
"storno_uid TEXT",\r
"storno, brisanja, veliki popusti, fioka, gotovina, razlike; samo šef",\r
"Storno, poništavanje, brisanje, veliki popusti, fioka bez računa, gotovina preko granice, razlika na zaključku. Ista upozorenja vidi vlasnik u Menadžeru.",\r
"Strani",\r
"Strani gost",\r
"STREČ",\r
"strong",\r
"STRONGBOW",\r
"struja",\r
"sub",\r
"subota",\r
"SUDZUK",\r
"SUDŽUK",\r
"sumarni račun",\r
"SUMARNI RAČUN",\r
"sumarni račun {0}{1}",\r
"Sumarni račun glasi na kupca, a neki od računa nije izdat tom kupcu.",\r
"Sumarni račun je već storniran.",\r
"Sumarni račun mora navesti račune na koje se odnosi (IKOF, vrijeme i iznos svakog).",\r
"Sumarni račun mora navesti račune na koje se odnosi.",\r
"Sumarni račun ne može imati naknadu: na njemu nema prometa mimo pojedinačnih računa.",\r
"Sumarni račun ne može imati popust.",\r
"Sumarni račun ne nosi stavke: promet je već na pojedinačnim računima.",\r
"Sumarni račun nema IKOF, pa se storno ne može izdati.",\r
"Sumarni račun nema spisak računa.",\r
"Sumarni račun nema zbirove po stopama.",\r
"Sumarni račun nosi stvarni način plaćanja, ne odloženo plaćanje (ORDER).",\r
"Sumarni račun nosi stvarni način plaćanja, ne odloženo plaćanje.",\r
"Sumarni račun plaćen iz avansa se ne stornira na kasi: avans ostaje iskorišćen. Storno nije urađen.",\r
"Sumarni račun plaćen virmanom glasi na kupca, a potrošnja na sobu je izdata bez tog kupca. Potrošnju na sobu naplatite drugim načinom ili posebno. Ništa nije izdato.",\r
"Sumarni račun se može pozvati na najviše 1000 računa (dato: {0}). Potrebno je izdati više sumarnih računa.",\r
"Sumarni račun se može pozvati na najviše 1000 računa.",\r
"Sumarni račun se stornira kroz „Storno računa\\" (korektivni sumarni račun).",\r
"Sumarni račun: ista stopa PDV-a je navedena dva puta.",\r
"Sumarni račun: stopa {0} % je navedena na više računa nego što ih je u spisku.",\r
"Sumarni račun: zbir pojedinačnih računa ({0}) nije jednak zbiru po stopama ({1}).",\r
"Sumpor-dioksid i sulfiti",\r
"SUNCOKRET",\r
"SUNĐER",\r
"SUNDJER",\r
"SUNKA",\r
"ŠUNKA",\r
"SUPA",\r
"Susam",\r
"sv-SE",\r
"sva",\r
"Sva roba sa ovog računa je već vraćena.",\r
"Svaka promjena se bilježi kao izmjena cijene za ovo prodajno mjesto i šalje Knjigovodstvu.",\r
"Svaki artikal u spisku je jedna etiketa sa cijenom i cijenom po kg / l.",\r
"Svaki artikal u spisku je jedna etiketa sa cijenom i cijenom po kg / l.{0}",\r
"Svako otvaranje bez računa se bilježi (ko, kad, zašto) i vlasnik ga vidi u upozorenjima.",\r
"Svako prodajno mjesto ima svoje cijene. Bira se kasa na kojoj je ovaj uređaj, ili „Ova kasa na ovom mjestu\\" kad kase nema u spisku. Učitavaju se cijene tog mjesta.",\r
"Svako prodajno mjesto ima svoje cijene. Bira se kasa na kojoj je ovaj uređaj, ili „Ova kasa na ovom mjestu\\" kad kase nema u spisku. Učitavaju se cijene tog mjesta.{0}",\r
"sve",\r
"Sve",\r
"Sve ({0} EUR)",\r
"Sve grupe",\r
"Sve jednim sumarnim računom",\r
"Sve sobe su čiste.",\r
"Sve stavke stola su već poslate. Nema novih stavki za nalog.",\r
"sve stavke uklonjene",\r
"Sve stavke uklonjene",\r
"sve stolove ({0})",\r
"sve vrste",\r
"Sve vrste soba",\r
"SVEĆ",\r
"SVESK",\r
"svi",\r
"Svi",\r
"Svi artikli menija su dostupni.",\r
"svi kasiri",\r
"Svi u „{0}\\"",\r
"SVIJEĆ",\r
"SVINJ",\r
"svoja",\r
"Sync sada",\r
"Sync: poslato {0}{1}, u redu {2}",\r
"synced",\r
"tabak",\r
"tabaka",\r
"Tabela je sačuvana: {0}",\r
"tabela za elektronske etikete i artikli za vagu (PLU)",\r
"Tabla soba",\r
"table",\r
"Tablet preko lokalne mreže",\r
"tačan iznos",\r
"tačno",\r
"Tačno",\r
"Taj predračun je već na ekranu.",\r
"taj račun je storniran",\r
"Taj račun je već na ekranu.",\r
"Taj račun je već vraćen i naplaćen.",\r
"Taksa na fiskalnom računu",\r
"Taksa naplaćena van računa je veća od stvarnih plaćanja na računu.",\r
"Taksa nije prihod objekta; uplaćuje se opštini.",\r
"Taksa ulazi u osnovicu PDV-a",\r
"taksa.bezTaksePoslijeNoci",\r
"taksa.danIzvjestaja",\r
"taksa.djecaDo",\r
"taksa.exOznaka",\r
"taksa.rokUplateDana",\r
"taksa.umanjenjeProc",\r
"taksa.umanjenoDo",\r
"taksa.uOsnoviciPdv",\r
"TANQUERAY",\r
"tbody",\r
"td",\r
"TEA",\r
"TECHNICALERROR",\r
"Tehničke greške koje čekaju slanje",\r
"tehničkih grešaka čeka slanje: {0}",\r
"TEKILA",\r
"Tekst odgovora je obavezan.",\r
"Tekst poruke je obavezan.",\r
"tel.",\r
"Telefon",\r
"Telefon „{0}\\" je odspojen.",\r
"Telefon „{0}\\" više ne može da šalje narudžbe; za ponovni rad potrebno je novo uparivanje. Odspojiti telefon?",\r
"Telefon je uparen sa kasom „{0}\\".",\r
"Telefon je uparen.",\r
"Telefon konobara",\r
"Telefon konobara ne izdaje račune: konobar na njemu bira sto i šalje narudžbe glavnoj kasi u radnji (preko Wi-Fi-ja), a glavna kasa štampa nalog i izdaje račun. Uparivanje se radi na glavnoj kasi (Podešavanja → Telefoni konobara → „Upari telefon\\"). Nastaviti?",\r
"Telefon konobara radi samo na Androidu.",\r
"Telefon mora biti na Wi-Fi-ju radnje. Konobar se poslije prijavljuje svojim imenom i PIN-om (Podešavanja → Kasiri).",\r
"Telefon nije uparen sa ovom kasom ili je odspojen. Potrebno je ponovno uparivanje.",\r
"Telefon šalje narudžbe",\r
"telefon TEXT",\r
"Telefone konobara prima kasa na Windowsu sa Setup-om 1.4 ili novijim. Potrebno je instalirati nov Setup.",\r
"Telefone konobara prima samo kasa na Windowsu (Setup 1.4 ili noviji).",\r
"Telefoni konobara (narudžbe preko Wi-Fi-ja radnje)",\r
"Telefoni rade samo u režimu „Ugostiteljstvo\\".",\r
"TEQUIL",\r
"TEQUILA",\r
"TEREA",\r
"termalna rolna",\r
"Terminal je odobrio drugi iznos ({0} umjesto {1}).",\r
"Terminal je spreman.",\r
"Terminal je spreman. ({0})",\r
"Terminal je vratio odgovor druge transakcije.",\r
"Terminal je zauzet.",\r
"Terminal ne odgovara.",\r
"Terminal ne podržava ovu radnju.",\r
"Terminal nedostupan: ponudi ručnu potvrdu",\r
"Terminal neto",\r
"Terminal nije dobio odobrenje banke.",\r
"Terminal nije dostupan (proba).",\r
"Terminal nije dostupan: {0}",\r
"Terminal nije dostupan. Kartica nije zadužena.",\r
"Terminal nije javio ishod (proba).",\r
"Terminal nije javio ishod plaćanja {0} ({1}). Kartica je možda zadužena. Potrebno je provjeriti na terminalu ili slipu da li je plaćanje odobreno.\\n\\nBroj odobrenja sa slipa (ako je odobreno):",\r
"Terminal nije javio ishod za {0} s.",\r
"Terminal nije javio ishod. Ishod je potrebno provjeriti na terminalu.",\r
"Terminal nije primio zahtjev.",\r
"Terminal za probu (bez uređaja)",\r
"Terminal za probu je spreman.",\r
"terminal: {0}",\r
"Terminal: {0}",\r
"Terminal: {0} transakcija, {1}.",\r
"Terminal: odobreno ({0})",\r
"terminal: prodaja {0}",\r
"TEST",\r
"text/html; charset=utf-8",\r
"text/plain; charset=utf-8",\r
"text/xml; charset=utf-8",\r
"textarea",\r
"Tezina",\r
"Težina je van opsega vage.",\r
"Težina nije mirna. Potrebno je sačekati da se vaga smiri.",\r
"Težina robe na mjerenje se čita sa vage priključene na kasu. Na račun ide samo mirna težina; kasir je potvrđuje. Toledo 8217 (i Dibal / CAS u tom načinu): komanda „W\\"; CAS: vaga šalje red „ST,GS,…kg\\"; opšti: bilo koji red sa težinom.",\r
"th",\r
"thead",\r
"Tijelo zahtjeva nije ispravno.",\r
"TIN",\r
"Tip",\r
"Tip mora biti: {0}.",\r
"Tivat",\r
"TJESTENIN",\r
"To",\r
"To je već cijena ovog artikla.",\r
"To su sve stavke na stolu. Cio sto se briše samo na kasi, uz razlog (evidencija brisanja).",\r
"TOALET PAPIR",\r
"TOBLERON",\r
"Tog konobara nema (ili nije aktivan) na kasi.",\r
"Tog obrisanog računa nema.",\r
"Tog računa više nema na čekanju.",\r
"token {0}:{1}",\r
"TOMATO SOS",\r
"TONIC",\r
"TONIK",\r
"TOPLJENI",\r
"TOST",\r
"tr",\r
"Trajna licenca ({0}): bez ograničenja, svi moduli",\r
"traka",\r
"Transakcija terminala nije nađena.",\r
"Transakcije terminala",\r
"TRAPIST",\r
"TRAVARICA",\r
"Traženje u mreži…",\r
"traži instalaciju novog Setup-a . Postavljanje iz programa nije moguće.",\r
"Traži IRIS Server u mreži",\r
"traži račun",\r
"Trgovina (marketi, kiosci, prodavnice)",\r
"TROLLI",\r
"Trosak",\r
"trošak rada u periodu",\r
"Troskovi",\r
"Troslovna oznaka, npr. DEU.",\r
"Troslovna oznaka, npr. MNE.",\r
"Troslovna oznaka.",\r
"Trudnica / porodilja do 1 godine",\r
"try { DI d = new DI(); d.n = \\"Kasa\\"; d.t = \\"RAW\\"; if (StartDocPrinter(h, 1, d) == 0) throw new Exception(\\"KASA_NE_PRIMA\\");",\r
"TUBORG",\r
"TUNA",\r
"Turistička org.",\r
"Turistička vila",\r
"Turistički apartmani",\r
"Turski",\r
"Tuzi",\r
"TWIX",\r
"type=\\"password\\" inputmode=\\"numeric\\" maxlength=\\"8\\"",\r
"type=\\"text\\" inputmode=\\"decimal\\"",\r
"type=\\"text\\" inputmode=\\"decimal\\" class=\\"iznos\\"",\r
"U dijalogu za štampu bira se A4 štampač ili čuvanje u PDF.",\r
"U dijalogu za štampu potrebno je izabrati A4 štampač (štampač računa je za rolnu).",\r
"U fajlu nema nijednog artikla sa šifrom, nazivom i cijenom. Katalog nije mijenjan.",\r
"U fajlu nema RSA privatnog ključa. Potreban je .pfx/.p12 fajl sa ključem (ne .cer).",\r
"U fajlu nema sertifikata (X.509) koji odgovara privatnom ključu.",\r
"u folderu Dokumenti\\\\Kasa",\r
"U folderu nema cjenovnika firme PIB {0}, a ima za PIB {1}. Ako je ova kasa te firme, potrebno je promijeniti PIB i naziv (Podešavanja → Firma na računu).",\r
"U kasi je {0} € gotovine (granica {1} €) — izdvojiti višak",\r
"U kasi je {0} gotovine (granica {1}). Višak je potrebno izdvojiti (Smjena → Podizanje).",\r
"U međuvremenu je nešto promijenjeno (smjena, čekanje, slanje). Potrebno je ponovo provjeriti.",\r
"u naplati",\r
"U objektu",\r
"U ovoj grupi nema artikala.",\r
"U ovoj smjeni nema nijednog računa.",\r
"U ovom paketu nema prodajnog mjesta ove kase („{0}\\"). Cijene nisu mijenjane.",\r
"u ovom periodu",\r
"U ovom periodu",\r
"U ovom periodu cjenovnik traži najmanje {0} noći.",\r
"U paketu firme nema nijednog prodajnog mjesta. Market se dodaje u Knjigovodstvu (Podešavanja → Marketi) i objavljuje kasama (Cjenovnik kasa → „Razmijeni sada\\" ili „Sačuvaj cjenovnik u fajl\\").",\r
"U paketu je verzija {0}, a traži se {1} — paket se ne prihvata.",\r
"U paketu nema prodajnog mjesta {0}.",\r
"U paketu nema tog prodajnog mjesta.",\r
"U poruci je kontrolni znak (poruka nije sastavljena u ovom programu).",\r
"U poruci nedostaje potpis.",\r
"U poruci nedostaje sam zahtjev.",\r
"U posljednjih {0} h",\r
"U pregledaču nema foldera razmjene.",\r
"U pregledaču nema foldera razmjene. Fajl se uvozi ručno.",\r
"u redu",\r
"U redu",\r
"U redu za slanje: {0}.",\r
"u redu: {0}",\r
"U spisku nema kase sa kodom {0}.",\r
"U sumarni račun ulaze samo računi sa odloženim plaćanjem (i njihova storna).",\r
"u toku / prekinuto",\r
"U ugostiteljstvu je račun na ekranu vezan za sto: „Nalog\\" štampa kuhinji / šanku samo ono što još nije poslato i vraća sto na čekanje; pri plaćanju se izdaje običan fiskalni račun. Dugmad „Na čekanje\\" i „Čekanja\\" postaju „Na sto\\" i „Stolovi\\". Napomena uz stavku (✎) se štampa na nalogu.",\r
"U upotrebi",\r
"U Windowsu nije postavljen podrazumijevani štampač.",\r
"UBRUS",\r
"Učesnik školske ekskurzije",\r
"Učitaj paket",\r
"Učitaj paket iz fajla…",\r
"Učitaj ponovo",\r
"Učitaj u korpu",\r
"Učitano: {0} artikala ({1})",\r
"Učitano: {0} artikala, {1} barkodova{2}{3}",\r
"Učitavaju se cijene ovog mjesta ( ). Izdati računi se ne mijenjaju.",\r
"Učitavaju se cijene ovog mjesta ({0}). Izdati računi se ne mijenjaju.",\r
"Učitavanje cijena: {0}…",\r
"Učitavanje cijena…",\r
"Učitavanje fajla…",\r
"Učitavanje gostiju…",\r
"Učitavanje konobara sa kase…",\r
"Učitavanje paketa",\r
"Učitavanje računa…",\r
"Učitavanje stolova…",\r
"Učitavanje…",\r
"Ugostiteljstvo",\r
"Ugostiteljstvo (kafić, restoran)",\r
"Ugostiteljstvo (kafići, restorani)",\r
"Ugostiteljstvo (stolovi, nalog kuhinji)",\r
"ugrađena verzija",\r
"ugrađeni štampač Sunmi",\r
"Ugrađeni štampač Sunmi (servis proizvođača)",\r
"uid TEXT",\r
"uid, radnja, barkod, sifra, sa_sifre, naziv, komada, vrijeme, vrijeme_utc, ko, kasir_id, izvor, uredjaj, enu, svoja, upijena, ponistava",\r
"uid, sifra, naziv, jm, pdv_stopa, barkod, stara, cijena, mjesto, enu, pj, vrijeme, ko, izvor, uredjaj, svoja",\r
"Uklanjanja:",\r
"Uklanjanje sertifikata",\r
"Uklanjanje veze se ne poništava. Barkod se ponovo povezuje sa artiklom.",\r
"uključeno",\r
"Uključeno",\r
"Uključeno: kasa štampa isječak koji gost potpisuje.",\r
"Uključeno: kase u restoranu i baru upisuju potrošnju na račun sobe.",\r
"Uključeno: prati se i prijava lokalnoj turističkoj organizaciji.",\r
"Uključeno: rezervacija bez prijave dan poslije dolaska prelazi u „Gost nije došao\\".",\r
"Uključeno: taksa se ne obračunava po gostu.",\r
"Uključeno: taksa se oporezuje stopom smještaja.",\r
"Uključi QR meni na stolovima (ova kasa prima narudžbe svog mjesta)",\r
"Uključiti i promjene veće od 3×",\r
"Uključivanjem ove opcije program šalje u zajednički katalog barkodova: barkod, naziv artikla, jedinicu mjere i stopu PDV-a. Ne šalju se cijene, količine, dobavljači ni podaci o firmi. Poslati podaci služe svim korisnicima programa za prijedlog naziva pri unosu nepoznatog barkoda. Opcija se može isključiti u svakom trenutku; ranije poslati podaci ostaju u katalogu.",\r
"Ukloni",\r
"Ukloni barkod",\r
"Ukloni barkod {0}",\r
"Ukloni iz spiska",\r
"Ukloni PIN",\r
"Ukloni sertifikat",\r
"Ukloni sliku",\r
"Ukloniti {0} iz spiska?\\nUpisana pakovanja ostaju sačuvana.",\r
"Uklonjene stavke",\r
"uklonjeno prije naplate",\r
"Uklonjeno prije naplate",\r
"uklonjeno prije otpisa",\r
"Uklonjeno prije otpisa",\r
"uklonjeno prije predračuna",\r
"uklonjeno REAL",\r
"Uklonjeno sa stola {0}{1}.",\r
"Ukrajinski",\r
"Ukupno",\r
"UKUPNO",\r
"UKUPNO · popust {0}{1}",\r
"UKUPNO · popust nije ispravan",\r
"Ukupno PDV",\r
"Ukupno popusta",\r
"Ukupno za naplatu",\r
"ul",\r
"Ulazak u Crnu Goru",\r
"Ulazni PDV bez prava na odbitak (nabavke označene „bez prava na odbitak\\" + ručni dodatak)",\r
"Ulazni PDV na domaći promet proizvoda i usluga (fakture dobavljača + oprema/troškovi + zavisni)",\r
"Ulcinj",\r
"ULJE",\r
"Uloga",\r
"ULOSC",\r
"ULOŠC",\r
"UMAK",\r
"Umanjen iznos do",\r
"Umanjen iznos do (godina)",\r
"Umanjenje (%)",\r
"Umanjenje za goste do granice iznad.",\r
"Umanjenje: između 0 i 100 %",\r
"Umanjeno",\r
"Unesi barkodove",\r
"UNIMPLEMENTED",\r
"UNIONPAY",\r
"unos",\r
"Unos",\r
"Unos količine",\r
"Unos novog artikla se ne poništava. Artikal se može označiti kao „ne prodaje se više\\".",\r
"Unos objekta",\r
"Unos PIN-a",\r
"Unosi se iznos prebrojane gotovine.",\r
"UPALJAC",\r
"UPALJAČ",\r
"uparen",\r
"Uparen telefon „{0}\\".",\r
"uparena",\r
"uparena kasa",\r
"Uparena kasa i neposlate narudžbe se brišu sa telefona. Za ponovni rad potrebno je novo uparivanje QR kodom sa kase.",\r
"Upareni Bluetooth uređaji…",\r
"Upareni: {0}",\r
"Upari",\r
"Upari telefon…",\r
"Uparivanje nije uspjelo: QR kod nije sa ove kase.",\r
"Uparivanje sa kasom…",\r
"Uparivanje sa serverom",\r
"Uparivanje telefona konobara",\r
"UPC-A",\r
"upijena TEXT",\r
"Upis na disk nije moguć; podatak nije sačuvan. {0} Ponovni pokušaj je moguć za minut.",\r
"Upis na disk nije uspio; podatak nije sačuvan. ({0})",\r
"Upis na server čeka: {0}",\r
"Upis objekta…",\r
"Upis pakovanja artikla",\r
"Upis preostalog iznosa",\r
"Upis prethodnih dokumenata na server još čeka vezu. {0} kad se upis završi.",\r
"Upis računa na ekranu je u toku.",\r
"Upis računa na ekranu je u toku. Obrisani račun nije vraćen.",\r
"Upis računa na ekranu je u toku. Predračun nije učitan.",\r
"Upis računa…",\r
"Upis soba…",\r
"Upis u prijemni folder je prekinut.",\r
"Upisan je novi PIN, a označeno je i „Ukloni PIN\\". Dozvoljeno je jedno od ta dva.",\r
"Upisani kôd softvera pripada drugom proizvođaču. Potreban je kôd softvera ove kase.",\r
"Upisano gostiju: {0} od {1}.{2}",\r
"upisano ručno",\r
"Upisao: {0} · {1}{2}{3}",\r
"Upiši",\r
"Upiši depozit",\r
"Upiši podizanje",\r
"Upiši rezervaciju",\r
"Upišite cijenu noći.",\r
"Upišite ime i prezime gosta.",\r
"Upišite ime nosioca rezervacije.",\r
"Upišite isti domen ovdje i sačuvajte. Sertifikat (https) server pravi sam pri prvom otvaranju — do 1 minut.",\r
"Upišite iznos avansa.",\r
"Upišite naziv objekta.",\r
"Upišite naziv svake vrste sobe.",\r
"Upišite opis usluge.",\r
"Upišite oznake soba.",\r
"Upišite oznaku sobe.",\r
"Upišite razlog.",\r
"Upišite: {0}.",\r
"Upisuje se na stavku takse bez PDV-a.",\r
"Upit",\r
"Upit (ne zauzima sobu)",\r
"Upiti",\r
"Upiti, potvrđene, u objektu",\r
"Uplaćeni avans se vraća iz računa sobe (Vrati avans).",\r
"Uplaćeno",\r
"Uplata",\r
"Uplate",\r
"Upozorenja",\r
"Upozorenja vlasniku",\r
"Upozorenje pred istek roka (dana)",\r
"Upućen na banjsko ili klimatsko liječenje",\r
"Uređaj",\r
"Uređaj {0}:{1} ne odgovara.",\r
"Uređaj {0}:{1}: {2}",\r
"Uređaj će ponovo raditi kao kasa (izbor kase, računi).",\r
"Uređaj je zatvorio vezu.",\r
"Uređaji kase",\r
"USB (OTG kabl)",\r
"USB (OTG)",\r
"USB štampač (Android, OTG kabl)",\r
"using System; using System.Runtime.InteropServices;",\r
"Usitnjavanje / kusur",\r
"Usluga je dodata na račun sobe.",\r
"Usluge",\r
"Usluge (IT, agencije, konsalting, servisi, zakup)",\r
"uto",\r
"utorak",\r
"UUID poruke nije ispravan: „{0}\\".",\r
"Uvezi cijene / katalog iz fajla…",\r
"Uvezi izmjene cijena iz fajla…",\r
"Uvezi ključ (PEM)…",\r
"Uvezi podešavanja iz fajla (config.json)…",\r
"Uvezi sertifikat",\r
"Uvezi sertifikat (.pfx)…",\r
"Uvoz cijena / kataloga",\r
"Uvoz kataloga",\r
"Uz fiskalni račun br.",\r
"Uz fiskalni račun br. {0}",\r
"Uz jedinicu neto količine se upisuje i količina.",\r
"Uz neto količinu se bira i jedinica (JM neto).",\r
"Uz neto količinu se upisuje i jedinica (KG, G, L, ML, M ili KOM).",\r
"uz otpis",\r
"uz račun",\r
"Uz svaku stavku se upisuje količina koja se vraća (prazno = ne vraća se). Korektivni račun obuhvata samo vraćenu robu; popusti se računaju srazmjerno. Novac se vraća kako je plaćeno: virman → virmanom (bez gotovine iz kase), samo kartica → karticom, inače gotovinom.",\r
"VAFL",\r
"Vaga",\r
"vaga / interni",\r
"Vaga nije poslala težinu.",\r
"Vaga: {0}",\r
"Vaga: {0} kg (mirno).",\r
"Vaga: {0} kg = {1}",\r
"Valuta",\r
"Van fiskalnog računa (poseban red na štampi)",\r
"Van radnog vremena",\r
"Van upotrebe",\r
"VANILIN",\r
"VARIKIN",\r
"VAT",\r
"Važi do",\r
"važi do {0}",\r
"važi do {0}{1}",\r
"Važi kada cjenovnik nema period za taj dan.",\r
"Važi od",\r
"vazi_do TEXT",\r
"već {0} h",\r
"Već je izdat račun broj {0}. Brojač se ne može vratiti unazad.",\r
"Već je izdat račun broj {0}. Vraćanje brojača unazad nije moguće.",\r
"veća od 3× (označeno)",\r
"Vegan",\r
"VEGETA",\r
"Vegetarijansko",\r
"velika",\r
"Velika količina",\r
"Velika promjena: {0} → {1}. Za potvrdu: Sačuvaj (Enter) još jednom.",\r
"Veliki povrat",\r
"VELO",\r
"VERMUT",\r
"Verzija",\r
"verzija {0}",\r
"Verzija {0} je postavljena. Potrebno je zatvoriti i ponovo otvoriti kasu.",\r
"Verzija {0} je preuzeta i postavljena.",\r
"Verzija {0} je preuzeta i primjenjuje se pri sljedećem pokretanju.",\r
"Verzija {0} je preuzeta i primjenjuje se pri sljedećem pokretanju. Ponovno pokretanje: klik na oznaku.",\r
"Verzija {0} je preuzeta i provjerena.",\r
"Verzija {0} je preuzeta. Instalacija: klik na oznaku.",\r
"Verzija {0} je već preuzeta. Potrebno je zatvoriti i ponovo otvoriti kasu.",\r
"Verzija {0} se na ovoj kasi nije pokrenula",\r
"Verzija {0} se na ovoj kasi nije upalila, pa je vraćena prethodna. Javi se održavanju.",\r
"Verzija {0} traži instalaciju novog Setup-a{1}. Postavljanje iz programa nije moguće.",\r
"Verzija instalacije",\r
"Verzija instalacije kase nije poznata — ažuriranje nije moguće.",\r
"Verzija koja radi",\r
"Veza",\r
"Veza barkoda {0} je poništena.",\r
"Veza je mjerena (mobilni podaci).",\r
"Veza je prekinuta usred preuzimanja.",\r
"Veza je već poništena.",\r
"Veza nije pronađena.",\r
"Veza radi. Prijavljeni korisnik: {0}",\r
"Veza sa FZO",\r
"Veza sa FZO servisom nije podešena.",\r
"Veza sa FZO servisom nije podešena. Specifikaciju servisa i sertifikat dostavlja FZO ugovornoj apoteci.",\r
"Veza sa izdavačem",\r
"Veza sa serverom",\r
"Veza sa serverom je isključena.",\r
"Veza sa serverom je ponovo uspostavljena.",\r
"Veza sa serverom nije dostupna. Pokušava se ponovo.",\r
"Veza sa serverom nije podešena.",\r
"Veza sa serverom radi u instaliranoj kasi (Windows, Android), ne u pregledaču.",\r
"Veza sa terminalom je prekinuta prije odgovora.",\r
"Veza sa terminalom je prekinuta: {0}",\r
"Veza sa terminalom traži nov Setup kase (ljuska 2111).",\r
"Veza sa terminalom…",\r
"Veza sa uređajem je prekinuta.",\r
"Veza sa uređajem nije otvorena.",\r
"Veza sa uređajem traži novu verziju aplikacije.",\r
"Veza više ne postoji. Poništavanje nije moguće.",\r
"Vezu barkoda poništava samo šef. Potrebno je upisati šefa sa PIN-om (Podešavanja → Kasiri).",\r
"VICEROY",\r
"VILJAM",\r
"VILJAMOVKA",\r
"VINJAK",\r
"VINO",\r
"VIOLETA",\r
"Virman",\r
"Virman se ne može kombinovati sa drugim načinima plaćanja.",\r
"Virman se ne može kombinovati sa gotovinom ili karticom na istom računu. Potrebno je izdati dva računa.",\r
"Virman se ne može kombinovati sa gotovinom, karticom, bonom ili instant prenosom na istom računu.",\r
"VIRSL",\r
"VIRŠL",\r
"VISA",\r
"višak",\r
"Više",\r
"Više artikala ima ovaj barkod (izbor u spisku ispod).",\r
"Više artikala ima ovaj barkod. Artikal se bira u spisku.",\r
"Više načina plaćanja",\r
"Više načina plaćanja · virman · napomena…",\r
"Više nisu u katalogu: {0}",\r
"više od 3×",\r
"VISKI",\r
"Viza",\r
"Viza važi do",\r
"vjernost_naziv TEXT",\r
"vjernost_telefon TEXT",\r
"vlastita",\r
"VLAZNE MARAM",\r
"VLAŽNE MARAM",\r
"VOĆNI JOG",\r
"VODA",\r
"VODKA",\r
"VOGUE",\r
"VOTKA",\r
"Vraća se gostu",\r
"Vraćanje isteklih sniženja nije uspjelo: {0}",\r
"Vraćanje isteklih sniženja: {0}",\r
"Vraćanje na verziju {0} nije moguće. Baza podataka je već prilagođena verziji {1}, a starije verzije je ne mogu bezbjedno koristiti.",\r
"Vraćanje podataka artikala nije uspjelo: {0}",\r
"Vraćanje prethodne verzije",\r
"Vraćanje veza barkodova nije uspjelo: {0}",\r
"vraćen → račun",\r
"vraćen → račun{0}{1}",\r
"Vraćena je verzija",\r
"Vraćena je verzija {0}.",\r
"Vraćena je verzija {0}. Primjenjuje se pri sljedećem pokretanju programa.",\r
"Vraćena je verzija {0}. Primjenjuje se pri sljedećem pokretanju programa.{1}",\r
"vraćeno",\r
"Vraćeno",\r
"vraćeno {0}",\r
"vraćeno {0} izmj. šefa",\r
"Vraćeno {0} na karticu.",\r
"Vraćeno i naplaćeno:",\r
"vraceno TEXT",\r
"VRANAC",\r
"Vrati",\r
"Vrati avans",\r
"Vrati cijene",\r
"Vrati cijene iz posljednjeg paketa firme",\r
"Vrati na ekran",\r
"Vrati na ekran i naplati",\r
"Vrati na kasu",\r
"Vrati prethodnu verziju",\r
"Vrati sačuvano",\r
"Vrati u upotrebu",\r
"Vrati uređaj u režim kase",\r
"Vratiti verziju {0}? Podaci ostaju sačuvani. Promjena važi od ponovnog pokretanja programa.",\r
"VREĆA ZA",\r
"Vrijednost",\r
"Vrijednost boda (€)",\r
"Vrijednost bodova je veća od iznosa računa.",\r
"Vrijednost otpisane robe",\r
"Vrijednost promjene je obavezna (npr. 10 ili -5).",\r
"VRIJEDNOST ROBE",\r
"Vrijednost robe:",\r
"Vrijednost uklonjenog:",\r
"Vrijednosti za odobreno",\r
"Vrijednosti za odustalo",\r
"Vrijeme",\r
"vrijeme >= ?",\r
"Vrijeme događaja je ispred sata uređaja. Potrebno je provjeriti datum i vrijeme uređaja.",\r
"Vrijeme događaja nije čitljivo.",\r
"Vrijeme dolaska se upisuje sada; od njega teče rok za prijavu gostiju.",\r
"Vrijeme izdavanja avansnog računa nije ispravno.",\r
"Vrijeme izdavanja nije u obliku 2026-07-31T07:01:00+02:00 (dato: „{0}\\").",\r
"Vrijeme izdavanja računa je u budućnosti. Potrebno je provjeriti sat uređaja.",\r
"Vrijeme izdavanja računa nije čitljivo.",\r
"Vrijeme na računu je ispred sata uređaja. Potrebno je provjeriti datum i vrijeme uređaja.",\r
"Vrijeme na uređaju se razlikuje od vremena Poreske više od dozvoljenog (6 sati) ili je u budućnosti. Potrebno je podesiti tačan datum i vrijeme uređaja.",\r
"Vrijeme promjene depozita se razlikuje od vremena Poreske više od dozvoljenog. Potrebno je podesiti sat uređaja ili poslati prijavu kao naknadnu dostavu.",\r
"Vrijeme rezervacije nije ispravno (npr. 19:30).",\r
"Vrijeme slanja nije u obliku 2026-07-31T07:01:00+02:00 (dato: „{0}\\").",\r
"vrijeme_utc TEXT",\r
"vrijeme_z TEXT",\r
"Vrsta",\r
"Vrsta (iz Knjigovodstva)",\r
"Vrsta identifikacije mora biti TIN (PIB/JMB).",\r
"Vrsta isprave",\r
"Vrsta kase nije navedena u podacima iz Knjigovodstva.",\r
"Vrsta objekta",\r
"Vrsta recepta nije ispravna.",\r
"vrsta se bira",\r
"Vrsta slike nije ispravna.",\r
"Vrsta sobe",\r
"Vrsta terminala",\r
"Vrsta tijela zahtjeva nije podržana.",\r
"Vrsta vage",\r
"Vrsta vize",\r
"Vrste soba",\r
"Vrstu kase (market ili kiosk) određuje Knjigovodstvo (Cjenovnik kasa → Kase i marketi). Pogrešna vrsta se ispravlja u Knjigovodstvu; do tada je šef može promijeniti u Podešavanjima → Kasa.",\r
"warn",\r
"WC",\r
"WEBP",\r
"WELLNESS",\r
"WHERE {0}",\r
"WHERE aktivan=1",\r
"WHERE kod LIKE ?",\r
"WHERE svoja = 1",\r
"WHISK",\r
"WHISKEY",\r
"WHISKY",\r
"Windows",\r
"Windows ne može da otključa fajl tajne.json — zaključan je drugim Windows nalogom ili na drugom računaru",\r
"Windows štampač (sirovo)",\r
"Windows štampač postoji samo na Windowsu.",\r
"Windows trenutno ne može da otključa fajl tajne.json — šifrovanje nije dostupno",\r
"WINSTON",\r
"Wolt, Glovo, Telefon",\r
"Wolt, Glovo, telefon; narudžba kao sto sa brojem",\r
"YIPPY",\r
"Z (smjena zaključena)",\r
"Z bez otvorene smjene",\r
"Za „{0}\\" (red {1}) se može vratiti najviše {2} (na računu {3}, već vraćeno {4}).",\r
"Za „{0}\\" se može vratiti najviše {1}.",\r
"Za artikal {0} se može vratiti najviše {1} (na računu {2}, već vraćeno {3}).",\r
"Za čišćenje",\r
"Za direktnu štampu i fioku potreban je nov Setup kase (1.5).",\r
"Za instalaciju je potrebno odobriti instaliranje iz ovog programa (podešavanja telefona → Instaliranje nepoznatih aplikacija), zatim ponovo izabrati „Instaliraj sada\\".",\r
"Za izdavanje",\r
"Za kasu koja je ove godine radila u drugom programu upisuje se posljednji broj računa koji je taj program izdao; numeracija se nastavlja od njega.",\r
"Za kasu koja je ove godine radila u drugom programu upisuje se posljednji broj računa tog programa; numeracija se nastavlja od njega.",\r
"Za naplatu",\r
"Za naplatu: {0} EUR",\r
"Za obuku i probu, bez firme: artikli se dodaju ručno (⋯ Više → Artikli i cijene). Firma se povezuje kasnije u Podešavanjima → Kasa.",\r
"Za opštinu {0} iznos takse je {1} EUR.",\r
"za ovaj dan",\r
"Za ovaj dan nema rezervacija.",\r
"Za ovaj štampač kasa ne može da pročita stanje papira.",\r
"Za ovu vrstu terminala kasa ne šalje iznos (Podešavanja → Uređaji kase).",\r
"Za period dok svi uređaji firme (kase, Knjigovodstvo, Menadžer) nisu upareni sa serverom: kasa svoje fajlove piše i u folder, a cjenovnik i izmjene čita i iz njega. Kad su svi uređaji upareni, prelazni režim se isključuje i folder služi samo za rezervnu kopiju. Potreban je podešen folder.",\r
"Za plaćanje virmanom mora biti upisan kupac (PIB i naziv).",\r
"Za prijavu nedostaje: {0}.",\r
"Za račun na firmu; za virman je obavezan. Fizičko lice: JMBG ili broj isprave umjesto PIB-a.",\r
"Za razlog „Drugo\\" napomena je obavezna.",\r
"Za stavku „{0}\\" nedostaju podaci računa sa odloženim plaćanjem (izdat na drugoj kasi).",\r
"Za uvoz sertifikata potreban je PIB firme (Podešavanja → Fiskalizacija).",\r
"Za verziju {0} treba prvo instalirati novi Setup kase ({1} ili noviji). Na ovom računaru je Setup {2}. Podaci kase ostaju sačuvani.",\r
"Za verziju {0} treba prvo instalirati novi Setup kase{1}. Na ovom računaru je Setup {2}. Podaci kase ostaju sačuvani.",\r
"Za virman mora biti upisan kupac (PIB i naziv).",\r
"Za zamjenu je potreban pristanak pacijenta.",\r
"Žabljak",\r
"Zaboravi",\r
"Zaboravi kasu",\r
"Zaboravljen PIN",\r
"ZACIN",\r
"ZAČIN",\r
"Zadnja provjera",\r
"Zadnja razmjena",\r
"Zadnji",\r
"Zadnji računi",\r
"Zadržani avans se obračunava kao naknada za otkaz.",\r
"Zadržani dio je naknada za otkaz",\r
"zadržava artikle i cijene koji su sada u njoj",\r
"Zadrži",\r
"Zadrži za račun",\r
"Zaduženo",\r
"Zaduženo {0} EUR · uplaćeno {1} EUR · saldo {2} EUR",\r
"Zahtjev je ponovljen (odbijen).",\r
"Zahtjev je poslat izdavaču.",\r
"Zahtjev je prevelik.",\r
"Zahtjev je već potpisan.",\r
"Zahtjev lokalnom serveru traži https adresu i otisak CA.",\r
"Zahtjev nije ispravan.",\r
"Zahtjev nije poslat terminalu: {0}",\r
"zahtjev: {0}",\r
"Zahtjevi",\r
"Zahtjevi firme",\r
"Zahtjevi poslati sa ove kase",\r
"Zakazane cijene",\r
"Zakazane cijene iz cjenovnika nisu upisane: {0}",\r
"Zaključak",\r
"zaključak (Z)",\r
"Zaključak {0}",\r
"Zaključak dana (proba).",\r
"Zaključak dana je urađen na terminalu.",\r
"Zaključak dana na terminalu",\r
"Zaključak dana se radi na terminalu (Concert ga ne prenosi kasi).",\r
"Zaključak smjene (Z)",\r
"zaključan je lozinkom",\r
"Zaključci nisu upisani u folder: {0}",\r
"zaključena",\r
"Zaključena",\r
"Zaključi",\r
"Zaključi smjenu (Z)…",\r
"Zamijeni",\r
"Zamijeni katalog",\r
"Zamjena",\r
"Zamjena (privatni recept: samo ako propisanog nema i pacijent pristaje)",\r
"Zamjena je dozvoljena samo kad propisanog lijeka nema.",\r
"Zamjena je dozvoljena samo lijekom iste supstance, oblika i jačine.",\r
"Zamjena propisanog lijeka na teret FZO-a nije dozvoljena.",\r
"zamjena za",\r
"zamjena za {0}",\r
"ZAMRZNUT",\r
"Zaokruživanje",\r
"zapamćen do izbora kase",\r
"zapamćeni otisak nije otisak CA sertifikata",\r
"zapis {0} nije upisan ({1})",\r
"Zapis predračuna je nečitljiv.",\r
"Zapis sadrži stavke uklonjene sa računa. Ne mogu se vratiti na ekran kao račun.",\r
"zatečen pri zatvaranju kase",\r
"Zatvorena",\r
"Zatvori",\r
"Zatvori program",\r
"zauzet",\r
"Zauzeto (ostvareno)",\r
"Zbir",\r
"Zbir plaćanja ({0}) je manji od iznosa računa ({1}).",\r
"Zbir plaćanja ({0}) je veći od iznosa računa ({1}), a višak se ne može vratiti iz gotovine.",\r
"Zbir plaćanja ({0}) je veći od iznosa za naplatu ({1}).",\r
"Zbir plaćanja ({0}) nije dovoljan: nedostaje {1} EUR.",\r
"Zbir plaćanja ({0}) nije jednak iznosu avansa ({1}).",\r
"Zbir plaćanja ({0}) nije jednak iznosu računa ({1}).",\r
"Zbir plaćanja ({0}) nije jednak iznosu sumarnog računa ({1}).",\r
"Zbir plaćanja ({0}) nije jednak iznosu za naplatu ({1}).",\r
"Zbir prikazanih",\r
"Zbir računa je nula ili manji. Sumarni račun nije potreban.",\r
"ŽELE",\r
"ZEMICK",\r
"ZEMIČK",\r
"ženski",\r
"Zeta",\r
"ZEWA",\r
"ZILAVK",\r
"ŽILAVK",\r
"ZILET",\r
"ŽILET",\r
"ZIP iz više dijelova ili ZIP64",\r
"Žiro račun firme za instant",\r
"Žitarice sa glutenom",\r
"ZLATNA DUNJA",\r
"ZLATNA SLJIVA",\r
"ZLATNA ŠLJIVA",\r
"znak",\r
"Znak",\r
"Znak firme",\r
"Znak mora biti kvadratnog oblika (razlika stranica do 10 %).",\r
"Zona još nije prepoznata.",\r
"ZVAK",\r
"ŽVAK",\r
"ZYN",\r
"Objava nove verzije nije prošla provjeru potpisa izdavača. Ažuriranje nije preuzeto.",\r
"Objava nove verzije nema potpis izdavača. Ažuriranje nije preuzeto.",\r
"Podaci o važećim verzijama nisu prošli provjeru potpisa izdavača. Ažuriranje nije preuzeto.",\r
"Podaci o važećim verzijama su istekli, pa se ažuriranja trenutno ne mogu provjeriti. Provjera se ponavlja sama.",\r
"Verzija {0} je povučena. Čeka se sljedeća verzija.",\r
"Objavljena verzija {0} je starija od već objavljene verzije {1}. Ažuriranje nije preuzeto.",\r
"provjera ažuriranja",\r
"feed ažuriranja: objava nije ispravnog oblika",\r
"feed ažuriranja: potpis objave ne važi",\r
"feed ažuriranja: potpisana objava glasi na drugi program",\r
"feed ažuriranja: objava bez potpisa",\r
"feed ažuriranja: potpis stanja ne važi",\r
"feed ažuriranja: stanje glasi na drugi program",\r
"feed ažuriranja: stanje isteklo",\r
"feed ažuriranja: stanje starije od posljednjeg prihvaćenog",\r
"feed ažuriranja: objava bez stanja",\r
"feed ažuriranja: objava niža od ranije potpisane",\r
"· na početku ili kraju smjene",\r
"(posljednjih {0} od {1})",\r
"(računa:",\r
"{0}\\n\\nKupac mora imati {1} ili više godina. Datum rođenja sa isprave (nije obavezno):",\r
"{0} h · do roka od 48 sati: {1} h",\r
"{0}: {1} ({2} na 100 računa; ostali kasiri {3})",\r
"{0}: {1} ({2} na 100 računa)",\r
"🌙 Promet po radnom danu",\r
"📶 Rad bez interneta",\r
"🛡 Izuzeci po kasiru",\r
"Artikal nije dodat: po datumu rođenja kupac ima {0} godina.",\r
"Ažuriranje programa, podrška, e-recept Fonda",\r
"Bez interneta",\r
"Bon prodat na drugoj kasi važi ovdje tek kad stigne razmjena.",\r
"brisanja prije naplate",\r
"čeka vezu",\r
"Cijene, artikli, barkodovi, akcije",\r
"COALESCE(NULLIF(r.kasir, ''), '{0}')",\r
"Datum rođenja nije ispravan. Upisuje se kao dan.mjesec.godina, na primjer 15.03.2008.",\r
"Događaji",\r
"Događaji{0}",\r
"Drugi prozor na istom računaru.",\r
"Ekran za kupca",\r
"Fajlovi čekaju u redu i šalju se sami kad se veza vrati.",\r
"fioka bez računa",\r
"Fioka bez računa",\r
"Fioka otvorena bez računa — {0}",\r
"Gost naručuje preko interneta; narudžbe sa telefona konobara rade.",\r
"h · do roka od 48 sati:",\r
"Izdavanje računa (gotovina, kartica, virman)",\r
"Izdvojeno kasira:",\r
"Izuzeci po kasiru",\r
"Kalendarski dan",\r
"Kalendarski dan {0} (računa: {1})",\r
"Kasa prodaje i bez interneta: podaci su na uređaju, a ono što ide Poreskoj upravi i u kancelariju čeka u redu i šalje se samo kad se veza vrati.",\r
"Kasa radi bez veze onoliko dana koliko je upisano u licenci; poslije toga traži javljanje serveru.",\r
"Katalog je na kasi. Nove cijene iz kancelarije stižu kad se veza vrati.",\r
"Korektivni račun se izdaje na kasi i šalje naknadno, kao i svaki račun.",\r
"Najstariji čeka",\r
"Nema računa ni događaja u ovom periodu.",\r
"nije uključeno",\r
"Nijedan kasir ne odstupa od ostalih.",\r
"Od toga poslije ponoći (računa:",\r
"Od toga poslije ponoći (računa: {0})",\r
"Odbij prodaju",\r
"Odbijeno od Poreske uprave (traži pregled u Podešavanjima)",\r
"Plaćanje karticom na terminalu banke",\r
"Poklon-bonovi i bodovi vjernosti",\r
"Popusti (računa:",\r
"Popusti (računa: {0})",\r
"Poređenje",\r
"Povrat robe sa računa",\r
"Povrati",\r
"pregled za lokal koji radi poslije ponoći; samo šef",\r
"Pregled za lokal koji radi poslije ponoći: računi se sabiraju od početka radnog dana do istog časa sljedećeg dana. Datum računa, fiskalni podaci, smjene, zaključci (Z) i dnevni izvještaj se ne mijenjaju.",\r
"Prijava depozita Poreskoj upravi čeka u istom redu.",\r
"Promet po radnom danu",\r
"Provjera licence",\r
"Provjera starosti",\r
"Provjera starosti: prodaja nije potvrđena — {0}",\r
"QR meni na stolovima (narudžbe gostiju)",\r
"r.datum >= ? AND r.datum < ?",\r
"Račun dobija IKOF i QR kod na kasi; Poreskoj upravi se šalje naknadno.",\r
"Račun obrisan prije naplate",\r
"Računi čekaju u redu i šalju se sami kad se veza vrati; rok dostave je 48 sati od izdavanja.",\r
"Računi i prijave koji čekaju slanje Poreskoj upravi",\r
"Rade preko lokalne mreže lokala, bez interneta.",\r
"radi",\r
"Radni dan",\r
"Radni dan {0}: {1} – {2} {3}",\r
"Radni dan počinje u",\r
"Radni dan počinje u ponoć, pa je jednak kalendarskom danu.",\r
"Razmjena sa Knjigovodstvom i Menadžerom (zaključci, promet uživo, cijene)",\r
"ručni popusti: {0} % prometa",\r
"ručni popusti: {0} % prometa (ostali kasiri {1} %)",\r
"Slanje Poreskoj upravi",\r
"Slanje računa Poreskoj upravi",\r
"Smjena: depozit, podizanje, presjek (X), zaključak (Z)",\r
"šta kasa radi bez veze i šta trenutno čeka slanje",\r
"Štampa računa, etiketa i izvještaja",\r
"Štampač je vezan za kasu ili lokalnu mrežu.",\r
"Stanje sada",\r
"Starost",\r
"Starost: nije potvrđeno",\r
"Stavke uklonjene prije naplate",\r
"Stolovi, nalog kuhinji, telefoni konobara, ekran kuhinje",\r
"storna i povrati",\r
"storna i povrati na početku ili kraju smjene: {0}",\r
"Storna, povrati, brisanja prije naplate, fioka bez računa, ručni popusti i nepotvrđene provjere starosti, po kasiru koji je radnju uradio. Kasir je izdvojen kad ima najmanje tri takva događaja i dvostruko češće od ostalih kasira. Izdvajanje je znak za provjeru, ne dokaz.",\r
"storna, povrati, brisanja, fioka bez računa, ručni popusti i provjere starosti po kasiru; samo šef",\r
"Storna: {0}",\r
"Storno, povrat robe, „Poništi\\"",\r
"SUMMARY",\r
"Terminal ima svoju vezu; kasa samo bilježi način plaćanja.",\r
"Traže vezu; nastavljaju se kad se veza vrati.",\r
"traži vezu",\r
"Veza uređaja sa mrežom",\r
"nije obavezno",\r
"Plaćanje dobavljaču iz kase",\r
"Polog u banku",\r
"Predaja pazara",\r
"Sitan trošak",\r
"Sitniš / dopuna",\r
"Uz razlog „Drugo\\" napomena je obavezna.",\r
"Vraćanje podignutog novca",\r
"— izaberite razlog —",\r
"Artikal nije dodat: provjera starosti nije završena.",\r
"Datum je u budućnosti. Prikazan je i dalje {0}.",\r
"Period je skraćen na posljednjih {0} dana do izabranog datuma.",\r
"Provjera razmjene je u toku. Ishod će biti prikazan čim se završi.",\r
"Razlog nije izabran. Potrebno je izabrati razlog sa spiska.",\r
"Razmjena je provjerena.{0}",\r
"Sljedeći dan je u budućnosti.",\r
"Razmjena je provjerena.",\r
"; ispred: {0}",\r
"; koraci: {0}",\r
"{0} {1} ms",\r
"čekanje reda",\r
"Izdaj račun od 0,00 €",\r
"izvoz baze ({0} KB)",\r
"izvoz baze (rezervna kopija)",\r
"masovna izmjena + snimak",\r
"Novac se vraća gotovinom iz kase.",\r
"Novac se vraća na karticu (bez gotovine iz kase).",\r
"Novac se vraća virmanom (bez gotovine iz kase).",\r
"novi dnevnik",\r
"Obavještenje „{0}\\" je zatvoreno. Očitani artikal se dodaje na račun.",\r
"Obavještenje je zatvoreno. Očitani artikal se dodaje na račun.",\r
"Popust je jednak vrijednosti robe, pa je iznos računa 0,00 €.\\n\\nRačun bez iznosa se izdaje samo kad se roba zaista daje bez naplate. U suprotnom je potrebno ispraviti popust.",\r
"priprema upisa",\r
"provjera baze",\r
"Račun je plaćen na više načina. Cio iznos povrata se isplaćuje gotovinom iz kase.",\r
"Račun od 0,00 €",\r
"Račun od 0,00 € (popust jednak vrijednosti robe)",\r
"red dnevnika na disk",\r
"snimak baze",\r
"snimak baze (ako treba)",\r
"snimak baze (automatski)",\r
"snimak na disk",\r
"spor upis: {0} — čekao {1} ms, trajao {2} ms{3}{4}",\r
"upis (transakcija)",\r
"Uz svaku stavku se upisuje količina koja se vraća (prazno = ne vraća se). Korektivni račun obuhvata samo vraćenu robu; popusti se računaju srazmjerno.",\r
", probni sistem Poreske (TEST)",\r
", upisao {0}",\r
": šifre artikala „kesa\\" (zarezom) za mjesečni izvještaj o broju kesa, do 5. u mjesecu (Više → Plastične kese). Artikli u grupi „Plastične kese (naknada)\\" iz šifarnika se broje i bez upisa ovdje.",\r
". Presjek stanja (X) i dnevni / periodični izvještaj su u prozoru smjene i u pregledu računa.",\r
". Račun potpisan drugim (ranijim) sertifikatom ili na drugoj kasi daje drugačiji IKOF.",\r
". Računi ostaju (bez telefona i imena). Zapis u Knjigovodstvu briše Knjigovodstvo (zahtjev ide uz zaključke kase). Brisanje se ne može poništiti.",\r
". Vjernost se ne koristi dok kupac ponovo ne pristane.",\r
"· dana: {0}",\r
"· duvan bez popusta",\r
"· kod PJ",\r
"· korektivnih:",\r
"· objekat",\r
"· objekat {0} · operater {1}. Presjek stanja (X) i dnevni / periodični izvještaj su u prozoru smjene i u pregledu računa.",\r
"· operater",\r
"· ukupno",\r
"( ), verzija obavještenja",\r
"(odobrio {0})",\r
"(Uredba, Sl. list CG 1/26).",\r
"(Zakon o zaštiti podataka o ličnosti, Sl. list CG 133/26): vjernost se koristi uz zapisanu saglasnost kupca (obavještenje na ekranu i papiru); podaci kupca bez kupovine duže od roka se brišu sami, a računi ostaju. Pregled: Više → Kupci vjernosti — zaštita podataka.",\r
"{0} — komada",\r
"{0} Duvanski proizvodi u izboru: {1}{2}.",\r
"{0} Fiskalni računi se ne izdaju dok se ne uveze nov sertifikat (Podešavanja → Fiskalizacija → Uvezi sertifikat). Nov sertifikat izdaje ovlašćeni izdavalac na zahtjev firme.",\r
"{0} kom",\r
"{0} kom · {1}",\r
"{0} nije u obliku koji dodjeljuje Poreska uprava (ab123cd456).",\r
"{0} Račun nije izdat.",\r
"{0} Saglasnost {1} prije korišćenja vjernosti.",\r
"{0}: saglasnost je povučena {1}. Vjernost se ne koristi dok kupac ponovo ne da saglasnost.\\n\\nUpisati novu saglasnost?",\r
"📝 Dnevnik izmjena podešavanja",\r
"🔎 Provjera IKOF-a",\r
"🔐 Kupci vjernosti — zaštita podataka",\r
"🖨 Štampaj izvještaj",\r
"🖨 Štampaj obavještenje",\r
"🧾 Izvještaji za inspektora",\r
"🛍 Plastične kese",\r
"🛍 Plastične kese (naknada)",\r
"Adresa ažuriranja",\r
"apoteka.*",\r
"Artikal nije nađen u katalogu.",\r
"Artikli označeni kao plastična kesa",\r
"Automatsko ažuriranje",\r
"Bez gotovine.",\r
"Bez saglasnosti kupca vjernost se ne koristi.",\r
"brisanje (rok čuvanja)",\r
"brisanje na zahtjev",\r
"Brisanje podataka kupca odobrava šef PIN-om. PIN nije tačan.",\r
"Brisanje podataka kupca vjernosti",\r
"Brišu se saglasnost, bodovi i kupac vjernosti za broj",\r
"Broj komada po apoenu. Zbir ide u „Prebrojana gotovina\\", a specifikacija se čuva uz smjenu i štampa uz pazar.",\r
"Broj komada za {0} nije ispravan (cio broj, 0 ili više).",\r
"Broj računa (redni broj)",\r
"Broj računa (redni broj) mora biti cio broj veći od nule.",\r
"Brojanje gotovine po apoenima",\r
"Brojanje po apoenima, specifikacija uz pazar",\r
"čeka slanje Poreskoj",\r
"Cijena duvanskog proizvoda se na kasi ne mijenja: prodaje se po cijeni iz cjenovnika (Zakon o akcizama, čl. 50). Cijena se mijenja u Knjigovodstvu.",\r
"čl. 17",\r
"čl. 25",\r
"COALESCE(ko, '') <> '{0}'",\r
"date(r.datum) <= ?",\r
"date(r.datum) >= ?",\r
"Datum i vrijeme izdavanja",\r
"Datum i vrijeme izdavanja nisu ispravni (npr. 21.11.2026 10:15:30 ili kao u QR kodu).",\r
"DNEVNI ZBIROVI",\r
"Dnevnik izmjena podešavanja",\r
"ELEKTRONSKI ŽURNAL",\r
"elektronski žurnal, računi bez veze, korektivni računi, dnevni zbirovi; štampa i fajl (USB)",\r
"ENU",\r
"Evidencija zahtjeva",\r
"Fajl se čuva na izabrano mjesto (na Windowsu i na USB); na telefonu u Dokumenti/Kasa. Svaki izvještaj nosi kod ENU, kod PJ i operatera.",\r
"fiskal.*",\r
"Fiskalizacija isključena ({0}{1}){2}",\r
"Folder razmjene",\r
"Granica gotovine (€)",\r
"Greške izdavaču",\r
"IKOF JE ISTI kao na računu.",\r
"IKOF NIJE ISTI kao na računu.",\r
"IKOF sa računa (za poređenje)",\r
"Isključivanje fiskalizacije (PRODUKCIJA)",\r
"Isključivanje fiskalizacije u PRODUKCIJI traži PIN šefa i razlog (Zakon o fiskalizaciji, čl. 11). Isključivanje se bilježi i javlja vlasniku; računi izdati dok je fiskalizacija isključena nose natpis da nisu fiskalizovani.",\r
"Isključuje se:",\r
"istekao rok čuvanja neaktivnog kupca",\r
"Izmjena podešavanja: {0}",\r
"Iznos računa",\r
"Iznos stavke",\r
"Izračunaj IKOF",\r
"Izračunat IKOF",\r
"Izvještaj Agenciji za zaštitu životne sredine o broju kesa se predaje do {0} (Uredba, Sl. list CG 1/26).",\r
"Izvještaj je predat",\r
"Izvještaj o plastičnim kesama za {0}.{1}. se predaje do {2}.{3}.: {4} kom (naknada {5} €). Izvještaj: ⋯ Više → Plastične kese.",\r
"Izvještaj za {0}.{1}. je predat Agenciji?",\r
"izvoz podataka",\r
"izvoz podataka kupcu",\r
"kasa (automatski)",\r
"Kasa nema ključ za potpis (Podešavanja → Fiskalizacija).",\r
"Kasa radi u PRODUKCIJI. Isključivanje fiskalizacije se bilježi i javlja vlasniku; računi izdati dok je isključena nose natpis „RAČUN NIJE FISKALIZOVAN\\" i ne prijavljuju se Poreskoj upravi.",\r
"Kasa u PRODUKCIJI radi samo uz upisanog šefa sa PIN-om (Podešavanja → Kasiri).",\r
"ključ sertifikata za fiskalizaciju",\r
"ko, kada, staro → novo; samo šef",\r
"Kod ENU",\r
"Kod PJ",\r
"Kod softvera je ugrađen u program (Zakon o fiskalizaciji, čl. 15 st. 4) i ne upisuje se: PRODUKCIJA",\r
"kom ·",\r
"Kopija podataka (fajl)…",\r
"Kopija podataka je sačuvana: {0}",\r
"korektivni (povrat robe)",\r
"korektivni (storno)",\r
"Korektivni za",\r
"Korektivnih",\r
"Kupac PIB",\r
"Kupac vjernosti",\r
"Kupcu je dato obavještenje i kupac je saglasan sa obradom podataka za program vjernosti.",\r
"lower(COALESCE(a.grupa, '')) LIKE '%kes%naknad%'",\r
"lower(COALESCE(a.grupa, '')) LIKE '%plasti%kes%'",\r
"lower(COALESCE(a.podgrupa, '')) LIKE '%kes%naknad%'",\r
"lower(COALESCE(a.podgrupa, '')) LIKE '%plasti%kes%'",\r
"Mjesec nije ispravan.",\r
"mjesečni zbir komada po objektu, izvještaj do 5. u mjesecu",\r
"Na duvanske proizvode nije dozvoljen popust, akcija, bodovi ni poklon (Zakon o ograničavanju upotrebe duvanskih proizvoda, čl. 12).",\r
"Način saglasnosti nije poznat.",\r
"Naknada 0,05 € po kesi deblje od 50 µm (Uredba, Sl. list CG 1/26). Prodavac mjesečno izvještava Agenciju za zaštitu životne sredine o broju kesa, do 5. u mjesecu za prethodni mjesec. Kesa je artikal označen ispod (ili u grupi „Plastične kese (naknada)\\" iz šifarnika).",\r
"Napravljen",\r
"Naziv firme",\r
"Nema prometa u periodu.",\r
"Nema zapisanih izmjena.",\r
"nije fiskalizovan",\r
"nije fiskalizovan (probni režim)",\r
"Nijedan artikal nije označen.",\r
"Niz za potpis",\r
"Nova saglasnost",\r
"npr. 1001, 1002",\r
"npr. kvar, zamjena sertifikata",\r
"Obavještenje kupcu",\r
"Obavještenje o obradi podataka",\r
"Obrisani su podaci {0} kupaca vjernosti bez kupovine duže od {1} mjeseci (rok čuvanja, Podešavanja → Dodaci). Računi ostaju.",\r
"Obriši podatke",\r
"Obriši podatke kupca (šef)…",\r
"Od sada se vjernost (popust, bodovi) za ovaj broj ne koristi dok kupac ponovo ne da saglasnost. Podaci ostaju do brisanja ili isteka roka.",\r
"odbijen (Poreska)",\r
"odobrio {0}",\r
"osjetljivo = 1",\r
"Osnov oslobođenja",\r
"Osnov: saglasnost kupca. Saglasnost je dobrovoljna i može se povući u svakom trenutku, bez uticaja na kupovine prije povlačenja.",\r
"Označi kao kesu (šef)",\r
"PDV nije obračunat — {0} Zakona o PDV",\r
"PDV nije obračunat (stopa 0 %)",\r
"PIB (fiskalizacija)",\r
"PIB firme",\r
"PIB nije ispravan (8 cifara; za fizičko lice 13).",\r
"PIB poreskog obveznika",\r
"PIN šefa je obavezan.",\r
"PIN šefa nije tačan. {0}",\r
"PJ",\r
"Plaćanja",\r
"placeholder=\\"nije obavezno\\"",\r
"placeholder=\\"npr. 21.11.2026 10:15:30\\"",\r
"Plastične kese",\r
"Plastične kese (naknada)",\r
"Plastične kese (šifre)",\r
"Plastične kese {0}",\r
"Po apoenima…",\r
"Podaci koje o kupcu vjernosti čuva ova kasa (Zakon o zaštiti podataka o ličnosti, Sl. list CG 133/26, čl. 16 i 21).",\r
"Podaci kupca bez kupovine duže od {0} mjeseci se brišu sami (jednom dnevno). Sada takvih: {1}.",\r
"Podaci kupca su obrisani.",\r
"Podaci: broj telefona, ime (ako ga kupac da), kupovine u programu (datum, iznos, popust, bodovi).",\r
"Podešavanje",\r
"Poništavanje traži šefa",\r
"Poreska: SERTIFIKAT ISTEKAO",\r
"Potpis:",\r
"Potpis: {0}. Račun potpisan drugim (ranijim) sertifikatom ili na drugoj kasi daje drugačiji IKOF.",\r
"potpisan obrazac saglasnosti",\r
"potvrda kupca na ekranu kupca",\r
"povlačenje saglasnosti",\r
"Povlačenje saglasnosti",\r
"Povuci saglasnost",\r
"Prava kupca: pristup podacima i kopija podataka, ispravka, brisanje, ograničenje obrade, prenosivost i prigovor. Zahtjev se podnosi na kasi ili rukovaocu.",\r
"Prebrojano po apoenima: {0}. Štampati specifikaciju?",\r
"Predat je",\r
"Predato",\r
"prelazak sa PRODUKCIJE",\r
"prelazak sa PRODUKCIJE na TEST",\r
"Prigovor nadzornom organu: Agencija za zaštitu ličnih podataka i slobodan pristup informacijama.",\r
"prije korišćenja vjernosti.",\r
"probni ključ kase (bez sertifikata Poreske)",\r
"probni sistem Poreske (TEST)",\r
"Prodavac",\r
"Provjera godina",\r
"r.vrsta = 'storno'",\r
"RAČUN NIJE FISKALIZOVAN",\r
"Računi ostaju sačuvani po propisima o fiskalizaciji i računovodstvu; broj telefona i ime se poslije brisanja na njima ne vide.",\r
"Razlog / odobrio",\r
"Razlog je obavezan.",\r
"Rok čuvanja",\r
"Rok čuvanja neaktivnog kupca (mjeseci)",\r
"Rok čuvanja nije podešen (Podešavanja → Dodaci).",\r
"Rok čuvanja: dok traje saglasnost, a najduže {0} mjeseci od posljednje kupovine u programu.",\r
"Rok čuvanja: dok traje saglasnost.",\r
"Rok za izvještaj",\r
"rolna",\r
"Ručni popust bez šefa (%)",\r
"Rukovalac podacima: {0}.",\r
"Sačuvaj u fajl (CSV)…",\r
"Sačuvaj u fajl (JSON)…",\r
"Saglasan/na sam sa obradom podataka za program vjernosti.",\r
"Saglasnost",\r
"Saglasnost data",\r
"Saglasnost data {0} ({1}), verzija obavještenja {2}{3}.",\r
"Saglasnost je povučena",\r
"Saglasnost je povučena {0}. Vjernost se ne koristi dok kupac ponovo ne pristane.",\r
"Saglasnost je povučena.",\r
"Saglasnost je upisana.",\r
"Saglasnost je već povučena {0}.",\r
"Saglasnost kupca vjernosti",\r
"saglasnost, obavještenje, kopija podataka, brisanje na zahtjev",\r
"Šalji račune Poreskoj upravi (uklanjanje sertifikata)",\r
"samo osjetljive",\r
"se NE traži",\r
"se traži",\r
"Sertifikat za fiskalizaciju ističe {0} (još {1} {2}). Potrebno je na vrijeme pribaviti i uvesti nov sertifikat (Podešavanja → Fiskalizacija). Poslije isteka kasa ne izdaje fiskalne račune.",\r
"Sertifikat za fiskalizaciju je istekao {0}. Fiskalni računi se ne izdaju dok se ne uveze nov sertifikat (Podešavanja → Fiskalizacija → Uvezi sertifikat).",\r
"Sertifikat za fiskalizaciju je istekao {0}. Kasa ne izdaje fiskalne račune dok se ne uveze nov sertifikat (Podešavanja → Fiskalizacija → Uvezi sertifikat). Nov sertifikat izdaje ovlašćeni izdavalac (CoreIT) na zahtjev firme.",\r
"šifra ili barkod artikla",\r
"Šifre artikala „kesa\\"",\r
"Slijepo brojanje",\r
"Specifikacija gotovine",\r
"st.sifra IN ({0})",\r
"Štampa poslije naplate",\r
"Staro",\r
"Stopa PDV",\r
"Svaka izmjena podešavanja kase: ko, kada, staro → novo. Osjetljive izmjene (fiskalizacija, kodovi, granice popusta i upozorenja) idu i kao upozorenje vlasniku (Menadžer).",\r
"Svrha: program vjernosti — popust kupcu vjernosti i bodovi za kupovinu.",\r
"telefon kupca",\r
"U mjesecu nije prodata nijedna kesa.",\r
"U periodu nema takvih računa.",\r
"Ukupan iznos računa (€)",\r
"Ukupan iznos računa nije ispravan.",\r
"UKUPNO · popust {0}{1}{2}",\r
"Ukupno: {0}",\r
"Upisano.",\r
"Upiši saglasnost",\r
"Upiši saglasnost…",\r
"Upiši zbir",\r
"Upozorenje: brisanje (€)",\r
"Upozorenje: popust (%)",\r
"Upozorenje: razlika (€)",\r
"usmeno, poslije obavještenja na ekranu / papiru",\r
"Vjernost samo uz saglasnost kupca",\r
"Vjernost: rok čuvanja (mjeseci)",\r
"Vjernost: saglasnost obavezna",\r
"Vrijednost bodova je veća od iznosa robe na koju se daje popust (duvanski proizvodi su bez popusta i bodova).",\r
"Za ovaj broj nema upisane saglasnosti.",\r
"Za ovaj broj nema zapisa saglasnosti.",\r
"Za poreskog inspektora (Funkcionalna specifikacija fiskalizacije, „Verifikacija IKOF na ENU\\"): IKOF se ponovo računa iz parametara računa i digitalnog potpisa ove kase. Isti parametri uvijek daju isti IKOF.",\r
"za poreskog inspektora: IKOF iz parametara računa i poređenje sa računom",\r
"zahtjev kupca",\r
"Zakon o zaštiti podataka o ličnosti (Sl. list CG 133/26, od 19.03.2027): saglasnost koja se može dokazati, obavještenje kupcu, povlačenje saglasnosti, kopija podataka i brisanje na zahtjev. Računi ostaju; broj telefona i ime se na njima poslije brisanja ne vide.",\r
"Zakon o zaštiti podataka o ličnosti (Sl. list CG 133/26). Verzija obavještenja: {0}.",\r
"Zaštita podataka kupaca vjernosti",\r
"ŽURNAL KOREKTIVNIH RAČUNA",\r
"ŽURNAL RAČUNA IZDATIH BEZ VEZE",\r
"Grupa duvanskog proizvoda se na kasi ne mijenja (popust i cijena duvana su ograničeni zakonom). Grupa se mijenja u Knjigovodstvu.",\r
"— u roku od 5 dana (ZF čl. 18).",\r
": {0} {1} sa odloženim plaćanjem, ukupno",\r
": prodaja bona (Više → Poklon-bonovi) i plaćanje bonom (Više načina → Bon). Bon važi na svim kasama firme (razmjena preko servera). Prodaja bona je",\r
". Bezgotovinski račun koji se plaća kasnije (virman) nosi žiro račun firme i rok plaćanja.",\r
". Poreskoj ide sa oznakom BOUNDBOOK, u roku od 5 dana.",\r
"· slobodno",\r
"(ORDER). Naplata ide kasnije",\r
"(otpremnica kupcu-firmi, tura za sto) i",\r
"(porudžbina, ketering, rezervacija, usluga, veleprodaja) i plaćanje iz avansa;",\r
"(virman)",\r
"(Više → Fiskalni dokumenti → Zbirni račun).",\r
"(Više → Fiskalni dokumenti):",\r
"{0} se ne kombinuje sa drugim načinima plaćanja.",\r
"{0}: bon je jedna stavka po bonu (količina 1).",\r
"{0}: bon se izdaje avansnim računom ([FS] 5.8).",\r
"{0}: datum važenja bona nije u obliku 2026-12-31.",\r
"{0}: serijski broj bona „{1}\\" nije u obliku 12-2026-34567890.",\r
"⚠ Ispravka — račun u grešci…",\r
"🧾 Fiskalni dokumenti",\r
"ABW AFG AGO AIA ALA ALB AND ARE ARG ARM ASM ATA ATF ATG AUS AUT AZE BDI BEL BEN BES BFA BGD BGR BHR BHS BIH BLM BLR BLZ BMU BOL BRA BRB BRN BTN BVT BWA CAF CAN CCK CHE CHL CHN CIV CMR COD COG COK COL COM CPV CRI CUB CUW CXR CYM CYP CZE DEU DJI DMA DNK DOM DZA ECU EGY ERI ESH ESP EST ETH FIN FJI FLK FRA FRO FSM GAB GBR GEO GGY GHA GIB GIN GLP GMB GNB GNQ GRC GRD GRL GTM GUF GUM GUY HKG HMD HND HRV HTI HUN IDN IMN IND IOT IRL IRN IRQ ISL ISR ITA JAM JEY JOR JPN KAZ KEN KGZ KHM KIR KNA KOR KWT LAO LBN LBR LBY LCA LIE LKA LSO LTU LUX LVA MAC MAF MAR MCO MDA MDG MDV MEX MHL MKD MLI MLT MMR MNE MNG MNP MOZ MRT MSR MTQ MUS MWI MYS MYT NAM NCL NER NFK NGA NIC NIU NLD NOR NPL NRU NZL OMN PAK PAN PCN PER PHL PLW PNG POL PRI PRK PRT PRY PSE PYF QAT REU ROU RUS RWA SAU SDN SEN SGP SGS SHN SJM SLB SLE SLV SMR SOM SPM SRB SSD STP SUR SVK SVN SWE SWZ SXM SYC SYR TCA TCD TGO THA TJK TKL TKM TLS TON TTO TUN TUR TUV TWN TZA UGA UKR UMI RKS URY USA UZB VAT VCT VEN VGB VIR VNM VUT WLF WSM YEM ZAF ZMB ZWE",\r
"adv_iic TEXT",\r
"adv_vrijeme TEXT",\r
"ALB",\r
"Albanija",\r
"Artikal „nije promet u sistemu PDV\\"",\r
"Austrija",\r
"AUT",\r
"Avans i poklon-bon se ne koriste na istom računu. Potrebno je izdati dva računa.",\r
"Avans za porudžbinu, ketering, rezervaciju sale, uslugu ili isporuku robe. Na računu za robu avans se bira kao način plaćanja „Avans\\"; ostatak se plaća gotovinom, karticom ili virmanom.",\r
"Avansni račun je izdat: {0}.",\r
"Avansni račun se ne stornira ovdje. Avans se vraća kroz „Povrat avansa\\" (Više → Fiskalni dokumenti → Avansi).",\r
"avansni račun, povrat avansa, zbirni račun za odloženo plaćanje, umanjenje avansnih računa",\r
"Avansni računi",\r
"Avansni računi nisu uključeni (Podešavanja → Dodaci).",\r
"Bez kupca je potrebna oznaka (sto, porudžbina) po kojoj se pravi zbirni račun.",\r
"bez osnova (stopa 0)",\r
"bez oznake",\r
"bezgotovinske",\r
"Bezgotovinski i gotovinski računi sa odloženim plaćanjem ne idu u isti zbirni račun.",\r
"Bezgotovinski račun sa odloženim plaćanjem mora imati kupca (PIB i naziv).",\r
"Bezgotovinski računi sa odloženim plaćanjem se zbirno plaćaju virmanom.",\r
"BIH",\r
"Bjelorusija",\r
"BLR",\r
"Bon {0} nije na ovom avansnom računu.",\r
"Bon se koristi jednom (ostatak se gasi)",\r
"BON-",\r
"Bosna i Hercegovina",\r
"BOUNDBOOK",\r
"br. {0} · {1} · slobodno {2}",\r
"Br. soc. osig.",\r
"Broj iz knjige računa ima najviše 20 znakova.",\r
"Broj iz knjige računa je obavezan.",\r
"Broj kartice",\r
"broj kartice prodavca",\r
"Broj kupca",\r
"Broj računa iz knjige računa je obavezan.",\r
"Broj računa u knjizi",\r
"Broj socijalnog osiguranja",\r
"Čeka:",\r
"Čeka: {0}",\r
"Češka",\r
"CHE",\r
"CHN",\r
"COMPANY",\r
"Crna Gora",\r
"CZE",\r
"Datum i vrijeme iz knjige nisu ispravni (ne mogu biti u budućnosti).",\r
"Datum izdavanja",\r
"DEU",\r
"drzava TEXT",\r
"efi_naknadno TEXT",\r
"Fiskalni dokumenti",\r
"FRA",\r
"Francuska",\r
"GBR",\r
"h.dok = 'order'",\r
"h.rezervacija IS NULL",\r
"h.soba = ?",\r
"Holandija",\r
"HRV",\r
"Hrvatska",\r
"HUN",\r
"i prijavljena",\r
"IKOF avansnog računa nije ispravan (32 znaka, 0–9 i A–F).",\r
"ispravka (ERROR_CORRECTIVE)",\r
"Ispravka (ERROR_CORRECTIVE) se izdaje samo za račun prodaje.",\r
"Ispravka dokumenata avansa, odloženog i sumarnog plaćanja nije podržana na kasi.",\r
"Ispravka računa {0} (greška u naknadnoj provjeri)",\r
"Ispravka računa br. {0} je izdata{1}.",\r
"Ispravka računa u grešci",\r
"ispravka računa u grešci (ERROR_CORRECTIVE)",\r
"Ispravka računa u grešci (ERROR_CORRECTIVE)",\r
"Ispravka računa u grešci (ERROR_CORRECTIVE) se ne stornira. Ispravlja se nova ispravka na isti račun.",\r
"Ispravka računa u grešci se šalje Poreskoj, a kasa trenutno ne može da šalje: {0} Ispravka nije izdata.",\r
"Ispravka računa u grešci se šalje Poreskoj, a kasa trenutno ne može da šalje. Ispravka nije izdata.",\r
"Ispravka se ne može potpisati (nema ključa). Ispravka nije izdata.",\r
"ISR",\r
"ITA",\r
"Italija",\r
"Iz avansa se ne može platiti više od iznosa avansnog računa.",\r
"Iz knjige br. {0} · {1} (ukloni)",\r
"iz knjige računa",\r
"Iz knjige računa",\r
"Iz knjige računa br.",\r
"Izdaj ispravku",\r
"Izdaj zbirni račun ({0})",\r
"Iznos avansa (€)",\r
"Iznos koji se plaća iz avansa mora biti veći od nule.",\r
"Iznos povrata (slobodno {0})",\r
"Izrael",\r
"Kad kasa ili fiskalni servis ne radi, računi se izdaju rukom u",\r
"Kad se avans ili poklon-bon iskoristi na računu, avansni račun se umanjuje korektivnim računom (da PDV ne bude obračunat dvaput). Kasa to radi sama pri zaključku smjene.",\r
"Kad se avans ili poklon-bon iskoristi na računu, avansni račun se umanjuje korektivnim računom (da PDV ne bude obračunat dvaput). Kasa to radi sama pri zaključku smjene. {0}",\r
"kartica firme",\r
"Kartica firme",\r
"Kartica firme i ostala bezgotovinska plaćanja se ne kombinuju sa drugim načinima plaćanja na istom računu. Potrebno je izdati dva računa.",\r
"Kartica firme i ostala bezgotovinska plaćanja se ne mogu kombinovati sa gotovinom ili karticom na istom računu. Potrebno je izdati dva računa.",\r
"Kartica firme, kartica prodavca, ostalo bezgotovinsko",\r
"kartica prodavca",\r
"Kartica prodavca",\r
"Kina",\r
"Knjiga računa",\r
"knjiga_broj TEXT",\r
"knjigu računa",\r
"Korekcija avansnog računa bonova: zbir po bonovima nije jednak iznosu plaćenom bonovima.",\r
"Kosovo",\r
"Kupac — naziv",\r
"Kupac — PIB / JMB (za virman obavezno)",\r
"Kupac {0} plaća zbirni račun virmanom (bezgotovinski)",\r
"Kupac / oznaka",\r
"kupac_drzava TEXT",\r
"kupac_vrsta TEXT",\r
"Kupac: država „{0}\\" nije oznaka iz spiska (ISO 3166-1, tri slova, npr. MNE, SRB, DEU).",\r
"Kupac: nepoznata vrsta broja „{0}\\" (moguće: TIN, ID, PASS, VAT, TAX, SOC).",\r
"Kupac: PIB ima 8 cifara, a JMB 13 (dato: „{0}\\"). Za stranog kupca potrebno je izabrati državu i vrstu broja.",\r
"Kupac: PIB ima 8 cifara, a JMB 13. Za stranog kupca potrebno je izabrati državu i vrstu broja.",\r
"Lozinka sertifikata za bezgotovinske račune",\r
"Mađarska",\r
"MKD",\r
"Na avansnom računu je slobodno {0}.",\r
"Na jednom računu se mogu koristiti samo bonovi prodati istim računom (isti avansni račun). Potrebno je izdati dva računa.",\r
"Na jednom računu se mogu koristiti samo bonovi sa istog avansnog računa (prodati istim računom). Potrebno je izdati dva računa.",\r
"Na jednom računu se može koristiti najviše 20 bonova.",\r
"Na jednom računu se može koristiti samo jedna kartica prodavca.",\r
"Na jednom računu se može koristiti samo jedna kartica prodavca. Potrebno je izdati dva računa.",\r
"Na poklon-bon se ne daje popust: avansni račun glasi na nominalnu vrijednost bona.",\r
"Na računu: {0} (avansni račun). Bon se štampa poslije naplate.",\r
"Na stavci bona {0} je ostalo {1}, a korekcija je {2}.",\r
"nacin TEXT",\r
"Neki od izabranih računa više ne čeka zbirni račun (već je obuhvaćen ili storniran).",\r
"Nema avansnih računa.",\r
"Nema računa koji čekaju zbirni račun.",\r
"Nepoznat način plaćanja: „{0}\\" (moguće: Gotovina, Kartica, Virman, Bon, Instant, Kartica firme, Kartica prodavca, Ostalo bezgotovinsko).",\r
"Ništa ne čeka.",\r
"Njemačka",\r
"NLD",\r
"NOINTERNET",\r
"Nov avansni račun…",\r
"npr. 15/2026",\r
"npr. Avans — ketering 25.11.",\r
"npr. Sto 4",\r
"odloženo",\r
"odloženo plaćanje",\r
"Odloženo plaćanje — zbirni račun kasnije",\r
"Odloženo plaćanje i zbirni račun",\r
"Opis (za šta je avans)",\r
"Opis / kupac",\r
"ORDER",\r
"Osnov oslobođenja koji ide Poreskoj za artikal označen u Knjigovodstvu kao „nije promet u sistemu PDV\\". Potvrđuje knjigovođa.",\r
"ostalo bezgotovinsko",\r
"Ostalo bezgotovinsko",\r
"ovjerenu kod Poreske uprave. Ovdje se svaki takav račun unosi naknadno (iste stavke i plaćanje) i šalje Poreskoj sa oznakom",\r
"Ovo je ispravka računa u grešci. Povrat robe ide sa originalnog računa.",\r
"Oznaka (neobavezno)",\r
"Oznaka (sto, porudžbina)",\r
"PDV broj (strana firma)",\r
"pdv REAL",\r
"PIB / JMB",\r
"Plaćanje bonom ili iz avansa traži IKOF računa (fiskalizacija nije uključena ili nema sertifikata). Račun nije izdat.",\r
"Plaćanje bonom mora nositi IKOF avansnog računa kojim je bon izdat.",\r
"Plaćanje bonom mora nositi serijski broj bona.",\r
"Plaćanje karticom prodavca mora nositi broj kartice.",\r
"Plaćanje karticom prodavca: potrebno je upisati broj kartice.",\r
"Poklon-bon se ne unosi iz knjige računa.",\r
"Poklon-bon se plaća pri kupovini (avansni račun se izdaje za primljenu uplatu).",\r
"Poklon-bon se prodaje posebnim (avansnim) računom, bez druge robe na istom računu.",\r
"Poklon-bon se prodaje posebnim (avansnim) računom. Prvo je potrebno naplatiti ili ukloniti robu sa ekrana.",\r
"POL",\r
"Poljska",\r
"Poreski broj (strani)",\r
"Poseban sertifikat za",\r
"Poseban sertifikat za bezgotovinske račune",\r
"Potrebno je unijeti broj kartice prodavca.",\r
"Povrat avansa: {0}.",\r
"Povrat je od 0,01 do {0}.",\r
"prazno = žiro račun za instant",\r
"prodaja ({0} st.{1}){2}",\r
"prodaja podijeljena na {0} računa ({1} st.{2})",\r
"r.datum <= ?",\r
"r.datum >= ?",\r
"r.kupac_pib = ?",\r
"r.stornirao_uid IS NULL",\r
"r.vrsta = 'racun'",\r
"Račun br. {0} od {1}, {2}.\\n\\nIspravka se izdaje SAMO za račun koji je na portalu Poreske (SEP → Računi s greškom) označen greškom poslije naknadnih provjera. Šalje se isti račun (stavke, plaćanja, kupac) sa tačnim obračunom; promet i novac se ne mijenjaju. Rok: 8 dana od označavanja greške.{3}\\n\\nNapomena (neobavezno):",\r
"Račun ima {0} stavki, a Poreska prima najviše {1} na jednom računu (i najviše 150 kB). Automatski se dijeli samo račun plaćen jednim načinom, bez popusta na račun, vjernosti, bona, avansa i odloženog plaćanja. Potrebno je izdati više manjih računa.",\r
"Račun ima {0} stavki, a Poreska prima najviše {1}. Račun je potrebno podijeliti na više računa.",\r
"Račun ima više od 1000 stavki i izdat je kao {0} računa (ukupno {1}).",\r
"Račun iz knjige je stariji od 5 dana: rok za elektronsku dostavu (ZF čl. 18) je prošao. Račun se ipak unosi i šalje.",\r
"Račun iz knjige računa",\r
"Račun iz knjige računa je stariji od 30 dana. Unos nije moguć na kasi; potrebno je obratiti se Poreskoj upravi.",\r
"Račun iz knjige računa se šalje sa oznakom naknadne dostave BOUNDBOOK.",\r
"Račun iz knjige računa se unosi sa stvarnim načinom plaćanja.",\r
"Račun izdat rukom u knjigu računa (kasa ili fiskalni servis nije radio) unosi se na ekranu prodaje: stavke se otkucaju, pa",\r
"Račun je izdat prije {0} dana: rok od 8 dana je možda prošao.",\r
"Račun je storniran; ispravka nije potrebna.",\r
"Račun koji je SEP (Računi s greškom) označio greškom poslije naknadnih provjera",\r
"Račun nije fiskalizovan (nema JIKR). Ispravka se izdaje samo za račun koji je Poreska primila, a naknadna provjera označila greškom.",\r
"Račun sa odloženim plaćanjem se ne plaća iz avansa.",\r
"Račun se izdaje sada sa načinom plaćanja",\r
"računa",\r
"račune (virman, kartica firme, odloženo plaćanje firme): potpis ovlašćenog lica, dok gotovinske potpisuje pečat firme. Bez izbora jedan sertifikat važi za sve.",\r
"Računi sa odloženim plaćanjem (otpremnica kupcu-firmi, tura za sto) koji čekaju naplatu. Zbirni (sumarni) račun se izdaje jednom kupcu ili za jednu oznaku.",\r
"RKS",\r
"Rok plaćanja",\r
"Rok plaćanja (dana)",\r
"Rok plaćanja je od 0 do 365 dana.",\r
"Rok plaćanja ne može biti prije dana izdavanja računa.",\r
"Rok plaćanja nije ispravan datum.",\r
"Rok plaćanja virmanom (dana)",\r
"rok_dana INTEGER",\r
"rok_placanja TEXT",\r
"RUS",\r
"Rusija",\r
"Sa avansnog računa bonova se ne vraća dio. Stornira se cio račun (bonovi nisu korišćeni).",\r
"sa odloženim plaćanjem, ukupno",\r
"Sa računa je vraćen dio robe; ispravka nije moguća na kasi.",\r
"sa serijskim brojem svakog bona (FS v5, 3.5 i 5.8); plaćanje bonom ide Poreskoj kao „SVOUCHER\\" sa IKOF-om avansnog računa i brojem bona, a avansni račun se umanjuje za iskorišćeno pri zaključku smjene. Ovaj način",\r
"SAD",\r
"Serijski broj bona „{0}\\" nije u obliku 12-2026-34567890.",\r
"Sertifikat (bezgotovinski)",\r
"Sertifikat za bezgotovinske račune je uvezen{0}",\r
"Sertifikat za bezgotovinske račune se briše sa ove kase. Dok je uključen „Poseban sertifikat za bezgotovinske račune\\", kasa ne šalje račune Poreskoj.",\r
"Sjeverna Makedonija",\r
"Slovenija",\r
"SOC",\r
"SRB",\r
"Srbija",\r
"Stopa PDV-a budućeg prometa",\r
"Švajcarska",\r
"Švedska",\r
"SVN",\r
"SVOUCHER",\r
"SWE",\r
"TAX",\r
"tip_racuna TEXT",\r
"TUR",\r
"Turska",\r
"Ujedinjeno Kraljevstvo",\r
"Uključen je poseban sertifikat za bezgotovinske račune, a nije uvezen (Podešavanja → Fiskalizacija).",\r
"Ukloni taj sertifikat",\r
"UKR",\r
"Ukrajina",\r
"Umanjenje avansnih računa",\r
"umanjenje avansnih računa ({0})",\r
"Umanjenje avansnih računa nije urađeno za: {0}",\r
"Umanjenje avansnog računa — iskorišćen avans",\r
"Umanjenje avansnog računa — iskorišćeni poklon-bonovi",\r
"Umanjenje nije urađeno za: {0}",\r
"Umanjeno avansnih računa: {0}.",\r
"Umanji sada",\r
"Unos računa iz knjige računa…",\r
"USA",\r
"Uvezi sertifikat za bezgotovinske (.pfx)…",\r
"VAT_CL17 (podrazumijevano)",\r
"vd TEXT",\r
"Virman traži kupca: zbirni račun bez kupca se plaća gotovinom ili karticom.",\r
"Više načina plaćanja → Unos računa iz knjige računa",\r
"Vrijeme izdavanja (sat:minut)",\r
"Vrijeme izdavanja iz knjige računa je u budućnosti.",\r
"Vrijeme izdavanja iz knjige računa nije ispravno (datum i sat).",\r
"Vrijeme je potrebno upisati kao sat:minut, npr. 14:30.",\r
"Vrsta broja",\r
"vrsta_avansa TEXT",\r
"vrsta_id TEXT",\r
"vsn TEXT",\r
"Za karticu firme mora biti upisan kupac (PIB i naziv firme).",\r
"Za ovaj račun je već izdata ispravka.",\r
"za period; načini plaćanja",\r
"Za plaćanje karticom firme mora biti upisan kupac (PIB i naziv firme).",\r
"Za zbirni račun nije izabran nijedan račun sa odloženim plaćanjem.",\r
"zbirni račun",\r
"Zbirni račun",\r
"Zbirni račun bez kupca obuhvata račune iste oznake (sto, porudžbina).",\r
"Zbirni račun je izdat: {0}.",\r
"Zbirni račun kasnije (otpremnica, tura)…",\r
"Zbirni račun se izdaje jednom kupcu: izabrani računi glase na različite kupce.",\r
"Zbirni račun…",\r
"Zbirni računi nisu uključeni (Podešavanja → Dodaci).",\r
"zbirnim računom",\r
"Žiro račun firme (virman)",\r
"ziro_racun TEXT",\r
"— POZIV",\r
", izvor {0}",\r
"; kurs koji čeka poziv nije poslat",\r
"· izabrano {0}",\r
"· povrat",\r
"„{0}\\": podgrupa {1} ne postoji.",\r
"„{0}\\": stopa PDV-a {1} nije 21, 15, 7 ili 0 — važi podrazumijevana stopa kase.",\r
"„Često uz ovo\\" iz prodaje ove kase (kasa i telefon konobara)",\r
"(dodaci: {0} upozorenja)",\r
"(podešava se u „Ugostiteljstvo — napredno\\").",\r
"(rezervacija ima avans)",\r
"(sa dodacima)",\r
"{0} · PDV {1}% · dodatak uz jelo",\r
"{0} (odobrio: {1})",\r
"{0}: „{1}\\" je izabrano dvaput.",\r
"{0}: {1} (odobrio {2})",\r
"{0}: dokument {1} je izdat.",\r
"{0}: izbor je obavezan.",\r
"{0}: najviše {1} {2}.",\r
"{0}: nepoznat izbor „{1}\\".",\r
"{0}: potrebno je izabrati najmanje {1}.",\r
"{0}{1} · {2} st.{3}{4}{5}",\r
"{0}{1} (na stolu {2})",\r
"{0}najviše {1}",\r
"{0}Stavka ide na stanicu svoje šifre, podgrupe ili grupe; ostalo na podrazumijevanu.",\r
"% · dodatak uz jelo",\r
"+ {0} dodaci",\r
"+ Stanica",\r
"▶ Pozovi kurs:",\r
"▶ Pozovi kurs: {0}",\r
"▶ Pozovi:",\r
"▶ Pozovi: {0}",\r
"⚙ Ugostiteljstvo — napredno",\r
"🍷 Reprezentacija / na kuću / obrok osoblja",\r
"👤 Pazar po konobaru",\r
"🖨 Štampaj (Bluetooth)",\r
"🧑‍🍳 Kuhinja{0}",\r
"1 (isti stiže i paketom iz Knjigovodstva / Menadžera; opis: docs/nove-funkcije/ugostiteljstvo-2.md). Sada:",\r
"Alergeni",\r
"Alergeni iz QR menija: {0} artikala.",\r
"Alergeni po artiklu",\r
"Aleva paprika",\r
"Artikla {0} nema u katalogu kase.",\r
"avans_uid TEXT",\r
"bez kursa",\r
"Bez kursa",\r
"Bez luka",\r
"bez obračuna PDV-a",\r
"bez PDV-a",\r
"Bluetooth štampač",\r
"Broj gostiju za jednake dijelove: od 2 do 30.",\r
"čeka poziv",\r
"Često uz",\r
"Često uz {0}:",\r
"Često uz to:",\r
"Definicija dodataka nije ispravan JSON.",\r
"Definicija dodataka nije u očekivanom obliku.",\r
"Desert",\r
"dio",\r
"do {0}",\r
"Dobro pečeno",\r
"DOD-{0}-{1}",\r
"Dodaci",\r
"Dodaci jelima",\r
"Dodaci jelu",\r
"Dodaci jelu (pečenje, prilog, sir…)",\r
"Dodaj{0}",\r
"Dodatak „{0}\\" nije u katalogu kase (šifra {1}). Definiciju dodataka je potrebno provjeriti.",\r
"Dodatak se mijenja preko jela (dodir na tekst dodataka ispod naziva jela).",\r
"Dodatak se skida zajedno sa jelom (ili se jelo skida i naručuje ponovo sa drugim dodacima).",\r
"Duguje",\r
"Ekran",\r
"Ekran kuhinje",\r
"Fiskalni račun izdaje glavna kasa.",\r
"Fiskalni račun izdaje glavna kasa.{0}",\r
"Format",\r
"Format {0} 1 (isti stiže i paketom iz Knjigovodstva / Menadžera; opis: docs/nove-funkcije/ugostiteljstvo-2.md). Sada: {1} grupa{2}.",\r
"Gdje se štampa račun?",\r
"Glavno jelo",\r
"gost, povod, ime radnika",\r
"Gosti su stigli",\r
"Gosti su stigli — {0}",\r
"gotova",\r
"Gotovo za ovu stavku",\r
"Grilovano povrće",\r
"Grupa „{0}\\" je navedena dvaput; važi prva.",\r
"Grupa „{0}\\" nema nijednu opciju i preskočena je.",\r
"Grupa „{0}\\": opcija „{1}\\" je navedena dvaput; važi prva.",\r
"Grupa „{0}\\": opcija bez naziva je preskočena.",\r
"Grupa bez oznake ili naziva je preskočena.",\r
"Grupe / podgrupe (zarezom)",\r
"IKOF: {0}",\r
"ili: jednaki dijelovi (broj gostiju)",\r
"Interni dokument",\r
"Interni dokument odobrava šef.",\r
"Interni dokumenti nisu uključeni (Podešavanja → Ugostiteljstvo).",\r
"Interni dokumenti nisu uključeni (Ugostiteljstvo — napredno).",\r
"Interni dokumenti uključeni (odobrava šef)",\r
"interno TEXT",\r
"Ispravno: {0} grupa.",\r
"izbor",\r
"Izbor „{0}\\" ne pripada dodacima ovog artikla.",\r
"izbora",\r
"Izdaj dokument",\r
"Iznos predaje nije ispravan.",\r
"Iznos stola {0} je {1} €. Potrebno je osvježiti sto i ponoviti naplatu.",\r
"JIKR: {0}",\r
"Kasa nije potvrdila naplatu (veza). Naplatu je potrebno ponoviti istim zahtjevom.",\r
"Kašnjenje (crveno) poslije minuta",\r
"kgs",\r
"Količina prati jelo",\r
"Količina svake stavke koju plaća ovaj gost ostaje na ekranu za naplatu; ostatak se vraća na sto. Dio stavke: npr. 0,5 = pola pice. Dodaci jelu idu uz jelo. Za jednake dijelove upisuje se broj gostiju (stavke se tada ne upisuju).",\r
"Konobar",\r
"konobar bira",\r
"Konobar je obavezan.",\r
"Konobar koji je služio sto (račun stola) ili kasir koji je izdao račun. „Predato\\" = gotovina koju je konobar predao; „duguje\\" = gotovina naplaćena za stolom koja još nije predata.",\r
"Konobar naplaćuje sa telefona (račun izdaje ova kasa)",\r
"konobar TEXT",\r
"Konobari",\r
"Krvavo",\r
"Kurs",\r
"Kurs (predjelo, glavno, desert)",\r
"Kurs {0}",\r
"Kurs 2 i dalje čeka „Pozovi sljedeći kurs\\"",\r
"Kurs 4",\r
"Kurs 5",\r
"kurs čeka poziv",\r
"Kurs nije ispravan.",\r
"Kurs po grupi artikla",\r
"Kursevi (predjelo, glavno jelo, desert)",\r
"Kursevi uključeni",\r
"kursevi, stanice štampe, ekran kuhinje, dodaci jelu, alergeni, naplata sa telefona; samo šef",\r
"MAC adresa nije ispravna.",\r
"MAC adresa štampača telefona (npr. 00:11:22:33:44:55).",\r
"MAC adresa štampača telefona.",\r
"mekušci",\r
"Na ekranu je 1/{0} računa stola za naplatu; ostatak ({1} {2}) je na stolu {3}. Za sljedećeg gosta: jednaki dijelovi na {4}.",\r
"Na ekranu je račun. Potrebno ga je prvo vratiti na sto ili naplatiti.",\r
"Na ekranu nema stavki.",\r
"Na kasi",\r
"na ovoj kasi",\r
"Na račun kuće („na kuću\\")",\r
"na štampaču telefona (Bluetooth)",\r
"Na stolu {0} ima stavki koje nisu poslate kuhinji / šanku. Potrebno je poslati nalog ili potvrditi naplatu bez toga.",\r
"Na stolu {0} nema zadržanog kursa.",\r
"Na stolu nema kursa koji čeka poziv.",\r
"Na telefonu",\r
"Način plaćanja nije ispravan (gotovina ili kartica).",\r
"najmanje {0},",\r
"najmanje {0}, najviše {1}",\r
"Nalog {0} je poslat ({1} {2}){3}. Sto {4} je na čekanju.",\r
"Nalog nije odštampan; kurs nije pozvan. Potrebno je provjeriti štampač.",\r
"Nalog više ne postoji.",\r
"Nalozi sa kase i telefona konobara. „Gotovo\\" (cio nalog ili stavka po stavka) javlja konobaru da je spremno. Tablet u kuhinji: Android aplikacija u režimu „Kuhinja\\" (uparuje se kao telefon konobara).",\r
"Naplaćeno.",\r
"Naplata",\r
"Naplata — čeka se kasa…",\r
"Naplata — sto {0}",\r
"Naplata {0} nije potvrđena od kase.",\r
"Naplata nije potvrđena od kase. Prije odustajanja je potrebno provjeriti na kasi da račun nije izdat.",\r
"Naplata nije urađena.",\r
"Naplata sa telefona nije uključena na kasi (Podešavanja → Ugostiteljstvo).",\r
"Naplati i bez toga",\r
"Neposlate stavke",\r
"Nepoznat format „{0}\\" (očekuje se {1}).",\r
"nije potvrđena od kase.",\r
"nova tura{0}",\r
"Nove stavke su u kursu koji čeka poziv („Pozovi kurs\\" u pregledu stolova).",\r
"npr. bez soli",\r
"obavezno",\r
"Obrok osoblja",\r
"od toga otvoreni stolovi ( )",\r
"od toga otvoreni stolovi ({0})",\r
"Odobrio (šef)",\r
"Odustani od naplate",\r
"opis TEXT",\r
"orašasti",\r
"Otvorena smjena",\r
"Otvori sto",\r
"Papir",\r
"Pazar po konobaru",\r
"PDV iz prodajne cijene (konzervativno)",\r
"PDV se obračunava iz prodajne cijene",\r
"PDV tretman",\r
"Pečenje",\r
"Pice",\r
"Pomfrit",\r
"Ponovi (isti zahtjev)",\r
"popust",\r
"Potrebno je upisati ko je odobrio.",\r
"Pozvan kurs „{0}\\" (nalog {1}). Sto {2} je na čekanju.",\r
"prazno = po stavkama",\r
"Predaja je upisana.",\r
"Predaja novca — {0}",\r
"predaja novca konobara",\r
"Predaja…",\r
"Predaje",\r
"Predjela:1; Glavna jela:2; Deserti:3",\r
"Predjelo",\r
"Preuzmi iz QR menija",\r
"Prijedlozi",\r
"Prilog",\r
"Primio",\r
"Primjer",\r
"Primljeni iznos je manji od iznosa računa.",\r
"Primljeno {0} · povrat {1}",\r
"Primljeno od gosta (gotovina, neobavezno)",\r
"promet, gotovina i kartica po konobaru; predaja novca; samo šef",\r
"QR računa (Poreska uprava) — gost ga skenira telefonom.",\r
"račun izdat",\r
"Račun je odštampan na kasi.",\r
"Račun je odštampan na štampaču telefona.",\r
"Račun naplaćen sa telefona se štampa",\r
"Račun nema QR kod (probni rad).",\r
"Račun nije izdat: {0} Sto je vraćen.",\r
"Račun NIJE odštampan na kasi — potrebno je provjeriti štampač.",\r
"Račun se štampa na kasi.",\r
"Račun se štampa na štampaču telefona.",\r
"Račun stola nosi kod operatera konobara koji je služio sto (kad konobar ima svoj kod)",\r
"Razlog je obavezan (npr. gost, povod, ime radnika).",\r
"Red po artiklu: „šifra: brojevi\\" (1–14:",\r
"Red po artiklu: „šifra: brojevi\\" (1–14: {0}).",\r
"Reprezentacija",\r
"Reprezentacija / na kuću / obrok osoblja",\r
"Reprezentacija, „na kuću\\", obrok osoblja",\r
"Rezervacija ne postoji.",\r
"roba sa ekrana bez naplate, uz razlog i odobrenje šefa",\r
"Roba sa ekrana se skida sa stanja bez naplate. Dokument nije fiskalni račun; vidi se u izvještajima i zaključku za Knjigovodstvo odvojeno od prodaje i otpisa. PDV tretman:",\r
"Roba sa ekrana se skida sa stanja bez naplate. Dokument nije fiskalni račun; vidi se u izvještajima i zaključku za Knjigovodstvo odvojeno od prodaje i otpisa. PDV tretman: {0} (podešava se u „Ugostiteljstvo — napredno\\").",\r
"Roštilj",\r
"Sada važi raspored iz osnovnih podešavanja (kuhinja + šank). Izmjena ovdje ga zamjenjuje.",\r
"Šifre",\r
"Sir",\r
"smjena_id = ?",\r
"So",\r
"Srednje pečeno",\r
"Štampa na telefonu nije uspjela: {0}",\r
"Štampa računa",\r
"Štampač nije podešen.",\r
"Štampač telefona je sačuvan.",\r
"Štampač telefona je uklonjen.",\r
"Stanice štampe (kuhinja, šank, roštilj, pica, desert…)",\r
"Stavka ide na stanicu svoje šifre, podgrupe ili grupe; ostalo na podrazumijevanu.",\r
"Stavka naloga ne postoji.",\r
"Sto {0} je trenutno otvoren na kasi. Naplata je moguća kad kasir vrati sto.",\r
"Sto {0} nema otvoren račun (možda je već naplaćen).",\r
"Sto {0}: gosti {1}{2}.",\r
"Sto {0}: kurs „{1}\\" čeka poziv.",\r
"Sto {0}: kurs „{1}\\" ide odmah.",\r
"Sto {0}: naplaćeno sa telefona ({1}), {2} {3} €.",\r
"Sto {0}: pozvan kurs „{1}\\".",\r
"Sto {0}: račun {1} izdat ({2}, {3} €).{4}",\r
"Šunka",\r
"Sve stanice",\r
"Tretman PDV-a potvrđuje knjigovođa; zaključak za Knjigovodstvo nosi vrstu, razlog, ko je odobrio i PDV po stopama.",\r
"Ugostiteljstvo — napredno",\r
"Ugostiteljstvo — sačuvano{0}.",\r
"Upiši predaju",\r
"Upozorenje (žuto) poslije minuta",\r
"upozori",\r
"uz_red INTEGER",\r
"Verzija {0} nije podržana; čita se kao verzija 1.",\r
"vrijeme >= ? AND vrijeme <= ?",\r
"Vrsta internog dokumenta nije ispravna.",\r
"Začin za pomfrit",\r
"{0} · {1} os.",\r
"gosti: {0}",\r
"rez. {0}",\r
"za plaćanje",\r
"· rezervacija stola",\r
"(br. {0})",\r
"15 % (hrana, usluživanje)",\r
"Avans — rezervacija {0}",\r
"Avans — rezervacija {0}, {1}.{2}. {3}",\r
"avans {0}",\r
"Avansni račun za rezervaciju je izdat{0}.",\r
"br. {0} · {1} · slobodno {2}{3}",\r
"Izdaje se avansni račun (fiskalni). Pri naplati stola iznos se odbija kroz „Više načina plaćanja → Avans\\".",\r
"Iznos avansa je obavezan.",\r
"Plaćeno",\r
"Rezervacija već ima avans.",\r
"Sto {0} ima avans rezervacije. Naplata je na kasi (plaćanje iz avansa).",\r
"Stopa PDV-a",\r
"; kopija računa kupcu nije uključena",\r
"; kopija računa kupcu: da",\r
"(ENU {0})",\r
"(kad kasa dobije vezu sa serverom)",\r
"(kupac vjernosti) | pib:",\r
"(nema podataka)",\r
"(odobr. {0})",\r
"(PDF) e-poštom poslije naplate; papirni račun se izdaje kao i do sada. Bez veze sa serverom kopija čeka i šalje se kasnije.",\r
"{0} · kasa {1}",\r
"{0} {1} {2} {3} re",\r
"{0} artikala",\r
"{0} rg {1} {2} {3} {4} re f",\r
"{0} RG {1} w {2} {3} m {4} {5} l S",\r
"{0}, {1} (kasa {2}). Izvještaj je u prilogu (PDF i Excel).",\r
"<?xml version=\\"1.0\\" encoding=\\"UTF-8\\" standalone=\\"yes\\"?>",\r
"<< /Title {0} /Producer (IRIS CORVINA){1} /CreationDate ({2}) >>",\r
"<< /Type /Catalog /Pages 2 0 R >>",\r
"<< /Type /Encoding /BaseEncoding /WinAnsiEncoding /Differences [{0}] >>",\r
"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding 5 0 R >>",\r
"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding 5 0 R >>",\r
"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {0} {1}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {2} 0 R >>",\r
"<< /Type /Pages /Kids [{0}] /Count {1} >>",\r
"✉ {0} (ukloni)",\r
"✉ E-pošta{0}",\r
"✉ E-poštom",\r
"✉ Pošalji kopiju računa e-poštom…",\r
"Adresa e-pošte nije ispravna (npr. ime@primjer.me).",\r
"Adresa e-pošte nije ispravna.",\r
"Adrese su u podešavanju pošte firme (Menadžer); kasa ne bira adresu.",\r
"akcija: {0}, popust",\r
"BT {0} rg /{1} {2} Tf {3} {4} Td ({5}) Tj ET",\r
"BT {0} rg /F1 7.5 Tf {1} {2} Td ({3}) Tj ET",\r
"Cacute",\r
"Ccaron",\r
"Čeka potvrdu Poreske uprave (JIKR).",\r
"čeka: {0}",\r
"Dcroat",\r
"E-pošta kase",\r
"E-pošta kupca",\r
"E-pošta nije dostupna na ovoj kasi.",\r
"E-pošta: {0} pismo nije poslato (Više → E-pošta).",\r
"E-račun",\r
"Elektronska kopija računa",\r
"ELEKTRONSKA KOPIJA RAČUNA — original je papirni račun izdat na kasi.",\r
"Excel",\r
"Excel tabela je sačuvana:",\r
"FEFF",\r
"FISKALNI RAČUN",\r
"Izabrati vlasnika ili knjigovođu.",\r
"izvještaj",\r
"Izvještaj je u redu za slanje e-poštom.",\r
"Kasa {0} · {1}{2}",\r
"Kasa nije uparena sa serverom — pisma čekaju.",\r
"Kasa nije uparena sa serverom IRIS CORVINA — izvještaj se može sačuvati kao fajl.",\r
"knjigovođi",\r
"Kome",\r
"kopija računa",\r
"Kopija računa ide na {0}{1}.",\r
"kopije računa kupcima i izvještaji vlasniku/knjigovođi; stanje slanja",\r
"kopiju računa",\r
"KUPAC",\r
"Kupac dobija",\r
"Međuzbir (bez popusta na račun)",\r
"Način saglasnosti",\r
"Naplaćeni promet",\r
"Nema artikala za izvoz.",\r
"Nema pisama.",\r
"Nema tabele za izvoz.",\r
"Obavještenje kupcu (pamćenje adrese)",\r
"Osnov: saglasnost kupca. Saglasnost je dobrovoljna i može se povući u svakom trenutku; tada se adresa briše.",\r
"Otpis po artiklima",\r
"Otpis robe (nije promet)",\r
"PDF",\r
"PDF je sačuvan:",\r
"PDV {0} (osn. {1})",\r
"pib:",\r
"Po načinu plaćanja",\r
"Podaci: adresa e-pošte, uz broj telefona kupca vjernosti ili PIB kupca-firme.",\r
"Ponovi",\r
"Popust na račun {0}",\r
"Poruka (neobavezno)",\r
"Pošalji izvještaj e-poštom",\r
"Pošta firme je uključena{0}.",\r
"Pošta firme nije uključena (Menadžer → E-pošta i izvještaji).",\r
"POVRAT ROBE — KOREKTIVNI RAČUN",\r
"Prava kupca: pristup, ispravka, brisanje, ograničenje obrade, prenosivost i prigovor; prigovor i Agenciji za zaštitu ličnih podataka i slobodan pristup informacijama.",\r
"predato serveru",\r
"Provjera računa kod Poreske uprave",\r
"Provjereno {0}.",\r
"RAČUN",\r
"Racun {0}.pdf",\r
"Račun nije nađen na kasi.",\r
"Računi i promet prije popusta",\r
"Rok čuvanja: dok traje saglasnost, odnosno dok postoji kupac vjernosti.",\r
"Stavka",\r
"STORNO RAČUN",\r
"STORNO RAČUNA",\r
"strana {0} od {1}",\r
"Svrha: slanje elektronske kopije računa na adresu kupca (uz papirni račun).",\r
"tel:",\r
"trailer\\n<< /Size {0} /Root 1 0 R /Info 6 0 R >>\\nstartxref\\n{1}\\n%%EOF",\r
"U podešavanju pošte firme nisu upisane adrese vlasnika ni knjigovođe (Menadžer → E-pošta i izvještaji).",\r
"UKUPNO ZA PLAĆANJE",\r
"vlasniku i knjigovođi",\r
"Zapamćena adresa uz kupca (saglasnost",\r
"Zapamćena adresa uz kupca (saglasnost {0}).",\r
"Zapamti adresu uz kupca {0} (uz saglasnost kupca)",\r
"Žiro račun",\r
"· kartica",\r
"· kasira iz Menadžera:",\r
"· popust do {0} %",\r
"· povezana",\r
"· povezana {0} · kasira iz Menadžera: {1} · spisak od {2}",\r
"· spisak od",\r
"{0}\\n\\nRoba je fizički tu? Prodaja se nastavlja, a razlika se vidi na popisu.",\r
"{0} sa telefona ({1}): {2}",\r
"{0}: po stanju objekta {1} (podatak {2}.{3}. {4}).",\r
"{0}: potreban je PIN (ili kartica) — odobrava {1}.{2}",\r
"{0}{1}: popust bez odobrenja (%)",\r
"📱 Zatraži sa telefona",\r
"administrator",\r
"Adresa štampača (ESC/POS)",\r
"Brze tipke",\r
"Čeka odobrenje",\r
"Depozit gotovine",\r
"Depozit i podizanje gotovine",\r
"Dnevnik odobrenja",\r
"Etiketa poslije promjene cijene",\r
"Fioka: adresa",\r
"fiskalna i bezbjednosna podešavanja se ne mijenjaju daljinski",\r
"Fiskalna podešavanja se ne mijenjaju daljinski.",\r
"Gotovina po kasiru",\r
"Granica popusta je procenat od 0 do 100.",\r
"Granica popusta kasira je procenat od 0 do 100 (prazno = granica uloge).",\r
"granica_popusta REAL",\r
"HKDF",\r
"ima još {0}",\r
"iz Menadžera",\r
"izbor pri štampi",\r
"Izbor štampača pri svakoj štampi",\r
"Izmjena cijena i artikala",\r
"izmjena TEXT",\r
"Izvještaji i kontrola",\r
"kartica je upisana",\r
"Kartica nije upisana nijednom aktivnom kasiru.",\r
"kartica_hes TEXT",\r
"kartica_so TEXT",\r
"Kasa je povezana sa Menadžerom (ključ firme {0}). Kasira iz Menadžera: {1}.",\r
"Kasa nije povezana sa serverom ni sa folderom razmjene — kod se nema gdje provjeriti.",\r
"Kasir „{0}\\" je upisan u Menadžeru. Izmjene (PIN, uloga, objekti, ukidanje) se rade u Menadžeru i stižu na sve kase.",\r
"Kasiri iz Menadžera: {0}",\r
"kasiri iz Menadžera: {0} (spisak {1})",\r
"Kasiri, PIN-ovi i uloge mogu se upisivati u Menadžeru za sve kase odjednom (i ukidanje radnika). Kasa se povezuje jednom, kodom sa uređaja administratora Menadžera (Kase lanca → Kod za kase).",\r
"Kasiri, PIN-ovi i uloge mogu se upisivati u Menadžeru za sve kase odjednom (i ukidanje radnika). Kasa se povezuje jednom, kodom sa uređaja administratora Menadžera (Kase lanca → Kod za kase).{0}",\r
"Ključ firme:",\r
"Kod kartice ima najmanje {0} znakova (čitač kartice ga upisuje sam).",\r
"Kod kartice ima najmanje {0} znakova (upisuje ga čitač kartice).",\r
"Kod nije ispravan ili je istekao. Potreban je kod sa uređaja administratora Menadžera (Kase lanca → Kod za kase).",\r
"Kod operatera: {0} · PIN: {1}{2}{3}{4}",\r
"Kod za kase ima 12 znakova (npr. AB12-CD34-EF56), sa uređaja administratora Menadžera.",\r
"Kod za kase se vidi na uređaju administratora Menadžera (Kase lanca → Kod za kase). Kod se upisuje jednom; poslije toga kasiri, uloge i podešavanja stižu sa servera, potpisani ključem firme.",\r
"Kodna strana štampača",\r
"Kratak rok trajanja",\r
"Lanac kasa: {0}",\r
"Menadžer (lanac kasa)",\r
"Menadžer: {0}",\r
"mijenja se u Menadžeru",\r
"Na serveru je spisak kasa ove firme — potreban je samo kod.",\r
"Na serveru još nema spiska kasa iz Menadžera ove firme (PIB {0}). Potrebno je da uređaj administratora Menadžera bude na vezi.",\r
"Nastavi naplatu",\r
"Nema odobrenja u posljednjih 30 dana.",\r
"nema robe",\r
"Nema robe po stanju",\r
"nije povezana",\r
"Novi spiskovi kasira, podešavanja i odobrenja sa telefona više neće stizati. Kasiri iz Menadžera ostaju kakvi su sada (posljednji spisak).",\r
"obavezna uz „Drugo\\"",\r
"objekti TEXT",\r
"odbijeno",\r
"Odbijeno sa telefona: {0}{1}.",\r
"Odobrenja: {0}",\r
"Odobrenje može dati i vlasnik ili šef sa telefona (Menadžer).",\r
"Odobrenje sa telefona",\r
"Odobrenje sa telefona nije dostupno (kasa nije povezana sa Menadžerom ili je isključeno). Potreban je PIN šefa.",\r
"odobreno",\r
"Odobreno sa telefona: {0}{1}.",\r
"Odobrio",\r
"Ostale radnje uz odobrenje",\r
"Oštećena roba / ambalaža",\r
"PIN / kartica",\r
"PIN nije ispravan ili ta osoba ne odobrava ovu radnju ({0}).",\r
"Početak radnog dana",\r
"podešavanja iz Menadžera: {0}",\r
"Podešavanja kase",\r
"Podizanje gotovine",\r
"Popust {0} % na računu {1}{2}{3}",\r
"Popust bez odobrenja (%)",\r
"Popust bez odobrenja je procenat od 0 do 100 (prazno = granica uloge).",\r
"Popust preko granice",\r
"popust_odobrio TEXT",\r
"popust_razlog TEXT",\r
"poslovođa",\r
"Poslovođa",\r
"povezana",\r
"povezana sa Menadžerom (ključ {0}){1}",\r
"Poveži ponovo (nov kod)",\r
"Poveži sa Menadžerom",\r
"Poveži sa Menadžerom…",\r
"Povezivanje sa Menadžerom",\r
"povučeno",\r
"Prava po ulozi",\r
"Prava po ulozi su sačuvana.",\r
"Prava po ulozi…",\r
"prazno = „Ručni popust bez šefa\\" iz podešavanja",\r
"prazno = granica uloge",\r
"Prekid veze sa Menadžerom",\r
"Prekini vezu",\r
"Prekini vezu sa Menadžerom",\r
"Presjek i zaključak smjene (Z)",\r
"Prijava i karticom: kartica se prislanja na čitač.",\r
"prisloniti karticu na čitač dok je kursor u polju; prazno = bez izmjene",\r
"Prodaja bez stanja",\r
"Razlog popusta ({0} %)",\r
"Razlog popusta obavezan",\r
"Reklamacija",\r
"Rok zahtjeva za odobrenje (min)",\r
"Ručni popust {0} % (bez odobrenja najviše {1} %)",\r
"Ručni popust traži razlog",\r
"sa PIN-om odobrava storno, povrat, otpis, popuste i cijene (Prava po ulozi).",\r
"Šef ima sva prava. Radnju bez prava kasir radi uz odobrenje (PIN ili kartica onoga ko ima pravo, ili sa telefona preko Menadžera). Ista prava može poslati i Menadžer za sve kase.",\r
"šefa",\r
"Širina rolne (mm)",\r
"Spisak iz Menadžera je potpisan drugim ključem firme ({0}; kasa je povezana sa {1}). Potrebno je ponovo povezati kasu kodom.",\r
"Spisak iz Menadžera nema ispravan potpis ključem firme i nije primijenjen.",\r
"Spisak kasira iz Menadžera nema aktivnog šefa sa PIN-om — šef „{0}\\" ostaje aktivan na ovoj kasi (PRODUKCIJA ne radi bez šefa).",\r
"Stalni kupac / ugovor",\r
"Štampač naloga kuhinji",\r
"Štampač naloga šanku",\r
"Štampač računa",\r
"stanje {0}",\r
"stanje objekta (podatak",\r
"stanje objekta (podatak {0})",\r
"Stanje robe: {0}",\r
"Storno i poništavanje računa",\r
"Ta kartica je već upisana drugom kasiru.",\r
"telefon",\r
"Traži",\r
"type=\\"password\\" inputmode=\\"numeric\\" maxlength=\\"40\\"",\r
"Ukloni karticu",\r
"Uz „Drugo\\" je potrebno upisati napomenu.",\r
"Vaga na kasi",\r
"Vaga: barkod sa težinom",\r
"Vaga: pravila barkoda",\r
"Veća količina (veleprodaja)",\r
"Veza sa Menadžerom je prekinuta.",\r
"veza sa Menadžerom prekinuta{0}",\r
"Zahtjev je poslat vlasniku i šefovima (Menadžer → Čeka odobrenje).",\r
"Zahtjev važi još {0}:{1}",\r
"Zahtjev za odobrenje je istekao bez odgovora. Moguće je odobrenje PIN-om šefa.",\r
"zajedničko (početni depozit, isplata pri Z)",\r
"Zaposleni",\r
"zatraženo sa telefona: {0}",\r
"Znakova u redu (ESC/POS)",\r
"{0}: potreban je PIN {1} (ili kartica).{2}",\r
"PIN nije ispravan ili ta osoba ne odobrava ovu radnju (odobrava PIN {0}).",\r
"poslovođe",\r
": kartica se prislanja na čitač.",\r
"{0}: kartica se prislanja na čitač.",\r
"← Prijava za rad",\r
"bez ove oznake neoznačena stavka traži napomenu",\r
"Danas nema upisanih događaja.",\r
"Dnevni zaključak kartičnog terminala urađen",\r
"Događaj",\r
"Dolazak / odlazak",\r
"Dolazak / odlazak: unos PIN-a",\r
"dolazak kasira",\r
"Dolazak upisan",\r
"Evidencija i karticom",\r
"Evidencija radnog vremena: izbor radnika, pa PIN (ili kartica). Prijava za rad na kasi se ne mijenja.",\r
"Evidenciju radnog vremena vodi Menadžer (raspored i stvarni dolazak); kasa šalje događaje.",\r
"Gotovina u fioci prebrojana",\r
"Kartični terminal uključen i povezan",\r
"kasa je zatvorena bez odjave; vrijeme posljednje radnje",\r
"Kasa, štampač i čitač rade; rolna papira na mjestu",\r
"Kontrolna lista smjene",\r
"Kontrolna lista: otvaranje smjene",\r
"Kontrolna lista: zatvaranje smjene",\r
"Lista pri otvaranju smjene i prije zaključka (Z)",\r
"Lista smjene",\r
"lista smjene ({0})",\r
"Lista smjene je sačuvana.",\r
"Lista smjene…",\r
"Nepoznata vrsta događaja prisutnosti.",\r
"obavezna kad stavka nije označena",\r
"Odjava kasira iz prethodnog rada nije upisana: {0}",\r
"odjava sa kase",\r
"odlazak kasira",\r
"Odlazak upisan",\r
"Početna gotovina u fioci prebrojana",\r
"prazno = ugrađene stavke",\r
"Prijava i karticom",\r
"prijava na kasu",\r
"prijavio se drugi kasir",\r
"Prisutnost danas",\r
"prisutnost nije upisana: {0}",\r
"Računi na čekanju pregledani",\r
"Radnik",\r
"Radno mjesto čisto i uredno",\r
"Radno mjesto očišćeno, uređaji isključeni",\r
"Stavka koja nije u redu ostaje neoznačena, uz napomenu.",\r
"Stavke otvaranja",\r
"stavke se odvajaju znakom „;\\"",\r
"Stavke zatvaranja",\r
"Sve stavke liste moraju biti označene.",\r
"Sve stavke moraju biti označene",\r
"Sve stavke moraju biti označene.",\r
"Upis nije uspio.",\r
"Upis nije uspio. Potrebno je ponovo izabrati radnika.",\r
"Za neoznačene stavke potrebna je napomena.",\r
", posljednji",\r
". Količine ispod su ono što nije vraćeno.",\r
"· kasa",\r
"· kasa {0}{1}",\r
"(arhiva)",\r
"(dijelova arhive: {0})",\r
"(PIB {0}), kasa {1}, računa {2}, posljednji {3}.",\r
"(posljednji {0})",\r
"), kasa",\r
"{0} · {1} · {2} MB",\r
"{0} (stariji od {1})",\r
"{0} MB",\r
"{0} od {1}, {2}.",\r
"{0} Povrat nije urađen.",\r
"{0} računa · {1} stavki · {2}",\r
"↩ Račun druge kase",\r
"↩ Račun druge kase ili stariji račun",\r
"↩ Račun druge kase…",\r
"⇪ Pošalji račune na server",\r
"⚙ Podešavanja arhive",\r
"✔ Provjeri arhivu",\r
"⟲ Vraćanje iz rezervne kopije",\r
"⟲ Vraćanje iz rezervne kopije…",\r
"📷 Skeniraj QR",\r
"🗄 Arhiva računa",\r
"🗄 Arhiviraj sada",\r
"AND id = ?",\r
"arhiva",\r
"Arhiva je prazna.",\r
"Arhiva računa nije dostupna na ovom uređaju.",\r
"arhiva računa: {0}",\r
"arhiva računa: {0} računa, baza {1} → {2} MB ({3} ms)",\r
"Arhiviraju se računi stariji od (dana, najmanje {0})",\r
"Arhiviraju se računi stariji od (dana)",\r
"Arhiviranje na kasi",\r
"Arhiviranje računa",\r
"Arhiviranje računa je isključeno (Podešavanja → Arhiva računa).",\r
"Arhiviranje starih računa na kasi",\r
"Arhiviranje u toku: {0} od {1} računa…",\r
"Arhiviranje u toku…",\r
"Arhivirano {0} računa ({1} stavki, dijelova arhive: {2}). Baza: {3} → {4} MB.",\r
"Arhivirano računa",\r
"Arhivski fajl {0} nedostaje. Potrebno je obnoviti ga iz kopije na serveru (Više → Arhiva računa → Provjeri arhivu).",\r
"Arhivski fajl nije upisan ispravno (pročitan sadržaj se razlikuje). Arhiviranje je prekinuto; baza nije mijenjana.",\r
"Baza kase",\r
"Baza kase je vraćena iz kopije {0}. Dosadašnja baza je sačuvana ({1}). {2}{3}",\r
"baza kase se nije mogla otvoriti",\r
"Baza kase se zamjenjuje izabranom kopijom pri sljedećem pokretanju programa. Dosadašnja baza se ne briše: premješta se u poseban folder „Prije vraćanja\\" u folderu podataka kase. Sertifikat, veza sa serverom i arhiva računa ostaju. Kopija se prvo provjerava.",\r
"Baza kase se zamjenjuje kopijom pri ponovnom pokretanju. Program se sada zatvara i pokreće ponovo.\\n\\nZa potvrdu je potrebno upisati riječ VRATI.",\r
"Baza kase se zamjenjuje ovom kopijom; dosadašnja (neispravna) baza se ne briše. Za potvrdu je potrebno upisati riječ VRATI.",\r
"Broj računa, IKOF ili QR kod sa računa",\r
"Brojač računa je postavljen iza posljednjeg izdatog broja: {0}.",\r
"Brojač računa je već iza posljednjeg izdatog broja.",\r
"Brojač računa poslije vraćanja kopije nije postavljen: {0}",\r
"Brojač računa postavljen ({0}): {1}",\r
"brojač računa postavljen poslije vraćanja kopije: {0}",\r
"Brojači računa se poslije povratka postavljaju iza posljednjeg broja koji je kasa izdala (brojevi iz sadašnje baze i sa servera) — nijedan redni broj se ne ponavlja.",\r
"Dijelovi arhive",\r
"Dio arhive nije poznat ovoj bazi: {0}",\r
"Dio se može obnoviti iz kopije na serveru (dugme „Obnovi sa servera\\").",\r
"dokumenti:",\r
"Fajl arhive nije čitljiv (JSON).",\r
"Fajl arhive obnovljen sa servera ({0} računa).",\r
"Fajl nije arhiva računa kase.",\r
"Granica veličine baze (MB)",\r
"Granica veličine baze nije ispravna.",\r
"Izabrana kopija više ne postoji. Potrebno je ponovo otvoriti spisak kopija.",\r
"izabrani fajl nije baza kase",\r
"Kad baza pređe (MB, 0 = bez granice)",\r
"kasa {0}",\r
"Kasa arhivira sama, jednom dnevno, kad miruje. Kad baza pređe granicu veličine, arhiviraju se računi stariji od",\r
"Kasa arhivira sama, jednom dnevno, kad miruje. Kad baza pređe granicu veličine, arhiviraju se računi stariji od {0} dana.",\r
"kasa nije uparena sa serverom",\r
"Kasa nije uparena sa serverom IRIS CORVINA (Podešavanja → Server).",\r
"kase",\r
"kase {0}",\r
"kase {0}{1} od {2}, {3}.",\r
"Količina je obavezna uz najmanje jednu stavku (ili „Vrati sve\\").",\r
"kopija dana (folder kase)",\r
"Kopija je druge firme (PIB {0}), a kasa radi za PIB {1}. Povratak nije moguć.",\r
"Kopija je druge kase ({0}), a ova kasa radi kao {1}.",\r
"Kopija nema podataka firme ni računa (prazna kasa).",\r
"Kopija nije baza kase: {0}",\r
"Kopija nije ispravna.",\r
"Kopija nije pročitana u cijelosti ({0} od {1} bajtova).",\r
"Kopija se ne može otvoriti: {0}",\r
"Kopija se ne može pročitati.",\r
"kopija se samo čita",\r
"Kopija:",\r
"korektivni",\r
"Korektivnih računa uz ovaj račun (sve kase):",\r
"Korektivnih računa uz ovaj račun (sve kase): {0}. Količine ispod su ono što nije vraćeno.",\r
"masovna izmjena + sažimanje + snimak",\r
"MB",\r
"Najmanje {0} dana (fajl zaključaka za Knjigovodstvo nosi promet po artiklu za 90 dana).",\r
"Nedozvoljeno ime arhivskog fajla: {0}",\r
"Neispravnih dijelova:",\r
"Neispravnih dijelova: {0} od {1}.",\r
"Nema računa za arhivu.",\r
"Nema rezervnih kopija baze na ovom uređaju.",\r
"Nema rezervnih kopija baze na ovom uređaju. Potrebno je obratiti se održavanju.",\r
"Nepoznata kopija.",\r
"Obnovi sa servera",\r
"Obnovljen fajl arhive nije upisan ispravno.",\r
"odbijeno: {0}",\r
"Ostalo za arhivu: {0} (sljedeći krug).",\r
"Otisak fajla arhive se ne slaže sa otiskom u bazi kase (to nije fajl ovog dijela arhive).",\r
"Otisak sadržaja fajla arhive se ne slaže sa upisanim otiskom (fajl je oštećen ili mijenjan).",\r
"Podešavanja arhive računa",\r
"Poreska uprava je odbila ovaj račun na kasi koja ga je izdala; povrat se ne može prijaviti.",\r
"Poslato {0}, potvrđeno {1}, čeka slanje {2}.",\r
"Posljednje arhiviranje",\r
"Posljednji račun u kopiji",\r
"Potrebno je upisati broj računa (npr. 125 ili 125/2026), IKOF ili skenirati QR kod sa računa.",\r
"Potvrda nije upisana. Kopija nije vraćena.",\r
"Potvrđeno na serveru",\r
"Povrat — račun {0}",\r
"povrat bez provjere na serveru ({0})",\r
"Povrat i storno računa druge kase iste firme ili starijeg računa (server)",\r
"povrat i storno računa druge kase iste firme ili starijeg računa; broj, IKOF ili QR sa računa",\r
"Povrat i storno računa koji je izdala druga kasa iste firme ili starijeg (arhiviranog) računa. Račun se traži na serveru po broju (npr. 125 ili 125/2026), IKOF-u ili QR kodu sa računa kupca. Korektivni račun izdaje ova kasa, uz IKOF originala.",\r
"Povrat je moguć samo sa računa prodaje (ne sa korektivnog računa ni ispravke).",\r
"Povrat računa druge kase ili starijeg (arhiviranog) računa traži vezu sa serverom IRIS CORVINA. Povrat nije urađen.",\r
"Povrat sa ovog računa je upravo u toku na kasi {0}. Potrebno je sačekati da se završi pa pokušati ponovo.",\r
"povrat sa servera ({0}{1})",\r
"Povrat uz račun {0}/{1}{2}{3}",\r
"Povrat uz račun br.",\r
"Povratak iz rezervne kopije radi u instaliranoj kasi (Windows, Android).",\r
"Povratak iz rezervne kopije traži instalaciju kase 2111 ili noviju (nov Setup).",\r
"prijavljen",\r
"Prije vracanja",\r
"Provjera kopije…",\r
"Provjera u toku…",\r
"provjeren {0}",\r
"Račun {0} na serveru se ne slaže sa bazom kase. Obnova nije urađena.",\r
"račun {0} nije u fajlu",\r
"račun {0}: stavke u fajlu se ne slažu sa bazom",\r
"Račun hotela ili račun plaćen iz avansa se vraća na kasi koja ga je izdala.",\r
"Račun je izdala druga firma (PIB {0}). Povrat je moguć samo za račune ove firme.",\r
"Račun je prijavljen Poreskoj upravi u PRODUKCIJI, a kasa sada radi u probnom okruženju. Povrat nije urađen.",\r
"Račun još nije prijavljen Poreskoj upravi na kasi koja ga je izdala (čeka slanje). Povrat je moguć kad bude prijavljen.",\r
"Račun nije nađen na serveru. Kasa koja ga je izdala ga možda još nije poslala (nema veze sa serverom).",\r
"Račun nije u fajlu arhive: {0}",\r
"Račun nije u svom dijelu arhive ({0}).",\r
"Račun sa poklon-bonom (prodat bon ili plaćeno bonom) se vraća stornom na kasi koja ga je izdala.",\r
"Računa u bazi",\r
"Računa u kasi sada",\r
"Računa u kopiji",\r
"rezerva u folder (Google Drive)",\r
"Sadržaj fajla arhive je oštećen (raspakivanje).",\r
"Sadržaj fajla arhive nije čitljiv.",\r
"Sadržaj fajla arhive nije ispravan.",\r
"sažimanje baze (VACUUM)",\r
"Server ne poznaje ovu radnju (potrebna je novija verzija servera).",\r
"Server nije bio dostupan: ako su poslije kopije izdavani računi na drugom uređaju sa istim kodom kase, potrebno je provjeriti posljednji broj (Podešavanja → Fiskalizacija → „Postavi…\\").",\r
"Server nije vratio stavke računa.",\r
"Slanje nije uspjelo: {0}",\r
"Slanje računa na server",\r
"Slanje računa na server (arhiva na serveru, povrat sa druge kase)",\r
"Spremno za arhivu",\r
"stari računi u arhivi kase i na serveru, provjera arhive, vraćanje iz rezervne kopije",\r
"Stariji računi koji su prijavljeni Poreskoj i potvrđeni na serveru idu u arhivu na disku kase; u bazi ostaje skraćen zapis (broj, datum, iznos, IKOF, JIKR, plaćanja, PDV po stopama), pa izvještaji i žurnali daju iste brojeve, a kasa se brže pokreće. Stavke arhiviranog računa se čitaju iz arhive (pregled, kopija računa, žurnal za inspektora); povrat i storno idu preko servera.",\r
"Stavke u arhivi (zbir po stopi PDV-a)",\r
"Svi dijelovi arhive su ispravni ({0}).",\r
"tada se arhiviraju računi stariji od {0} dana",\r
"Traženje kopija…",\r
"Traženje na serveru…",\r
"Traženje računa druge kase traži vezu sa serverom IRIS CORVINA (Podešavanja → Server).",\r
"U kopiji je {0} računa, u kasi {1}: {2} računa izdatih poslije kopije neće biti u bazi kase (ostaju na serveru i kod Poreske). Brojači računa se poslije povratka postavljaju iza posljednjeg izdatog broja.",\r
"Vraćanje baze kase iz rezervne kopije {0}",\r
"Vraćanje dijela arhive u bazu",\r
"Vraćanje iz rezervne kopije",\r
"Vraćanje iz rezervne kopije nije uspjelo: {0} Kasa radi sa dosadašnjom bazom.",\r
"vraćanje kopije {0}",\r
"vracen",\r
"vraćen u bazu",\r
"Vraćeno u bazu: {0} računa.",\r
"VRATI",\r
"Vrati kopiju",\r
"Vrati ovu kopiju",\r
"Vrati sve što nije vraćeno",\r
"Vrati u bazu",\r
"— „NLB/Payten — na istom uređaju\\" (podešavanje u dijelu NLB/Payten); kad je kasa na drugom uređaju — „NLB/Payten — preko mreže / Bluetooth-a\\":",\r
"— račun se izdaje uz to plaćanje pri sljedećoj naplati istog iznosa.",\r
", pa kasa provjerava vezu, a iznos se kuca na terminalu (ručna potvrda broja odobrenja).",\r
", verzija {0}",\r
"(Castles Saturn1000, Android) šalje iznos aplikaciji NLB „Powered by Payten\\" na istom uređaju i čita rezultat: broj odobrenja, maskiranu karticu, vrstu kartice. Kasa ne procesira kartice. Storno i kopija slipa idu kroz aplikaciju Payten.",\r
"(Castles)",\r
"(štampač)",\r
"{0}\\n\\n(Pregled je kopiran — može se proslijediti Payten-u / Castles-u.)",\r
"{0} (rezultat stigao poslije ponovnog pokretanja kase)",\r
"{0}{1}{2} [klasa {3}]",\r
"978 ili EUR",\r
"adresa (šablon)",\r
"Akcija: kopija",\r
"Akcija: povrat",\r
"Akcija: pregled",\r
"Akcija: prodaja",\r
"Akcija: storno",\r
"Aktivnost (klasa)",\r
"aktivnosti: {0}",\r
"Aplikacija {0} nije instalirana na ovom uređaju.",\r
"Aplikacija NLB/Payten radi na Android terminalu (kasa instalirana na istom uređaju).",\r
"Aplikacija Payten je javila „odobreno\\" uz otkazanu aktivnost.",\r
"Aplikacija Payten je naplatila drugi iznos ({0} umjesto {1}).",\r
"Aplikacija Payten je vratila rezultat drugog plaćanja.",\r
"Aplikacija Payten je zatvorena bez rezultata.",\r
"Aplikacija Payten ne prima ovu radnju od kase — radi se u samoj aplikaciji (Storno / Kopija / Pregled).",\r
"Aplikacija Payten nije nađena na ovom uređaju.",\r
"Aplikacija Payten nije vratila ishod plaćanja.",\r
"Aplikacija Payten se nije javila kasi u roku.",\r
"Aplikacija Payten: {0} {1}{2}",\r
"Aplikacija zatvorena bez rezultata",\r
"Aplikacije za plaćanje: {0}",\r
"APPROVED,OK,SUCCESS,00,000",\r
"Bluetooth (upareni): {0}",\r
"Bluetooth {0}",\r
"centi (broj)",\r
"centi (tekst)",\r
"DECLINED,REJECTED,DENIED,FAILED,05,51,55",\r
"Direktna štampa računa (ESC/POS) se podešava u Podešavanjima → Dodaci. Ovdje se provjerava stanje papira: Sunmi kroz servis proizvođača, ostali štampači ESC/POS upitom „DLE EOT 4\\" (štampač mora odgovarati na upit). NLB terminal Castles Saturn1000: „Ugrađeni štampač terminala\\" (rolna 57 mm = 32 znaka) — kasa traži štampač koji uređaj izlaže kao USB ili Bluetooth uređaj; Castles SDK za štampač nije javno dostupan, pa je to pretpostavka dok se ne provjeri na uređaju (dugme „Pregled uređaja\\"). Kad direktna štampa ne uspije, račun ide kroz Android sistem za štampu. Za veleprodaju na terenu: Bluetooth štampač 58 mm (32 znaka) ili 80 mm (48 znakova) štampa i kupca-firmu (naziv, PIB, adresa) i broj odobrenja kartice.",\r
"dok Payten ne da specifikaciju App-to-App (javno nije objavljena) — upisuju se po specifikaciji. Paket „proba\\" = lažna aplikacija Payten za probu toka. Vrsta terminala mora biti „NLB/Payten — na istom uređaju\\".",\r
"DRUGA{0}",\r
"dugme „Pronađi aplikaciju Payten\\" ili proba",\r
"ECR specifikacija banke još nije dostupna",\r
"ECR veza sa NLB/Payten terminalom čeka specifikaciju banke — iznos se ne šalje terminalu.",\r
"eur „12.50\\" (tekst)",\r
"eur (broj)",\r
"IP, Bluetooth adresa, InnerPrinter, USB „vid:pid” (prazno = prvi USB štampač; ugrađeni: prazno = sam traži)",\r
"JSON u jednom polju",\r
"JSON: polje zahtjeva",\r
"Kasa instalirana",\r
"Kasa šalje iznos terminalu, terminal vraća ishod (broj odobrenja, maskirana kartica, vrsta kartice). Račun se izdaje tek kad terminal odobri plaćanje. NLB terminal (Castles Saturn1000, aplikacija NLB „Powered by Payten\\"): kad je kasa instalirana",\r
"Kopija",\r
"Kopija (proba)",\r
"Kopija posljednjeg slipa",\r
"Kopija slipa (proba).",\r
"Kopija slipa iz kase",\r
"Kopija slipa je odštampana.",\r
"Kopija slipa se radi na terminalu.",\r
"Kupac je odustao (proba)",\r
"kupac odustao (kartica nije zadužena)",\r
"Lažna aplikacija Payten (proba)",\r
"mreža {0}",\r
"na NLB terminalu",\r
"na samom terminalu",\r
"Nađena aplikacija Payten: {0}. Upisana u polje paketa — za čuvanje „Sačuvaj\\".",\r
"Nađeno više mogućih aplikacija ({0}) — paket se upisuje ručno.",\r
"Naplata u aplikaciji NLB/Payten na ovom uređaju: kupac prislanja, ubacuje ili provlači karticu.",\r
"Naplata u aplikaciji Payten je već u toku.",\r
"Nazivi akcija i polja (po specifikaciji Payten)",\r
"Nazivi ispod su pretpostavka",\r
"nejasno — kasir provjerava Pregled u aplikaciji",\r
"Nepoznat ishod aplikacije Payten: {0}",\r
"nije nađena nijedna (Payten, NLB, Castles).",\r
"Nije upisana aplikacija Payten (Više → Uređaji kase → NLB/Payten → Pronađi aplikaciju Payten).",\r
"Nije upisana aplikacija Payten.",\r
"Nije urađeno.",\r
"NLB/Payten — na istom uređaju (App-to-App)",\r
"NLB/Payten — preko mreže / Bluetooth-a (ECR, čeka specifikaciju)",\r
"npr. sema://pay?amount={centi}&ref={ref}&callback={povratak}",\r
"Oblik iznosa",\r
"Paket aplikacije Payten",\r
"PAYTEN-PROBA",\r
"PENDING",\r
"polja Intent-a",\r
"Polje broja terminala",\r
"Polje naplaćenog iznosa",\r
"Polje povratne adrese",\r
"Polje vrste transakcije",\r
"port {0}",\r
"Potrebna je nova verzija aplikacije kase (NLB/Payten).",\r
"Potrebna je nova verzija aplikacije kase.",\r
"Povrat na karticu iz kase",\r
"povratna adresa kase (iriskasa://placanje/…)",\r
"Povratna adresa kase nije dostupna u ovoj verziji aplikacije.",\r
"Povratna adresa nije nosila referencu ovog plaćanja.",\r
"prazno = ista",\r
"prazno = ne šalje se",\r
"prazno = po akciji",\r
"prazno = početni ekran aplikacije",\r
"prazno = rezultat u poljima",\r
"Pregled (zaključak) iz kase",\r
"Pregled uređaja",\r
"Pregled uređaja radi na Android uređaju.",\r
"Probna aplikacija na uređaju",\r
"Pronađi aplikaciju Payten",\r
"PT{0}",\r
"Radi se u aplikaciji Payten.",\r
"REFUND",\r
"REPORT",\r
"REPRINT",\r
"Rezultat",\r
"rezultat aktivnosti",\r
"Rezultat: polje sa JSON-om",\r
"Šablon adrese",\r
"SALE",\r
"Servisi štampe Android-a: {0}",\r
"servisi: {0}",\r
"Sistemske biblioteke proizvođača: {0}",\r
"Storno iz kase (isti dan)",\r
"Storno: polje broja odobrenja",\r
"Storno: polje izvorne reference",\r
"Storno: polje RRN",\r
"terminal: kopija slipa {0}",\r
"terminal: rezultat poslije ponovnog pokretanja {0}",\r
"Ugrađeni štampač terminala (Castles Saturn1000 i sl.)",\r
"ugrađeni štampač terminala (Castles Saturn1000)",\r
"Upisana probna aplikacija Payten na ovom uređaju (aktivnost u kasi: Odobri / Odbij / Odustani / Bez rezultata). Za čuvanje „Sačuvaj\\", pa „Proba naplate\\".",\r
"Urađeno.",\r
"Uređaj: {0} {1}, Android {2}{3}",\r
"USB uređaji: {0}",\r
"Veza sa terminalom postoji ({0}). {1}",\r
"VOID",\r
"Vrijednosti za odbijeno",\r
"Vrsta: kopija",\r
"Vrsta: povrat",\r
"Vrsta: pregled",\r
"Vrsta: prodaja",\r
"Vrsta: storno",\r
"Za zahtjev u obliku adrese potreban je šablon adrese (NLB/Payten → Šablon adrese).",\r
"Zahtjev",\r
"— bez izvršioca —",\r
"— drugo vrijeme —",\r
"— nema (samo ime) —",\r
"; avans se bira u „Više načina plaćanja\\"",\r
"· avans {0}",\r
"· avans {0} · za naplatu",\r
"· garancija {0} mj.",\r
"· granica {0}",\r
"· izvršilac {0}",\r
"· naplaćen",\r
"· PIB {0}",\r
"· podsjetnik poslat",\r
"· račun {0}",\r
"· za naplatu",\r
"(poslije ponude)",\r
"{0} · {1} · {2} min",\r
"{0} · {1} min",\r
"{0} · PDV {1}% · {2}",\r
"{0} {1}: razlog otkazivanja",\r
"{0} mj.",\r
"{0} mjeseci poslije termina",\r
"{0} obrađuje ime, broj telefona i e-poštu klijenta radi zakazivanja termina, obavještenja o promjeni termina i, uz posebnu saglasnost, podsjetnika e-poštom prije termina. Podaci se ne daju trećim licima osim obrađivaču (IRIS CORVINA, server programa). Telefon i e-pošta se brišu {1}; klijent može u svakom trenutku tražiti uvid, ispravku ili brisanje podataka i povući saglasnost.",\r
"{0}: cijena na nalogu ({1}) je veća od cijene u cjenovniku kase ({2})",\r
"{0}: nema šifre artikla kase",\r
"{0}: stopa PDV-a u katalogu ({1} %) nije ista kao na nalogu ({2} %)",\r
"{0}Klijent",\r
"% traži pisani pristanak (ZZP čl. 21).",\r
"% traži prethodni pisani pristanak klijenta. Prihvaćenu ponudu potpisuju servis i klijent; jedan primjerak se predaje klijentu.",\r
"+ Nov termin",\r
"+ Prijem uređaja / vozila",\r
"+ Stavka (rad, dio, materijal)",\r
"⚙ Usluge — podešavanja",\r
"✍ potpis",\r
"✍ Potpis klijenta",\r
"👤 Promet po izvršiocu",\r
"📅 Termini",\r
"📅 Termini{0}",\r
"📷 Slika uređaja",\r
"🔧 Radni nalozi",\r
"🔧 Radni nalozi servisa",\r
"🔧 Radni nalozi{0}",\r
"🖨 Ponuda",\r
"🖨 Prijemnica",\r
"🖨 Radni nalog",\r
"Artikal nije u katalogu kase.",\r
"Avans — nalog {0}, {1}",\r
"Avans — termin {0} {1}, {2}",\r
"Avansni račun je izdat ({0}).",\r
"bez",\r
"bez IKOF-a",\r
"Bez izvršioca",\r
"Boja (#RRGGBB, neobavezno)",\r
"Brisanje podataka klijenta",\r
"Brisanje podataka klijenta (zaštita podataka o ličnosti)",\r
"Brisanje telefona i e-pošte klijenta na zahtjev",\r
"broj, klijent, serijski broj, registracija",\r
"čeka dio",\r
"Čeka dio",\r
"čeka pristanak",\r
"Čekanje dijela je faza odobrenog naloga ili naloga u radu.",\r
"Cijena bez PDV",\r
"Cijena je povećana iznad pristanka klijenta: potreban je pisani pristanak prije naplate.",\r
"Cijena je povećana više od {0} % u odnosu na pristanak ({1} € → {2} €): nalog se ne završava dok se ne upiše pisani pristanak klijenta ({3} st. 2).",\r
"Dan nije ispravan.",\r
"Datum ({0}) je prije datuma prijema {1}",\r
"Datum ({0}) je u budućnosti.",\r
"Datum ({0}) nije ispravan.",\r
"Datum ili vrijeme nije ispravno.",\r
"Datum preuzimanja je prije datuma završetka.",\r
"Datum prijema",\r
"Dijagnoza",\r
"Dijagnoza je faza primljenog naloga (prije pristanka klijenta).",\r
"dodatak uz jelo",\r
"Druga usluga",\r
"Drugo vrijeme (HH:MM)",\r
"elektronski (e-pošta, poruka)",\r
"en-GB",\r
"Fajl nije slika.",\r
"Garancija na rad",\r
"Garancija na rad (mjeseci)",\r
"Garancija: broj mjeseci.",\r
"I na svim ostalim terminima sa istim telefonom / e-poštom",\r
"Ime i prezime klijenta",\r
"Ime klijenta nije upisano.",\r
"Izmjena termina",\r
"Iznad",\r
"Iznad {0} pristanak je potpisana ponuda; povećanje veće od {1} % traži pisani pristanak (ZZP čl. 21).",\r
"Iznos avansa nije ispravan.",\r
"Iznos sa PDV-om, poslije popusta; storna umanjuju promet. „—\\" = stavke bez izvršioca (roba, stavke van usluga).",\r
"izvršilac",\r
"Izvršilac",\r
"Izvršilac (ime)",\r
"izvršilac (osoba)",\r
"Izvršilac / mjesto",\r
"Izvršilac / mjesto: ne radi više",\r
"izvrsilac TEXT",\r
"Izvršilac usluge",\r
"Izvršilac:",\r
"Izvršioci se upisuju u Usluge → Podešavanja (kasa ili Menadžer).",\r
"izvršioci, mjesta, trajanje i materijal usluga; samo šef",\r
"kalendar po izvršiocu i mjestu, zakazivanje, termin → račun, avans",\r
"Klijent",\r
"Klijent (ime i prezime ili naziv)",\r
"Klijent je odbio ponudu, uređaj se vraća bez popravke?",\r
"klijent je stigao",\r
"Klijent nije upisan.",\r
"Klijent potvrđuje predaju uređaja i podatke sa prijemnice.",\r
"Klijent preuzeo",\r
"Klijent preuzima završen uređaj (sada: {0}). Uređaj po odbijenoj ponudi se vraća radnjom „odbijeno\\".",\r
"Klijent želi podsjetnik e-poštom",\r
"Ko preuzima uređaj ({0})?",\r
"Kod kasira / operatera (neobavezno)",\r
"Količina (rad: sati)",\r
"Kontakt",\r
"Kontakt (telefon, e-pošta)",\r
"Kupac (firma)",\r
"Kupac-firma {0}: upisati kupca na računu (dugme Kupac) ako se račun izdaje firmi.",\r
"Kupac-firma: naziv",\r
"Kupac-firma: PIB (neobavezno)",\r
"Kvar / zahtjev",\r
"Materijal „{0}\\": šifra iz kataloga i količina po usluzi.",\r
"Materijal koji se naplaćuje (šifra:količina, …)",\r
"Materijal nije u katalogu kase: {0}",\r
"Materijal uključen u cijenu (šifra:količina, …)",\r
"materijal uz uslugu",\r
"Materijal uz uslugu prati količinu usluge.",\r
"mjesto (stolica, box, sala)",\r
"Mjesto (stolica, box, sala)",\r
"Na ekranu je račun koji se kuca: potrebno ga je naplatiti ili staviti na čekanje.",\r
"na zahtjev klijenta",\r
"Način pristanka",\r
"Način pristanka klijenta nije izabran.",\r
"Nalog {0}",\r
"Nalog {0} je na ekranu{1}.",\r
"Nalog {0} je naplaćen; mijenja se samo preuzimanje.",\r
"Nalog {0} je naplaćen; stavke se ne mijenjaju.",\r
"Nalog {0} je primljen.",\r
"Nalog {0} je zatvoren ({1}); stavke se ne mijenjaju.",\r
"Nalog {0}: potpis klijenta na prijemu i štampa prijemnice?",\r
"Nalog nema stavki izvršenih radova, djelova i materijala.",\r
"Nalog nema stavki: pristanak se daje na ponudu sa radovima, djelovima i materijalom.",\r
"Nalog nije nađen.",\r
"Nalog se ne može naplatiti na kasi: {0}. Naplata kroz fakturu Knjigovodstva ili ispravka stavki.",\r
"Naziv nije upisan.",\r
"Ne radi više",\r
"Nepoznata faza naloga.",\r
"Nepoznata radnja radnog naloga.",\r
"nije došao",\r
"Nije došao",\r
"Nije u katalogu kase (nije na računu): {0}",\r
"Nov izvršilac",\r
"Nov izvršilac (frizer, serviser, ljekar)",\r
"Nov termin — usluge i izvršilac",\r
"Novo mjesto",\r
"Novo mjesto (stolica, box, sala)",\r
"npr. laptop Dell 5420, Golf 7",\r
"Obriši telefon i e-poštu",\r
"Odbija se ponuda ili povećanje cijene (sada: {0}).",\r
"Odbijeno / vraćeno",\r
"Opis kvara / zahtjev",\r
"Opis kvara / zahtjev klijenta",\r
"Opis kvara nije upisan.",\r
"Oprema",\r
"Oprema predata uz uređaj",\r
"Osnovica {0} · PDV {1} ·",\r
"Otkaži termin",\r
"Otkazivanje termina",\r
"Pauza poslije usluge (min)",\r
"pisani pristanak e-poštom ili porukom",\r
"pisani pristanak predat lično",\r
"pisano (potpis)",\r
"po artiklu (usluga = rad, roba = dio)",\r
"Podaci klijenta su obrisani (termina: {0}).",\r
"Podešavanja usluga",\r
"Podsjetnik ide na e-poštu: upisati e-poštu klijenta.",\r
"Podsjetnik klijentu, radno vrijeme i rok čuvanja podataka: Menadžer → Usluge → Podešavanja.",\r
"Ponuda",\r
"ponuda izdata",\r
"Ponuda klijentu",\r
"Ponuda nema stavki: upisati radove, djelove i materijal sa cijenama.",\r
"Ponuda sa specifikacijom radova, materijala i djelova (Zakon o zaštiti potrošača, čl. 21). Povećanje cijene veće od",\r
"Ponuda sa specifikacijom radova, materijala i djelova (Zakon o zaštiti potrošača, čl. 21). Povećanje cijene veće od {0} % traži prethodni pisani pristanak klijenta. Prihvaćenu ponudu potpisuju servis i klijent; jedan primjerak se predaje klijentu.",\r
"Ponuda se izdaje za primljen nalog ili za nalog koji čeka pristanak na povećanje cijene (sada: {0}).",\r
"PONUDA ZA POPRAVKU",\r
"Posebna stavka računa uz uslugu.",\r
"Poslije naplate se skida sa stanja (utrošak, nije na računu).",\r
"Potpis i štampa",\r
"Potpis je prazan.",\r
"Potpis je sačuvan uz nalog.",\r
"Potpis klijenta —",\r
"Potpis klijenta — {0}",\r
"potpisana ponuda (obje strane)",\r
"potvrđen",\r
"Predlog avansa za termin (€)",\r
"Predmet",\r
"Predmet (uređaj, vozilo)",\r
"Predmet nije upisan.",\r
"Preuzeo",\r
"Preuzeto",\r
"Preuzimanje",\r
"Prijem",\r
"Prijem uređaja / vozila",\r
"prijem uređaja ili vozila, status, dijelovi i rad, ponuda i pristanak, naplata",\r
"Prijemnica",\r
"PRIJEMNICA",\r
"Prilog se ne može prikazati.",\r
"Prilozi",\r
"Primi",\r
"Pristanak",\r
"pristanak je potpisana ponuda; povećanje veće od",\r
"Pristanak klijenta",\r
"Pristanak se upisuje za nalog sa ponudom ili za povećanje cijene (sada: {0}).",\r
"Promet po izvršiocu",\r
"Promet po izvršiocu {0} – {1}",\r
"Račun {0} — materijal uključen u cijenu usluge",\r
"Rad počinje poslije pristanka klijenta (sada: {0}).",\r
"Radni nalog",\r
"RADNI NALOG",\r
"Radni nalog {0} — {1}",\r
"Radni nalozi",\r
"Radni nalozi servisa",\r
"Red za server:",\r
"Red za server: {0} upis nije primljen — {1}",\r
"RN-{0}-{1}",\r
"Sačuvaj potpis",\r
"Saglasnost klijenta (telefon, e-pošta)",\r
"Serijski broj / registracija",\r
"Server još nema usluge (starija verzija servera).",\r
"Servis",\r
"servis izdaje pisanu ponudu prije rada. Uređaj se preuzima uz ovu prijemnicu.",\r
"Šifra ili barkod artikla (iz šifarnika)",\r
"Slika je dodata nalogu.",\r
"Slika se ne može pročitati.",\r
"Šta se podešava",\r
"Štampa ponude za potpis klijenta?",\r
"Stanje pri prijemu",\r
"Stanje pri prijemu (oštećenja)",\r
"Stavka „{0}\\": cijena nije ispravna.",\r
"Stavka „{0}\\": količina mora biti veća od nule.",\r
"Stavka „{0}\\": stopa PDV-a je 21, 15, 7 ili 0 %.",\r
"Stavka „{0}\\": vrsta je rad, dio ili materijal.",\r
"Stavka naloga",\r
"Stavka nema naziv.",\r
"Stigao",\r
"Stopa PDV-a usluge",\r
"Svi (30 dana)",\r
"Telefon i e-pošta klijenta se brišu sa servera; ime ostaje kao inicijali. Brisanje se ne može poništiti.",\r
"Telefon i e-pošta se upisuju samo uz saglasnost klijenta (izabrati način saglasnosti).",\r
"Termin {0} ({1}) je na ekranu{2}.",\r
"Termin je izmijenjen.",\r
"Termin je zakazan: {0} {1}.",\r
"Termin: {0}",\r
"Termini",\r
"Termini —",\r
"Termini — {0}",\r
"Termini i radni nalozi traže vezu kase sa serverom (Podešavanja → Server).",\r
"Trajanje (min)",\r
"Trajanje i materijal usluge",\r
"Trajanje: najmanje 5 minuta.",\r
"Traži mjesto (stolica, box, sala)",\r
"traži pisanu ponudu",\r
"Treća usluga",\r
"U katalogu kase nema usluga (grupa „Usluge\\" u šifarniku Knjigovodstva).",\r
"u radu",\r
"U radu",\r
"Ukloni iz kalendara",\r
"Ukupno {0}",\r
"Ukupno sa PDV-om",\r
"upis nije primljen —",\r
"Upiši pristanak",\r
"Usluga",\r
"Usluga iz šifarnika",\r
"Usluga je podešena.",\r
"Usluge — podešavanja",\r
"Usluge (termini, radni nalozi, izvršilac)",\r
"usluge po izvršiocu za period; samo šef",\r
"Usluge termina nisu u katalogu kase: {0}",\r
"Usluge: {0} upis na server nije primljen (Usluge → Termini → Red za server).",\r
"usmeno (do praga pisane ponude)",\r
"usmeno (lično ili telefonom)",\r
"Utrošak materijala nije upisan: {0}",\r
"utrošak materijala za uslugu",\r
"vraćanja",\r
"Vrati na zakazan",\r
"Vrijednost popravke je {0} €, veća od {1} €: potrebna je pisana ponuda sa specifikacijom radova, materijala i djelova koju potpisuju servis i klijent ({2} st. 1 i 3).",\r
"Vrijednost popravke je {0} €, veća od {1} €: prije pristanka se izdaje pisana ponuda sa specifikacijom radova, materijala i djelova ({2} st. 1).",\r
"Vrijeme (slobodno)",\r
"Vrijeme termina: HH:MM.",\r
"Za firmu: račun ili faktura na firmu.",\r
"Za popravku veću od {0} € prihvaćenu ponudu potpisuju servis i klijent; jedan primjerak se predaje klijentu ({1} st. 3).",\r
"Za popravku vrijednosti veće od",\r
"Za popravku vrijednosti veće od {0} servis izdaje pisanu ponudu prije rada. Uređaj se preuzima uz ovu prijemnicu.",\r
"Za povećanje cijene veće od {0} % potreban je prethodni pisani pristanak klijenta, dat lično ili sredstvima komunikacije na daljinu ({1} st. 2).",\r
"Zakaži",\r
"Zakon o zaštiti potrošača („Sl. list CG\\" 12/26), čl. 21",\r
"Završava se nalog u radu (sada: {0}).",\r
"završen (naplaćen)",\r
"Završeno",\r
"završetka",\r
"Zbir stavki ({0} €) je veći od izdate ponude ({1} €) za više od {2} %: izdati novu ponudu.",\r
", stanje {0}",\r
"· razlika {0}.",\r
"(ili kartica)",\r
"(računi gotovinom + depoziti − podizanja).",\r
"{0}\\n\\nPotvrditi da je roba fizički tu? Prodaja se bilježi, a razlika se vidi na popisu.",\r
"{0}: potreban je PIN {1}{2}.{3}",\r
"📣 Javi menadžeru: roba nestaje",\r
"Artikal „{0}\\" nije u katalogu kase.",\r
"artikal koji brzo nestaje (danas / sutra); ide u upozorenja i prijedlog dopune objekta",\r
"Artikal nije izabran.",\r
"Avansni račun kupcu-firmi (fiskalizacija računa)",\r
"Bez predaje",\r
"Bezgotovinski račun kupcu-firmi (fiskalizacija računa)",\r
"Brojim po apoenima",\r
"drugi artikal — šifra ili barkod",\r
"Fiskalizacija računa",\r
"i ulazi u prijedlog dopune i narudžbe. Bez veze čeka i šalje se sa prvim sljedećim fajlom kase.",\r
"isključeno = prijava imenom i PIN-om",\r
"Javi menadžeru: roba nestaje",\r
"Kasir upisuje prebrojanu gotovinu svog dijela; razlika po kasiru je u X i Z",\r
"Menadžer je obaviješten: {0} — {1}.",\r
"Nema otvorene smjene ili prijavljenog kasira.",\r
"neobavezno kad je artikal izabran",\r
"nestaje danas",\r
"nestaje sutra",\r
"nestaje u narednim danima",\r
"nije zakonska obaveza (ZZP traži cijenu, procenat i iznos popusta na računu)",\r
"npr. ostalo 3 komada, kupci traže",\r
"Očekivano za",\r
"Očekivano za {0}:",\r
"Poslovođa upisuje i mijenja samo kasire i konobare. Šefa i poslovođu upisuje šef.",\r
"Potrebno je izabrati artikal ili upisati šifru.",\r
"Potrebno je upisati prebrojanu gotovinu (npr. 125,50).",\r
"Potvrđujem prodaju",\r
"Prebrojana gotovina mog dijela (€)",\r
"Predaj",\r
"Predaja gotovine — {0}",\r
"Predaja gotovine kasira {0}: prebrojano {1} €, očekivano {2} €",\r
"Predaja gotovine: {0} {1}{2}",\r
"Predaja moje gotovine…",\r
"Predaju gotovine radi prijavljeni kasir.",\r
"predao {0}",\r
"Prijava kasira karticom",\r
"Šifra ili barkod (drugi artikal)",\r
"Upisuje se gotovina koju je kasir primio u ovoj smjeni (njegov dio fioke).",\r
"Upisujem zbir",\r
"Upozorenje ide menadžeru za objekat",\r
"Zbirni račun (fiskalizacija računa)",\r
", dospjelo {0}",\r
", naplata duga",\r
", valuta {0}",\r
"· bez PDV",\r
"· bez PDV {0}{1} · osnovica {2} · PDV {3}{4}",\r
"· limit {0}",\r
"· osnovica",\r
"· rabat {0} %",\r
"( ) na ime plaćanja duga .",\r
"({0}) na ime plaćanja duga{1}.",\r
"(bez fakture — uplata na dug)",\r
"(limit {0}, dug {1}).",\r
"(najstariji od {0} UTC)",\r
"(stanje iz Knjigovodstva)",\r
"{0} — ocjena robe",\r
"{0} — povrat u magacin (raspoloživo {1})",\r
"{0} — račun {1}",\r
"{0} — škart",\r
"{0} · PIB {1}{2}",\r
"{0} (kod kupca {1})",\r
"{0} (traženo {1}, raspoloživo {2})",\r
"{0} fiskalnih računa čeka potvrdu Poreske uprave (JIKR) više od 36 h (najstariji od {1}). Rok za dostavu je dva dana (Zakon o fiskalizaciji, čl. 17). Potrebno je što prije povezati kasu na internet; ako to nije moguće do isteka roka, Poresku upravu je potrebno obavijestiti.",\r
"{0} Naplata gotovinom nije dozvoljena (podešavanje kase). Naplata je moguća karticom ili virmanom.",\r
"{0} Naplata gotovinom nije moguća.",\r
"{0} od {1}{2} — otvoreno {3}",\r
"{0} Prodaja preko zalihe vozila nije dozvoljena.",\r
"{0}: količina ambalaže je cio broj komada.",\r
"{0}: na vozilu {1}.",\r
"{0}: traženo {1}, raspoloživo {2}",\r
"♻ Povrat ambalaže",\r
"💶 Naplata duga",\r
"📋 Razduženje vozača",\r
"📶 Računi bez potvrde Poreske",\r
"🖨 A4 račun",\r
"🚚 Stanje vozila",\r
"Ambalaža",\r
"Ambalaža nije predmet prometa i ne ulazi u osnovicu PDV-a; vraća se ili se zadužuje po vrijednosti.",\r
"Ambalaža nije predmet prometa i nije u osnovici PDV-a.",\r
"Bez odobrenja se ne izdaje",\r
"Bez provjere",\r
"Bez upozorenja nedjeljom i praznikom",\r
"BLOKIRAN",\r
"blokiran za odloženo plaćanje",\r
"Broj {0}",\r
"Broj komada koje kupac vraća. Ambalaža se vodi evidencijski (ZPDV čl. 20 st. 13).",\r
"cijena kase",\r
"cjenovnik {0}",\r
"crveno",\r
"Datum {0}",\r
"Datum i vrijeme",\r
"Dug",\r
"dug {0}",\r
"Dug {0}{1}{2}{3} (stanje iz Knjigovodstva)",\r
"Evidencijski dokument",\r
"gajbe, boce, palete od kupca-firme; stanje ambalaže kod kupca",\r
"Gotovina kupcu {0} uz upozorenje servera (zbir ≥ 10.000 €), odobrio {1}: {2}",\r
"Gotovina kupcu preko zbira 10.000 € (povezane transakcije)",\r
"Gotovina od prodaje",\r
"Gotovina od prodaje {0}, naplata duga {1}.{2}",\r
"Gotovina se ne prima",\r
"HITNO: {0} fiskalnih računa čeka potvrdu Poreske uprave (JIKR) više od 48 h (najstariji od {1}). Rok za dostavu računa izdatih bez veze je dva dana (Zakon o fiskalizaciji, čl. 17). Potrebno je odmah povezati kasu na internet; ako to nije moguće, Poresku upravu je potrebno obavijestiti o razlogu kašnjenja.",\r
"Ispravno (vraća se na stanje)",\r
"iz vozila",\r
"Izaberi",\r
"Izdato",\r
"Izdato kupcima",\r
"Iznos je veći od otvorenog dijela fakture {0} ({1} €).",\r
"Iznos naplate nije ispravan.",\r
"Iznos računa {0} prelazi raspoloživi limit kupca {1}{2}",\r
"Iznos sa PDV",\r
"Kao u Knjigovodstvu. Gotovinski račun i kartica se izdaju bez provjere limita.",\r
"kartica",\r
"Kasa (ENU) {0}",\r
"kasa bez odobravaoca",\r
"KOPIJA",\r
"KOREKTIVNI RAČUN (POVRAT)",\r
"Kupac {0} je blokiran za odloženo plaćanje{1}.",\r
"Kupac nije u šifarniku kupaca-firmi.",\r
"Kupac obavezan prije naplate",\r
"kupac-firma plaća otvorenu fakturu ili dug; priznanica (nije fiskalni račun), gotovina u kasu",\r
"limit {0}",\r
"Limit i blokada kupca (virman, odloženo)",\r
"Limit kupca",\r
"Na vozilu nema dovoljno robe: {0}. Račun nije izdat.",\r
"Najveća količina stavke",\r
"Najviše {0} (otvoreni dio fakture).",\r
"Naplata duga",\r
"Naplata duga (gotovina)",\r
"Naplata duga gotovinom uz odobrenje ({0}) — {1}",\r
"Naplata je upisana: {0} ({1}).",\r
"Naplata na terenu.",\r
"Nastavi",\r
"Ne izdaje se",\r
"Nema kupca-firme sa tim PIB-om ili nazivom. Kupci-firme stižu iz Knjigovodstva (paket kase).",\r
"Nepoznat artikal ambalaže: {0}",\r
"Neto kod kupaca",\r
"Nije fiskalni račun",\r
"Nije upisana nijedna količina ambalaže.",\r
"Objekat ove kase je veleprodajni. Način rada „Veleprodaja\\" se bira u Podešavanja → Režim rada.",\r
"Objekat ove kase je vozilo (pokretni poslovni prostor). Način rada „Teren\\" se bira u Podešavanja → Režim rada.",\r
"Objekat ove kase u Knjigovodstvu je {0}.",\r
"Objekat: {0}",\r
"Odloženo plaćanje preko limita / blokiranom kupcu uz odobrenje ({0}) — {1}, račun {2}",\r
"Odloženo plaćanje preko limita ili blokiranom kupcu",\r
"Otvorena je nova smjena (#{0}) za naplatu duga gotovinom.",\r
"Pakovanja: {0} (npr. „3 {1}\\")",\r
"PDF (A4)",\r
"PDF je sačuvan: {0}",\r
"PDV stopa",\r
"PIB ili naziv kupca-firme:",\r
"po računu / fakturi br.",\r
"Po stanju vozila nema dovoljno robe:\\n{0}\\n\\nNastaviti?",\r
"Potrebno je upisati bar jednu količinu.",\r
"Potrebno je upisati kupca (PIB i naziv) — način rada „Veleprodaja\\" / „Teren\\".",\r
"Povrat ambalaže",\r
"POVRAT AMBALAŽE",\r
"Povrat ambalaže je upisan.",\r
"povrat robe u magacin, škart, predaja gotovine i ambalaže",\r
"Povrat u magacin",\r
"Povrat u magacin je izbrojana roba koja se vraća; razlika prema stanju vozila je manjak (ili višak).",\r
"Povratna ambalaža",\r
"Povratna ambalaža — evidencijski (ZPDV čl. 20 st. 13)",\r
"Povratna ambalaža nije upisana u Knjigovodstvu (paket kase nema ambalažu).",\r
"Povratna ambalaža se vodi evidencijski (ZPDV čl. 20 st. 13) i nije predmet prometa.",\r
"Povratna ambalaža uz prodaju kupcu-firmi",\r
"Poziv na broj",\r
"Poziv na broj:",\r
"Predao (kupac)",\r
"Predao (vozač)",\r
"Predata gotovina (€) — za predaju {0}",\r
"Predata gotovina ne može biti negativna.",\r
"Predata gotovina nije ispravna.",\r
"Primio ({0})",\r
"Primio (magacin / blagajna)",\r
"Priznanica",\r
"PRIZNANICA",\r
"Priznanica {0}",\r
"Priznanica nije fiskalni račun (plaća se već izdat račun). Gotovina ulazi u kasu (smjenu).",\r
"Priznanica potvrđuje uplatu po već izdatom računu i ne zamjenjuje fiskalni račun. Gotovina se uplaćuje na račun firme (predaja pazara).",\r
"Priznanica potvrđuje uplatu po već izdatom računu i ne zamjenjuje fiskalni račun. Gotovina se uplaćuje na račun firme (predaja pazara).{0}",\r
"Probni rad — račun nije prijavljen Poreskoj upravi.",\r
"Prodaja iz vozila (pokretni poslovni prostor).",\r
"Prodaja preko zalihe vozila (teren)",\r
"Prodato",\r
"R.br.",\r
"Rabat",\r
"Rabat %",\r
"rabat kupca",\r
"Račun / faktura",\r
"Račun A4 {0}",\r
"Račun je izdat na kasi",\r
"Račun je izdat na kasi {0}. {1}",\r
"Račun sa odloženim plaćanjem se izdaje samo uz odobrenje. Gotovinski račun i kartica se izdaju bez odobrenja.",\r
"Računi bez potvrde Poreske uprave:",\r
"Računi bez potvrde Poreske uprave: {0}.",\r
"Računi koji čekaju potvrdu Poreske uprave:",\r
"Raspoloživo",\r
"Razduženje je upisano.",\r
"Razduženje je upisano. Razlika kod {0} artikala.",\r
"Razduženje vozača",\r
"RAZDUŽENJE VOZAČA",\r
"Razduži",\r
"Robu izdao",\r
"Robu primio (potpis i pečat kupca)",\r
"rok {0} d.",\r
"Škart",\r
"Škart (ne prodaje se)",\r
"Stanje ambalaže kod kupca poslije povrata:",\r
"Stanje vozila",\r
"STANJE VOZILA",\r
"Teren (prodaja iz vozila)",\r
"U načinu rada „Veleprodaja\\" / „Teren\\" potrebno je upisati kupca (PIB i naziv) prije naplate. Račun nije izdat.",\r
"ugovorna cijena{0}",\r
"Ukupno za predaju",\r
"Upiši povrat",\r
"Uplatilac",\r
"Uplatio",\r
"Upozorenje",\r
"Upozorenje uz odobrenje",\r
"Upozori (preko limita); blokada uz odobrenje",\r
"Utovar (podatak)",\r
"utovar, prodato, raspoloživo; štampa zaduženja vozila",\r
"Utovareno",\r
"Uz račun",\r
"Veleprodaja (cash & carry, kupci-firme)",\r
"Veleprodaja i teren",\r
"veleprodajni — predlaže se režim „Veleprodaja\\"",\r
"Vozač",\r
"Vozilo",\r
"vozilo (pokretni poslovni prostor) — predlaže se režim „Teren\\"",\r
"Vraćeno od kupaca",\r
"Za ovo vozilo nema podatka o utovaru (zaliha vozila stiže iz Knjigovodstva uz paket kase).",\r
"Zabrana rada nedjeljom (Zakon o unutrašnjoj trgovini, čl. 35b) odnosi se na trgovinu na malo. Ako objekat prodaje i građanima, potrebno je isključiti.",\r
"Zaliha vozila",\r
"Zbir gotovine kupca dostiže 10.000 € (čl. 65 st. 2).",\r
"Zbir gotovine kupca na serveru ≥ 10.000 €",\r
"Zbir sa ostalim kasama i Knjigovodstvom nije provjeren (nema veze sa serverom).",\r
"Limit i blokada kupca",\r
"Teren: prodaja preko zalihe vozila",\r
"— čeka se potvrda kase…",\r
"Naplata {0} — čeka se potvrda kase…",\r
"Račun bez oznake naknadne dostave mora imati vrijeme slanja jednako vremenu izdavanja (Poreska ga inače odbija, greška 11).",\r
"Snimanje baze… Izdati računi su sačuvani; kasa nastavlja za trenutak.",\r
"Uređaj nije pokrenuo štampu u roku od 30 sekundi. Potrebno je ponoviti štampu."\r
]\r
`;export{a as default};
