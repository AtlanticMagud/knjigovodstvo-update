const a=`[\r
"-Command",\r
"-ExecutionPolicy",\r
"-NonInteractive",\r
"-NoProfile",\r
"— (kasa Vergi İdaresi'ne kaydedilene kadar)",\r
"— (bilgisayar yerel ağda değil)",\r
"— (Ayarlar → Fiskalizasyon'da girilir)",\r
"— {0}+{1} bedava",\r
"— masasız —",\r
"— fiyatlar güncellendi.",\r
"— reçetedeki ilaç verilir —",\r
"— kart (POS)",\r
"— kiosk olarak kayıtlı kasa (örn. dükkânın önünde). Pazar günleri ve tatillerde de çalışır, yalnızca kiosk için izin verilen mallarla.",\r
"— dükkânın içindeki kasa. Pazar günleri ve tatillerde çalışmaz (İç Ticaret Kanunu md. 35b).",\r
"— {0} adetten itibaren {1}",\r
"— havale ile öder",\r
"— TEKRAR",\r
"— oda hesabı",\r
", kasa ise şununla çalışıyor:",\r
", ancak tamamen değil. Bakım ekibine başvurun.",\r
", kullanılan",\r
", kasiyer {0}",\r
", lisans {0}",\r
", lot {0}",\r
", {1} tutarın {0} kadarı tahsil edildi{2}",\r
", {0} tarihli",\r
", onay {0}",\r
", fişsiz onaylanan:",\r
", bu nedenle önceki sürüm geri yüklendi. Bakım ekibinin bilgilendirilmesi gerekir.",\r
", bu nedenle önceki geri yüklendi. Bakım ekibinin bilgilendirilmesi gerekir.",\r
", PIB {0}",\r
", kartla ödeme (POS)",\r
", ind.",\r
", Vergi İdaresi",\r
", referans numarası",\r
", atlanan {0}",\r
", fatura {0}",\r
", fiş iptali, ayarlar, kasiyerler ve kasa değişikliği onun PIN'ini gerektirir.",\r
", geçerlilik:",\r
", geçerlilik: {0}{1}.",\r
", iade edilen {0}",\r
", malın değeri katalog fiyatlarıyla",\r
"; ürün artık satılmıyor",\r
"; fiyatlar: {0}",\r
"; o zamana kadar: \\"Manuel onay\\" veya \\"Deneme terminali\\".",\r
"; beklemede: {0} mesaj.",\r
"; geri kalanı masa {0}'da",\r
"; tüm kayıtlar korundu.",\r
": tartılan ürünler (kg), kg fiyatı ve PLU numarasıyla, tartı yazılımına içe aktarmak için.",\r
": teslimat (\\"Wolt 123\\" gibi bir masa olarak sipariş), mutfak ekranı (\\"Mutfak\\" modunda tablet veya Daha fazla → Mutfak ekranı), rezervasyonlar ve salon düzeni (masa görünümü).",\r
": tutar",\r
": tutar {0}, kullanılan {1},",\r
": nakit tahsilatta ve \\"Çekmeceyi aç\\" düğmesiyle açılır (kaydedilen bir nedenle). Çekmece genellikle termal yazıcıya bağlıdır.",\r
": fiş düzenlenmeden önce terminalden onay (reddedilen kart için fiş düzenlenmez); Android'de ayrıca telefonla tahsilat için bankanın uygulaması (SoftPOS; paket adı, bankanın uygulamasının Google Play adresindedir). Anlık ödeme: müşteri kendi bankasından firmanın hesabına öder; Vergi İdaresi'ne \\"OTHER-CASH\\" olarak gider (test sisteminde doğrulama gerekir).",\r
": terazi barkodu kuralları \\"önekler:tür:ürün haneleri:değer haneleri:ondalık\\" biçiminde, noktalı virgülle ayrılmış; tür: tezina (ağırlık) | iznos (tutar) | komad (adet). Örnek: \\"27,28:iznos:5:5:2; 2:tezina:5:5:3\\". Boş = varsayılan kural (önekler 20–29, ağırlık).",\r
": kupon satışı (Daha fazla → Hediye kuponları) ve kuponla ödeme (Diğer yöntemler → Kupon). Kupon firmanın tüm kasalarında geçerlidir (sunucu üzerinden veri alışverişi). Kupon satışı KDV'li bir mali fiştir (tek amaçlı kupon), kuponla ödeme ise Vergi İdaresi'ne \\"SVOUCHER\\" olarak bildirilir. Bu yöntemi",\r
": fiş ve kupon sürücüsüz olarak doğrudan termal yazıcıya gider (daha hızlı, kağıt kesme ve QR kodu ile). Android'de ayrıca Bluetooth yazıcıya ve Android kasanın yerleşik yazıcısına (\\"InnerPrinter\\") gider.",\r
": tüm ürünlerin fiyatı, kg / l fiyatı ve kampanya sırasındaki önceki en düşük fiyatıyla tablosu, etiket yazılımına içe aktarmak için.",\r
": tüm ürünlerin fiyatı, kg / l fiyatı ve kampanya sırasındaki önceki en düşük fiyatıyla tablosu, etiket yazılımına içe aktarmak için. {0}",\r
": katalogda {0}",\r
". Kasa bu kodla {0} tarihinde başka bir programda fiş düzenlediyse, son fiş numarasının girilmesi gerekir (Ayarlar → Fiskalizasyon → \\"Ayarla…\\").",\r
". Mali fiş ödeme sırasında düzenlenir.",\r
". Kasa bu mali bilgiyi otomatik olarak değiştirmez (kasa, Vergi İdaresi'ne kendi iş yeri için kayıtlıdır). Doğru kod SEP'te doğrulanır: fiyat listesindeki kod doğruysa \\"İş yeri kodu\\" alanına (Mali onay) girilir ve kaydedilir; kasadaki kod doğruysa düzeltme Muhasebe'de yapılır (Kasa fiyat listesi → Kasalar ve mağazalar).",\r
". Listedeki ENU kodu, daha önce kayıt edilmiş bir kasanın kodudur. Yeni ENU kodu girilene (kasa kaydı) veya şef mevcut kodu önceki kasanın son fiş numarasıyla birlikte onaylayana kadar kasa fişleri Vergi İdaresi'ne göndermez (Ayarlar → Fiskalizasyon).",\r
". Telefonda kalırlar ve girişten sonra gönderilirler. Çıkış yapılsın mı?",\r
". Diğer ürünlere arama ile ulaşılabilir.",\r
". Kalemler girildikten sonra: \\"Sipariş fişini gönder\\" veya \\"Masaya\\"; tahsilat masayı kapatır.",\r
". QR kodu 10 dakika geçerlidir ve yalnızca tek bir telefon içindir.",\r
". Fiş, para geldiğinde düzenlenir.",\r
". Şu anda girilen:",\r
". A4 üzerine 4 adet A6 kart basılır (stand veya etiket).",\r
"… ve diğer",\r
"… ve {0} tane daha",\r
"· {0} ürün · {1} masa · kasa {2} · sipariş {3}",\r
"· {0} bekliyor",\r
"· © 2026 Dragomir Dačević, yazar ve hak sahibi. Tüm hakları saklıdır.",\r
"· kampanya sonu {0}.{1}.",\r
"· kampanya: {0}",\r
"· antibiyotik (reçete 3 gün geçerli)",\r
"· barkod {0}{1}",\r
"· puan: {0}",\r
"· puan +{0}{1} = {2}",\r
"· no. {0}",\r
"· bekleyen: {0}",\r
"· kasa fiyatı {0} €",\r
"· fiyatlar kontrol edildi {0}{1}",\r
"· etiketlere eklendi",\r
"· giriş {0}",\r
"· HATA",\r
"· grup {0}",\r
"· IKOF {0}",\r
"· kasa {0}",\r
"· kasa sunucu ile eşleştirilmemiş",\r
"· {0} saatinden beri gecikti",\r
"· garson {0}",\r
"· FZO listesi: {0}",\r
"· FZO listesinde değil",\r
"· kasa menüsünde yok",\r
"· kontrol edilmedi",\r
"· çıkış {0}",\r
"· çıkış {0} idi",\r
"· onay {0}",\r
"· avans ödendi",\r
"· indirim {0}",\r
"· indirim {0} %",\r
"· Kasa göndermeye hazır olduğunda Vergi İdaresi'ne bildirilecektir.",\r
"· para üstü {0}",\r
"· çağrılar: {0}",\r
"· atlanan {0} (fiyat 0,01 €'nun altında veya {1} €'nun üzerinde olurdu)",\r
"· fiş iptal edildi",\r
"· fiş no. {0}",\r
"· sıra {0}",\r
"· sertifika {0} {1} daha geçerli",\r
"· vardiya #{0}",\r
"· kasada {0}",\r
"· eşleştirildi {0} · {1}",\r
"· sunucuyla eşleştirildi",\r
"› arama \\"{0}\\"",\r
"\\"{0}\\" yazdırmaz, dosyaya kaydeder. Ayarlar'dan gerçek bir yazıcı seçin.",\r
"\\"Odaya\\": odadaki misafirin fişi hemen tahsil edilmez, oda hesabına eklenir ve çıkışta ödenir (toplu fiş). Sunucu bağlantısı gerekir.",\r
"\\"Yeni kasa olarak başlat\\", kasa kurulumu 1.8.0'dan itibaren çalışır (yeni Setup).",\r
"\\"Yeni kasa olarak başla\\" kurulu kasada çalışır (Windows, Android).",\r
"\\"Yeni kasa olarak başla\\" için kasa kurulumu 1.8.0 veya üzeri gerekir (yeni Setup).",\r
"\\"Yeni kasa olarak başlat\\": kasa, ilk kurulumdan sonraki gibi başlar (firmaya bağlantı, fişsiz, kasiyersiz ve ayarsız) — ör. başka bir firma için kasa. Mevcut veriler silinmez: veritabanı yedeğiyle birlikte, kasanın veri klasörü içinde tarihli ayrı bir klasöre taşınır. Yalnızca amir, vardiya kapatıldıktan sonra.",\r
"Son fişin {0} \\"iptali\\" ({1})",\r
"Son fişin \\"İptali\\" amirin PIN'ini gerektirir",\r
"\\"Kasadan QR tara\\"",\r
"\\"Geçerlilik bitişi\\", \\"geçerlilik başlangıcı\\"ndan önce.",\r
"\\"Geçerlilik bitişi\\" geçmişte olamaz.",\r
"\\"Geçerlilik başlangıcı\\" geçmişte olamaz.",\r
"( , ort.",\r
"({0} veya daha yeni)",\r
"({0} kişi-gece)",\r
"({0} fiş)",\r
"({0} zaten mevcut)",\r
"({0}) AND {1}",\r
"(üst grup yok)",\r
"(işaretsizler atlanır)",\r
"(alt grup yok)",\r
"(girişsiz)",\r
"(\\"Yeni fiyatlar\\" düğmesi).",\r
"(kasa ENU, mağaza). Kod ile kasa, firmaya sunucu üzerinden bağlanır, fiyatları otomatik alır ve değişiklikleri ile kapanışları Muhasebe'ye gönderir.",\r
"(Bilgisayar için Google Drive; Muhasebe ve Yönetici'nin paylaştığı klasör).",\r
"(ve {0} tane daha)",\r
"(ve bu fişten daha önce çıkarılan: {0})",\r
"({0} önce sona erdi)",\r
"(her yazdırmada seçim)",\r
"({0} kaldı)",\r
"(telefonla sadakat müşterileri): müşteri puan biriktirir ve bunları indirim olarak harcar; firmanın tüm kasalarında geçerlidir.",\r
"(yerel sunucu)",\r
"(pasif)",\r
"(PIN yok)",\r
"(yok; hepsi tek sipariş fişinde)",\r
"(listeden seçilmedi).",\r
"(ciro değildir)",\r
"(toplama dahil değil)",\r
"(girilmemiş: Ayarlar → Ek özellikler)",\r
"(yeni ürün: {0})",\r
"(yeni ürün {0})",\r
"(onay {0})",\r
"(şef onayladı)",\r
"(matrah",\r
"(matrah",\r
"(matrah {0})",\r
"(p.broj = ?{0})",\r
"(PIB {0})",\r
"(\\"Belgeler\\" içinde senkronizasyonun doldurduğu alt klasör, varsayılan olarak \\"KnjigSync\\").",\r
"(indirim {0})",\r
"(Vergi İdaresi)",\r
"(boş kod)",\r
"(hesap {0})",\r
"(rulo)",\r
"(satıştan gizlenir; onay işareti kaldırılarak geri getirilir)",\r
"(uyuyor)",\r
"(fiş yazıcısı)",\r
"(iptal edildi)",\r
"(daha önce kaldırıldı)",\r
"(tasarruf",\r
"(adet başına {0} tasarruf)",\r
"(her zaman)",\r
"(zaten fişleri var)",\r
"(sürüm {0})",\r
"(Daha fazla → Uyarılar; Yönetici): storno, iptal, fişsiz çekmece ve limitin üzerindeki nakit her zaman bildirilir; diğer uyarılar için aşağıdaki limitler geçerlidir.",\r
"(sadakat)",\r
"(dolu, birleştirme)",\r
"), kasaya aktarılır (USB, e-posta, Drive) ve burada yüklenir.",\r
"). Ayrıntılar \\"Kasa\\" bölümündeki notta.",\r
"[DllImport(\\"winspool.drv\\", CharSet = CharSet.Unicode, SetLastError = true)] public static extern bool OpenPrinter(string p, out IntPtr h, IntPtr d);",\r
"[DllImport(\\"winspool.drv\\", CharSet = CharSet.Unicode, SetLastError = true)] public static extern int StartDocPrinter(IntPtr h, int l, DI d);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool ClosePrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool EndDocPrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool EndPagePrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool StartPagePrinter(IntPtr h);",\r
"[DllImport(\\"winspool.drv\\", SetLastError = true)] public static extern bool WritePrinter(IntPtr h, byte[] b, int n, out int w);",\r
"[KasaRaw]::Posalji($env:KASA_RAW_STAMPAC, [Convert]::FromBase64String([IO.File]::ReadAllText($env:KASA_RAW_FAJL)))",\r
"[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] public class DI { public string n; public string o; public string t; }",\r
"{0}\\n\\nMüşteri 18 yaşında veya daha büyük mü?",\r
"{0}\\n\\n\\"Fişleri Vergi İdaresi'ne gönder\\" etkinken ve bu düzeltilmediği sürece kasa fiş düzenlemez.\\n\\nDüzeltilene kadar gönderim kapatılsın mı (deneme çalışması)?",\r
"{0}\\n\\nÇalışma saatleri dışında fiş düzenlemek onay gerektirir.",\r
"{0}\\n\\n{1} tutarı terminale girilmelidir. Fiş, terminal ödemeyi onayladığında düzenlenir. Slipteki onay numarası:",\r
"{0}\\n\\n{1}{2} ödemesi terminalin kendisinde iptal edilmelidir. İşlem çözülene kadar \\"Terminal işlemleri\\" listesinde kalır.",\r
"{0}\\n(örn. buzsuz, sütlü, iyi pişmiş)",\r
"{0}\\n{1} kg = {2}\\n\\nMiktar onaylansın mı?",\r
"{0} — {1} EUR",\r
"{0} — {1} EUR {2}",\r
"{0} — {1} EUR. Kalem tahsilat yapılmadan kapatılır ve bakiyeye dahil edilmez.",\r
"{0} — dosyalar kasada bekliyor.",\r
"{0} — oda hesabı {1}",\r
"{0} — yazdırma daha önce bellek yetmediği için kesildi: kasayı kapatıp yeniden başlatın.",\r
"{0} · {1} – {2} · {3} gece",\r
"{0} · {1} (çalışmayı kısıtlamaz)",\r
"{0} · {1} EUR (serbest {2})",\r
"{0} · {1} tarihine kadar · bakiye {2} EUR",\r
"{0} · {1} tarihine kadar{2}{3}",\r
"{0} · KDV {1}%",\r
"{0} · PIB {1}",\r
"{0} · indirim {1} %",\r
"{0} · masalar",\r
"{0} · aranan: {1}",\r
"{0} · sadakat {1} %",\r
"{0} (odasız)",\r
"{0} (masa {1})",\r
"{0} (en fazla {1})",\r
"{0} (katalogda yok)",\r
"{0} (bulunamadı)",\r
"{0} (PIB {1})",\r
"{0} {1}",\r
"{0} AND {1}",\r
"{0} ürün",\r
"{0} ürün ({1})",\r
"{0} ürün",\r
"{0} paket boyutsuz (etikette kg / l fiyatı olmayacak)",\r
"{0} no. {1}",\r
"{0} bekliyor",\r
"{0} bugün yok",\r
"{0} Ayrıntılar: etikete tıklayın.",\r
"{0} Bu düzeltilene kadar fiş düzenlenmez.",\r
"{0} etiket",\r
"{0} etiket",\r
"{0} EUR",\r
"{0} EUR {1}",\r
"{0} dosya",\r
"{0} dosya gönderilmeyi bekliyor",\r
"Fişteki ({1}) ve fiskalizasyondaki ({2}) firma {0} aynı olmalıdır.",\r
"{0} adlı müşterinin {1} puanı var (değeri {2}). Bu fiş için puan sayısı (en çok {3}):",\r
"{0} Seçim kasada kaydedildi.",\r
"{0} deneme modunda düzenlendi (Vergi İdaresi'ne bildirilmedi), bu nedenle gerçek belge ona atıfta bulunamaz.",\r
"{0} hâlâ deneme amaçlı ({1}). Vergi İdaresi'nin atadığı bir kod gereklidir.",\r
"{0}, bekleyen bir fişte (beklemede veya masada). Birim ve KDV ancak o fiş tahsil edildikten veya silindikten sonra değiştirilebilir.",\r
"{0} ekrandaki fişte. Birim ve KDV, fiş tahsil edildiğinde veya silindiğinde değiştirilebilir.",\r
"{0} Vergi İdaresi tarafından reddedildi. Önce yeniden gönderilmesi gerekir (Fişler → Gönderilmeyenler).",\r
"{0} boş.",\r
"{0} çok büyük.",\r
"{0}, {1} × {2} pikselden büyük.",\r
"{0}, {1} KB'tan büyük.",\r
"{0} kg · {1}",\r
"{0} dk",\r
"{0} için PIN yok. PIN kasada girilir (Ayarlar → Kasiyerler).",\r
"{0} bir sayı değil.",\r
"{0} hiçbir fiş silinmedi.",\r
"{0} gönderilmedi",\r
"{0}, 2026-07-31T07:01:00+02:00 biçiminde değil (verilen: \\"{1}\\").",\r
"{0}, ab123ab123 biçiminde değil (verilen: \\"{1}\\").",\r
"{0} ab123ab123 biçiminde değil (girilen: {1}).",\r
"{0} girilmemiş.",\r
"{0} düzenlenmiş bir fişten hiçbir kalem kaldırılmadı.",\r
"{0} Hiçbir şey düzenlenmedi.",\r
"{0} gece",\r
"{0} Yeni vardiya açılamaz.",\r
"{0}, {1} tarihli",\r
"{0} reddedildi",\r
"{0} İade terminalde yapılmalıdır.",\r
"{0} reçete",\r
"{0} artık satılmıyor. Ürünün fişten çıkarılması veya zayi olarak kaydedilmesi gerekir (Daha fazla → Mal zayiatı).",\r
"{0} artık satılmıyor. Ürünün fişten kaldırılması gerekiyor.",\r
"{0} artık satılmıyor. Bu ürünü içeren fiş tahsil edilemez; yalnızca zayi mümkündür (Daha fazla → Mal zayi).",\r
"{0} kalem",\r
"{0} Bu nedenle yazdırma, yazıcı seçim penceresi üzerinden yapılır; bu pencere olmadan yazdırmak için fiş yazıcısını seçin.",\r
"{0} kalem",\r
"{0} kalem",\r
"{0} kalem",\r
"{0} adet 3 kattan büyük (işaretli)",\r
"{0} artık satışta değil",\r
"{0} Onaylamak için \\"Kaydet\\"e (Enter) bir kez daha basın.",\r
"{0}, bunların {1} tanesi bu noktanın fiyatıyla",\r
"{0}, hepsi genel fiyatlarla",\r
"{0}: {1} ({2} dk sonra yeniden deneme)",\r
"{0}: KDV'den muaf ürünün oranı 0 olmalıdır (verilen: %{1}).",\r
"{0}: fiş numarası pozitif bir tam sayı olmalıdır.",\r
"{0}: saat 14:00 biçiminde",\r
"{0}: fiyat negatif olamaz (iptalde miktar negatiftir).",\r
"{0}: bir tarih veya null.",\r
"{0}: firma KDV sisteminde değil, ancak kalem KDV içeriyor.",\r
"{0}: tarih seçin.",\r
"{0}: 0 ile 100 % arasında",\r
"{0}: miktar sıfır.",\r
"{0}: reçeteli ilaç. Yalnızca reçeteyle verilebilir (Reçeteyle verme).",\r
"{0}: ad zorunludur.",\r
"{0}: negatif miktar yalnızca düzeltme fişinde (iptal) mümkündür.",\r
"{0}: geçersiz sayı",\r
"{0}: geçersiz fiyat.",\r
"{0}: geçersiz miktar.",\r
"{0}: geçersiz KDV oranı.",\r
"{0}: bilinmeyen KDV muafiyet dayanağı \\"{1}\\".",\r
"{0}: muafiyet dayanağı yalnızca 0 oranıyla kullanılabilir (verilen: %{1}).",\r
"{0}: \\"{1}\\" muafiyet kodu bilinmiyor veya oran %0 değil.",\r
"{0}: {1} adetlik paket. {2} adet eklendi.",\r
"{0}: veriler kaydedildi.",\r
"{0}: indirim negatif olamaz.",\r
"{0}: şefin PIN'i gereklidir.",\r
"{0}: son kullanma tarihi {1}.",\r
"{0}: son kullanma tarihi {1} tarihinde geçti. Ürün eklenmedi.",\r
"{0}: %{1} KDV oranı mümkün değil.",\r
"{0}: tam sayı girin.",\r
"{0}. Mali fiş ödeme sırasında düzenlenir.",\r
"{0}{1} — {2}, {3}.\\nSilme işlemi silinenler kaydında kalır (Daha fazla → Silinen fişler); fiş oradan geri getirilebilir.",\r
"{0}{1} · {2} kalem{3}{4}",\r
"{0}{1} · {2} karakter",\r
"{0}{1} {2} yazdırıldı.",\r
"{0}{1} yazdırılmadı (yazıcı). Kasaya bildirildi; yazıcı çalıştığında yeniden gönderilmesi gerekiyor.",\r
"{0}a.sifra IN ({1})",\r
"{0}dosyalar kasada bekler ve bağlantı kurulunca gönderilir.",\r
"{0}{1} düzenlenmedi: {2} Kalanı yeniden tahsil edin; düzenlenmiş belgeler ikinci kez düzenlenmez.",\r
"{0}Gönderilmedi: kasa, deneme servisine gönderilmeden önce ÜRETİM ortamına geçti.",\r
"{0}Dosyadan paket (internetsiz)",\r
"{0}Vergi İdaresi servisi bu iletiyi {1} kez kabul etmedi ve neden belirtmedi (diğer iletileri kabul etti). Son yanıt: {2} {3} öğesini kontrol edip yeniden gönderin.",\r
"{0}{1} numaralı masadaki her şey zaten gönderildi.",\r
"{mjesto}: {naziv} · {stara} → {nova}",\r
"*izbor-pri-svakoj-stampi*",\r
"&amp;",\r
"&gt;",\r
"&lt;",\r
"&quot;",\r
"%\\"kljuc\\":\\"{0}\\"%",\r
"%\\"tip\\":\\"korekcija\\"%",\r
"%\\"tip\\":\\"namjera\\"%",\r
"%\\"tip\\":\\"prijava\\"%",\r
"%\\"uid\\":\\"{0}\\"%",\r
"•••••••• (kayıtlı; boş = değişiklik yok)",\r
"← Başka kasiyer",\r
"← Listeye dön",\r
"↩ Malın {0} iadesi…",\r
"＋ {0} bu noktada",\r
"+ Bu kodla yeni ürün",\r
"± tutar (€)",\r
"± yüzde (%)",\r
"<!doctype html>",\r
"= KASADA",\r
"★ Hızlı",\r
"⚠ Uyarılar (30 gün)",\r
"⟳ Menüyü şimdi yayınla",\r
"🍽 Masa hesabını böl",\r
"🏢 {0} · PIB {1}",\r
"🏢 Müşteri ekle…",\r
"💳 Kasa cihazları",\r
"💳 Kasa cihazları{0}",\r
"📝 Menü içeriği",\r
"📝 Menü içeriği (adlar, açıklamalar, görseller, diller)",\r
"📤 Fiyatları dışa aktar",\r
"📱 Garsonlar: {0}",\r
"📱 Masalarda QR menü",\r
"📱 Masalarda QR menü",\r
"📱 QR menü{1}{2}",\r
"📷 Kasadaki QR'ı tara",\r
"🔍 Ada veya koda göre ara (tüm ürünler)…",\r
"🔍 Ara: nokta veya kasa kodu…",\r
"🖨 A4 / PDF",\r
"🖨 Rulo",\r
"🖨 Yazdır (Z)",\r
"🖨 Belgeyi yazdır",\r
"🖨 Kopyayı yazdır",\r
"🖨 Ara raporu yazdır (X)",\r
"🧑‍🍳 Mutfak ekranı",\r
"🧑‍🍳 Mutfak",\r
"🧾 Misafir hesabı istiyor",\r
"🧾 Hesap",\r
"🙋 Garsonu çağırıyor",\r
"🚫 Bugün yok",\r
"🚫 Bugün yok",\r
"🛟 Destek: yeni yanıt",\r
"🛟 Destek",\r
"$ErrorActionPreference = \\"Stop\\"",\r
"0 = sınırsız",\r
"0 = sınırsız.",\r
"0 = mesaj yok",\r
"0 = yalnızca süresi geçmiş",\r
"1. Muhasebe'den kod (önerilir)",\r
"288 hariç 28",\r
"2B barkod (GS1 DataMatrix / QR)",\r
"4–8 hane; boş = değişiklik yok",\r
"4–8 hane; boş = PIN yok",\r
"400 ve 404 hariç 40",\r
"58 mm (32 karakter)",\r
"6A4D-92DE-B3DB-A31D",\r
"80 mm (42 karakter)",\r
"80 mm (48 karakter)",\r
"a.naziv_n LIKE ?",\r
"ABSOLUT",\r
"ACCOUNT",\r
"ACTIMEL",\r
"ACTIVIA",\r
"Add-Type -TypeDefinition @\\"",\r
"yönetici",\r
"Adres",\r
"FZO WebService adresi",\r
"IRIS adresi (hemen çalışır): {0}",\r
"Kasa adresi",\r
"Kasa adresi: {0}",\r
"Müşteri adresi",\r
"Yerel sunucu adresi girildi. Eşleştirme: eşleştirme kodu, ardından \\"Bağlan\\" / \\"Eşleştir\\".",\r
"Misafir menüsü adresi",\r
"Sunucu adresi",\r
"Sunucu adresi \\"https://\\" ile başlamalıdır.",\r
"Sunucu adresi https değil.",\r
"Sunucu adresi geçerli değil.",\r
"Sunucu adresi, API anahtarı ve API sırrı zorunludur.",\r
"Cihaz adresi geçerli değil (IP:port).",\r
"Cihaz adresi geçerli değil. IP adresi ve port girilmelidir (ör. 192.168.1.60:8888).",\r
"Güncelleme adresi",\r
"Güncelleme adresi geçerli değil.",\r
"Güncelleme adresi ayarlanmadı.",\r
"Yeni sürümü indirme adresi kullanılamıyor.",\r
"Tablet adresi:",\r
"ADVANCE",\r
"AES-GCM",\r
"Acente",\r
"AJVAR",\r
"Kampanya",\r
"kampanya ·",\r
"kampanya · {0}",\r
"Kampanya \\"{0}\\": {1}{2}",\r
"Eylem (Intent)",\r
"KAMPANYA −",\r
"KAMPANYA −{0}",\r
"akcija TEXT",\r
"kampanya: {0}",\r
"Kampanyalar ve sadakat",\r
"kampanya fiyatı",\r
"Saat şu anda doğruysa (daha önce yanlışlıkla ileri alınmıştı), yönetici bunu PIN ile onaylar. Aksi halde cihazdaki tarih ve saat ayarlanmalıdır. O zamana kadar fiş düzenlenemez.",\r
"Cihaz saati yanlışlıkla ileri alınıp sonra düzeltildiyse, kasa fiş düzenlemeyi reddeder (saat geri alınmış). Bu düğmeyle amir, saatin artık doğru olduğunu onaylar.",\r
"Tür bilinmiyorsa seçim Mağaza'dır; türün Muhasebe'de de girilmesi gerekir.",\r
"aktivan",\r
"Aktif",\r
"Aktif bir ENU değiştirilemez.",\r
"aktivna",\r
"aktif",\r
"alerjenler",\r
"Alerjenler (Tüketicilerin gıda hakkında bilgilendirilmesi yönetmeliği)",\r
"ALEVA",\r
"alkol",\r
"Alkollü – Bira",\r
"Alkollü – Şarap",\r
"Alkollü – Sert içkiler",\r
"ALU FOLIJ",\r
"AMARETTO",\r
"AMARO",\r
"AMEX",\r
"AMSTEL",\r
"analitik",\r
"Analiz",\r
"Analiz {0} – {1}",\r
"AND {0}",\r
"AND client_uid=?",\r
"AND id=?",\r
"AND kasa_id = ?",\r
"AND p.godina = ?",\r
"AND rezervacija = {0}",\r
"Andrijevica",\r
"Android",\r
"Antibiyotik",\r
"AnyDesk / RustDesk",\r
"APEROL",\r
"API anahtarı",\r
"API sırrı",\r
"Banka uygulaması (SoftPOS paketi)",\r
"Banka uygulaması belirsiz bir sonuç döndürdü.",\r
"Bu cihazdaki banka uygulaması (Android)",\r
"Banka uygulaması tutarı kasadan almıyor.",\r
"Uygulamada kasa listesi yok. Bir veri paketinin (dosya) içe aktarılması gerekir.",\r
"Kupon nominal değerleri (€, virgülle ayrılmış)",\r
"Eczane — ayarlar",\r
"application/json; charset=utf-8",\r
"APPROVED",\r
"APPROVED,OK,0,00",\r
"Nisan",\r
"Nisan",\r
"AQUA",\r
"AQUA VIVA",\r
"AQUAFRESH",\r
"Arapça",\r
"ARASID",\r
"ARAŠID",\r
"ARIEL",\r
"AROXOL",\r
"Ürün",\r
"\\" \\" ürünü bulunamadı.",\r
"\\"{0}\\" ürününün {1} barkodu yok.",\r
"\\"{0}\\" ürünü bulunamadı.",\r
"\\"{0}\\" ürününün zaten {1} barkodu var.",\r
"{0} ürünü bu fişte yok.",\r
"{0} ürünü katalogda yok.",\r
"Bon ürünü oluşturulmadı. Nominal değerleri kontrol edin (Ayarlar → Ek özellikler).",\r
"Ürün eklendi: {0}, {1}, kod {2}.",\r
"Ürün zaten listede.",\r
"Bir ürünün en fazla {0} barkodu olabilir.",\r
"Ürün eklenmedi: reşit olmayanlara satış yasaktır.",\r
"Bu ürünün pazar günleri ve resmî tatillerde satışı yasaktır (md. 35b).",\r
"Ürün bulunamadı.",\r
"Ürün katalogda yok: {0}",\r
"Ürün katalogda yok.",\r
"Bu kod, barkod veya ada sahip ürün bulunamadı.",\r
"ürün etiketler için \\"Yeni fiyatlar\\" listesine eklenir",\r
"artikal TEXT",\r
"Ürün, bu satış noktasının fiyatıyla bu kasanın kataloğuna girer ve Muhasebe ile Yönetici'ye gönderilir. Kodu program atar.",\r
"Ürünün fiyatı zaten bu.",\r
"Ürün artık katalogda değil ve listeden kaldırıldı.",\r
"Ürün sayısı",\r
"Katalogdaki satılmayan ürünler",\r
"Yeni etiket bekleyen ürünler: {0}.\\nYazdırmadan listeden kaldırılsın mı (etiketler zaten raflarda)?",\r
"\\"Şu anda yok\\" işaretli ürünler: {0}.",\r
"ürünler artık katalogda yok",\r
"Ürünler artık katalogda yok",\r
"ürün; yazdırma ve tablo hepsini içerir.",\r
"ürün. İçe aktarma tüm ürünleri ve fiyatları değiştirir; düzenlenmiş fişler değişmez. Dosya, tek bir kasanın kataloğu veya mağazalara göre fiyatları içeren bir paket olabilir.",\r
"Katalogda \\"{0}\\" ürünü yok.",\r
"\\"{0}\\" ürünü artık kasa kataloğunda yok. Kataloğun yenilenmesi gerekiyor.",\r
"Katalogda \\"{0}\\" kodlu ürün yok. Yeni ürün için ad da zorunludur.",\r
"Ürün artık katalogda yok: {0}. Ekrandan kaldırılması gerekir.",\r
"Ürünleri ve fiyatları yalnızca şef değiştirebilir. PIN'li bir şef girilmelidir (Ayarlar → Kasiyerler).",\r
"Ürünleri ve fiyatları amir \\"Ürünler ve fiyatlar\\" ekranında (Daha fazla → Ürünler ve fiyatlar) değiştirir: fiyat değişikliği, yeni ürün, veri düzenleme, toplu değişiklik. Değişiklikler kaydedilir ve Muhasebe'ye ile Yönetici'ye gönderilir; değişiklik dosyaları (\\"kasa-cijene\\" biçimi) elle de aktarılabilir.",\r
"Kasadaki ürünleri yalnızca yönetici değiştirebilir. PIN'li bir yönetici girilmelidir (Ayarlar → Kasiyerler).",\r
"Ürünler",\r
"Barkodsuz ürünler (ekmek, poşet, meyve) kod alanının üzerinde düğmeler olarak gösterilir; düğmeye dokunmak ürünü fişe ekler. En fazla 24.",\r
"Ürünler ve fiyatlar",\r
"Ürünler ve fiyatlar (amir)…",\r
"Bu kasadaki ürünler ve fiyatlar, Muhasebe'den alınan firmanın son paketindekilerle (bu kasanın satış noktası fiyatları) değiştirilir; kasada daha yeni fiyatlar olsa bile. Düzenlenmiş fişler değişmez.",\r
"Bu kasadaki ürünler ve fiyatlar \\"{0}\\" dosyasının içeriğiyle değiştirilir. Düzenlenmiş fişler değişmez.",\r
"Artık katalogda bulunmayan ürünler geri getirilmedi: {0}.",\r
"ürün",\r
"ATLANTIC INVESTMENT D.O.O.",\r
"AUTIĆ",\r
"Yazıcı seçilmediği için ödeme sonrası otomatik yazdırma kapalı. Yazıcı Ayarlar'da seçilir (Fiş ve yazdırma); o zamana kadar fiş \\"Son\\" düğmesiyle yazdırılır.",\r
"Otomatik \\"Gelmedi\\"",\r
"Güncellemeleri otomatik indir",\r
"Teknik hataların otomatik gönderimi kapalı (Ayarlar → Destek ve hatalar). Gönderim açılana kadar bu bildirim de gönderilmez.",\r
"Teknik hataların otomatik gönderimi açık (Ayarlar → Destek ve hatalar).",\r
"Teknik hataların otomatik gönderimi açık (Ayarlar → Destek ve hatalar).{0}",\r
"avans",\r
"Avans",\r
"Avans — {0}",\r
"{0} EUR avans tahsil edildi.",\r
"{0} EUR avans iade edildi.",\r
"Avans ve iptal",\r
"İptalde avans",\r
"Konaklama avansı",\r
"Konaklama avansı {0} – {1}",\r
"Avanslar",\r
"Kullanılan avanslar",\r
"Alınan avanslar",\r
"İade edilen avanslar",\r
"avans fişi",\r
"Avans fişi",\r
"AVANS FİŞİ",\r
"Avans fişi IKOF",\r
"Avans fişi IKOF {0}",\r
"Avans fişi düzenlendi (IKOF {0}), ancak sunucuya kayıt başarısız oldu. Kaydı tekrarlayın; fiş yeniden düzenlenmez.",\r
"Avans fişi Vergi İdaresi tarafından reddedildi. Önce yeniden gönderilmesi gerekir.",\r
"Avans fişi bu fiş için zaten düzeltildi.",\r
"Avans fişi aynı zamanda düzeltme fişi olamaz.",\r
"Avans fişi bu kasada mevcut değil.",\r
"Avans fişinde IKOF yok.",\r
"Avans fişi bu kasada düzenlenmedi ve avans fişi verileri sunucuya kaydedilmedi.",\r
"KDV oranı {0} % olan avans fişi.",\r
"Avans fişi alınan ödeme için düzenlenir: ödeme yöntemi avans veya ertelenmiş ödeme olamaz.",\r
"Avans fişi başka fişlere atıfta bulunmaz.",\r
"Avans fişi burada iptal edilmez. Avans, oda hesabındaki \\"Avans iadesi\\" yoluyla iade edilir.",\r
"Ağustos",\r
"Ağustos",\r
"AXE",\r
"Programdan güncelleme tarayıcıda desteklenmez; Windows ve Android'deki kasada kullanılabilir.",\r
"Güncellemeye yalnızca HTTPS bağlantısı üzerinden izin verilir.",\r
"Güncelleme indirildi",\r
"Bir güncelleme zaten sürüyor — bitmesini bekleyin.",\r
"Güncelleme başarısız oldu ({0}). Hiçbir şey değiştirilmedi.",\r
"Güncelleme başarısız oldu.",\r
"Program güncellemesi",\r
"Güncellemeler yalnızca kasanın resmî yayın adresinden ({0}) alınır.",\r
"güncelleme: {0}",\r
"güncelleme: Verzije klasörü dışında silme reddedildi: {0}",\r
"güncelleme: userData tam yol olmalıdır",\r
"BABY",\r
"BACARDI",\r
"Backspace",\r
"BADEM",\r
"BAGET",\r
"BAILEYS",\r
"BAJADER",\r
"BALLANTIN",\r
"BALLANTINES",\r
"BALON",\r
"BANINI",\r
"Bar",\r
"BARILLA",\r
"Barkod",\r
"\\"{0}\\" barkodu geçerli değil (rakam, harf, tire ve nokta, en çok 32 karakter).",\r
"{0} barkodu {1} ürününe bağlandı{2}",\r
"{0} barkodu zaten başka bir ürüne ait. Barkod alanının altında bir seçim yapılması gerekir.",\r
"{0} barkodu zaten {1} ürünlerinde var.",\r
"{barkod} barkodu \\"{naziv}\\" ürününe bağlandı.",\r
"{barkod} barkodunun zaten \\"{naziv}\\" ürünü var.",\r
"Barkod zorunludur.",\r
"Barkod geçerli değil (rakam, harf, tire ve nokta, en fazla 32 karakter).",\r
"Bir soru açık olduğu için barkod kabul edilmedi. Soruyu kapatıp barkodu yeniden okutun.",\r
"Barkod hiçbir ürüne bağlı değil.",\r
"Barkodu yalnızca yönetici taşıyabilir. PIN'li bir yönetici girilmelidir (Ayarlar → Kasiyerler).",\r
"Barkodu üründen yalnızca yönetici kaldırabilir. PIN'li bir yönetici girilmelidir (Ayarlar → Kasiyerler).",\r
"barkodu olmayan mevcut bir ürüne barkod eklenir; ad ve fiyat değişmez",\r
"Barkod mevcut ürüne eklenir. Ürünün adı ve fiyatı değişmez.",\r
"Barkod, kod veya adın bir kısmı",\r
"barkod, ardından Enter",\r
"Barkod",\r
"Barkodlar",\r
"BATAK",\r
"BATERIJ",\r
"Ürün veritabanı yüklenemedi: {0}",\r
"Veritabanı okuma sırasında hata bildirdi, tüm veritabanının kontrolü ise başarılı geçti; bilgisayar bellek hatası olabilir. Hata tekrarlanırsa bilgisayarın incelenmesi gerekir.",\r
"Kasa veritabanı hasarlı ve açılamıyor (ne son ne de önceki anlık görüntü). Veritabanı dosyaları değiştirilmedi.",\r
"Kasa veritabanı henüz diske kaydedilmedi — bir dakika sonra yeniden deneyin.",\r
"Veritabanı kaydedilmedi ({0}). Kurulum iptal edildi.",\r
"Veritabanı kaydedilmedi ({0}). Yeniden başlatma iptal edildi.",\r
"Kasanın belleğindeki veritabanı hasarlı (bilgisayar bellek hatası) ve diske yazılmadı. Düzenlenen fişler kayıtlı. Kasayı kapatıp yeniden başlatın.",\r
"BB",\r
"Bearer {0}",\r
"BEBETO",\r
"BEBI",\r
"Bebek ürünleri",\r
"bečići",\r
"BECK",\r
"BEEFEATER",\r
"BEER",\r
"BELVEDERE",\r
"Berane",\r
"\\"IKOF ve QR hesapla\\" olmadan Vergi İdaresi'ne gönderim mümkün değildir: fişler IKOF ve QR kodu olmadan, mali olmayan fiş olarak düzenlenir.\\n\\nMali onay ve gönderimin ikisi de kapatılsın mı (deneme çalışması)?",\r
"Barkodsuz",\r
"Puansız",\r
"Oda atanmadı",\r
"Glutensiz",\r
"grupsuz",\r
"Seçim yapılmazsa sunucuda girilen işletme modu geçerlidir; yoksa kasa her şeyi gösterir.",\r
"Kamera yok: QR kodunun metnini girin",\r
"müşterisiz",\r
"Müşterisiz",\r
"Müşteri yok. Bir firmaya proforma için müşteri (PIB ve ad) seçilmelidir.",\r
"aksansız (c c z s dj)",\r
"Laktozsuz",\r
"lisans yok (sınırsız çalışma)",\r
"yeni veri yok",\r
"yanıt yok",\r
"paket boyutsuz (etikette kg / l fiyatı olmayacak)",\r
"Cari yok",\r
"Dönemde cirosu olmayanlar",\r
"fişsiz",\r
"fişsiz, gerekçeyle; açma kaydedilir",\r
"Düzensiz (ızgara)",\r
"gerekçesiz",\r
"reçetesiz",\r
"süresiz",\r
"Görsel yok",\r
"odasız",\r
"Odasız",\r
"Yazdırma yok",\r
"Şu geceden sonra vergi yok",\r
"vergisiz: {0}",\r
"FZO ile sözleşme yok (yalnızca özel reçeteler)",\r
"Kasiyer girilmemişse kasa girişsiz çalışır. En az bir kasiyer girildiğinde kasa açılışta giriş ister ve kasiyerin adı fişe basılır.",\r
"bağlantı yok",\r
"Bağlantısız",\r
"{0} tarihinden beri bağlantı yok",\r
"{0}:{1} saatinden beri bağlantı yok",\r
"kasa başlatıldığından beri bağlantı yok",\r
"Sunucuyla bağlantı {0} {1} süredir yok (izin verilen {2}). Sunucu bağlantısı yeniden kurulana kadar yalnızca okuma ve dışa aktarma.",\r
"Sadakatsiz",\r
"Alkolsüz – Enerji içecekleri",\r
"Alkolsüz – Gazlı",\r
"Alkolsüz – Meyve suyu/Nektar",\r
"Alkolsüz – Su",\r
"BIBER",\r
"Bijelo Polje",\r
"Bilanço, Gelir tablosu, Basitleştirilmiş dipnotlar, İstatistik eki",\r
"Toplu değişiklik için ürün seçimi:",\r
"BISCUIT",\r
"BISKVIT",\r
"Veri bitleri",\r
"BITTER",\r
"Bluetooth",\r
"Bluetooth (Android)",\r
"Euro başına puan (0 = kapalı)",\r
"Puanlar % indirim ile birlikte harcanamaz.",\r
"Puanlar yalnızca sadakat müşterisi ile harcanır (Müşteri → Telefon).",\r
"Sadakat puanları",\r
"Renk",\r
"BOMBAY",\r
"BOMBON",\r
"Kupon",\r
"Çek {0} süresi {1} tarihinde doldu.",\r
"Çek {0} bu kasa tarafından bilinmiyor. Bugün başka bir kasada satın alındıysa sunucuyla veri alışverişi beklenmelidir (Ayarlar → Sunucu).",\r
"Bu fişteki çek {0} zaten kullanıldı ({1} €). Fiş iptal edilemez.",\r
"Bonun geçerliliği {0} tarihinde sona erdi.",\r
"Bon bu kasa tarafından bilinmiyor (başka bir kasadan henüz ulaşmamış olabilir).",\r
"Çek, tüm mağazalarımızda, bir veya birden fazla alışverişte, çek tutarına kadar kullanılır. Nakitle değiştirilemez.",\r
"Çek, tüm mağazalarımızda, bir veya birden fazla alışverişte, çek tutarına kadar kullanılabilir. Nakitle değiştirilemez.",\r
"Kupon geçerlilik süresi (gün)",\r
"BON-{0}",\r
"Gazi / savaş malulü",\r
"Konaklama",\r
"{0} günden uzun konaklama",\r
"30 günden uzun konaklama",\r
"Konaklama vergisi",\r
"Konaklama vergisi ({0}{1}",\r
"Konaklama vergisi (kişi başı gecelik EUR)",\r
"Konaklama vergisi (tahmini)",\r
"Konaklama vergisi (fiş dışı)",\r
"Konaklama vergisi gelir değildir; özet fişler ciro değildir (ciro tek tek fişlerdedir).",\r
"Aylara göre konaklama vergisi",\r
"{0} belediyesi için konaklama vergisi {1} EUR; tesis kurallarında {2} EUR.",\r
"Konaklama vergisi",\r
"BOUNTY",\r
"br",\r
"BR",\r
"No",\r
"no. {0}",\r
"no. {0} ·",\r
"BRANDY",\r
"BRASNO",\r
"BRAŠNO",\r
"BRAVO",\r
"BREF",\r
"BRENDI",\r
"BRIJAC",\r
"BRIJAČ",\r
"Gelecek tarihli silmeler ({0}; cihaz saati değiştirilmiş)",\r
"Silmeler:",\r
"Silme",\r
"Son kalemi sil",\r
"Girilmekte olan fişi sil (müşteri vazgeçti, parası yok); silinenler kaydında kalır",\r
"Silme kaydedilir: kim, ne zaman, ne kadar, neden. Şef tüm silinen fişleri görür.",\r
"Eski kodun üründen silinmesi",\r
"Kalem silme",\r
"Numara",\r
"Belge numarası",\r
"belge numarası",\r
"Belge numarası",\r
"Numara zaten {0}. Değişiklik yok.",\r
"Terminal için kasa numarası",\r
"Karne numarası",\r
"Bu bilgisayarda {0} programının gösterdiği numara. Bu program yoksa alan boş kalır.",\r
"Paketteki adet sayısı sıfırdan büyük olmalıdır.",\r
"Lisans numarası L-2026-0001 biçiminde olmalıdır.",\r
"Sipariş numarası",\r
"Numara geçerli değil (tam sayı, ör. 1250).",\r
"Kişi sayısı geçerli değil.",\r
"Fiş numarası",\r
"Reçete numarası",\r
"Reçete numarası girilmemiş.",\r
"Oda sayısı",\r
"Telefon numarası zorunludur.",\r
"Vize numarası",\r
"Sağlık karnesi numarası veya JMBG",\r
"Sağlık karnesi numarası veya JMBG geçerli değil.",\r
"Bu kasanın fiş sayacı ({0}), alışveriş klasöründeki son numaranın ({1}) gerisinde. Kasa bir kopyadan geri yüklendi veya yeniden kuruldu. Fiş düzenlenmedi. Son düzenlenen numaranın, en az {2}, girilmesi gerekir (Ayarlar → Fiskalizasyon → \\"Ayarla…\\").",\r
"Bu kasanın fiş sayacı ({0}/{1}), alışveriş klasöründeki numaranın ({2}) gerisinde. Kasa bir kopyadan geri yüklendi veya yeniden kuruldu. Son düzenlenen numara, en az {3}, ayarlanana kadar (Ayarlar → Fiskalizasyon → \\"Ayarla…\\") kasa Vergi İdaresi için fiş düzenlemez.",\r
"BRUT",\r
"Brüt",\r
"BRÜT",\r
"bruto REAL",\r
"Hızlı tuşlar (kodlar, virgülle ayrılmış)",\r
"Hızlı seçim",\r
"Hız",\r
"Hız (seri)",\r
"Budva",\r
"BUDWEIS",\r
"BUREK",\r
"BURN",\r
"button",\r
"BUTTON",\r
"Bypass",\r
"Byte",\r
"CABERNET",\r
"CACKALIC",\r
"ČAČKALIC",\r
"CAJ",\r
"ČAJ",\r
"CAMEL",\r
"CAMPARI",\r
"cancel",\r
"CANCELED",\r
"CANCELED,CANCELLED,ABORTED",\r
"CAPPUC",\r
"CAPTAIN MORGAN",\r
"Planlanan varıştan sonraki günün saati (0–23).",\r
"CAS (ST/US,GS)",\r
"CASH",\r
"CAST(ROUND({0} * 100) AS INTEGER)",\r
"CAST(ROUND(COALESCE({0}, 0) * 100) AS INTEGER)",\r
"CEDEVIT",\r
"bekliyor",\r
"bekliyor (masa kasada)",\r
"Vergi İdaresi'nin önce {0} öğesini almasını bekliyor.",\r
"Vergi İdaresi'nin önce iptal edilen fişi almasını bekliyor.",\r
"İndirmenin yeniden denenmesini bekliyor",\r
"Vergi İdaresi bekleniyor",\r
"Vergi İdaresi onayı bekleniyor",\r
"Muhasebe'den fiyat listesi bekleniyor (ana bilgisayar: Kasa fiyat listesi → \\"Şimdi veri alışverişi yap\\"). Kasa fiyat listesini otomatik alır.",\r
"Gönderim bekliyor",\r
"Sunucuya gönderilmeyi bekliyor",\r
"toplu fişi bekliyor",\r
"Bekleyen: {0}.",\r
"Vergi İdaresi bekleniyor",\r
"Bekletilenler",\r
"Sonuç bekleme (sn)",\r
"Sabit ağırlık bekleme (ms)",\r
"Kereviz",\r
"Merkezi fiş sunucusuna gönderilmeyi bekleyen: {0}.",\r
"Per",\r
"Cetinje",\r
"CETKIC",\r
"ČETKIC",\r
"Perşembe",\r
"CEVAP",\r
"ĆEVAP",\r
"CHAMPAGNE",\r
"CHANDON",\r
"CHARDON",\r
"checked",\r
"CHESTERFIELD",\r
"CHIO",\r
"chip",\r
"bağlantı etiketi",\r
"CHIPS",\r
"CHIPSY",\r
"CHIVAS",\r
"CIF",\r
"CIGARE",\r
"CIGARET",\r
"CIGARETA",\r
"sigara",\r
"CIGARETE",\r
"tüm grup",\r
"tamamı",\r
"Fiyat",\r
"fiyat · kod",\r
"Fiyat (EUR, KDV dahil)",\r
"{0} € fiyatı çok yüksek (en fazla {1} €).",\r
"{nova} fiyatı alış fiyatından ({nabavna}) düşük. Fiyat girilsin mi?",\r
"{nova} fiyatı ilacın izin verilen en yüksek fiyatını ({max}) aşıyor.",\r
"ürün fiyatı ve kampanyası, fişe girmeden",\r
"fiyat ve kg / l fiyatı",\r
"fiyat ve kg / l fiyatı, yazdırma",\r
"fiyat ve kg / l fiyatı, yazdırma",\r
"Fiyat ve ödeme",\r
"Fiyat çok yüksek.",\r
"Fiyat bu arada değişti. Geri alma mümkün değil.",\r
"Fiyat sıfırdan büyük olmalıdır.",\r
"Gecelik fiyat",\r
"Gecelik fiyat (EUR)",\r
"Gecelik fiyat geçerli değil.",\r
"Döneme göre gecelik fiyat, KDV dahil. Bir oda türü için dönem, tüm türler için dönemden önceliklidir; dönem dışında türün temel fiyatı geçerlidir.",\r
"Birim fiyatı",\r
"Gecelere göre fiyat",\r
"KDV dahil fiyat",\r
"KDV dahil fiyat (EUR)",\r
"Fiyat, ürünün fiyatına dokunularak değiştirilir ve bu satış noktası için geçerlidir. Değişiklikler Muhasebe ve Yönetici'ye gönderilir.",\r
"tek dokunuşla fiyat, yeni ürün, ürün düzenleme, toplu değişiklik; yalnızca şef, Muhasebe'ye ve Yönetici'ye aktarılır",\r
"bu satış noktası için girilmiş fiyat",\r
"cijena_utc TEXT",\r
"cijena_vrijeme TEXT",\r
"Firma paketinden fiyatlar",\r
"Ofisten gelen ve yeni etiket bekleyen fiyatlar",\r
"Kasadaki fiyatları yalnızca yönetici değiştirebilir. PIN'li bir yönetici girilmelidir (Ayarlar → Kasiyerler).",\r
"Kasadaki fiyatlar, programdaki paketten ({1}) daha yeni bir paketten ({0}). Önce daha yeni fiyat dosyasının yüklenmesi gerekir (\\"Paketi dosyadan yükle…\\").",\r
"Fiyatlar güncellendi.",\r
"Katalogdaki fiyatlar değişti; tutarın kontrol edilmesi gerekir.",\r
"Katalogdaki fiyatlar değişti. Tutar kontrol edilip tahsilat tekrarlanmalıdır.",\r
"\\"{0}\\" için fiyatlar",\r
"Fiyatlar: {0}.",\r
"Fiyatı yetkili bir kullanıcı değiştirir.",\r
"CIMET",\r
"CINZANO",\r
"Katalogun tamamı, sunucudaki ürünler ve fiyatlarla değiştirilir.",\r
"CIPS",\r
"ČIPS",\r
"Temizlik",\r
"Eski silinmiş fişlerin temizlenmesi başarısız oldu: {0}",\r
"Temizlik devam ediyor",\r
"Temiz",\r
"Barkod okuyucu indiriliyor (Google Play hizmetleri). Yarım dakika sonra tekrar denenebilir.",\r
"Belge okuyucu bölgeyi buraya yazar; satır satır elle de girilebilir.",\r
"Ağırlığı barkoddan oku (terazi)",\r
"Fiyat listesi",\r
"Muhasebe'deki bu kasa fiyat listesi şu iş yeri kodunu belirtiyor",\r
"Fiyat listesi başka bir firmaya ait (PIB {0}) ve uygulanmadı.",\r
"Kasa fiyat listesi → \\"Fiyat listesini dosyaya kaydet\\"",\r
"Fiyat listesi farklı bir iş yeri kodu belirtiyor (",\r
"Fiyat listesi uygulanmadı: {0}",\r
"Fiyat listesi okunamıyor: {0}",\r
"Klasördeki fiyat listesi başka bir firmaya ait (PIB {0}).",\r
"md. {0}",\r
"md. 26",\r
"md. 27",\r
"CLIPSY",\r
"COALESCE(p.kupac_pib, '') LIKE ?",\r
"COALESCE(podgrupa,'') = ?",\r
"COALESCE(r.popust, 0)",\r
"COALESCE(r.popust, 0) <> 0",\r
"COALESCE(r.vrsta, 'racun') <> 'otpis'",\r
"COALESCE(st.popust, 0)",\r
"COALESCE(vrsta, 'racun') <> 'otpis'",\r
"COCA",\r
"COCKTA",\r
"COGNAC",\r
"COINTREAU",\r
"COKOLAD",\r
"ČOKOLAD",\r
"COLA",\r
"COLGATE",\r
"Concert bu işlemi desteklemiyor: {0}",\r
"Concert: beklenmeyen uzunlukta yanıt ({0})",\r
"Concert: mesaj 34 karakter değil",\r
"Content-Type, {0}",\r
"CORNFLAKE",\r
"CORONA",\r
"CORRECTIVE",\r
"CP852 (č ć ž š đ)",\r
"Karadağca",\r
"CROCKY",\r
"CROISS",\r
"CUBA",\r
"CUCLA",\r
"maskeli saklanır",\r
"Kişisel verilerin saklanması (yıl)",\r
"Kişisel verilerin saklanması: en az 1 yıl",\r
"Evet",\r
"İleri",\r
"gün",\r
"Gün",\r
"Gün / başlangıç",\r
"Rapor günü: 1 ile 31 arasında",\r
"gün",\r
"Ayın her 15 gününün bitiminden sonraki gün sayısı.",\r
"bugün",\r
"Bugün",\r
"Bugün {0}. Bu kiosk için pazar günleri ve tatillerde hangi malların satılabileceği girilmemiş (md. 35b). Satış kısıtlanmamıştır.\\n\\nİzin verilen ürün gruplarının listesi Muhasebe'de girilir (Kasa fiyat listesi → kasa).",\r
"Günler",\r
"Danilovgrad",\r
"DATA",\r
"data-rn=\\"smjena\\" data-id=\\"{0}\\" title=\\"Bu vardiyanın kapanış (Z) raporunu yeniden yazdır\\"",\r
"datalist",\r
"Tarih",\r
"\\"bitiş\\" tarihi \\"başlangıç\\" tarihinden önce.",\r
"\\"bitiş\\" tarihi YYYY-AA-GG biçiminde veya null (süresiz) olmalıdır.",\r
"\\"Başlangıç\\" tarihi \\"bitiş\\" tarihinden sonradır.",\r
"\\"başlangıç\\" tarihi YYYY-AA-GG biçiminde olmalıdır.",\r
"\\"Geçerlilik bitişi\\" tarihi \\"geçerlilik başlangıcı\\" tarihinden önce.",\r
"\\"Geçerlilik bitişi\\" tarihi 2026-07-31 biçiminde değil (verilen: \\"{0}\\").",\r
"\\"Geçerlilik başlangıcı\\" tarihi 2026-07-31 biçiminde değil (verilen: \\"{0}\\").",\r
"Tarih geçerli değil.",\r
"Reçete tarihi",\r
"Reçete yazılış tarihi gelecekte.",\r
"Reçete yazılış tarihi girilmemiş.",\r
"Rezervasyon tarihi geçerli değil.",\r
"doğum tarihi",\r
"Doğum tarihi",\r
"gelecekte bir tarih",\r
"Karadağ'a giriş tarihi",\r
"Cihaz tarihi ({0}), son fişin tarihinden ({1}) önce. Cihaz saati ve tarihi doğru olana kadar fiş düzenlenmez.",\r
"Organ / kan bağışçısı (10 defadan fazla)",\r
"DAVIDOFF",\r
"DAYS",\r
"Devre dışı bırakılmış bir ENU değiştirilemez.",\r
"Aralık",\r
"Aralık",\r
"DECLINED",\r
"DEFGHIJKLMNOPQRSTUVWXYZ",\r
"DEO",\r
"Para girişi",\r
"Para girişi — kasaya para",\r
"para girişi / çıkışı",\r
"Para girişi kaydedildi:",\r
"PARA GİRİŞİ…",\r
"Para girişleri",\r
"Para girişleri ve çıkışları",\r
"DETERDZ",\r
"DETERDŽ",\r
"DEZINF",\r
"DEZODOR",\r
"Dibal (Toledo gibi)",\r
"DIGESTIV",\r
"bir kısmının",\r
"şu ürünle de paylaşılıyor:",\r
"{0} ile de paylaşılıyor",\r
"Çocuk",\r
"{0} yaşına kadar çocuk",\r
"12 yaşına kadar çocuk",\r
"Resim boyutları okunamıyor.",\r
"DINERS",\r
"Misafirin payı ({0} EUR)",\r
"Misafirin payı (bakiye)",\r
"Hasta payı",\r
"Carinin payı ({0} EUR)",\r
"Carinin payı (bakiye)",\r
"Cari hesabın bir kısmı faturalandırılmak üzere bırakılır.",\r
"Malın bir kısmı zaten iade edildi; kalanı iptalle değil, iade ile döndürülür.",\r
"Bu fişteki malın bir kısmı zaten iade edildi. Kalanı \\"Malın bir kısmının iadesi\\" ile iade edilir.",\r
"kalemlerin bir kısmı ödemeye, kalanı masada kalır",\r
"Doğrudan yazdırma",\r
"Doğrudan yazdırma (ESC/POS)",\r
"Doğrudan yazdırma kullanılamıyor. Uygulamanın yeni bir sürümü (1.5) gereklidir.",\r
"Doğrudan yazdırma başarısız oldu: {0}. Yazdırma yazıcı sürücüsü üzerinden yapılır.",\r
"Fişlerin doğrudan yazdırılması",\r
"Doğrudan fiş yazdırma (ESC/POS) Ayarlar → Eklentiler bölümünde ayarlanır. Burada kâğıt durumu kontrol edilir: Sunmi üretici servisi ile, diğer ESC/POS yazıcılar \\"DLE EOT 4\\" sorgusuyla (yazıcı sorguya yanıt vermelidir). Sahada toptan satış için: 58 mm (32 karakter) veya 80 mm (48 karakter) Bluetooth yazıcı kurumsal müşteriyi (unvan, vergi no, adres) ve kart onay numarasını da yazdırır.",\r
"Doğrudan yazdırma yalnızca kurulu kasada çalışır (Windows / Android).",\r
"Doğrudan gönderim",\r
"Doğrudan gönderim: Emniyet Müdürlüğü'nün teknik talimatı alındıktan sonra kullanılabilir.",\r
"müdür",\r
"disabled",\r
"disabled title=\\"Kod ürünün kodudur; taşıma mümkün değil.\\"",\r
"disabled title=\\"İlaç kasanın kod listesinde yok\\"",\r
"DISARONNO",\r
"Disk dolu — dosya kaydedilmedi. Yer açıp yeniden deneyin. (ENOSPC)",\r
"Disk dolu — veri alışverişi dosyası yazılmadı. (ENOSPC)",\r
"Disk dolu — yer açın (örneğin Dokumenti\\\\Kasa içindeki eski yedekler), ardından yeniden deneyin. (ENOSPC)",\r
"Disk dolu — yedek kopya yazılmadı. (ENOSPC)",\r
"div",\r
"Çocuk",\r
"Firma faaliyetleri",\r
"DJELIMICNO",\r
"Günlük rapor",\r
"Bu günün günlük raporu",\r
"Günlük özet",\r
"günlük",\r
"Günlük {0} MB'tan büyük.",\r
"Kayıt otomatik tutulur ve misafir bildirim verileri kadar saklanır.",\r
"Ekteki günlük: en fazla {0} metin satırlık dizi (satır en fazla {1} karakter).",\r
"Günlük: {0}–{1} kayıtları eksik; kurtarma durdu (günlüğün bir kopyası saklandı).",\r
"Günlük: {0}. satır hasarlı; kurtarma o noktada durdu (günlüğün bir kopyası saklandı).",\r
"Günlük: {0} kaydı uygulanamadı ({1}) ve atlandı; sonraki kayıtlar uygulandı. Günlüğün bir kopyası saklandı. Bakım ekibine başvurun.",\r
"bitiş",\r
"Bitiş",\r
"Bitiş (dahil)",\r
"{0} tarihine kadar",\r
"Misafirin ayrılış günü odayı boşaltması gereken saat.",\r
"tedarikçi",\r
"Tedarikçiler",\r
"tedarikçi",\r
"dobro",\r
"Hoş geldiniz",\r
"DOCUMENTS",\r
"Ek özellikler (1.5)",\r
"Ekle",\r
"Misafir ekle",\r
"Bu ürüne de ekle",\r
"Yeni ürün olarak ekle",\r
"Ödeme yöntemi ekle",\r
"Tesis ekle",\r
"Reçete ekle",\r
"Odaları ekle",\r
"Hizmet ekle",\r
"Oda türü ekle",\r
"etiketlere ekle",\r
"Ek kasalar veya cihazlar, deneme süresinin uzatılması, ek modül (Muhasebe, Yönetici) veya başka bir talep. Yayıncı burada yanıt verir (onaylandı / reddedildi, gerekçesiyle).",\r
"Ek modül (Muhasebe, Yönetici…)",\r
"Ek yatak",\r
"{0} numaralı masaya eklendi.",\r
"Eklenen oda: {0}{1}.",\r
"Listeye eklendi: yeni fiyatlı {0}.",\r
"Eklendi: {0}",\r
"Eklendi.",\r
"Ekleme — masa {0}",\r
"Birden fazla oda ekleme",\r
"Fiyata dokunmak yeni fiyat için tuş takımını açar. Fiyat bu satış noktası için geçerlidir, kaydedilir (kim, ne zaman, eski → yeni) ve Muhasebe ile Yönetici'ye gönderilir.",\r
"Anlaşılan gecelik fiyat (EUR)",\r
"Kasanın ENU'su yokken fişler",\r
"Vergi İdaresi sertifikası ve kodları olmadığı sürece veya ortam TEST olduğu sürece. Fişte başlığın altında \\"DENEME MODU — VERGİ İDARESİNE BİLDİRİLMEMİŞTİR\\" yazar.",\r
"fiş düzenlenene kadar",\r
"Bu düzeltilene kadar fiş düzenlenemez.",\r
"belge,",\r
"Deliller",\r
"Zayi belgeleri:",\r
"Belge",\r
"Belge no.",\r
"Belge kendi numarasını alır (O-1, O-2…), yazdırılır ve fiş incelemesinde \\"Zayiatlar\\" altında görülür.",\r
"Sıradaki belge bu kasada mevcut değil veya IKOF'u yok.",\r
"Belge IKOF olmadan düzenlendi.",\r
"Belge yazdırmak için çok büyük ({0} MB). Dönemi veya seçimi daraltın ve parçalar halinde yazdırın (rapor tablo olarak da kaydedilebilir).",\r
"Belge mali değildir ve ciroya dahil edilmez. Mal, satılmış gibi stoktan düşülür. Amaç: son kullanma tarihi geçmiş, hasarlı veya kullanılamaz durumda olup tedarikçinin geri almadığı mallar.",\r
"Zayiat belgesi",\r
"Zayi belgesi bir fiş değildir. İade mümkün değil.",\r
"Zayi belgesi iptal edilmez. Mal zayiatı bir kayıt belgesidir, fiş değildir.",\r
"Zayi belgesi iptal edilemez. Mal zayii bir fiş değildir.",\r
"Belge IKOF olmadan düzenlenemez (fiskalizasyon açık değil veya sertifika yok). Hiçbir şey düzenlenmedi.",\r
"Belgeler düzenlendi. Oda hesabına kayıt, sunucu bağlantısını bekliyor.",\r
"Varışlar",\r
"Ülkeye göre varışlar ve geceleme (TU-11)",\r
"Ülke ve aya göre varışlar ve geceleme",\r
"Bugünden itibaren girişler",\r
"Giriş",\r
"Giriş (ilk gece)",\r
"giriş {0}",\r
"bugün giriş",\r
"Bugün giriş",\r
"Giriş kaydedildi.",\r
"Giriş gecikti ({0})",\r
"Giriş saati (itibaren)",\r
"Giriş saati (itibaren)",\r
"Ev yapımı",\r
"yerli",\r
"Yerli misafir",\r
"Yerli misafir (Karadağ vatandaşı)",\r
"Yerli: {0} varış, {1} geceleme · yabancı: {2} varış, {3} geceleme.",\r
"DOMACIC",\r
"DOMAĆIC",\r
"{0} alan adı girildi. Bu alan adıyla QR kodları ana kasada yazdırılır (QR menü → Ayarlar → kendi alan adı).",\r
"Alan adı kaldırıldı. QR kodları IRIS menü adresine yönlendirir.",\r
"DOMESTOS",\r
"ĐON",\r
"Ek ödeme",\r
"ek ödeme {0}",\r
"Ek ücretler",\r
"DORINA",\r
"DORITOS",\r
"Kahvaltı, yarım pansiyon, tam pansiyon.",\r
"Teslimat",\r
"Kasanın yeni {0} sürümü kullanılabilir (Ayarlar → Güncelleme).",\r
"Yeni sürüm mevcut:",\r
"Yeni sürüm mevcut: {0}",\r
"dot",\r
"DOVE",\r
"İzin {0} kasası için verilmiş, bu ise {1} kasası.",\r
"İzin yalnızca {0} için geçerli. Bugün için yeni bir izin gerekir.",\r
"Erişime izin ver",\r
"izin verildi",\r
"Dr. Deneme (faksimile 0000)",\r
"DRAZE",\r
"DRAŽE",\r
"DRESING",\r
"DRINA",\r
"Uyuşturucu",\r
"uyuşturucu (PRp)",\r
"Uyuşturucu ve psikotrop maddeler özel eczanede FZO hesabına verilmez.",\r
"Diğer belge",\r
"başka kasa",\r
"Başka kasa",\r
"Diğer türler",\r
"Kalemleri ve fiş tutarını gösteren ikinci bir pencere; ikinci monitörde tam ekran açılır. Bir sonraki fişten itibaren geçerlidir.",\r
"diğer",\r
"Diğer",\r
"Diğer (not)",\r
"Diğer (açıklama notta)",\r
"Ülke",\r
"Veren ülke",\r
"Belgenin verildiği ülke",\r
"belgeyi veren ülke",\r
"doğum ülkesi",\r
"Doğum ülkesi",\r
"Vatandaşlık",\r
"uyruk",\r
"Uyruk",\r
"ĐUBR",\r
"DUEL",\r
"Düzeltme fişinin borcuna ait belge yok.",\r
"düğme",\r
"Ana ekrandaki \\"↩ İptal\\" düğmesi son fişi (müşteri ödemedi, giriş hatası) düzenlendikten sonra 30 dk'ya kadar iptal eder; bu işaret olmadan, fişi düzenleyen kasiyer onu amirin onayı olmadan iptal eder. Daha eski fişlerin stornosu (Fişler) her zaman amir gerektirir.",\r
"DUHAN",\r
"DUNHILL",\r
"yinelenen ama bulunamadı",\r
"Tütün",\r
"DUVAN",\r
"İki kişilik oda",\r
"Çift tahsilat",\r
"Çift tahsilat ({0}): {1} Fiş görünümü → iptal.",\r
"Çift tahsilat: {0} — fiş iptal edilmeli",\r
"DZAK",\r
"DŽAK",\r
"DZEM",\r
"DŽEM",\r
"E-kopya: müşteri ekranında fiş QR'ı (saniye)",\r
"E-posta",\r
"e-reçete FZO (servis)",\r
"FZO e-reçetesi, FZO reçetesi (Fon uygulaması / elle), özel reçete; eczacı",\r
"Hastanın e-reçeteleri",\r
"e.g. The kitchen is open until 11 pm",\r
"EACCES",\r
"EADDRINUSE",\r
"EAN-13",\r
"EAN-8",\r
"EBUSY",\r
"EC",\r
"ECDSA",\r
"EDAMER",\r
"efi_uuid TEXT",\r
"efi_zadnji TEXT",\r
"ekran şunu bildirdi: {0}",\r
"Ekran boş.",\r
"Mutfak ekranı (siparişler ekranda da)",\r
"Mutfak ekranı kasada etkin değil (Ayarlar → Eklentiler).",\r
"Müşteri ekranı",\r
"Android kasanın ikinci ekranında müşteri ekranı (Sunmi T2, D2s ve benzeri çift ekranlı kasalar).",\r
"Ağ üzerinden müşteri ekranı kasada açık değil.",\r
"Müşteri ekranı açık",\r
"Müşteri ekranı: bu bilgisayarın ikinci monitöründe pencere ve/veya yerel ağda tablet (tablet tarayıcısı aşağıdaki adresi açar). Tablet için garson telefonu sunucusu açık olmalıdır (Ayarlar → Garsonlar).",\r
"Fiş ekranı hazır değil.",\r
"ekran yüklenmedi ({0})",\r
"ekran çöktü ({0})",\r
"Müşteri ekranı (ikinci monitör)",\r
"ekran: {0}",\r
"Fişin elektronik kopyası: QR'ı telefonla okutun",\r
"Elektronik etiketler",\r
"E-posta",\r
"ENERG",\r
"İngilizce",\r
"ENOENT",\r
"ENOSPC",\r
"Enter",\r
"enu TEXT",\r
"EPERM",\r
"ERDINGER",\r
"Esc",\r
"Escape",\r
"ESPRESSO",\r
"ESSE",\r
"Etiket",\r
"Fiyat ve kg / l fiyatlı etiket",\r
"Etiketler",\r
"Fiyat etiketleri",\r
"EUR",\r
"EUR · bakiye",\r
"EUR · ödenen",\r
"EUROCREM",\r
"EUROKREM",\r
"Kayıtlar bir yıl saklanır; daha eski kayıtlar otomatik olarak silinir.",\r
"Kayıtlar bir yıl saklanır. Ulaşılabilir en eski tarih: {0}.",\r
"Kayıt belgesi (mali fiş değildir). Mal stoktan düşüldü; ciroya dahil edilmez ve Vergi İdaresi'ne bildirilmez.",\r
"ex TEXT",\r
"F tuşları",\r
"Ana ekranda F tuşları (faresiz çalışma). F5 ve F12 kullanılmaz. Tuş, açık pencere yokken çalışır.",\r
"FA",\r
"FAIRY",\r
"Dosya",\r
"\\"{0}\\" dosyası, kasa listesi içeren bir paket değil, tek bir kasanın kataloğunu içerir. Katalogun tamamı dosyanın içeriğiyle değiştirilir; kasa listesi aynı kalır. Düzenlenmiş fişler değişmez.",\r
"{0} dosyası bozuk",\r
"{0} dosyası hasarlı ve okunamıyor",\r
"{0} dosyası boş",\r
"{0} dosyası okunamıyor ({1})",\r
"{0} dosyası açılamıyor",\r
"Fiyat değişikliği dosyası başka bir firmaya ait (PIB {0}).",\r
"dosya {0} MB'tan büyük ve sunucuya gönderilmiyor.",\r
"Dosya kasanın config.json dosyasına benzemiyor (kasa kodu, firma veya sunucu adresi yok).",\r
"Dosya okunamıyor (config.json ayar dosyası bekleniyor).",\r
"Dosya okunamıyor (JSON kasa kataloğu bekleniyor).",\r
"Dosya okunamıyor (JSON bekleniyor).",\r
"Dosya bir PIN sıfırlama izni değil.",\r
"Dosya bir fiyat değişikliği dosyası değil (\\"kasa-cijene\\" biçimi).",\r
"Dosya bir fiyat değişiklikleri dosyası değil (\\"kasa-cijene\\" biçimi bekleniyor).",\r
"Dosya bir kasa kataloğu değil (\\"kasa-katalog\\" biçimi bekleniyor).",\r
"Dosya değiştirilmedi; kasa deneme modunda çalışıyor. Kasanın yeniden başlatılması gerekir. Hata tekrarlanırsa (ör. veriler başka bir bilgisayardan aktarıldıysa), okunamayan anahtarlar aşağıdaki düğmeyle atılır ve sertifika yeniden içe aktarılır.",\r
"Dosya bir kasa veri paketi değil (\\"kasa-paket\\" biçimi bekleniyor).",\r
"Dosya tamamen yazılmadı.",\r
"Dosya tam olarak yazılmadı. İşlem tekrarlanmalıdır.",\r
"Sertifika, anahtar ve sunucu parolasını içeren dosya bir kenara taşınır (silinmez) ve kasa bunlar olmadan, yeni gibi devam eder.\\n\\nBundan sonra sertifikanın (.pfx) yeniden içe aktarılması ve sunucu parolasının girilmesi gerekir.\\n\\nBu adım yalnızca kasanın yeniden başlatılması hatayı gidermediğinde öngörülmüştür. Devam edilsin mi?",\r
"Dosya Muhasebe'de oluşturulur (",\r
"Sertifika dosyası boş.",\r
"tajne.json dosyası kaybolmuş, önceki kopyası tajne.json.stari mevcut — elle geri yüklenmelidir",\r
"tajne.json dosyası bozuk — boş veya okunamıyor",\r
"tajne.json dosyası açılamıyor — başka bir program tarafından kullanılıyor veya erişim reddedildi ({0})",\r
"tajne.json dosyası kasanın tanıdığı biçimde değil",\r
"Alışveriş klasöründeki {0} kasasının kapanış dosyasını başka bir cihaz yazıyor ({1} tarihinde oluşturulmuş). Kasa yeni kurulmadıysa veya bir kopyadan geri yüklenmediyse iki cihaz aynı kasa olarak çalışıyor. Birinde doğru kasanın seçilmesi gerekir (Ayarlar → Kasayı değiştir).",\r
"değişiklik dosyaları: {0}, uygulanan {1}{2}",\r
"Sunucuya gönderilmeyi bekleyen kasa dosyaları: {0}.",\r
"Kasa, sunucudan gelen dosyaları ve kendi veri alışverişi dosyalarını kendi alanında saklar (veri alışverişi klasöründe değil); bu nedenle veri alışverişi için ne Autosync ne de \\"tüm dosyalara erişim\\" izni gerekir.",\r
"Güncelleme dosyaları kullanımda (antivirüs?). Hiçbir şey değiştirilmedi — bir dakika sonra yeniden deneyin.",\r
"Kasa dosyaları sunucuya gönderilmeyi bekliyor.",\r
"Bu kasanın sunucuya ulaşmayan dosyaları: {0}. Yalnızca veri alışverişi klasöründe kalırlar.",\r
"FANTA",\r
"Eczacı:",\r
"Eczacı: {0}",\r
"Şubat",\r
"Şubat",\r
"Feed",\r
"Feed'de geçersiz bir en düşük Setup sürümü (minSetup) var.",\r
"Feed'de Android paketi için geçersiz bir sürüm etiketi var.",\r
"Feed'de geçersiz bir sürüm etiketi var.",\r
"Feed'de geçerli bir sağlama toplamı (sha256) yok — paket kabul edilemez.",\r
"Feed'de \\"verzija\\" ve \\"url\\" alanları yok.",\r
"Feed geçerli bir JSON değil.",\r
"FETA",\r
"fic IS NOT NULL",\r
"FIDE",\r
"FINLANDIA",\r
"Çekmece",\r
"Çekmece açıldı (kaydedildi).",\r
"Çekmece fişsiz açıldı: {0}",\r
"Çekmece açılmadı: {0}",\r
"Çekmece şu yolla açılır",\r
"Para çekmecesi",\r
"firma",\r
"Firma",\r
"Firma / paket",\r
"firma sunucuda devre dışı",\r
"firma, yayıncıdaki teknik hata alımını kapattı",\r
"Firma, yayıncıda teknik hataların alınmasını kapatmış. Bildirim gönderilmedi; destek ekibine mesajla yazılabilir (Mesajlar sekmesi).",\r
"Firma, yayıncıda teknik hataların alınmasını kapatmış. Bildirim gönderilmiyor; destek ekibine mesajla yazılabilir (Mesajlar sekmesi).",\r
"Firma sunucuda geçici olarak devre dışı bırakıldı. Bu kasanın dosyaları bekler ve firma yeniden etkinleştirildiğinde otomatik olarak gönderilir (her 15 dakikada bir deneme). Yeniden eşleştirme gerekmez.",\r
"Fişteki firma",\r
"Firma Vergi Mükellefleri Sicili'nde mevcut değil.",\r
"Firma Vergi Mükellefleri Sicili'nde aktif değil.",\r
"Firma KDV sisteminde değil (Ayarlar), ancak fişte KDV'li bir kalem var. Ürünlerin KDV oranları veya firmanın KDV durumu düzeltilmelidir.",\r
"Firma KDV sisteminde değil, ancak fişte KDV'li bir kalem var.",\r
"Firmalar:",\r
"fiscal_error LIKE ?",\r
"Mali onay",\r
"Mali onay (fiskalizasyon) ayarlarda kapalı.",\r
"mali onaylı",\r
"Çıkışta mali belgeler",\r
"Mali veriler",\r
"Mali fiş",\r
"Mali fiş ödeme sırasında düzenlenir.",\r
"Mali servis okunabilir bir yanıt olmadan HTTP {0} ile yanıt verdi.",\r
"Mali servis iletiyi tanımadı. Olası neden: yanlış servis adresi (Ayarlar → Fiskalizasyon) veya program hatası.",\r
"Mali",\r
"FLASIC",\r
"FLAŠIC",\r
"FLIPS",\r
"Klasör (Google Drive)",\r
"Klasör (Google Drive) ayarlanmamış.",\r
"kasanın veri klasörü bilinmiyor",\r
"Veri alışverişi klasörü yok veya erişilemiyor: {0}",\r
"Veri alışverişi klasörü ayarlanmamış (Ayarlar → Muhasebe ile veri alışverişi).",\r
"Muhasebe ile veri alışverişi klasörü (Google Drive)",\r
"Klasör, kasanın veritabanı yedeği için kullanılır: günde bir kez, son 7 gün, \\"Kasa rezerva\\" alt klasöründe.",\r
"Otomatik kayıt klasörü ayarlanmamış (Ayarlar → Ek özellikler).",\r
"Elektronik etiketler için klasör",\r
"formül",\r
"FRUCTAL",\r
"FRUVITA",\r
"FZO",\r
"FZO (Fon uygulaması)",\r
"FZO {0}",\r
"FZO elle reçete",\r
"FZO servisi (ayarlanmadı)",\r
"FZO WebService (Fon'un şartnamesine göre)",\r
"GARNIER",\r
"GAUDA",\r
"GAULOISES",\r
"GAZIRAN",\r
"GEL ZA TUS",\r
"GEL ZA TUŠ",\r
"GET",\r
"GILLETTE",\r
"GIN",\r
"GLADE",\r
"ana",\r
"ana",\r
"ana kasa",\r
"GLO",\r
"yıl",\r
"Google Drive",\r
"Google Drive (Autosync)",\r
"Google Drive (yedek)",\r
"GORDON",\r
"GORDONS",\r
"GORKI LIST",\r
"GORSKA",\r
"misafir",\r
"Misafir",\r
"Misafir — {0} {1}",\r
"Misafir (QR menü)",\r
"Misafir (QR){0}",\r
"misafirin bildirimi bekliyor",\r
"Misafir sonunda geldi",\r
"Misafir silindi.",\r
"Misafirin çıkışı yapıldı.{0}",\r
"Misafir taşındı.",\r
"Misafir kaydedildi.",\r
"Gelmedi",\r
"misafir bugün çıkış yapıyor",\r
"Misafir kendi siparişini iptal eder",\r
"Misafir siparişi iptal etti (QR menü)",\r
"Misafir masadaki QR kodu tarar, menüyü kendi dilinde görür ve sipariş verir — sipariş doğrudan masaya ve mutfağa / bara gider (garson onaylamaz). Misafir, fiş düzenlenene kadar siparişi iptal edebilir, garsonu çağırabilir ve hesap isteyebilir (POS terminalinde kart veya nakit). Mali fişi, garson masayı tahsil ettiğinde bu kasa düzenler.",\r
"Misafir hesabı istiyor. Kasa bilgilendirildi.",\r
"Misafir hesabı istiyor",\r
"misafir odada",\r
"Odada misafir var",\r
"misafir çağırıyor",\r
"Misafir garsonu çağırıyor",\r
"Misafir: {0}",\r
"misafirin bildirimi bekliyor",\r
"Misafirler",\r
"misafirler telefonlarından sipariş verir, garson çağırma, hesabı kartla / nakit ödeme; QR kodlar, diller, görseller",\r
"Misafirler kendileri sipariş verir (bu olmadan: yalnızca menü, garson çağırma ve hesap)",\r
"misafirler girilmedi",\r
"Misafirler girilmedi.",\r
"misafir tesiste",\r
"hazır",\r
"nakit",\r
"Nakit",\r
"NAKİT",\r
"Aynı müşteriden nakit",\r
"Aynı müşteriden bir günde nakit: {0} (sınır 10.000 €, md. 65 f. 2) — {1}",\r
"10.000 € ve üzeri nakit kabul edilemez (Kara Paranın Aklanmasının ve Terörün Finansmanının Önlenmesi Kanunu, md. 65). Fiş düzenlenmedi. Ödeme kartla veya havale ile yapılabilir.",\r
"Kasadaki nakit",\r
"Kasadaki azami nakit (€)",\r
"Nakit ciro",\r
"tamam",\r
"Tamam",\r
"Tamam ({0})",\r
"Şehir",\r
"GRAH",\r
"GRAND KAF",\r
"GRANINI",\r
"GRASAK",\r
"GRAŠAK",\r
"bedava (N+M)",\r
"hata",\r
"greška",\r
"Hata",\r
"Kasa hatası (kod {0}).",\r
"Ekran hatası",\r
"Kasada hata: {0}",\r
"Kasada hata oluştu.",\r
"Mali servis tarafında hata. Gönderim daha sonra tekrarlanacak.",\r
"Elektronik imza okunurken hata oluştu.",\r
"İmza öğesi okunurken hata oluştu.",\r
"Tahsilat hatası",\r
"başlatma hatası",\r
"çalışan işlem hatası",\r
"Sunucu hatası.",\r
"giriş hatası",\r
"Giriş hatası",\r
"Hata: {0}",\r
"GREY GOOSE",\r
"Atıştırmalıklar",\r
"GRISIN",\r
"GRIZ",\r
"grup",\r
"Grup",\r
"Grup boş.",\r
"grupa_id INTEGER",\r
"grupa_id, proizvodjac, neto, neto_jm, pakovanje, max_zaliha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",\r
"Gruplar (kategoriler)",\r
"Bara giden gruplar",\r
"Toplu değişiklik",\r
"Toplu fiyat değişikliği",\r
"GST PLUS",\r
"GUARANA",\r
"GUMENE",\r
"Gusinje",\r
"GUSTIN",\r
"H:TAKSA",\r
"HALLS",\r
"HARIBO",\r
"HAVANA CLUB",\r
"HEETS",\r
"HEINEKEN",\r
"HELJD",\r
"HELL",\r
"temizlik ürünleri",\r
"HEMIJSK OL",\r
"HENNESSY",\r
"Herceg Novi",\r
"hidden",\r
"hijyen",\r
"Hijyen ve kimyasallar",\r
"Acil (cito)",\r
"HLEB",\r
"HLJEB",\r
"HMAC",\r
"Hostel",\r
"Otel",\r
"otel: {0}{1}",\r
"Otelcilik (oteller, apartmanlar, odalar)",\r
"Konaklamayla birlikte yiyecek",\r
"HRENOVK",\r
"md. 17 kapsamında kronik hastalık (kötü huylu, diyabet, epilepsi, MS, HIV, hepatit…)",\r
"http",\r
"HTTP {0}",\r
"HTTP {0}: {1}",\r
"https",\r
"https://… veya http://…:8080",\r
"İnsani yardım",\r
"Alışverişiniz için teşekkürler",\r
"ve fişin sonradan tahsil edilip edilmediği.",\r
"ve Vergi İdaresi'ne gönderilmez. ENU, kasa kaydedildikten sonra girilir (Ayarlar → Fiskalizasyon).",\r
"ve ciroya dahil edilmez; mal stoktan düşülür.",\r
"ve ciroya dahil edilmez; mal stoktan düşülür.{0}",\r
"ICE TEA",\r
"ICE-TEA",\r
"ID",\r
"Program kimliği ({0})",\r
"iframe",\r
"IGRACK",\r
"IGRAČK",\r
"IHDR",\r
"IKOF",\r
"IKOF {0}",\r
"IKOF {0}{1}",\r
"Avans fişinin IKOF'u geçerli değil (\\"{0}\\").",\r
"Avans fişinin IKOF'u geçerli değil.",\r
"Ertelenmiş ödemeli fişin IKOF'u geçerli değil.",\r
"IKOF imzasıyla uyuşmuyor (IKOF, imzanın MD5 değeri olmalıdır). Fiş hatalı kaydedilmiş.",\r
"veya",\r
"veya tutar €",\r
"ILUMA",\r
"var",\r
"Ad",\r
"{0} adı ayrılmıştır",\r
"dosya adı klasörün dışına çıkıyor: {0}",\r
"kasanın okuyamadığı karakterler içeren dosya adı",\r
"Misafir adı zorunludur.",\r
"ad ve soyad",\r
"Ad ve soyad",\r
"Kasiyerin adı zorunludur.",\r
"Telefon adı (kasada görünür)",\r
"img",\r
"INDIJSK",\r
"bilgi: OCR ile girilen hasılatta çoğu zaman \\"KDV hariç toplam\\" yoktur; fiş KDV dahil − KDV olarak alır",\r
"Ingenico Telium (Concert)",\r
"input",\r
"INPUT",\r
"inputmode=\\"decimal\\" placeholder=\\"0 = sınırsız\\"",\r
"inputmode=\\"numeric\\" placeholder=\\"8765\\"",\r
"inputmode=\\"url\\" placeholder=\\"https://…\\"",\r
"INSEKT",\r
"Kurulum, vardiya kapatıldıktan sonra mümkündür.",\r
"Kurulum başlatılamıyor.",\r
"Mevcut sürümün üzerine kurulur; veriler korunur.",\r
"Mevcut sürümün üzerine kurulur; veriler korunur.{0}",\r
"Şimdi yükle",\r
"Anlık",\r
"Anlık ödeme",\r
"Anlık ödeme (hesaba transfer)",\r
"Anlık ödeme etkin değil (Ayarlar → Eklentiler).",\r
"Anlık transfer",\r
"INTEGRAL",\r
"IntPtr h; if (!OpenPrinter(stampac, out h, IntPtr.Zero)) throw new Exception(\\"KASA_NEMA_STAMPACA\\");",\r
"Engellilik",\r
"INVOICE",\r
"IP (192.168.1.50), Windows yazıcı adı veya Bluetooth adresi",\r
"IP, Bluetooth adresi, InnerPrinter, USB \\"vid:pid\\" (boş = ilk USB yazıcı)",\r
"IP, Windows yazıcı adı, Bluetooth adresi veya InnerPrinter",\r
"IPv4",\r
"IQOS",\r
"IRIS",\r
"IRIS CORVINA",\r
"IRIS CORVINA Kasa",\r
"IRIS CORVINA Kasa {0} · © 2026 Dragomir Dačević, yazar ve hak sahibi. Tüm hakları saklıdır.",\r
"IRIS ECR (JSON, terminale köprü)",\r
"IRIS Kasa",\r
"IRIS Kasa — müşteri ekranı",\r
"IRIS Server",\r
"Bu ağda IRIS Server bulunamadı. Adres elle girilebilir (IRIS Server programının \\"Genel bakış\\" ekranı) veya eşleştirme kodu IRIS Admin'den alınan bağlantı olarak girilir.",\r
"Sonuç",\r
"Ödeme sonucu bilinmiyor",\r
"Misafir imzası için slip",\r
"Kapalı",\r
"sunucuda devre dışı",\r
"kapalı",\r
"Kapalı: fişler KDV'siz düzenlenir.",\r
"Devre dışı bırak",\r
"İkisini de kapat",\r
"Gönderimi kapat",\r
"Bağlantıyı kes",\r
"Mali onayı kapatma",\r
"Gönderimi kapatma",\r
"Sunucu bağlantısını kesme",\r
"Kullanılan",\r
"Kullanılan puan: {0}, indirim {1}.",\r
"Kullan",\r
"Deneyim",\r
"Ödendi",\r
"kapanışta ödeme çıkışı",\r
"Belge",\r
"Belge geçerlilik tarihi",\r
"Veri düzeltme",\r
"Düzeltmeler ve iyileştirmeler.",\r
"Düzelttiği avans fişi IKOF",\r
"Düzelttiği avans fişi IKOF {0}{1}",\r
"Belgeyi veren makam",\r
"Aynı bildirim son 10 dakika içinde zaten gönderildi.",\r
"sona erdi",\r
"son kullanma tarihi geçmiş",\r
"Son kullanma tarihi geçti",\r
"İndirme zaman aşımına uğradı.",\r
"Aynı fiş referans fişler arasında iki kez belirtilmiş.",\r
"Aynı fiş iki kez belirtilmiş.",\r
"aynı ad hem dosya hem klasör: {0}",\r
"aynı ad iki kez geçiyor: {0}",\r
"Item",\r
"Item Price",\r
"Item Tax",\r
"ITF",\r
"teslimat uygulamasından (veya müşterinin adı)",\r
"Avanstan",\r
"avanstan {0}",\r
"Avanstan fiş tutarından ({0}) fazlası ödenemez.",\r
"Avanstan fiş tutarından fazlası ödenemez.",\r
"\\"{0}\\" dosyasından yeni kasa listesi alınır ve {1} yüklenir. Düzenlenmiş fişler değişmez.",\r
"\\"{0}\\" dosyasından sunucu adresi, yazdırma ve benzeri ayarlar alınır.\\n\\nKasa etiketi, satış noktası, firma, Vergi İdaresi'ne ait tüm kodlar, ortam ve gönderim anahtarları değiştirilmez (kasa, kasa listesinden seçilmiştir).",\r
"\\"{0}\\" dosyasından sunucu ve yazdırmanın yanı sıra kasa etiketi, mağaza, firma ve Vergi İdaresi kodları da alınır. Ortam (TEST/ÜRETİM) ve gönderim anahtarları alınmaz.",\r
"Belgeden yalnızca veriler okunur; görüntü kaydedilmez.",\r
"addan",\r
"FZO şartnamesinden",\r
"Listeden ürünleri seçin…",\r
"Dosya seç…",\r
"Listeden kasa seç…",\r
"Görsel seç…",\r
"Seç…",\r
"Avans fişini seçin.",\r
"Tarih seçin.",\r
"Geçerli bir dönem seçin.",\r
"Raporu ve dönemi seçin, ardından \\"Göster\\"e basın.",\r
"Aynı satırda son geceyi seçin.",\r
"Oda türünü seçin.",\r
"seçildi",\r
"Aynı masa seçildi.",\r
"seçildi",\r
"Seçilenler",\r
"seçilen ürünler ( )",\r
"seçilen ürünler ({0})",\r
"seçildi. Ürünler listede işaretlenir.",\r
"Listeden bir ürün seçildiğinde dillere göre adı ve açıklaması, alerjenler, etiketler ve görsel açılır.",\r
"Listeden bir grup seçildiğinde dillere göre adı, menüdeki sırası ve kutucuk görseli açılır.",\r
"Kasa seçimi",\r
"Kasa seçimi kullanılamıyor.",\r
"Gruba göre seçin veya ada göre arayın.",\r
"Çalışma mağazasını seçin",\r
"Listeden seçim düzenlemeyi açar; \\"Yeni kayıt\\" yeni bir kayıt ekler.",\r
"Listeden seçim verileri gösterir.",\r
"Seçim daha sonra ayarlardan değiştirilebilir (Ayarlar → Kasa).",\r
"Ver — nakit",\r
"Ver — kart",\r
"Avans fişi düzenle",\r
"Fiş düzenle",\r
"Bir iptal fişi düzenlenir ve bu fiş kayıtlarda iptal edilmiş olarak kalır. İptal geri alınamaz.",\r
"Teslim eden",\r
"Veren makam",\r
"Düzenlendi:",\r
"Düzenlendi:",\r
"Reçete ile verildi. Fiş: {0} ({1}).",\r
"Düzenlenen: {0}.",\r
"izdavac",\r
"yayıncı: {0}",\r
"yayıncı: ekrana erişim talebi",\r
"Reçeteli satış",\r
"Savunma",\r
"Düzenle",\r
"Ürün bilgilerini düzenle",\r
"Değişiklik",\r
"Ürünü düzenle",\r
"Değişiklik geri alındı. Fiyat {stara} değerine döndürüldü.",\r
"Kasiyeri düzenle",\r
"Değişiklik bulunamadı.",\r
"Ürün verisi değişikliği burada iptal edilmez. Veriler ürün formunda değiştirilir.",\r
"Fiyat değişiklikleri kaydedildi: {0}",\r
"Fiyat değişiklikleri: uygulanan {0}{1}, atlanan {2}, diğer kasalar için {3}.",\r
"Menü değişiklikleri kaydedilmedi",\r
"Değişiklikler kaydedilmedi. Vazgeçilsin mi?",\r
"Bu kasadaki değişiklikler klasöre yazılmadı: {0}",\r
"Bu kasanın değişiklikleri girildi.",\r
"bu kasanın değişiklikleri kaydedildi",\r
"Menü içeriğindeki değişiklikler kaydedilmedi ve silinecek.",\r
"{0} sürümündeki değişiklikler",\r
"Tutar",\r
"IZNOS",\r
"Tutar (EUR)",\r
"Avans tutarı sıfırdan büyük olmalıdır.",\r
"Avans fişi tutarı sıfırdan büyük olmalıdır.",\r
"Depozito tutarı negatif olamaz.",\r
"Vardiya başında kasadaki nakit tutarı (€).\\nBoş veya 0 = kasa avansı yok.",\r
"Tutar zorunludur.",\r
"Tutar terminale gönderildi. Müşteri terminalde kartla öder.",\r
"Tutar çok büyük.",\r
"Tutar, terminalin kabul ettiği en yüksek tutarı aşıyor ({0} €).",\r
"Tutar, avansın serbest kısmından büyük.",\r
"Avans düzeltme tutarı sıfırdan büyük olmalıdır.",\r
"Tutar sıfırdan büyük olmalıdır.",\r
"Terminaldeki tutar: {0}. Fiş, ancak terminal ödemeyi onayladıktan sonra düzenlenir. Slipteki onay numarası (isteğe bağlı):",\r
"Ücret tutarı sıfırdan büyük olmalıdır.",\r
"Tutar geçerli değil",\r
"Tutar geçerli değil. Örnek: 1250,50 (binlik ayırıcı olmadan, en fazla iki ondalık).",\r
"Silinen fişin tutarı negatif olamaz.",\r
"Ödeme tutarı geçerli değil.",\r
"Nakit çekim tutarı sıfırdan büyük olmalıdır.",\r
"Nakit çekim tutarı sıfır olamaz.",\r
"İndirim tutarı geçerli değil.",\r
"İade tutarı (EUR)",\r
"İade tutarı 0.",\r
"İade tutarı sıfırdan büyük olmalıdır.",\r
"Tutar, odanın izin verilen borcunu aşıyor.",\r
"Fiş tutarı ({0}), kalemlerinin toplamından ({1}) büyük.",\r
"Tutar belediyeye göre önerilir; diğer belediyeler için belediye kararındaki tutarı girin.",\r
"Özet fiş iptal tutarı sıfırdan küçük olmalıdır.",\r
"Özet fiş tutarı sıfırdan büyük olmalıdır.",\r
"Özet fiş tutarı tek tek fişlerin toplamına eşit değil.",\r
"Vergi tutarı",\r
"Vergi tutarı (kişi başı gecelik EUR)",\r
"Vergi tutarı kaydedildi.",\r
"Vergi tutarı 10 EUR'dan fazla",\r
"Vergi tutarı geçerli değil.",\r
"Tutar sent olarak (aksi halde avro)",\r
"İletideki tutar ({0}) fiş tutarı ({1}) değil.",\r
"\\"{0}\\" için tutar geçerli değil.",\r
"Ödeme tutarı geçerli değil.",\r
"Terminal için tutar geçerli değil.",\r
"Rapor",\r
"Önceki ay için vergi raporu.",\r
"Raporlar",\r
"Raporlar kullanılamıyor.",\r
"Kaynak",\r
"izvor TEXT",\r
"IZVORSKA",\r
"Dışa aktarma",\r
"CSV dışa aktar",\r
"j4sVG68Z6QZGUfZ64qBQSMeUiLa8LQYOxzMKIXC-Pmg",\r
"Doz",\r
"Doz",\r
"JACK",\r
"JACK DANIELS",\r
"JACOBS",\r
"JAFA",\r
"JAFFA",\r
"JAGER",\r
"JÄGER",\r
"JAGERMAISTER",\r
"JAGERMEIJSTER",\r
"JAGERMEISTER",\r
"JÄGERMEISTER",\r
"JAGNJET",\r
"Yumurta",\r
"JAMESON",\r
"JANA",\r
"Ocak",\r
"Ocak",\r
"JAR",\r
"JCB",\r
"{0} fiş var",\r
"1 fiş var",\r
"ekranda.",\r
"açık.",\r
"indirildi ve yüklendi.",\r
"indirildi ve bir sonraki başlatmada uygulanacak.",\r
"indirildi ve doğrulandı.",\r
"Bir şefin PIN'i yok ve onay veremez (başka bir şefin PIN'i istenir). PIN \\"Düzenle\\" düğmesiyle girilir.",\r
"Birim",\r
"Ölçü birimi listede yok.",\r
"Net miktar birimi şunlardan biri olmalıdır: {0}.",\r
"Ambalaj birimi kg, l veya adet olmalıdır.",\r
"bir",\r
"tek seferlik",\r
"Tek kişilik oda",\r
"JELEN",\r
"Dil",\r
"Bu kasanın ekran yazılarının dili; hemen geçerli olur. Mali fişler, çıktılar, etiketler ve dışa aktarımlar Karadağca kalır.",\r
"Bu cihazın ekran yazılarının dili. Dışa aktarımlar (Excel, PDF), çıktılar ve etiketler Karadağca kalır.",\r
"Bu cihazın ekran yazılarının dili. Dışa aktarımlar (PDF, Excel, XML), çıktılar, mali fişler ve Vergi İdaresi formları Karadağca kalır.",\r
"Dil değiştirilmedi: {0}",\r
"Program dili",\r
"Dil: {0}{1}",\r
"JIKR",\r
"JIM BEAM",\r
"Birim",\r
"JM neto",\r
"jm TEXT",\r
"JMB",\r
"JOGURT",\r
"JOHNNIE",\r
"JOHNNIE WALKER",\r
"{0} kaldı",\r
"Daha fazla kasa / cihaz",\r
"Henüz misafir siparişi yok.",\r
"henüz olmadı",\r
"Dün",\r
"JUICE",\r
"Temmuz",\r
"Temmuz",\r
"Haziran",\r
"Haziran",\r
"JUNEC",\r
"JUNEĆ",\r
"JUNETINA",\r
"Ne zaman",\r
"Etkinken fişler, stornolar, para girişleri ve çıkışları internet erişimi olur olmaz Vergi İdaresi'ne gider. Sertifika ve geçerli kodlar gereklidir. Değişiklik yalnızca \\"Kaydet\\" sonrasında geçerli olur. Etkinken ve kasa hazır değilken (sertifika yok, kod geçersiz) fiş düzenlenmez.",\r
"Girildiğinde",\r
"KAFA",\r
"Kahve ve çay",\r
"KAHLUA",\r
"KAHVA",\r
"KAJMAK",\r
"KAKAO",\r
"Misafir ayrılırken fişlerin nasıl düzenleneceği.",\r
"Takvim",\r
"Kamp",\r
"Kanal",\r
"Kanal deneme veya kararlı olmalıdır.",\r
"Teslimat kanalları (virgülle ayrılmış)",\r
"Teslimat kanalları girilmemiş (Ayarlar → Ek özellikler).",\r
"KAPUCIN",\r
"KARLOV",\r
"Kart",\r
"KART",\r
"Kart / anlık ödeme",\r
"Kart: \\"Terminalde onaylandı mı?\\" onayı",\r
"Kasa",\r
"KASA",\r
"Kasa (ENU)",\r
"Kasa {0} · {1} · sunucuyla eşleştirildi",\r
"{0} numaralı kasa tahsilata başladı. Yalnızca bu kasa çalışmıyorsa serbest bırakılabilir.",\r
"Kasa ↔ terminal",\r
"Kasa, teknik hataları (ekran çökmesi, sunucu hatası, Vergi İdaresi tarafından reddedilme) fiş içeriği olmadan yayıncıya otomatik olarak gönderir; kişisel veriler (adlar, telefonlar, tutarlar) gönderilmeden önce silinir. Burada kasanın kaydetmediği şeyler açıklanır: hangi işlem yapılıyordu, ne bekleniyordu ve ne oldu.",\r
"Kasa ve terminal uyumlu.",\r
"Firmanın kasa listesinden seçilen kasa, kendi satış noktasının fiyatlarını da alır.",\r
"Kasa, avans fişi için düzeltme fişi düzenler.",\r
"Kasa, her fiyat değişikliğinde bunu \\"{0}\\" klasörüne (esl_cijene.json) otomatik olarak yazar.",\r
"Kasa sunucuya bağlı ve veri alışverişi güncel.",\r
"Kasa sunucuya bağlı ve veri alışverişi güncel.{0}",\r
"Kasaya bildirildi: {0} numaralı masa hesabı istiyor.",\r
"Kasa yeni olarak başlatıldı. Önceki veriler şu klasörde saklandı: {0}.",\r
"Kasa ayarlandı: {0} · {1}, {2}{3}{4}",\r
"Kasa ayarlandı: {0} · etiket {1}, {2}",\r
"Kasa firmaya bağlandı",\r
"Kasa {0} firmasına bağlandı (PIB {1})",\r
"Kasa {0} firmasına bağlandı. Fiyatlar alınıyor…",\r
"Kasa bağlandı. Firmanın fiyat listesi sunucuda yok (Muhasebe: Kasa fiyat listesi → \\"Şimdi veri alışverişi yap\\").",\r
"Kasa deneme modunda",\r
"Kasa sunucuyla eşleştirildi: {0} ({1}).",\r
"Kasa sunucuyla eşleştirilmiş. Muhasebe ve Yönetici ile veri alışverişi yalnızca sunucu üzerinden yapılır, bu klasör kullanılmaz. {0}",\r
"Kasa zaten eşleştirilmiş. Yeni eşleştirme \\"Bağlantıyı kes\\" işleminden sonra mümkündür.",\r
"Kasa okunamayan bir yanıt döndürdü.",\r
"kasa henüz seçilmedi",\r
"Kasa henüz eşleştirmeye hazır değil.",\r
"Kasa yanıt vermiyor — yeniden deneyin.",\r
"Kasa bu telefonu tanımıyor. Eşleştirmenin yeniden yapılması gerekir.",\r
"Kasanın firma paketi yok. Kasa, Muhasebe'ye bir kod veya dosyadan alınan paketle bağlanır.",\r
"Kasada \\"{0}\\" rolü yok. Kasada yalnızca kasa şefi (sef-kase) ve kasiyer rolleri var. Talimat yürütülmedi.",\r
"kasa seçilmedi",\r
"Kasa seçilmedi",\r
"Kasa sunucuya bağlı değil (Ayarlar → Sunucu) — QR menü sunucu üzerinden çalışır.",\r
"Kasa IRIS CORVINA sunucusuna bağlı değil ve Muhasebe ile veri alışverişi yok.",\r
"Kasa hazır değil (kasa penceresi açık değil).",\r
"Kasa Vergi İdaresi için hazır değil",\r
"Kasa sunucudan alıma hazır değil (eşleştirilmemiş veya veri alışverişi klasörü yok).",\r
"Kasa hazır değil.",\r
"kasa eşleştirilmemiş (Sunucu bölümü)",\r
"Kasa sunucuyla eşleştirilmemiş (Ayarlar → Sunucu). Bildirim gönderilemez.",\r
"Kasa IRIS CORVINA sunucusuyla eşleştirilmemiş (Ayarlar → Sunucu). Program içinden destek yalnızca eşleştirilmiş kasa için çalışır.",\r
"Kasa IRIS CORVINA sunucusuyla eşleştirilmemiş. Mesajlar, talepler ve hata bildirimleri sunucu üzerinden gider. Eşleştirme: yayıncının verdiği kodla (Ayarlar → IRIS CORVINA sunucusu).",\r
"Kasa IRIS CORVINA sunucusuyla eşleştirilmemiş. Eşleştirmeyi şef, yöneticinin verdiği kodla yapar (Ayarlar → \\"IRIS CORVINA sunucusu (veri alışverişi)\\"); veri alışverişi bundan sonra sunucu üzerinden, birkaç saniye içinde gerçekleşir.",\r
"Kasa sunucuyla eşleştirilmemiş ve klasör ayarlanmamış.{0}",\r
"Kasa sunucuyla eşleştirilmemiş, bu nedenle veri alışverişi bu klasör üzerinden yapılırSunucuyla eşleştirmeden sonra (yukarıdaki bölüm) veri alışverişi beklemeden sunucu üzerinden yapılır ve klasör yedek için kullanılır. Boş = kapalı.",\r
"Kasa sunucu ile eşleştirilmemiş. Değişiklikler eşleştirmeye kadar kasada bekler (Ayarlar → IRIS CORVINA sunucusu).",\r
"Kasa eşleştirilmemiş.",\r
"Kasa, {0} ENU kodunda kalır (daha önce kaydedilmiş kasanın kodu) ve fişler Vergi İdaresi'ne bu kodla gönderilir. Onay yalnızca Vergi İdaresi ile anlaşma halinde yapılabilir; aksi halde yeni bir ENU kodu girilir.",\r
"Kasa yeni olarak başlıyor. Program kapanıyor ve yeniden başlayacak…",\r
"Kasa, ilk kurulumdan sonraki gibi başlar: firmaya bağlanma ekranı gelir; fiş, kasiyer, ayar ve sunucu bağlantısı olmaz. Program kapanır ve yeniden başlar.\\n\\nMevcut veriler silinmez: kasa veri klasörü içinde tarihli ayrı bir klasöre taşınır ve veritabanı yedeği alınır.\\n\\nOnaylamak için NOVA sözcüğünün yazılması gerekir.",\r
"Kasa sunucuyla dosya alışverişini durdurur ve belirtecini unutur (cihazı sunucuda yönetici devre dışı bırakır). Klasör (Google Drive) üzerinden veri alışverişi, eşleştirmeden önceki gibi çalışmaya devam eder. Yeniden eşleştirmek için yeni bir kod gerekir.{0}",\r
"Kasa, firmanın verilerini, satış noktalarını, ürünlerini ve fiyatlarını Muhasebe'den alır.",\r
"Kasa, misafir siparişlerini QR menüden alır.",\r
"Kasa, garsonların telefonlarından sipariş alır ({0}). Son 90 sn içinde bağlanan: {1}.",\r
"Kasa telefonları şu adreste kabul eder:",\r
"Kasa Racun",\r
"Kasa sunucu olmadan da çalışır. Sunucu girildiğinde her fiş, internet erişimi olur olmaz otomatik olarak gönderilir.",\r
"Kasa resepsiyon olarak da çalışır",\r
"Kasa şu anda yeni kasa olarak başlatılamıyor:\\n\\n· {0}",\r
"Kasa tutarı terminale gönderir, terminal sonucu döndürür (onay numarası, maskelenmiş kart, kart türü). Fiş, terminal ödemeyi onayladığında düzenlenir. NLB terminali için tür ve bağlantı, terminaldeki banka uygulamasına bağlıdır —",\r
"Kasa bu cihazda başlatılamıyor: \\"Android System WebView\\" çok eski.\\n\\n\\"Android System WebView\\" Play Store'da güncellenmeli (sürüm {1} veya üzeri) ve kasa yeniden başlatılmalıdır. Güncelleme mümkün değilse cihaz kasayı desteklemiyor.\\n\\nVerilere dokunulmadı.",\r
"Kasa başlatılamadı.\\n\\n{0}\\n\\nVerilere dokunulmadı. Programı kapatıp yeniden başlatmanız gerekir. Hata tekrarlanırsa veri klasörünü saklayıp bakım ekibine başvurulmalıdır.",\r
"Kasa sunucuya bağlanıyor.",\r
"fiyatlar değiştiğinde kasa esl_cijene.json dosyasını yazar",\r
"Kasa şu anda {0} sürümünden çalışıyor ve dosyaları geçerli değil. Kasayı kapatın, yeniden açın, ardından güncellemeyi tekrarlayın.",\r
"Kasa-Azuriranje",\r
"Kasa: {0}{1}",\r
"Kasa: kartla",\r
"Kasalar ve mağazalar → Kasa ekle ve kod oluştur",\r
"kasiyer",\r
"Kasiyer",\r
"Kasiyer · neden · ne",\r
"Kasiyer · ne kaldırıldı",\r
"Kasiyer / operatör",\r
"Kasiyer kaydedildi: {0}",\r
"Kasiyer kaydedildi: {0}. Ayarlar kapatıldıktan sonra kasiyer girişi yapılır.",\r
"Kasiyer mevcut değil.",\r
"ada göre kasiyer",\r
"kasiyer terminalden onayladı",\r
"kasiyer onayladı: onaylanmadı",\r
"Vardiya kapanışında kasiyer saydığı tutarı girer; beklenen tutar ve fark yalnızca kapanışta (Z) görülür. PIN'li amir her şeyi, X raporunda da dahil, görür.",\r
"\\"{0}\\" adında bir kasiyer zaten var.",\r
"kasir TEXT",\r
"kasir_id INTEGER",\r
"Kasiyerler",\r
"Kasiyerler \\"Kasiyerler\\" bölümünde girilir: ad, PIN ve operatör kodu. Bundan sonra kasa açılışta kimin çalıştığını sorar ve kasiyerin adı fişe yazılır.",\r
"gecikti",\r
"Daha sonra",\r
"Katalog boş.",\r
"Katalog kaydedildi: {0}",\r
"Katalog içe aktarıldı: {0}, {1} barkod",\r
"Sunucudan katalog",\r
"katalog: —",\r
"katalog: {0}",\r
"Katalog: {0} ürün.",\r
"Kategori",\r
"Kategoriler",\r
"KECAP",\r
"KEČAP",\r
"KEFIR",\r
"KEKS",\r
"KESA ZA",\r
"kg",\r
"KG",\r
"KIFL",\r
"Yer fıstığı",\r
"KIKIRIKI",\r
"KILLA",\r
"kilogram (tartılarak)",\r
"KINDER",\r
"kiosk",\r
"Kiosk",\r
"Büfe — pazar günü modu",\r
"Kiosk — pazar günleri ve tatillerde de çalışır",\r
"Kiosk (pazar günleri ve tatillerde de çalışır)",\r
"Kiosk (pazar günleri de açık)",\r
"KISELO ML",\r
"KISJEL",\r
"KIT KAT",\r
"KITKAT",\r
"KLAMERIC",\r
"sınıf",\r
"bir masaya tıklamak onun fişini ekranda açar",\r
"Anahtar eski biçimde (RSA PRIVATE KEY). PKCS#8 (\\"BEGIN PRIVATE KEY\\") gerekir.",\r
"Anahtar içe aktarıldı",\r
"Anahtar parolayla korunuyor. Korumasız bir PKCS#8 gerekir.",\r
"Anahtar, içe aktarılan sertifikaya ait değil. Anahtarı da içeren bir sertifika (.pfx) içe aktarın veya önce mevcut sertifikayı kaldırın.",\r
"İmza anahtarı",\r
"kljuc=vrijednost; kljuc2=vrijednost2",\r
"Anahtarlar okunabiliyor. Hiçbir şey taşınmadı.",\r
"Anahtarlar kaldırıldı, ancak dosya hâlâ okunamıyor ({0}). Kasanın yeniden başlatılması gerekir.",\r
"KNJAZ",\r
"Yerli misafir defteri",\r
"Misafir defteri",\r
"Yabancı misafir defteri",\r
"Muhasebe",\r
"Knjigovodstvo-sync",\r
"Ko",\r
"KOBASIC",\r
"{0} kodu başka bir programla kayıtlı bir ENU'dur ve kullanılmamalıdır.",\r
"{0} kodu başka bir programla kayıtlı bir ENU'dur ve kullanılmamalıdır. Bu kasa için yeni bir ENU gerekir (Muhasebe → Kasalar ve mağazalar) veya \\"Bu yerde başka bir kasa\\" seçeneği seçilmelidir.",\r
"{0} kodu \\"{1}\\" ürününün kodudur ve kaldırılamaz.",\r
"{0} kodu \\"{1}\\" ürününün kodudur. Taşınamaz.",\r
"{stari} kodu aynı zamanda \\"{drugi}\\" ürününün barkodudur. Bu üründen silinsin mi?",\r
"ENU kodu (kasa)",\r
"Listeden ENU kodu",\r
"ENU kodu onaylandı.",\r
"ENU kodu kasa listesinden alınmıştır ve daha önce kaydedilmiş bir kasaya aittir. Bu program için Vergi İdaresi yeni bir ENU kodu atar (kasa kaydı); bu kod buraya girilir ve kaydedilir. O zamana kadar kasa fişleri Vergi İdaresi'ne göndermez. Vergi İdaresi ile anlaşma gereği kasa bu kodda kalıyorsa, amir bunu aşağıdaki düğmeyle onaylar ve önceki kasanın son fiş numarasını girer (\\"Ayarla…\\").",\r
"ENU kodu kayıtlı değil, aktif değil veya bu firmaya ait değil.",\r
"ENU kodu ab123ab123 biçiminde değil (verilen: \\"{0}\\").",\r
"Kodu sunucu yöneticisi verir (48 saat geçerlidir; tek bir kod firmanın tüm kasaları için geçerli olabilir, bu durumda cihaz adı kod adının ardına eklenir). Kasa eşleştirilmediği sürece veri alışverişi yalnızca klasör üzerinden yapılır (Google Drive, aşağıdaki bölüm).",\r
"Kasa kodu",\r
"Kasa kodu (ENU)",\r
"Kasa kodu (ENU) {0} kasa listesinden alındı ve daha önce kayıtlı bir kasaya aittir. Bu program için Vergi İdaresi yeni bir ENU kodu atar (Ayarlar → Mali onay → ENU kodu). Kasa, Vergi İdaresi ile anlaşma gereği bu kodu koruyorsa onayı sorumlu verir (\\"ENU'yu listeden onayla…\\").",\r
"Bakımcı kodu aktif bakımcıyla uyuşmuyor.",\r
"Yazılım bakımcı kodu",\r
"Operatör kodu",\r
"Vergi İdaresi'ndeki operatör kodu",\r
"Operatör kodu geçerli değil: 10 karakter, sırasıyla 2 harf, 3 rakam, 2 harf, 3 rakam (örn. ab123cd456). Alan boş bırakılabilir.",\r
"Operatör kodu, Vergi İdaresi'nin verdiği biçimde değil (ab123cd456: iki harf, üç rakam, iki harf, üç rakam). Kasiyerin henüz yoksa alanı boş bırakın.",\r
"Operatör kodu, kendi kodu olmayan kasiyerin fişleri için geçerlidir (Kasiyerler → Düzenle).",\r
"Operatör kodu: {0} · PIN: {1}{2}",\r
"İşyeri kodu",\r
"İşyeri kodu aktif bir işyerine ait değil.",\r
"Alan adı kayıt kuruluşunda (örn. domen.me) bir CNAME DNS kaydı oluşturun: ad \\"meni\\" (veya istediğiniz ad) → değer {0}.",\r
"Ağırlıklı kod (tartı etiketi) ürün barkodu değildir.",\r
"Ağırlıklı kod (terazi etiketi) bir ürünle ilişkilendirilmez.",\r
"Kod Muhasebe'de oluşturulur:",\r
"Yazılım kodu",\r
"Yazılım kodu etkin yazılımla uyuşmuyor (Ayarlar → Fiskalizasyon).",\r
"Kod şuraya yönlendirir:",\r
"Kod şuraya yönlendirir: {0}. A4 üzerine 4 adet A6 kart basılır (stand veya etiket).",\r
"Eşleştirme kodu",\r
"Eşleştirme kodunun süresi doldu veya kod zaten kullanıldı. Yeni bir kod gerekli (kasada: \\"Telefonu eşleştir\\").",\r
"Eşleştirme kodu zorunludur (sunucu yöneticisi verir).",\r
"Eşleştirme kodu zorunludur (sunucu yöneticisi verir).",\r
"Eşleştirme kodu zorunludur (Muhasebe: Kasalar ve mağazalar → Kasa ekle ve kod oluştur).",\r
"Eşleştirme kodu bu kasaya ait değil (veya yenisiyle değiştirildi).",\r
"eşleştirme kodu, örn. ABCD-EFGH-IJKL",\r
"Formdaki kodlar geçerli değil ve kaydedilmedi. {0}",\r
"Katsayı",\r
"KOKIC",\r
"KOKTEL",\r
"Mkt.",\r
"Kolašin",\r
"Miktar",\r
"Miktar",\r
"Miktar (kg)",\r
"Miktar (ambalaj)",\r
"En az bir kalem için miktar zorunludur.",\r
"En az bir kalem için miktar zorunludur.",\r
"geçersiz miktar",\r
"Miktar geçerli değil.",\r
"Son kalemin miktarı",\r
"Bu misafirin ödediği her kalemin miktarı tahsilat için ekranda kalır; geri kalanı masaya döner.",\r
"\\"{0}\\" için miktar çok büyük ({1}, en fazla {2}).",\r
"\\"{0}\\" için miktar 0 ile {1} arasında olmalıdır.",\r
"\\"{0}\\" için miktar geçerli değil.",\r
"miktar fiyatı",\r
"ne kadar",\r
"Adet",\r
"KOM",\r
"Komada u pakovanju",\r
"Komut (\\\\r, \\\\n, \\\\x05)",\r
"Mahsuplaşma",\r
"mahsup edildi",\r
"KOMPLET",\r
"KONJAK",\r
"garson",\r
"Garson (ve garson telefonu)",\r
"Telefondaki garson (Android, \\"Garson telefonu\\" modundaki Kasa) bir masa seçer, siparişi girer ve gönderir; sipariş fişini bu kasa yazdırır, hesap fişi de bu kasada düzenlenir. Garson ad ve PIN ile giriş yapar (Kasiyerler → \\"Garson\\" rolü). Kasa bilgisayarının yönlendiricide sabit bir adrese ihtiyacı vardır (adres değiştikten sonra telefon yeniden eşleştirilir). İlk etkinleştirmede Windows özel ağa erişim izni ister; izin zorunludur.",\r
"Garson artık kasada etkin değil.",\r
"Garsonlar: hata",\r
"İletişim bilgileri",\r
"Misafir iletişim bilgileri \\"Resepsiyon (misafirlerin kişisel verileri)\\" yetkisini gerektirir.",\r
"Bildirimler ve teklifler için iletişim bilgileri",\r
"Bağlam \\"{0}\\": izin verilmeyen alan veya çok uzun metin.",\r
"Ekteki bağlam {program, verzija, uloga, ekran} nesnesi olmalıdır.",\r
"Barkodun kontrol rakamı geçerli değil. Girilen rakamların kontrol edilmesi gerekir.",\r
"Kontrol numarası uyuşmuyor. Verileri belgeyle karşılaştırın.",\r
"Paketin sağlama toplamı uyuşmuyor — indirme reddedildi.",\r
"KONZERV",\r
"konserve",\r
"Kopyala",\r
"Tüm bildirimi kopyala",\r
"Kopyalama başarısız oldu.",\r
"Kopyalandı",\r
"avans fişi düzeltmesi",\r
"Avans fişi düzeltmesi — kullanılan avans",\r
"avans fişinin düzeltme fişi",\r
"Avansın düzeltme fişi düzenlenmedi Kasa bunu bir sonraki denemede kendisi düzenleyecek.",\r
"AVANS FİŞİNİN DÜZELTME FİŞİ",\r
"Avans fişinin düzeltme fişi, o avanstan ödenen fişleri belirtmelidir.",\r
"Avans fişinin düzeltme fişi: düzeltme tutarı, belirtilen fişlerde avanstan ödenen tutarların toplamına eşit değil.",\r
"Önceki tahsilat için avansın düzeltme fişi düzenlenmedi {1}, düzenlendiğinde.",\r
"Düzeltme fişi düzenlendi (IKOF {0}), ancak sunucuya kayıt başarısız oldu. Kaydı tekrarlayın.",\r
"Düzeltme fişi, düzelttiği fişten önce düzenlenemez.",\r
"Düzeltme fişi, asıl fişin IKOF'u yerine kendi IKOF'una atıfta bulunuyor.",\r
"Kullanıcı",\r
"En düşük emekli aylığı alan kişi",\r
"Kullanıcının {mjesto} için fiyat değiştirme yetkisi yok.",\r
"Sosyal koruma yararlanıcısı",\r
"Yalnızca bildirim için kullanılır.",\r
"KOTANYI",\r
"Kotor",\r
"Dönemin bitişi başlangıçtan önce.",\r
"kısa kod",\r
"KREMA",\r
"Kriptografik imza geçerli değil. Sertifikayı kontrol etmeniz gerekir.",\r
"KROASAN",\r
"KROISAN",\r
"Kasa banka uygulamasına yalnızca ödeme gönderir; iptal ve iade banka uygulamasında yapılır.",\r
"sürücü / yazdırma penceresi üzerinden",\r
"klasör üzerinden (Google Drive)",\r
"KRSTAC",\r
"krug INTEGER",\r
"sunucu ile veri alışverişi turu",\r
"KRUH",\r
"KRUSKOVAC",\r
"KRUŠKOVAC",\r
"Ev ve çeşitli",\r
"Ev veya daire",\r
"Ev kimyasalları",\r
"MUTFAK",\r
"KUKURUZ",\r
"KUMOVA",\r
"Müşteri",\r
"Fişteki müşteri (firma)",\r
"Fişte müşteri (firma) veya sadakat müşterisi (telefon)",\r
"Müşteri / kasiyer",\r
"Müşterinin {0} puanı var ve {1} puan harcayamaz.",\r
"Fişte müşteri",\r
"Fişteki müşterinin hem PIB numarası hem de adı olmalıdır.",\r
"Fişteki müşteri: {0}{1}.",\r
"müşterinin parası yok",\r
"Müşterinin parası yok",\r
"müşteri ödemedi",\r
"Müşteri ödemedi",\r
"müşteri vazgeçti",\r
"Müşteri vazgeçti",\r
"Müşteri, bankasının uygulamasından şu hesaba öder:",\r
"Müşteri {1} hesabına {0} öder, referans numarası {2}.\\n\\nÖdeme geldi mi (bankanın uygulamasından kontrol edin)?",\r
"sadakat müşterisi",\r
"Sadakat müşterisi — telefon",\r
"sadakat müşterisi · {0}",\r
"Sadakat müşterisi: {0}{1}{2}",\r
"kupac_adresa TEXT",\r
"kupac_grad TEXT",\r
"kupac_naziv TEXT",\r
"kupac_pib TEXT",\r
"Müşteri: ülke üç büyük harften oluşan bir kod olmalıdır, ör. MNE, SRB (verilen: \\"{0}\\").",\r
"Müşteri: ad zorunludur.",\r
"Müşteri: bilinmeyen kimlik numarası türü \\"{0}\\".",\r
"Müşteri: PIB zorunludur (gerçek kişi için JMBG veya kimlik belgesi numarası).",\r
"Müşteri: PIB geçerli değil (5–20 rakam/harf, boşluksuz).",\r
"Sadakat müşterileri:",\r
"KVASAC",\r
"Kota {0}, ≥ 0 olan bir tam sayı veya null (sınırsız) olmalıdır.",\r
"Kotalar zorunludur.",\r
"label",\r
"LAK ZA",\r
"zincir bağlantı sertifikasıyla başlamıyor",\r
"sertifika zinciri geçerli değil",\r
"LAV",\r
"LAVAZZA",\r
"LAY",\r
"LEDEN",\r
"LEDENI CAJ",\r
"LEDENI ČAJ",\r
"left",\r
"LEIBNIZ",\r
"LESNIK",\r
"LEŠNIK",\r
"yatak",\r
"Yatak",\r
"li",\r
"Ağır duyusal veya bedensel engeli olan kişi",\r
"65 yaşın üzerindeki kişi",\r
"Lisans",\r
"{0} lisansı (\\"{1}\\" paketi) Kasa modülünü içermiyor. Yeni vardiya açılamaz; lisansı genişletmek yayıncının işidir.",\r
"Lisans {0}, {1} tarihinde sona erecek ({2} {3} sonra).",\r
"Lisans {0}, {1} tarihinde sona erdi. Program {2} {3} daha çalışmaya devam edecek. Lisansın uzatılması gerekir.",\r
"Lisans {0}, {1} tarihinde sona erdi. Program yalnızca verileri okumak ve dışa aktarmak için çalışır. Lisansın uzatılması gerekir.",\r
"Lisans {0}, {1} tarihinde iptal edildi. Program yalnızca verileri okumak ve dışa aktarmak için çalışır.",\r
"Lisans {0}, {1} tarihinden itibaren askıya alındı. Askı kaldırılana kadar program yalnızca verileri okumak ve dışa aktarmak için çalışır.",\r
"{0} lisansı geçerli değil.",\r
"Lisans {0} süresiz geçerlidir.",\r
"Lisans {0}, {1} tarihine kadar geçerlidir",\r
"Eczacı lisansı — {0}",\r
"Firma lisansı geçerli değil. Yeni vardiya açılamaz.",\r
"Lisans geçerli değil: {0}",\r
"Lisans bir nesne değil.",\r
"Sunucudan lisans",\r
"Kullanılan kütüphanelerin lisansları",\r
"Kişisel hijyen",\r
"Kimlik kartı",\r
"Misafirlerin kişisel verilerini resepsiyon görür ve girer.",\r
"Misafirlerin kişisel verilerini bu yetkiye sahip kullanıcı görür.",\r
"Kişisel veriler",\r
"Kişisel veriler saklama süresi dolduğu için silindi.",\r
"İlaç",\r
"Reçeteli ilacı eczacı verir. Kasada eczacı girişi yapılmamış.",\r
"İlaç FZO İlaç Listesi'nde yok.",\r
"LIKER",\r
"LILY",\r
"LIMIT {0}",\r
"LIMONCELLO",\r
"LINDT",\r
"LION",\r
"LIQUEUR",\r
"LIZALIC",\r
"Hekim (faksimile)",\r
"LJESNIK",\r
"LJEŠNIK",\r
"Acılı",\r
"LOGEX",\r
"Logo",\r
"Logo · {0} × {1}",\r
"Firma logosu",\r
"Firmanın logosu ve amblemi Muhasebe'de ayarlanır (Ayarlar → Firma); kasa bunları sunucudan alır ve saklar, böylece internet olmadan da görünür. Logo fiş başlığının üzerinde yazdırılır (termal yazıcıda siyah-beyaz), amblem ise kasa başlığında ve kasiyer girişinde yer alır.",\r
"Firmanın logosu ve amblemi Muhasebe'de ayarlanır (Ayarlar → Firma); sunucuyla eşleştirilmiş kasa bunları otomatik alır. O zamana kadar fişte logo bulunmaz.",\r
"Fişteki logo",\r
"Yerel IRIS sunucusu",\r
"Yerel IRIS sunucusu (mağazadaki bilgisayarda IRIS Server programı): bu programın \\"Genel bakış\\" ekranındaki veya ağ aramasından gelen adres; kod alanına IRIS Admin'den alınan eşleştirme bağlantısı (iris://upari…) da girilebilir. Kasa yalnızca bu sunucunun CA sertifikasını kabul eder; Windows'a hiçbir şey yazılmaz.",\r
"Yerel IRIS sunucusu (dükkândaki bilgisayar): IRIS Server programının \\"Genel bakış\\" ekranından veya ağ aramasından alınan adres. Kod yerine IRIS Admin'den eşleştirme bağlantısı (iris://upari…) girilebilir.",\r
"Yerel IRIS sunucusu (kendi CA sertifikası) Android'de henüz desteklenmiyor; telefondaki kasa api.iriscorvina.me üzerinden çalışır.",\r
"yerel",\r
"kırılma",\r
"LOPTA",\r
"LOREAL",\r
"lose",\r
"LOT",\r
"LOVOR",\r
"lower(COALESCE(p.kupac_naziv, '')) LIKE ?",\r
"LOZA",\r
"Parola",\r
"Sertifikayla birlikte alınan parola.",\r
"Sertifika parolası",\r
"LOZOVACA",\r
"LOZOVAČA",\r
"LUCKY",\r
"LUCKY STRIKE",\r
"Acı bakla",\r
"LYFT",\r
"Eşleştirilmiş terminalin MAC adresi veya adı",\r
"MAESTRO",\r
"MAGUD COMPANY D.O.O.",\r
"Mayıs",\r
"Mayıs",\r
"MAJONEZ",\r
"MAKARON",\r
"Küçük otel",\r
"MALIBU",\r
"Perakende (mağaza, büfe)",\r
"eksik",\r
"Azalt",\r
"MARABU",\r
"MARAMIC",\r
"MARGARIN",\r
"MARINAD",\r
"mağaza",\r
"Mağaza",\r
"Mağaza — pazar günleri ve tatillerde çalışmaz",\r
"Mağaza (pazar günleri ve tatillerde çalışmaz)",\r
"Mağaza (pazar günleri kapalı)",\r
"Mağaza pazar günleri çalışmaz. Kiosk olarak kayıtlı bir işyerinin önündeki kasa pazar günleri de çalışır.",\r
"mağaza",\r
"MARLBOR",\r
"MARLBORO",\r
"MARMELAD",\r
"MARS",\r
"Mart",\r
"Mart",\r
"MARTINI",\r
"Marza {0}",\r
"MASKA",\r
"MASLAC",\r
"MASLINOVO",\r
"MASTERCARD",\r
"MAX FACTOR",\r
"max_zaliha REAL",\r
"MED",\r
"MEDENJ",\r
"MEDOVACA",\r
"MEDOVAČA",\r
"Ara toplam",\r
"Yumuşakçalar",\r
"Cihaz belleği dolu. Yer açılmalı (Belgeler/Kasa içindeki eski yedekler, gereksiz fotoğraflar) ve işlem tekrarlanmalıdır. ({0})",\r
"menajer",\r
"Yönetici",\r
"Menü",\r
"Menü yayınlandı. Bu işletmenin siparişlerini bu kasa alır.",\r
"Menü henüz hiçbir kasadan yayımlanmadı.",\r
"Menü henüz yayınlanmadı.",\r
"Menü henüz yayımlanmadı. QR menü, işyerinin ana kasasında etkinleştirilir.",\r
"Menü yayınlanmadı. QR menü ayarlardan açılır.",\r
"Menü: {0} {1}, {2} ürün",\r
"MENTOL",\r
"MENTOS",\r
"MERLOT",\r
"MESO",\r
"Et ve et ürünleri",\r
"METAXA",\r
"METLA",\r
"Mettler Toledo 8217",\r
"MİKRO",\r
"MILK",\r
"MILKA",\r
"MILKY WAY",\r
"milostDana: 0–90.",\r
"MINERALNA",\r
"minmax(46px, 1fr)",\r
"minmax(92px, max-content) repeat({0}, {1})",\r
"eksi",\r
"Önlem",\r
"Ay",\r
"Aylık rapor son günü (ayın günü)",\r
"Karma",\r
"yer",\r
"Yerler ve masalar",\r
"yer",\r
"Yer",\r
"Vizenin verildiği yer",\r
"doğum yeri",\r
"Doğum yeri",\r
"Giriş yeri",\r
"mjesto_id INTEGER",\r
"MKB-10",\r
"ML",\r
"Bu yaştan küçükler vergi ödemez.",\r
"Bu yaştan küçükler indirimli tutar öder.",\r
"MLEKO",\r
"Süt ürünleri",\r
"Süt",\r
"MLIJEKO",\r
"Süt ve süt ürünleri",\r
"MNE",\r
"Modüller: {0} içinden en az biri.",\r
"MOET",\r
"MOËT",\r
"MOGYI",\r
"Moj disk",\r
"Bugünkü değişikliklerim",\r
"Mojkovac",\r
"MONSTER",\r
"MONTE CARLO",\r
"MORTADEL",\r
"Motel",\r
"{0} ile {1} arasında puan harcanabilir.",\r
"MOZZAR",\r
"Ağ (LAN / Wi-Fi): IP:port",\r
"ağ yazıcısı",\r
"Ağ yazıcısı (IP, bağlantı noktası 9100)",\r
"MULTIVIT",\r
"erkek",\r
"MUSLI",\r
"My Drive",\r
"Android'de yeni sürüm APK indirilerek kurulur (adres denetimde: urlAndroid).",\r
"Android'de önceki sürüme dönmek, veriler silinmeden mümkün değildir, çünkü sistem eski bir sürümün yenisinin üzerine kurulmasına izin vermez. Düzeltme yeni bir sürüm olarak yayımlanır.",\r
"Avans fişinde {0} kaldı, düzeltme ise {1}.",\r
"Avans fişinde {0} serbest, {1} isteniyor.",\r
"Çek {0} üzerinde {1} € kaldı. {2} € ödeme mümkün değil.",\r
"Bonda {0} kaldı.",\r
"Beklemeye al",\r
"Bekleyen",\r
"Beklemede {0}. Bunların tahsil edilmesi veya silinmesi gerekir.",\r
"Etiketlerin üzerine yazdırıldığı ortam",\r
"Güncelleme için diskte yeterli alan yok (boş {0} MB, en az {1} MB gerekli). Hiçbir şey değiştirilmedi.",\r
"Güncelleme için diskte yeterli alan yok. Hiçbir şey değiştirilmedi.",\r
"Yalnızca özet fiş ve avans fişinin düzeltme fişi diğer fişlere atıfta bulunur.",\r
"Kasa kapatılırken girilmekte olan fiş ekrana geri getirildi. Fişin tahsil edilmesi veya silinmesi gerekir.{1}",\r
"ekranda",\r
"Hesabın bir kısmı tahsilat için ekranda.",\r
"Ekranda başka bir fiş var. Onu beklemeye alıp seçileni geri getirelim mi?",\r
"Ekranda başka bir fiş açık. Beklemeye alınıp proforma yüklensin mi?",\r
"Ekranda başka bir fiş açık. Onu beklemeye alıp silinen fişi geri getirelim mi?",\r
"Ekranda ilk",\r
"Ekranda ilk {0} ürün var; yazdırma ve tablo hepsini içerir.",\r
"Ekranda masasız bir fiş var. Masa {0}'a konulsun mu?",\r
"Ekranda bir masa fişi var. Önce masaya geri konulması veya tahsil edilmesi, ardından proformanın yüklenmesi gerekir.",\r
"Ekranda devam eden bir fiş var (kalem: {0}). Ekranda kalır ve sonraki vardiyaya girer.",\r
"Ekranda masa",\r
"Ekranda masa fişi yok.",\r
"Faturadaki {n} ürünün barkodu yok.",\r
"Mali fişlerde",\r
"Ana kasada: Ayarlar → QR menü → QR koddaki adres: \\"Kendi alan adı\\", ardından masa kodlarını yeniden yazdırın.",\r
"kasada",\r
"Kasada",\r
"tartılarak",\r
"Bu kasada \\"{0}\\" adlı kasiyer yok.",\r
"bu noktada",\r
"Bu cihazda fişli bir vardiya açık, bu nedenle şimdi kasa seçilemez. Sıra: \\"Deneme kasası\\", vardiya kapanışı (Z), ardından kasa seçimi (Ayarlar → Kasa).",\r
"Bu cihazda {0} klasörü bulundu. \\"Klasör\\" alanına girilip kaydedilmesi gerekir.",\r
"Bu cihazda terminale bağlanma yolu yok.",\r
"Bu cihazda okunamayan anahtarlar programdan atılamaz.",\r
"Bu cihazda terazi kullanılamıyor.",\r
"Bilgisayarda seri port bulunamadı (veya kabuk port seçimini desteklemiyor — yeni Setup gerekli).",\r
"Fişte artık katalogda olmayan bir ürün var. Ürünün fişten çıkarılması gerekir.{0}",\r
"Fişte, düzenlendiği kodlar yok (QR adresi eksik).",\r
"Oda hesabında tahsil edilecek kalem yok.",\r
"Fişte: {0}. Bon ödemeden sonra yazdırılır.",\r
"reçeteli",\r
"Reçetede \\"Değiştirmeyin!\\" işareti var.",\r
"IRIS CORVINA sunucusuna gönderilmeyi bekleyen: {0} dosya (kapanışlar, fiyatlar). Sunucuya bağlantı gerekir (\\"Şimdi veri alışverişi yap\\").",\r
"Odaya",\r
"Odaya — misafir imzası",\r
"{0} numaralı odaya",\r
"Odaya / ertelenmiş",\r
"Hedef masa",\r
"Sipariş fişi olmadan masaya",\r
"masada",\r
"Masada mutfağa / bara gönderilmemiş kalemler var. Sipariş fişi olmadan kaydedilsin mi?",\r
"Masada bu kalemden istenenden az miktar var. Masanın yenilenmesi gerekiyor.",\r
"Masada:",\r
"Masada: {0}",\r
"Telefonda klasör yalnızca geçiş modu için kullanılır.",\r
"Telefonda: Kasa →",\r
"{0} saatinde terminalde {1}{2} onaylandı, ancak fiş düzenlenmedi. Fiş bu ödemeyle, yeni tahsilat olmadan düzenlenir.",\r
"Terazide ürün yok.",\r
"çevrimiçi",\r
"Bağlı · güncel",\r
"Alış fiyatı",\r
"Alış değeri",\r
"Alış",\r
"Yöntem",\r
"Yöntem",\r
"Verginin çıkış fişinde nasıl gösterileceği.",\r
"Ödeme yöntemi",\r
"Faaliyet türü",\r
"Firmanın işletme modu (isteğe bağlı)",\r
"İade yöntemi",\r
"Bildirim yöntemi",\r
"fiş taslağı çok büyük",\r
"taslaklar",\r
"Üst grup",\r
"Bul",\r
"Üst",\r
"gün ve masa bazında misafir geliş bildirimleri",\r
"NAJLEPŠE",\r
"Harcamak için asgari puan",\r
"asgari gece",\r
"Asgari gece",\r
"En az {0} puan harcanır.",\r
"En çok satan ürünler (tutara göre)",\r
"Azami stok",\r
"En yüksek stok sıfırdan az olamaz.",\r
"Oda başına en yüksek borç",\r
"Oda başına en yüksek borç (EUR)",\r
"En büyük elle yapılan indirimler (kontrol — kampanyalar ve sadakat hariç)",\r
"Bir siparişte en fazla {0} kalem olabilir.",\r
"Ücret",\r
"FZO'nun karşıladığı reçete başına eczane ücreti (€)",\r
"Fişte ücret",\r
"sipariş",\r
"Fiş",\r
"NALOG",\r
"\\"{0}\\" talimatı programın bu sürümünde desteklenmiyor ({1} {2}).",\r
"\\"poruka\\" talimatında metin yok.",\r
"\\"reset-pin\\" talimatında kişi rolü yok (owner/admin/sef-kase veya kasir). Talimat yürütülmedi.",\r
"Sipariş fişi {0} {1}{2}",\r
"Sipariş fişi {0} gönderildi ({1} {2}). Masa {3} beklemede.",\r
"Fiş no.",\r
"Henüz gönderilmeyenler için mutfak / bar siparişi",\r
"Sipariş fişi yazdırılmadı; kalemler gönderildi olarak işaretlenmedi. Yazıcının kontrol edilmesi gerekir.",\r
"Sipariş fişi yazdırılmadı.",\r
"sipariş fişi gönderilmedi",\r
"Telefondan gelen sipariş ({0}, masa {1}) yazdırılmadı. Yazıcıyı kontrol edip siparişi yeniden gönderin.",\r
"siparişler ve \\"hazır\\"",\r
"Kasadan ve garsonların telefonlarından gelen siparişler. \\"Tamam\\" garsona hazır olduğunu bildirir. Mutfaktaki tablet: \\"Mutfak\\" modunda Android uygulaması (garson telefonu gibi eşleştirilir).",\r
"FZO özel uygulaması (reçete Fon'un uygulamasında işlenir)",\r
"naplaceno REAL",\r
"Özet fişlerle tahsil edilen",\r
"Tahsilat — oda {0}",\r
"Tahsilat — birden fazla ödeme yöntemi",\r
"\\"Odaya yaz\\" tahsilatı",\r
"Nakit tahsilat",\r
"Tahsilat mümkündür",\r
"Tahsilat serbest bırakıldı.",\r
"{0} numaralı kasada tahsilat sürüyor.",\r
"Tahsilat girildi.",\r
"Kartla tahsilat",\r
"Kartla ödeme — manuel",\r
"Android telefonda kartla ödeme (Tap to Phone): kasa tutarı banka uygulamasına gönderir ve sonucu okur. Kasa kartları işlemez. Alan adları bankaya bağlıdır (NLB Smart POS, OTP mPOS, Hipotekarna MojPOS) ve banka şartnamesine göre girilir. \\"proba\\" paketi = deneme için sahte banka uygulaması. Terminal türü \\"Bu cihazdaki banka uygulaması\\" olmalıdır.",\r
"Telefonda kartla ödeme (SoftPOS) Android cihazda çalışır.",\r
"Terminal üzerinden ödeme kullanılamıyor.",\r
"Oda hesabı tahsilatı",\r
"Telefonla ödeme (SoftPOS) Android cihazda çalışır.",\r
"Banka uygulamasında ödeme: müşteri kartı veya telefonu yaklaştırır.",\r
"{0} numaralı kasada tahsilat sürüyor",\r
"Tahsil et",\r
"Nakit tahsil et",\r
"Tahsil et ve fiş düzenle",\r
"Tüm geceleri tahsil et",\r
"NAPOLITAN",\r
"Not",\r
"Not — {0}",\r
"Not zorunludur.",\r
"Mutfak / bar için not",\r
"Not metin olmalıdır (boş olabilir).",\r
"napomena TEXT",\r
"Not: {0}",\r
"Seçili masa için YENİ kod oluştur (eski QR çalışmaz — örn. kötüye kullanılıyorsa)",\r
"Tesis ve odaları oluştur",\r
"Veritabanı yedeği oluştur",\r
"Şimdi klasöre yedek oluştur",\r
"Gelişmiş: sunucu adresi, dükkândaki yerel IRIS sunucusu",\r
"İleri ›",\r
"Değişikliklerden vazgeç",\r
"\\"{0}\\" siparişi açık.",\r
"Teslimat siparişi, kanal adı ve numarası olan bir \\"masa\\"dır: kalemleri girin, mutfağa \\"Siparişi gönder\\", kurye teslim aldığında ödeme alın. Raporlarda adıyla görünür.",\r
"\\"{0}\\" masası için misafirin siparişi reddedildi: masa kasaya girilmemiş.",\r
"Sipariş boş.",\r
"Sipariş alınmadı: {0}. Garsonu çağırın.",\r
"Teslimat siparişi",\r
"Misafir siparişleri (son 6 saat)",\r
"Bu yerin siparişlerini başka bir kasa alıyor. Bu kasada kabul için: QR menü → Menüyü şimdi yayınla.",\r
"Kasaya ulaşmayan siparişler:",\r
"Kasaya ulaşmayan siparişler: {0}. Telefonda kalırlar ve girişten sonra gönderilirler. Çıkış yapılsın mı?",\r
"Sipariş garson tarafından iptal edildi.",\r
"Yazıcıda yerel harfler",\r
"Başlık",\r
"naSobu.limit",\r
"naSobu.potpis",\r
"naSobu.ukljuceno",\r
"Toplu değişikliğe devam et",\r
"Düzenlemeye devam et",\r
"nav",\r
"Geri",\r
"Ürünlere dön",\r
"ad",\r
"Ad",\r
"Ürün adı",\r
"Ürün adı zorunludur.",\r
"Firma adı zorunludur.",\r
"Grup adı en fazla 60 karakter olabilir.",\r
"Dillere göre grup adı",\r
"Dillere göre ad ve açıklama (* zorunlu; boş = temel ad / İngilizce)",\r
"Ad veya INN (en az 2 harf)",\r
"Ürün adı veya kodu",\r
"Ad çok uzun (en fazla 120 karakter).",\r
"yeni grubun adı",\r
"Yeni grubun adı zorunludur.",\r
"Tesis adı",\r
"Tesis adı, belediye ve türe göre oda sayısı. Odalar daha sonra Ayarlar'dan değiştirilebilir.",\r
"Dönem adı",\r
"Satıcı adı",\r
"Satıcı adı zorunludur.",\r
"Cihaz adı",\r
"naziv_n LIKE ?",\r
"naziv_n TEXT",\r
"Dillere göre adlar, açıklamalar, alerjenler ve görseller Kasa (📝 Menü içeriği), Yönetici ve Muhasebe'de girilir — sunucudaki içerik aynıdır. Fiyatlar her zaman bu kasanın fiyatlarıdır.",\r
"hayır",\r
"Hayır",\r
"hayır — yalnızca garson",\r
"Hayır (nakit)",\r
"İzin verme",\r
"Misafir menüsünde gösterme (kasa satmaya devam eder)",\r
"satılmıyor",\r
"Artık satılmıyor",\r
"ciroya dahil edilmez ve Vergi İdaresi'ne bildirilmez.",\r
"dikkate alınmaz",\r
"Değiştirmeyin!",\r
"etkin değil",\r
"Okunamayan tajne.json dosyası kenara alınamıyor ({0}).",\r
"Okunamayan anahtarlar taşındı. Sertifikanın yeniden içe aktarılması gerekir.",\r
"okunamayan dosya adı",\r
"NECTAR",\r
"Paz",\r
"Pazar",\r
"Pazar",\r
"PAZAR",\r
"PAZAR · mağaza",\r
"Varıştan sonraki gün gelmedi sayılma saati",\r
"Gelmedi: saat 0 ile 23 arasında",\r
"nedolazak.doSati",\r
"Eksik",\r
"Düzenlenen fişin numarası eksik.",\r
"Eksik: {0}",\r
"Eksik: {0}.",\r
"Geçersiz veri alışverişi dosya adı: {0}",\r
"izin verilmeyen dosya adı: {0}",\r
"neg",\r
"Geçersiz ödeme tutarı ({0}).",\r
"Güncelleme kaydının anahtarı geçersiz.",\r
"Geçersiz kayıt.",\r
"Geçersiz miktar: {0}",\r
"Belirsiz sonuç",\r
"Terminalde belirsiz sonuç ({0}, {1}) — terminal kontrol edilmelidir",\r
"belirsiz sonuç {0}",\r
"belirsiz (zaman aşımı)",\r
"NEKTAR",\r
"yok",\r
"yok (terminalsiz kart)",\r
"yok (ilk fişte oluşturulur)",\r
"yerel ağda adres yok",\r
"Barkodu olmayan ürün yok. Ürün ad veya kod ile aranır.",\r
"Kaydedilecek ürün yok.",\r
"Bu seçim için ürün yok.",\r
"Bu arama için ürün yok.",\r
"Yazdırılacak ürün yok.",\r
"Bu barkodlu ürün yok",\r
"barkod yok",\r
"klasörde fiyat listesi yok",\r
"Bugün yok — misafir menüsü",\r
"Bu vardiyada para girişi veya çıkışı yok.",\r
"Bugün giriş yok.",\r
"Veritabanını açmak için yeterli boş bellek yok (veritabanı {0} MB). Diğer programları kapatın veya bilgisayarı yeniden başlatın, ardından kasayı çalıştırın. Veriler değiştirilmedi.",\r
"{0} dosyası yok (ne sunucuda ne de kasa dosyaları arasında).",\r
"Tesiste misafir yok.",\r
"Grup yok — gruplar ürün kod listesinden gelir (Muhasebe).",\r
"Geçerli bir sağlama toplamı (SHA-256) yok — paket kabul edilmiyor.",\r
"Fiyat veya ürün değişikliği yok.",\r
"\\" \\" için kasa yok.",\r
"\\"{0}\\" için kasa yok.",\r
"İmza için anahtar veya sertifika yok.",\r
"Bu numaralı sadakat müşterisi yok. Müşteriler Muhasebe'de girilir (Kasa fiyat listesi → Müşteriler).",\r
"Sipariş yok.",\r
"Masanın adı yok.",\r
"Etiketler için yeni fiyat yok.",\r
"Daha yeni sürüm yok.",\r
"Daha yeni sürüm yok. Kasada en son sürüm var ( ).",\r
"Daha yeni sürüm yok. Kasada en son sürüm var ({0}).",\r
"Tesis yok.",\r
"Yerel sunucudan yanıt yok.",\r
"Bugün çıkış yok.",\r
"güncelleme açıklaması yok",\r
"Bu dönemde mal zayii yok.",\r
"Açık vardiya yok.",\r
"Açık proforma yok.",\r
"Fiyat içeren veri paketi yok.",\r
"fiyat paketi yok",\r
"Yazıcıda kâğıt yok.",\r
"Paket verisi yok. Önce güncellemeyi denetlemek gerekir.",\r
"Dönem için veri yok.",\r
"Yazdırılacak veri yok (veya çok büyük).",\r
"Veri yok.",\r
"Gönderilmeyi bekleyen ileti yok.",\r
"Gönderilecek ileti yok. Daha önce reddedilen: {0}.",\r
"Mesaj yok. Destek, program içinde yanıt verir.",\r
"Bağlı barkod yok.",\r
"Bu aramaya uygun proforma yok.",\r
"Proforma yok.",\r
"İmza için özel anahtar yok.",\r
"Bu dönemde satış yok.",\r
"Satılmış bon yok.",\r
"Fiş yok",\r
"{0} fiş yok.",\r
"Beklemede fiş yok.",\r
"Bu dönemde fiş yok.",\r
"Dönemde fiş yok.",\r
"Bu arama için hesap yok.",\r
"Yazdırılacak fiş yok.",\r
"Bu PIB veya adla daha önceki müşteri yok.",\r
"Daha önceki müşteri yok.",\r
"Bu seçim için rezervasyon yok.",\r
"Sonuç yok",\r
"İmza için sertifika yok.",\r
"Ürün kodu yok.",\r
"Bu dönemde bu türde boş oda yok.",\r
"Bu dönem için boş oda yok.",\r
"Temizlenecek oda yok.",\r
"Zayi kaydedilecek kalem yok.",\r
"Kalem yok.",\r
"Müşteri ekranı sayfası yok.",\r
"Bu dönemde böyle fiş yok.",\r
"Terminal işlemi yok.",\r
"Kayıt yok.",\r
"Eşleştirilmiş Bluetooth cihazı yok. Yazıcı, telefon ayarlarında eşleştirilir.",\r
"Kayıtlı kasiyer yok.",\r
"Kayıtlı kasiyer yok. Kayıtlı kasiyer PIN ile giriş yapar ve adı fişte yer alır.",\r
"Ödeme yok.",\r
"Uyarı yok.",\r
"Bağlantı yok",\r
"Mali servisle bağlantı yok.",\r
"Kasa ile bağlantı yok (mağazanın Wi-Fi ağı).",\r
"Vergi İdaresi ile bağlantı yok. Gönderim bağlantı kurulduğunda devam eder.",\r
"sunucu ile bağlantı yok",\r
"Sunucu bağlantısı yok ({0}).",\r
"Sunucuyla bağlantı yok.",\r
"Sunucuyla bağlantı yok. {0} bağlantı gerektirir. Hiçbir şey düzenlenmedi.",\r
"Sunucuyla bağlantı yok. Oda hesabı tahsilatı bağlantı gerektirir.",\r
"Sunucuyla bağlantı yok. Odaya yazdırma kullanılamıyor.",\r
"Sunucuyla bağlantı yok. Avans iadesi bağlantı gerektirir.",\r
"Sunucuyla bağlantı yok. Odaya yazılan fişin iptali bağlantı gerektirir (özet fiş kontrolü).",\r
"Bu kasadan talep yok.",\r
"Zamanlanmış fiyat yok.",\r
"yok, hepsi gönderildi",\r
"isteğe bağlı",\r
"isteğe bağlı (\\"Diğer\\" için zorunlu)",\r
"isteğe bağlı (teslim süresi, ödeme şekli…)",\r
"İsteğe bağlı; \\"Diğer\\" nedeni için zorunludur.",\r
"işlenmemiş reddetme",\r
"tek (odd)",\r
"desteklenmiyor",\r
"gönderilmedi",\r
"Bilinmeyen barkod {barkod}",\r
"Bilinmeyen sonuç kodu: {0}",\r
"Bilinmeyen ödeme yöntemi: \\"{0}\\" (olası: Nakit, Kart, Havale, Bon, Anlık).",\r
"Bilinmeyen ödeme yöntemi: {0}",\r
"Bilinmeyen iade yöntemi: {0}",\r
"Bilinmeyen talimat.",\r
"Bilinmeyen konaklama vergisi gösterimi: {0}",\r
"bilinmeyen neden",\r
"Bilinmeyen istek.",\r
"bilinmeyen hata",\r
"Bilinmeyen hata",\r
"Bilinmeyen depozito işlemi: \\"{0}\\".",\r
"Bilinmeyen işlem.",\r
"Bilinmeyen lisans sürümü.",\r
"Bilinmeyen kasa türü: \\"{0}\\".",\r
"Bilinmeyen ücret türü: \\"{0}\\" (olası: PACK, COMMISSION, OTHER).",\r
"Bilinmeyen sonradan gönderim türü: \\"{0}\\".",\r
"Bilinmeyen talep türü.",\r
"Okunmamış destek yanıtları",\r
"Çalışılmayan",\r
"NESCAFE",\r
"NESKAF",\r
"NESQUIK",\r
"NESTLE",\r
"Net miktar",\r
"Net miktar sıfırdan büyük olmalıdır.",\r
"Net miktar, paketteki adet ve en yüksek stok sayı olarak girilir.",\r
"neto REAL",\r
"neto_jm TEXT",\r
"yakalanmamış hata",\r
"Kullanılamaz",\r
"🆕 Yeni fiyatlar ({0})",\r
"NEXT",\r
"NFC",\r
"NFD",\r
"değil",\r
"mali fiş değildir",\r
"İade için hiçbir kalem seçilmedi.",\r
"Henüz değil",\r
"Kopyalanmadı",\r
"Çek kodu oluşturulamadı. Tekrar denenmelidir.",\r
"Bağlı DEĞİL (siparişler alınmıyor)",\r
"Tahsil edilmedi:",\r
"hiçbir fiş silinmedi.",\r
"Onaylanmadı",\r
"ödemedi · fiş no. {0}",\r
"Yazıcının nerede olduğu ayarlanmamış (Ayarlar → Eklentiler).",\r
"gönderilmedi",\r
"Sunucuya bağlı değil",\r
"bu kasa tarafından bilinmiyor (başka bir kasadan gelen bon, sunucu veri alışverişiyle henüz ulaşmamış olabilir).",\r
"art arda {0} başlatmada açılmadı",\r
"hazır değil",\r
"Gelmedi",\r
"katalogda yok",\r
"Seri port girilmedi (ör. COM3).",\r
"Telefonla ödeme için banka uygulaması girilmedi (Ayarlar → Kasa cihazları → SoftPOS).",\r
"girilmedi",\r
"Mali onay sertifikası (.pfx) içe aktarılmadı. Kasa deneme anahtarıyla çalışıyor.",\r
"Girilen ad veya koda uyan ürün yok.",\r
"Hiçbir ürün seçilmedi.",\r
"Hiç reçete eklenmedi.",\r
"Eşleştirilmiş telefon yok.",\r
"düzenlenmiş bir fişten hiçbir kalem kaldırılmadı.",\r
"Bu proformadaki ürünlerin hiçbiri artık katalogda yok. Proforma yüklenemez.",\r
"Bu fişteki ürünlerin hiçbiri artık katalogda yok ({0}). Fiş geri getirilmedi ve silinenler kaydında kalıyor.",\r
"Bu fişteki ürünlerin hiçbiri artık katalogda yok ({0}). Ekrana geri getirmek mümkün değil; kayıt, kayıtlarda kalır.",\r
"Hiçbir ürünün fiyatı değişmeyecek.",\r
"NIKOTIN",\r
"NIKSIC",\r
"NIKŠIC",\r
"Nikšić",\r
"hiçbiri",\r
"Hiçbir şey değiştirilmedi.",\r
"gelmediler",\r
"NIVEA",\r
"Almanca",\r
"gece",\r
"Geceleme",\r
"Geceleme — {0}",\r
"Geceleme ve konaklamaya ek ücretler (yiyecek dışı).",\r
"gece",\r
"Gece",\r
"NONCASH",\r
"noopener noreferrer",\r
"son kullanma tarihini taşır: süresi geçmiş mal yalnızca amirin onayıyla (uyarıyla birlikte) satılır, son kullanma tarihi yaklaşan mal için ise uyarı gösterilir.",\r
"Rezervasyon sahibi",\r
"yeni ürün",\r
"Yeni ürün",\r
"Muhasebe'den yeni fiyat listesi ({0} ürün, {1})",\r
"{0} tarihli yeni fiyat listesi ({1} ürün)",\r
"Yeni masa kodu oluşturuldu. Önceki QR kod artık geçerli değil.",\r
"yeni yanıt",\r
"IRIS CORVINA desteğinden yeni yanıt (Daha fazla → Destek)",\r
"yeni destek yanıtı:",\r
"yeni destek yanıtı: {0}",\r
"Yeni proforma",\r
"Yeni masa QR kodu",\r
"Yayıncıya yeni talep",\r
"nova",\r
"Yeni",\r
"NOVA",\r
"yeni fiyat (€)",\r
"Yeni fiyat 0,01 €'nun altında veya {0} €'nun üzerinde olurdu (ürün sayısı: {1}). Fiyatlar değiştirilmiyor.",\r
"Yeni fiyat sıfırdan büyük olmalıdır.",\r
"Yeni grup",\r
"Yeni tahsilat",\r
"Terminalde {0} yeni tahsilat (önceden onaylanan kullanılmadı)",\r
"Desteğe yeni mesaj",\r
"Yeni rezervasyon",\r
"Yeni rezervasyon: odanın satırında ilk ve son geceyi seçin.",\r
"Yeni vardiya",\r
"yeni tur",\r
"Yeni sürüm {0}",\r
"Yeni sürüm, kasa boştayken otomatik olarak indirilir ve programın bir sonraki başlatılışında uygulanır. Vardiya açıkken yeniden başlatma önerilmez.",\r
"Yeni sürüm yalnızca Wi-Fi üzerinden otomatik indirilir; mobil veride indirme \\"Şimdi indir\\" düğmesiyle başlatılır. Kurulum ancak \\"Şimdi kur\\" ile başlar.",\r
"Kasadan çıkarılan para (günlük hasılatın teslimi, kasadan ödeme).{0}",\r
"Satış dışında kasaya konulan para (bozuk para, ek para).",\r
"Yeni fiyatlar",\r
"Yeni fiyatlar zaten listede.",\r
"etiketler için yeni fiyatlar:",\r
"etiketler için yeni fiyatlar: {0}",\r
"etiketler için yeni fiyatlar: {0} (Daha fazla → Fiyat etiketleri)",\r
"Kasım",\r
"Kasım",\r
"Yeni misafir",\r
"Yeni kasiyer",\r
"Yeni tesis",\r
"Yeni kayıt",\r
"Ofisten etiketler için yeni fiyatlar:",\r
"Ofisten etiketler için yeni fiyatlar: {0} (\\"Yeni fiyatlar\\" düğmesi).",\r
"yeni",\r
"Yeni",\r
"örn. 0,5",\r
"örn. 067 123 456",\r
"ör. 1, 2, 3, 4, Bar, Teras 1",\r
"örn. 10",\r
"örn. 10 veya -5",\r
"ör. 1001, 1002, 4475",\r
"ör. 101-110, 201",\r
"örn. 19:30",\r
"örn. 24",\r
"örn. 250 g",\r
"ör. 4*",\r
"örn. buzsuz, iyi pişmiş",\r
"örn. COCA COLA 0,5L",\r
"ör. tedarikçi, parti, ne oldu",\r
"ör. G:\\\\My Drive\\\\Knjigovodstvo-sync",\r
"ör. misafir telefonla iptal etti",\r
"örn. Mutfak saat 23'e kadar açıktır",\r
"ör. me.banka.pos",\r
"ör. me.banka.softpos veya proba",\r
"örn. meni.vasrestoran.me",\r
"ör. MNE",\r
"örn. arızalı mal",\r
"örn. İptalden sonra fiş, işaret olmadan \\"son fişler\\" içinde kalıyor…",\r
"örn. günlük hasılatın teslimi",\r
"örn. bozuk para",\r
"ör. 10 dk içinde dönecek",\r
"NRp",\r
"NT",\r
"Misafir girilirken önerilir; her satırda bir gerekçe.",\r
"NUDLE",\r
"NUTELLA",\r
"NUTRINO",\r
"Program hakkında",\r
"Her iki tarih de zorunludur.",\r
"Fişin silinme gerekçesi zorunludur.",\r
"Zayi gerekçesi zorunludur.",\r
"Yayıncı bildirimleri (kasanın başlatılmasından beri)",\r
"İşyeri",\r
"Tesis eklendi.",\r
"Tesis kaydedildi.",\r
"Tesis kullanımda",\r
"Tesis girildi.",\r
"Tesis henüz girilmedi. Girişi, ayar yetkisi olan bir kullanıcı yapar.",\r
"İşyerinde oda yok.",\r
"Tesiste oda yok. Odalar Ayarlar'dan girilir.",\r
"Tesiste oda türü yok. Türler Ayarlar'dan girilir.",\r
"Biçim",\r
"Yenilenebilir reçete en fazla 3 kez verilir.",\r
"Hesaplama",\r
"Hesaplanan",\r
"silindi",\r
"Silinmiş fiş",\r
"Fiş tahsilattan önce silindi ({0})",\r
"En az şu değerde silinen fiş (€)",\r
"beklemeden silindi",\r
"Beklemeden silindi",\r
"Ödemeden önce silinenler ({0}{1})",\r
"Silinmiş fiş okunamıyor.",\r
"Silinen fişler",\r
"Silinen fişler — daha eski",\r
"Silinen fişler, mal zayiatı, fiyat etiketleri",\r
"Silindi.",\r
"{0} {1} adlı misafir silinsin mi?",\r
"Bu kayıt silinsin mi?",\r
"Sil",\r
"Rakamı sil",\r
"Fişi sil",\r
"Bekleyen fişi sil",\r
"Eski kodu bu üründen sil",\r
"KDV mükellefi",\r
"Kasada beklenen: {0}",\r
"Temizle",\r
"Listeyi temizle",\r
"Belgeyi oku (makine tarafından okunabilir alan)",\r
"Ağırlığı oku",\r
"Tartıdan gelen etiket (ağırlıklı kod) okutuldu, ürünün barkodu değil. Tartılan ürün birim olarak kilogram ile girilir.",\r
"Terazi etiketi okundu (ağırlıklı kod). Böyle bir kod bir ürünle ilişkilendirilmez.",\r
"Okunan kod kasa ile eşleştirme için bir QR değil (kasada: Ayarlar → Garson telefonları → \\"Telefonu eşleştir\\").",\r
"Barkodu okutun veya ürün kodunu girin…",\r
"Barkodu kamerayla okut",\r
"/",\r
"Başlangıç",\r
"{0} tarihli",\r
"{0} tarihli —",\r
"{0} tarihli ({1})",\r
"{0} tarihli ({1}){2}{3}",\r
"{0} tarihli, {1}.",\r
"Avanstan {0} EUR serbest. İade mümkün değil.",\r
"Avanstan {0} serbest. {1} iadesi mümkün değil.",\r
"Odanın misafir için hazır olduğu saat.",\r
"Bildirim süresi bu saatten itibaren işler.",\r
"bunun terminal üzerinden",\r
"Kaynak",\r
"Reddet",\r
"Değişiklikleri sil",\r
"Okunamayan anahtarları at…",\r
"Okunamayan anahtarların atılması",\r
"reddedildi",\r
"Düşülen",\r
"Reddedildi (deneme)",\r
"Reddedildi (deneme).",\r
"Promise iletisiz reddedildi",\r
"Mali servisin yanıtı okunamıyor.",\r
"Yayıncının yanıtı",\r
"Yayıncı yanıtı: {1}",\r
"Yanıt gönderildi.",\r
"Kasanın yanıtı okunamıyor (kod {0}).",\r
"desteğe yanıt",\r
"Vergi İdaresi'nin yanıtı okunamıyor.",\r
"Sunucu yanıtı çok büyük.",\r
"Sunucu yanıtı geçerli değil (sıkıştırma).",\r
"Terminal yanıtı okunamıyor.",\r
"Terminal yanıtı belirsiz. Sonuç terminalde kontrol edilmelidir.",\r
"Bu konuya yanıt",\r
"Yanıtlar",\r
"Çıkış",\r
"Polise çıkış bildirimi",\r
"Polise çıkış bildirimi {0}",\r
"odjava.vrijemeDolaska",\r
"odjava.vrijemeOdlaska",\r
"Çıkış yap",\r
"Borçlu olarak çıkış yap",\r
"Misafirin çıkışı yapılsın mı? Oda \\"temizlenecek\\" durumuna geçer.",\r
"Çıkış yapıldı",\r
"Polise çıkış bildirildi",\r
"Turizm örgütüne çıkış bildirildi",\r
"Misafirlerin polise çıkış bildirimini Misafirler sekmesinde işaretleyin.",\r
"Fişi bekletme ve sıradaki müşteriden ödeme alma",\r
"Çıkışlar",\r
"Çıkış",\r
"çıkış {0}",\r
"Bugün çıkış",\r
"Çıkış saati (en geç)",\r
"Çıkış saati (en geç)",\r
"Çıkış {0} tarihine planlanmış. Konaklama {1} tarihine kısaltılsın mı?",\r
"Çıkış, girişten sonra olmalıdır.",\r
"Çıkış: {0}",\r
"Beklemedeki fişler tahsil edilmemiştir. Tahsilat, ekrana geri getirildikten sonra yapılabilir.",\r
"Bekletilen",\r
"Ertelenmiş ödeme (ORDER) aynı fişte başka bir ödeme yöntemiyle birleştirilemez.",\r
"Ertelenmiş ödeme başka bir ödeme yöntemiyle birleştirilmez.",\r
"onaylandı",\r
"onaylanan",\r
"Onay",\r
"Şef onayı",\r
"Onaylandı — fiş düzenle",\r
"Onaylandı (deneme)",\r
"Onaylandı (deneme).",\r
"Onaylandı {0}{1}{2}",\r
"Fişsiz onaylandı",\r
"fişsiz onaylanan {0}",\r
"Onaylandı",\r
"Terminalde fişsiz onaylandı ({0}{1})",\r
"Terminalde fişsiz onaylandı: {0}{1}",\r
"Onaylandı.",\r
"Onayla",\r
"Yetişkin",\r
"Belediye tarafından belirlenir, 0,10 ile 1,00 EUR arasında.",\r
"Telefonun bağlantısını kesme",\r
"Bağlantıyı kes",\r
"Yeni fiyatlı etiket (ve kg / l fiyatı) yazdırılsın mı?",\r
"Yeni ürün için etiket yazdırılsın mı?",\r
"İptal",\r
"off",\r
"offline",\r
"çevrimdışı: {0}",\r
"offlineDana: 1–365.",\r
"tamam",\r
"ortam",\r
"Ortam",\r
"ortam {0}",\r
"Ortam ÜRETİM ve kasa fişleri Vergi İdaresi'ne gönderiyor. Fişler mali fişlerdir.",\r
"Ekim",\r
"Ekim",\r
"ol",\r
"OL",\r
"OLOVK",\r
"OMEKSIV",\r
"OMEKŠIV",\r
"on",\r
"online",\r
"Operatör",\r
"operater_kod TEXT",\r
"Açıklama",\r
"Açıklama (isteğe bağlı), ör. müşteri adı. Fiş, ekrana geri getirilene kadar bekler.",\r
"açıklama (içindekiler, gramaj…)",\r
"güncelleme açıklaması okunamıyor",\r
"güncelleme açıklaması eksik",\r
"Hata açıklaması zorunludur.",\r
"Fişteki açıklama",\r
"Sorun açıklaması zorunludur.",\r
"Talebin açıklaması ve nedeni (örn. 1 Aralık'tan itibaren Bečići mağazasında bir kasa daha)…",\r
"Talep açıklaması zorunludur.",\r
"Narkotik ilaç yalnızca özel reçete (PRp) ile verilir.",\r
"Vergiye tabi",\r
"%0 oranında vergiye tabi teslimler (KDV Kanunu md. 25) (ürün esasına göre hasılat + md. 25 esaslı faturalar + elle)",\r
"%15 oranında vergiye tabi teslimler — matrah (hasılat + kesilen faturalar)",\r
"%21 oranında vergiye tabi teslimler — matrah (hasılat + kesilen faturalar)",\r
"%7 oranında vergiye tabi teslimler — matrah (hasılat + kesilen faturalar)",\r
"genel",\r
"genel fiyat",\r
"Genel fiyat",\r
"firmanın genel fiyatı (bu nokta için girilmemiş)",\r
"Genel fiyat, kendi fiyatı olmayan {n} noktada geçerlidir. Genel fiyat değiştirilsin mi?",\r
"genel fiyatlar",\r
"genel fiyatlar (deneme kasası)",\r
"Genel biçim",\r
"Belediye",\r
"Belediye",\r
"Genel fiyatı yönetici ve müdür değiştirir.",\r
"optgroup",\r
"option",\r
"OPTIONS",\r
"ORAL",\r
"Sert kabuklu yemişler",\r
"ORBIT",\r
"OREO",\r
"org_stavka INTEGER",\r
"belgeyi veren makam",\r
"ORp",\r
"Katılım payından muaf",\r
"Uluslararası anlaşma uyarınca muaf",\r
"Muaf, yaşa kadar",\r
"Muaf olanlar, yaşa kadar (yıl)",\r
"İstisna teslimler — teslimatlar (md. 26 ve 27) (ürün esasına göre hasılat + bu esaslı faturalar + elle)",\r
"Muaf tutulan",\r
"Tahsilatı serbest bırak",\r
"Muaf",\r
"Muaf",\r
"Dayanak",\r
"Varsa muafiyet gerekçesi.",\r
"osnov0 TEXT",\r
"osnov0_clan TEXT",\r
"Muafiyet gerekçeleri",\r
"Matrah",\r
"Gecelik temel fiyat (EUR, KDV dahil)",\r
"Temel gıda",\r
"Standart yatak",\r
"kişi",\r
"Kişi",\r
"\\"{0}\\" kişisi kasada kasiyerdir, ancak talimat \\"{1}\\" rolünü belirtiyor. Talimat yürütülmedi.",\r
"\\"{0}\\" kişisi kasada şeftir, ancak talimat \\"{1}\\" rolünü belirtiyor. Talimat yürütülmedi.",\r
"Kişi-gece",\r
"kişi",\r
"Cari borcu {0} EUR faturalandırılmak üzere kalıyor. Misafirin çıkışı yapılsın mı?",\r
"diğer",\r
"Diğer",\r
"kalan",\r
"Kalan",\r
"kalan {0}",\r
"ödemenin kalanı",\r
"kalanının",\r
"Açık bırak",\r
"hasarlı",\r
"Hasarlı (kırılma, arıza, bozulmuş)",\r
"OSVEZIV",\r
"Yenile",\r
"Kataloğu yenile",\r
"OSVJEŽIV",\r
"OTHER",\r
"Sunucunun bildirdiği CA parmak izi, kendi sertifikasında yok. Bağlantı kurulamadı.",\r
"Yerel sunucu CA parmak izi",\r
"CA parmak izi geçerli değil",\r
"Eşleştirme bağlantısındaki sertifika parmak izi, {0} adresindeki sunucunun sertifikasıyla eşleşmiyor. Bağlantı kurulamadı.",\r
"Parmak izleri aynı",\r
"iptal",\r
"İptal",\r
"İPTAL",\r
"İptal mutfağa / bara gönderildi.",\r
"Rezervasyon iptali",\r
"otkaz.stopaNaknade",\r
"otkaz.zadrzaniAvans",\r
"İptal edildi",\r
"iptal edilen",\r
"iptal edildi",\r
"iptal ({0}) / iade ({1})",\r
"İptal edildi",\r
"terminalde iptal edildi (manuel)",\r
"İptal et",\r
"Terminalde iptal et",\r
"Rezervasyonu iptal et",\r
"İptal",\r
"Terminalde iptal",\r
"Terminalde iptal başarısız ({0}): {1}{2}",\r
"İptal başarısız",\r
"Ödeme iptali",\r
"Terminalde ödeme iptali",\r
"Terminalde ödeme iptal ediliyor…",\r
"zayi",\r
"Zayi / fire",\r
"Zayi {0}",\r
"Zayiat kaydedildi: {0}, değer {1}. Belge mali fiş değildir.",\r
"Mal zayiatı",\r
"Mal zayii no.",\r
"Mal zayii no. {0}",\r
"mal zayii:",\r
"mal zayii: {0} belge, {1} (toplama dahil değil)",\r
"Zayi edilen mal (son kullanma tarihi geçmiş, hasarlı…), katalog fiyatlarıyla değer. Ciro değildir ve satışta değildir.",\r
"Ürüne göre zayi edilen mal",\r
"silindi",\r
"Zayiler",\r
"Zayiat et",\r
"Kalemi sil (zayi)",\r
"Veritabanı açılıyor…",\r
"Fişsiz çekmece açma",\r
"Açma kaydedildi. Çekmece kasadan açılacak şekilde ayarlanmamış (Ayarlar → Ek özellikler).",\r
"açık",\r
"açık",\r
"Açılış",\r
"Açılış kasa avansı olmadan yeni vardiya açıldı (#{0}). Kasada bulunan nakit, para girişi olarak girilir (Vardiya → PARA GİRİŞİ).",\r
"Açılış zamanı",\r
"açık",\r
"Açık",\r
"Aç",\r
"Çekmeceyi aç",\r
"Veri klasörünü aç",\r
"Siparişi aç",\r
"Yeni vardiya aç…",\r
"Fişi aç ›",\r
"Fişi iptal için aç",\r
"Vardiyayı aç",\r
"İptali aç ›",\r
"O fişi aç ›",\r
"OUZO",\r
"Bu yıl",\r
"Bu kasa kurulumunda programdan güncelleme yok. Daha yeni bir Setup kurulmalıdır.",\r
"Bu kasa kurulumu programdan yeniden başlatılamaz. Programı kapatıp yeniden açmak gerekir.",\r
"bu kasa",\r
"Bu kasa",\r
"Bu kasa mağaza olarak kayıtlıdır ve bugün {0}. Mağazalar pazar günleri ve tatillerde çalışmaz; bu günlerde fişler kiosk olarak kayıtlı kasadan düzenlenir (md. 35b).\\n\\nBu kasa kiosk olarak kayıtlıysa kasa türünün düzeltilmesi gerekir (Ayarlar → Kasa).",\r
"Bu kasa zaten seçili. Fiyatlar yeniden yükleniyor.",\r
"bu kasa",\r
"Bu işleme bu cihazda izin verilmez.",\r
"Programın bu sürümü ({0}) sunucuda artık desteklenmiyor. {1} veya daha yeni bir sürüme güncelleme gerekir — sunucuya yazma güncellemeyi bekliyor.",\r
"bu",\r
"Bu ENU başka bir programla kayıtlı. Bu kasa için, bu programa kayıtlı yeni bir ENU gerekir.",\r
"Bu yazılım kodu başka bir programla kayıtlı. Bu programın yazılım kodunu girin (program Vergi İdaresi portalında kaydedilirken verilir).",\r
"Bu ay",\r
"Bu yazdırma yöntemi Windows'ta yoktur (Bluetooth ile yazdırma Android içindir).",\r
"Bu imzalı talimat bu kasada zaten yürütüldü — tekrarlanan talimat yürütülmez; yeni bir talimat düzenleyin.",\r
"Bu cihazda rastgele sayı üreteci (WebCrypto) yok.",\r
"Bu cihazda kriptografi (WebCrypto) yok.",\r
"Bu cihazda imza için kriptografi (WebCrypto) yok.",\r
"Bu cihazda fişleri imzalamak için kriptografi (WebCrypto) yok.",\r
"burada",\r
"Burada yalnızca düzenlenen son fiş, düzenlendikten sonraki 30 dakika içinde iptal edilebilir. Daha eski bir fiş, fiş incelemesinde iptal edilir (Fişler → fiş → \\"Fişi iptal et…\\").",\r
"Bu ürünler artık katalogda yok: {0}.",\r
"Bu bir düzeltme fişidir. Bu fişten mal iadesi mümkün değil.",\r
"Bu bir iptal fişidir ve iptal edilemez.",\r
"Bu bir özet fiş iptalidir ve iptal edilemez.",\r
"Bu bir mali fiş değildir.",\r
"Bu müşteriden bugün bu kasada zaten {0} nakit tahsil edildi. Bu fişle ({1}) birlikte toplam {2} oluyor.\\n\\nKanun, toplamı 10.000 € veya daha fazla olan bağlantılı nakit ödemelere de izin vermez (md. 65 f. 2). Bu fişler aynı işin parçasıysa ödeme kartla veya havale ile alınır.",\r
"OVSEN",\r
"İşaretlenen ürünler menüde \\"şu anda yok\\" işaretiyle kalır ve misafir bunları sipariş edemez. Kasa bunları satmaya devam eder.",\r
"işaretli",\r
"Misafir gelmedi olarak işaretlensin mi? Oda serbest bırakılır.",\r
"Kod",\r
"Vergi kaleminin muafiyet kodu",\r
"Kasa etiketi",\r
"Kasa kodu (işyerindeki kasa sıra numarası) zorunludur.",\r
"Tesisin ait olduğu işletme biriminin kodu; boş = bağlı değil.",\r
"Oda etiketi",\r
"Sürüm etiketi geçerli değil — paket kabul edilmiyor.",\r
"Menü etiketleri",\r
"Oda kodları",\r
"OZUJSK",\r
"OŽUJSK",\r
"p.id, p.uid, p.niz, p.godina, p.broj, p.datum, p.vazi_do, p.kasa_id, p.market, p.enu, p.kasir, p.kupac_pib, p.kupac_naziv, p.kupac_adresa, p.kupac_grad, p.napomena, p.bruto, p.popust, p.ukupno, p.status, p.racun_uid, p.pretvoren, p.ponisten, p.ponistio, p.razlog, r.client_uid r_uid, r.ord_num r_ord, r.issue_dt r_issue, r.datum r_datum, r.fiscal_status r_fs, r.vrsta r_vrsta, r.iic r_iic, r.ukupno r_ukupno, r.stornirao_uid r_storn",\r
"p.status = ?",\r
"Hastanın geçerli e-reçetesi yok.",\r
"Hasta öder:",\r
"hasta kabul ediyor",\r
"Ekran çökmeleri, sunucu veri alışverişi hataları ve Vergi İdaresi'nin reddettikleri, fiş içeriği olmadan sunucu üzerinden yayıncı IRIS CORVINA'ya gönderilir; JMBG, banka hesabı, e-posta, telefon numaraları, tutarlar ile kasiyer ve müşteri adları gönderilmeden önce kaldırılır. Kapalı = hiçbir şey gönderilmez (Destek'ten elle bildirim de dahil).",\r
"PAGO",\r
"PAHULJIC",\r
"PAK",\r
"Paket",\r
"Banka uygulaması paketi",\r
"Dosyadan paket (internetsiz)",\r
"Paket çok büyük.",\r
"Paket yüklendi: {0}, {1}",\r
"Paket yüklendi. Listeden bir kasa seçilmelidir.",\r
"Paket yüklendi. Bir kasa seçilmesi gerekir.",\r
"Paket şunlardan biri olmalıdır: {0}.",\r
"Paket index.html içermiyor — geçerli bir kasa paketi değil.",\r
"Pakette hiç ürün yok.",\r
"Paket geçerli bir kasa paketi değil ({0}).",\r
"Paket geçerli bir ZIP değil (dosya eksik veya bozuk).",\r
"Paket diske doğru yazılmadı. Hiçbir şey değiştirilmedi — yeniden deneyin.",\r
"Paket kasa için değil — kabul edilmiyor.",\r
"Ambalaj",\r
"Ürün ambalaj bilgisini yönetici girer (yönetici PIN'i gerekir). Onay olmadan yalnızca devam eden yazdırma için geçerlidir.",\r
"Ambalaj miktarı sıfırdan büyük olmalıdır (ör. 250 g, 0,5 l, 10 adet).",\r
"Paket boyutu anlaşılamadı. Örnekler: 250 g, 0,5 l, 6x0,33 l, 10 adet.",\r
"paket boyutu girilmemiş (örn. 250 g); bunsuz kg / l fiyatı olmaz",\r
"pakovanje REAL",\r
"addaki paket boyutu belirsiz",\r
"Paket boyutu yalnızca bu baskı için geçerlidir. Kalıcı girişi şef onaylar.",\r
"Paket boyutu: 250 g, 0,5 l, 6x0,33 l, 10 adet",\r
"PALL MALL",\r
"PALMOLIVE",\r
"PALOMA",\r
"PANCET",\r
"PANFLEX",\r
"Pansiyon",\r
"PANTENE",\r
"Kâğıt bitmek üzere.",\r
"PAPIRIC",\r
"PAPIRIĆ",\r
"PAPIRN",\r
"Kağıt ürünleri",\r
"PAR",\r
"PARADAJZ",\r
"çift (even)",\r
"PARFEM",\r
"Eşlik",\r
"PARIZER",\r
"PARLIAMENT",\r
"PARMEZ",\r
"katılım {0}% {1}{2}",\r
"Katılım",\r
"Katılım payı",\r
"Reçete başına katılım payı (€)",\r
"Cari",\r
"Cari: {0}{1}{2}.",\r
"Cariler",\r
"Cariler (firmalar ve acenteler)",\r
"Ortak",\r
"Pasaport",\r
"PASS",\r
"PASTA",\r
"PASTA ZA ZUB",\r
"PASTET",\r
"PAŠTET",\r
"PASULJ",\r
"PAUŠAL",\r
"Çiftçiye %8 oranında ödenen götürü tazminat (elle)",\r
"Götürü ödeme",\r
"Götürü vergi ödemesi",\r
"Duraklamalar: {od, do} tarihlerinden oluşan dizi.",\r
"PAVLAKA",\r
"paznja",\r
"KDV",\r
"KDV {0}",\r
"KDV {0}{1}",\r
"%15 oranında yurt içi teslimlerde KDV (hasılat + kesilen faturalar)",\r
"%21 oranında yurt içi teslimlerde KDV (hasılat + kesilen faturalar)",\r
"%7 oranında yurt içi teslimlerde KDV (hasılat + kesilen faturalar)",\r
"Kupon satışında KDV",\r
"Gaz, elektrik ve ısıtma/soğutma tesliminde KDV (yükümlülük devri) (elle)",\r
"Yabancı kişilerin hizmetlerinde KDV (yabancı kişilerin hizmetleri (İthalat ve yabancı hizmetler) + elle)",\r
"İthalatta ödenen KDV (gümrük beyannameleri (İthalat ve yabancı hizmetler) + elle)",\r
"Oranlara göre KDV",\r
"Firmanın KDV durumu, fişte gönderilenle uyuşmuyor.",\r
"KDV oranı şunlardan biri olmalıdır: {0} %.",\r
"PECIVO",\r
"Fırın ürünleri ve tahıllar",\r
"PEKMEZ",\r
"PELAT",\r
"PELENE",\r
"PELINKOV",\r
"PELINKOVAC",\r
"pending",\r
"PEPSI",\r
"PERECE",\r
"PERFEX",\r
"Dönem",\r
"Dönem {0} – {1}",\r
"Dönem: {0}",\r
"Dönemsel",\r
"Dönemsel rapor",\r
"PERSIL",\r
"Cum",\r
"Cuma",\r
"PETIT",\r
"Petnjica",\r
"PFANNER",\r
"PIB",\r
"PIB (satıcı)",\r
"PIB {0}",\r
"PIB {0}{1}",\r
"PIB / telefon",\r
"Firma PIB numarası ({0}) sertifikada yok (sertifikadaki: {1}).",\r
"Firma PIB numarası 8 haneli olmalıdır, JMB için 13 (verilen: \\"{0}\\").",\r
"Fişteki firma PIB'i ({0}) ile mali onay PIB'i ({1}) farklı. PIB eşitlenmelidir (Ayarlar → Fişteki firma / Mali onay).",\r
"Firma PIB'i girilmemiş veya geçerli değil (8 hane).",\r
"Müşterinin PIB'i ve adı zorunludur.",\r
"PIB 8 haneden oluşur (gerçek kişiler için 13).",\r
"Müşteri PIB",\r
"PIB 8 veya 13 haneli olmalıdır.",\r
"Sertifikadaki PIB, fişteki firma PIB'iyle uyuşmuyor.",\r
"PIB, merkez şehir (belediye), en az bir işyeri (mağaza, dükkân, ofis)",\r
"PIB: {0}",\r
"İçecekler",\r
"İçecekler, Kahve ve çay",\r
"PILEC",\r
"PILEĆ",\r
"PIN",\r
"PIN — {0}",\r
"PIN en az 4 haneli olmalıdır.",\r
"PIN zorunludur.",\r
"PIN sıfırlandı. Yeni bir PIN girilmelidir (Ayarlar → Kasiyerler).",\r
"PIN girildi",\r
"PIN 4 ila 8 haneli olmalıdır.",\r
"PIN doğru değil.",\r
"PIN, bakım ekibinin verdiği bir izinle (dosya) sıfırlanır. İzin yalnızca bugün ve yalnızca bu kasa için geçerlidir. Şefin PIN'i sıfırlanır; şef girilmemişse tüm kasiyerlerin PIN'i sıfırlanır.\\n\\nBakım için kasa etiketi:\\n{0}\\n\\nİzin dosyası bir sonraki adımda seçilir.",\r
"Şef PIN'i",\r
"Şefin PIN'i doğru değil.",\r
"PIRE",\r
"PIRINAC",\r
"PIRINAČ",\r
"PISKOT",\r
"PIŠKOT",\r
"PIŠTOLJ",\r
"Alkol ve tütün satışında yaşı sor",\r
"Ekrana erişim sorusu kasanın bu ekranında mümkün değil. Talimat yürütülmedi.",\r
"etiket sorusu",\r
"Bir soru, talep veya sorun açıklaması. Yanıt buraya gelir (kasanın başlığında \\"yeni yanıt\\" işareti görünür).",\r
"etiketi sor",\r
"PIVO",\r
"PJURE",\r
"Ödeyen",\r
"Öder (yaşa göre)",\r
"Havale ile öder",\r
"Fişlerdeki kartlı ödemeler (iptal ve iadelerle) aynı günün terminal işlemleriyle karşılaştırılır. Manuel onaylar (terminal bağlantısı olmadan) kasa tarafından kontrol edilemez — banka ekstresiyle karşılaştırılır.",\r
"Ödeme",\r
"\\"Odaya\\" ödeme",\r
"{0} ödemesi terminalde iptal edildi.",\r
"{0}{1} ödemesi terminalde / banka uygulamasında iptal edilmelidir. İptal edildi mi?",\r
"Bonla ödeme etkin değil (Ayarlar → Eklentiler).",\r
"Çekle ödeme: çek kodu girilmelidir.",\r
"nakit ödeme",\r
"Nakit ödeme",\r
"Kanun, başka bir kişiye (tedarikçi, borç, ödeme) 10.000 € ve üzeri nakit ödemeye izin vermez (md. 65). Böyle bir ödeme banka hesabı üzerinden yapılır.\\n\\nGünlük hasılatın bankaya teslimi yasağın kapsamında değildir.\\n\\nPara çıkışı kaydedilsin mi?",\r
"Avanstan yapılan ödeme, avans fişinin IKOF'unu taşımalıdır.",\r
"Ödeme reddedildi.",\r
"Ödeme onaylandı.",\r
"Ödeme terminalde kesildi.",\r
"Ödeme zaten onaylandı",\r
"Kartla ödeme (garson POS terminalini getirir)",\r
"kartla ödeme (POS)",\r
"Havale ile ödeme, PIB numaralı bir müşteri gerektirir.",\r
"Havale ile ödeme, rezervasyonda PIB numaralı bir cari gerektirir.",\r
"placeholder=\\"https://… veya http://…:8080\\" inputmode=\\"url\\"",\r
"placeholder=\\"ör. 1, 2, 3, 4, Bar, Teras 1\\"",\r
"placeholder=\\"ör. 1001, 1002, 4475\\"",\r
"placeholder=\\"İçecekler, Kahve ve çay\\"",\r
"placeholder=\\"XXXX-XXXX-XXXX veya bağlantı iris://upari…\\" autocapitalize=\\"characters\\"",\r
"Avans ödendi",\r
"ödendi",\r
"Avansla ödendi",\r
"Planlanan çıkış",\r
"PLANTAZE",\r
"PLANTAŽE",\r
"Plav",\r
"PLAZMA",\r
"Pljevlja",\r
"Plužine",\r
"PNG",\r
"fiyat listesine göre",\r
"Günlere göre",\r
"Haftanın gününe göre",\r
"Kayıtlara göre şu anda kasada",\r
"Kayıtlara göre kasada {0} var, para çıkışı ise {1}.\\n\\nPara çıkışı kaydedilsin mi?",\r
"Kayıtlara göre kasada {0} var. Sayılan nakit tutarı girilir.",\r
"Çıkıştan itibaren süre dolunca misafirin kişisel verileri silinir.",\r
"Kasiyere göre",\r
"kg başına",\r
"adet başına)",\r
"Müşteriye göre",\r
"Aylara göre",\r
"ada göre",\r
"gecelik",\r
"Konaklama vergisi tutarı belediyeye göre önerilir.",\r
"kişi başı gecelik",\r
"Bu proforma için fiş düzenlenmiş. Proforma iptal edilemez.",\r
"Bu proforma için zaten fiş düzenlenmiş.",\r
"Etkinleştirildiğinde",\r
"başlangıç kasa avansı",\r
"Açılış kasa avansı",\r
"Başlangıç kasa avansı Vergi İdaresi'ne zaten bildirildi (veya gönderim zaten denendi). Fark MEVDUAT veya ÇEKİM olarak girilir.",\r
"Açılış depozitosu negatif olamaz.",\r
"Açılış kasa avansı şu anda Vergi İdaresi'ne gönderiliyor. Düzeltmeyi birkaç saniye sonra tekrarlayın.",\r
"Açılış kasa avansı: {0}",\r
"Açılış kasa avansı: vardiya başında kasadaki nakit tutarı (€).\\nBoş veya 0 = kasa avansı yok.",\r
"Başlangıç nakit depozitosu bugün için zaten bildirilmiş.",\r
"Bugün için açılış nakit depozitosu bildirilmemiş. Önce depozito bildirilmeli, ardından fiş gönderilmelidir.",\r
"Başla",\r
"Yeni kasa olarak başlat",\r
"Veri",\r
"ürün verileri",\r
"Misafir verileri — {0} {1}",\r
"Belgedeki veriler girildi. Kontrol edin ve tamamlayın.",\r
"Fiş verileri QR koduyla uyuşmuyor. Fiş düzenlendikten sonra değiştirilmiş.",\r
"Veriler başka bir cihazda değiştirildi. Değişikliklerinizi kaydedin veya vazgeçin, ardından yenileyin.",\r
"Bildirim verileri eksiksiz.",\r
"Emniyet Müdürlüğü ve turizm örgütüne bildirim için veriler.",\r
"podaci_upijeni TEXT",\r
"Veriler bu arada başka bir kullanıcı tarafından değiştirildi. Veriler yenilendi; değişikliği tekrarlayın.",\r
"Ayarlar",\r
"Ayarlar → Garson telefonları → \\"Telefonu eşleştir\\"",\r
"Eczane ayarları",\r
"Eczane ayarları kaydedildi.",\r
"Dosyadan ayarlar",\r
"QR menü ayarları",\r
"QR menü ayarları kaydedildi.",\r
"Ayarlar kaydedildi.",\r
"Kasa cihazı ayarları",\r
"Cihaz ayarları kaydedildi.",\r
"Podgorica",\r
"Alt grup",\r
"Paylaş",\r
"Masa {0} hesabını böl",\r
"Masa hesabını böl…",\r
"Para çıkışları",\r
"Para çıkışı",\r
"Para çıkışı — kasadan para",\r
"Para çıkışı kaydedildi:",\r
"10.000 € ve üzeri para çıkışı",\r
"Bakiyeden büyük para çıkışı",\r
"PARA ÇIKIŞI…",\r
"Alt kategoriler",\r
"Varsayılan yazıcı (Windows){0}",\r
"Windows'taki varsayılan yazıcı (\\"{0}\\") yazdırmaz, dosyaya kaydeder.",\r
"Windows varsayılanı",\r
"Destek",\r
"Destek ve hatalar (IRIS CORVINA)",\r
"IRIS CORVINA desteği yardım etmek için bu kasanın ekranına erişim istiyor.",\r
"IRIS CORVINA desteği bu kasanın ekranına erişim istiyor.",\r
"Program üzerinden destek, tarayıcıda değil, kurulu kasada (Windows, Android) çalışır.",\r
"Destek bu kasada kullanılamıyor.",\r
"Destek: mesajlar, hata bildirimi, talepler…",\r
"POGAC",\r
"POGAČ",\r
"hatalı kontrol basamağı",\r
"Hatalı kontrol basamağı",\r
"Yanlış PIN.",\r
"Sertifika parolası yanlış (veya dosya .pfx/.p12 değil).",\r
"Yanlış kanonikleştirme yöntemi.",\r
"Yanlış imza yöntemi.",\r
"Yanlış özet yöntemi.",\r
"poIsteku \\"citanje\\" olmalıdır.",\r
"hediye çeki {0}",\r
"Hediye bonu {0}",\r
"HEDİYE ÇEKİ {0} €",\r
"Hediye bonu yazdırıldı: {0} ({1} adet).",\r
"Hediye çeki başka bir çekle satın alınamaz.",\r
"Hediye çeki adet olarak satılır (bir fişte 1–50 adet).",\r
"Hediye kuponları",\r
"Hediye bonları açık değil. Şef açar (Ayarlar → Ek özellikler: nominal değerler, KDV, geçerlilik süresi).",\r
"Hediye kuponları etkin",\r
"başlatıldı: {0}",\r
"Cinsiyet",\r
"Polis",\r
"Hatalı biçimli alanlar (Vergi İdaresi şema kontrolü): {0}.",\r
"\\"düzenleyen\\" alanı zorunludur.",\r
"\\"düzenlenme\\" alanı ISO zamanı olmalıdır.",\r
"\\"İndirim\\" alanı boş. Yüzde için bir sayı girin, ardından %.",\r
"Onay numarası alanı",\r
"format alanı \\"iris-licenca\\" olmalıdır.",\r
"Sonuç alanı",\r
"Tutar alanı",\r
"Kart alanı",\r
"Mesaj alanı",\r
"Referans alanı",\r
"RRN alanı",\r
"Para birimi alanı",\r
"Dönen referans alanı",\r
"Kart türü alanı",\r
"POMFRIT",\r
"Yardımcı",\r
"Pzt",\r
"Tekrar (ORp)",\r
"Pazartesi",\r
"geri alır",\r
"iptal ediliyor",\r
"Yalnızca bu kasada yapılan değişiklik iptal edilebilir.",\r
"Yalnızca açık bir proforma iptal edilebilir.",\r
"ponistava TEXT",\r
"İptal",\r
"Fiyat değişikliğini geri alma",\r
"Son fişi iptal et (müşteri ödemedi, giriş hatası); kalemler beklemeye alınabilir",\r
"Proformanın iptali",\r
"Fişin iptali",\r
"Barkod bağlantısını geri alma",\r
"geri alındı",\r
"İptal edildi",\r
"İptal edildi {0}{1}{2}.",\r
"geri alındı",\r
"İptal edilenler",\r
"Misafir siparişinin iptali",\r
"geri alındı",\r
"Geri al",\r
"Seçimi temizle",\r
"Son fişi iptal et",\r
"Fişi iptal et",\r
"Tümünü geri al",\r
"Garson tarafından iptal edildi.",\r
"Sunucuya kaydı tekrarla",\r
"fiyat listesi yeniden alındı (servis)",\r
"Sunucudan yeniden alım: {0}",\r
"Yeniden başlatma, vardiya kapatıldıktan sonra mümkündür.",\r
"Yeniden başlatma başarısız oldu. Programı kapatıp yeniden açmak gerekir.",\r
"Reddedilen mesajlar yeniden gönderiliyor…",\r
"yeniden sildi",\r
"yeniden sildi {0} {1} {2}{3}",\r
"Yeniden başlat",\r
"Şimdi yeniden başlat",\r
"ponovo_kasir TEXT",\r
"ponovo_kasir_id INTEGER",\r
"ponovo_razlog TEXT",\r
"ponovo_vrijeme TEXT",\r
"Sunulan {0} sürümü, kasada zaten bulunan sürümden ({1}) eski.",\r
"Doluluk",\r
"Doluluk ve gelir",\r
"İndirim",\r
"{1} fişinde %{0} indirim",\r
"indirim %",\r
"Ekrandaki indirim ve müşteri, zayiatta",\r
"Ekrandaki indirim ve müşteri, zayiatta dikkate alınmaz.",\r
"İndirim kaldırıldı (fiyat değişti): {0}.",\r
"Sadakat müşterisinin indirimi tüm fişe uygulanır (elle indirim yoksa). Müşteri listesi Muhasebe'den gelir.",\r
"Gecelik fiyatta indirim (%)",\r
"Son kaleme indirim",\r
"Fişe indirim",\r
"Fiş indirimi negatif olamaz.",\r
"Kalem indirimi",\r
"İndirim, kalem tutarından ({0}) büyük olamaz.",\r
"İndirim geçerli değil.",\r
"{0} tutarındaki indirim, yeni kalem tutarından küçük olmadığı için \\"{1}\\" kaleminden kaldırıldı.",\r
"% cinsinden indirim 0 ile 100 arasında bir sayı olmalıdır.",\r
"Yüzde indirim: bir sayı, ardından %",\r
"popust_pct REAL",\r
"İndirim: 0 ile 100 % arasında.",\r
"İndirimler",\r
"PORCIJA",\r
"Vergi İdaresi iletiyi reddetti",\r
"Vergi İdaresi reddetti: {0} (Ayarlar → Fiskalizasyon).",\r
"Vergi İdaresi bu kasanın sertifikasını kabul etmiyor. Gönderim geçerli bir sertifikayı bekler.",\r
"Vergi İdaresi reddetti",\r
"Vergi İdaresi reddetti ({0}): {1}",\r
"Vergi İdaresi {0} öğesini reddetti, bu nedenle bu belge de bildirilemez. Neden giderildikten sonra: \\"Reddedilenleri yeniden gönder\\".",\r
"Vergi İdaresi iletileri reddetti: {0}. Bunların çözülmesi gerekir (Ayarlar → Fiskalizasyon).",\r
"Vergi İdaresi fişi reddetti",\r
"Vergi İdaresi iptal edilen fişi reddetti, bu nedenle iptal de alınamaz. Neden giderildikten sonra: \\"Reddedilenleri yeniden gönder\\" (önce orijinal, ardından iptal gider).",\r
"Vergi İdaresi'nde bu gün için zaten bildirilmiş bir açılış depozitosu var (kod 56). Bu giriş ayrıca tutulmaz.",\r
"Vergi İdaresi: {0} bekliyor · gönderim KAPALI",\r
"Vergi İdaresi: {0}{1}",\r
"Vergi İdaresi: HAZIR DEĞİL",\r
"Vergi İdaresi: SERTİFİKANIN SÜRESİ DOLDU",\r
"Ücretin vergi işlemi Vergi İdaresi ile kontrol edilmelidir.",\r
"Vergi İdaresi'ne gönderilmeyi bekleyen: {0}. İnternet bağlantısı ve gönderim gerekir (başlıktaki Vergi İdaresi göstergesi).",\r
"Bağlantı noktası",\r
"{0} numaralı bağlantı noktası kullanımda (başka bir kasa mı çalışıyor?) — başka bir bağlantı noktası seçin.",\r
"{0} portu bu bilgisayarda bulunamadı (bağlı cihaz, sürücü).{1}",\r
"{0} portu açılamıyor (başka bir program kullanıyor veya bağlı değil): {1}",\r
"Port / adres",\r
"Port önce Ayarlar'daki \\"Deneme\\" düğmesiyle bağlanmalıdır.",\r
"Portal",\r
"PORTO",\r
"Misafirlere mesaj (Karadağca)",\r
"Misafirlere mesaj (İngilizce)",\r
"Yayıncıdan mesaj",\r
"Mesaj desteğe gönderildi.",\r
"İleti çok büyük (en fazla 150 kB). Fişin birden fazla fişe bölünmesi gerekir.",\r
"Vergi İdaresi'ne gönderilmeyi bekleyen mesajlar: {0}. Gönderim kapalıyken mesajlar gönderilmez (teslim süresi, fişin düzenlenmesinden itibaren 48 saattir).\\n\\nGönderim kapatılsın mı?",\r
"Vergi İdaresi'ne gönderilmeyi bekleyen mesajlar: {0}. Kuyrukta kalırlar ve yalnızca sertifika yeniden içe aktarıldığında gönderilirler.",\r
"Mesaj okunamadı (boyut kontrolü).",\r
"Mesaj XSD şema doğrulaması sırasında okunamadı.",\r
"İleti şema doğrulamasını geçemedi: bir alan hatalı biçimde veya fişteki KDV firmanın KDV durumuyla uyuşmuyor.",\r
"desteğe mesaj",\r
"IRIS CORVINA desteğine ileti, hata bildirimi, talep (bir kasa daha, uzatma, modül)",\r
"Destek mesajı:",\r
"Vergi İdaresi'ne gidecek ileti {0} kB, izin verilen en fazla 150 kB. Fişin birden fazla fişe bölünmesi gerekir.",\r
"Cihaz için mesaj çok büyük.",\r
"ileti: {0}",\r
"Mesajlar",\r
"Vergi İdaresi'nin reddettiği mesajlar ({0}) otomatik olarak yeniden gönderilmez. Neden giderildikten sonra \\"Reddedilenleri yeniden gönder\\" düğmesiyle gönderilir.",\r
"Mesajlar",\r
"pos",\r
"POS terminali",\r
"Banka POS terminali, telefonla ödeme, terazi, F tuşları, müşteri ekranı; terminal işlemleri ve kasa ile mutabakat",\r
"POS terminali: {0}{1}{2}. İnceleme: Daha fazla → Kasa cihazları → Terminal işlemleri.",\r
"Gönder",\r
"Reddedilenleri yeniden gönder",\r
"Mesaj gönder",\r
"Şimdi gönder",\r
"Talebi gönder",\r
"Gönder",\r
"İş",\r
"KDV'siz ayrı kalem",\r
"gönderildi",\r
"gönderilen",\r
"Gönderilenler",\r
"gönderildi",\r
"Gönderildi",\r
"Gerekenden fazla anahtar bilgisi gönderildi.",\r
"İzin verilenden fazla imza gönderildi.",\r
"Yazdırmaya gönderildi: {0}{1}",\r
"Vergi İdaresi'ne gönderildi: {0}.",\r
"sonra",\r
"Bu kadar ardışık geceden sonra vergi hesaplanmaz; 0 = uygulanmaz.",\r
"Fiyat değişikliğinden sonra",\r
"Fiyat değişikliğinden sonra: {0}.",\r
"Son iki gün. Sarı: dikkat gerektirir — belirsiz sonuç (terminali kontrol edin) veya fişsiz onay (aynı tutarda fiş düzenleyin veya iptal edin). Belirsiz:",\r
"Son hata:",\r
"Son hata: {0}",\r
"Son katalog değişikliği tamamlanmadı ({0}). Fiyatları kontrol edip yeniden içe aktarın (Ayarlar → Ürünler ve fiyatlar).",\r
"Son katalog değişikliği tamamlanmadı. Fiyatlar \\"{0}\\" için programdan yeniden yüklendi. Daha yeni bir fiyat dosyası varsa yeniden içe aktarılması gerekir (Ayarlar → Ürünler ve fiyatlar).",\r
"Son not: {0}",\r
"Son denetim",\r
"Son veri alışverişi",\r
"Klasöre son yedek",\r
"son bağlantı {0}",\r
"Son değişiklikler",\r
"Son indirme başarısız oldu: {0} Bir sonraki denetimde yeniden denenir.",\r
"Son gönderim",\r
"Son numara",\r
"Son düzenlenen numara {0}. Bir sonraki fiş {1} numarasını alır.",\r
"Son düzenlenen numara {0} olur, dolayısıyla bir sonraki fiş {1} numarasını alır.\\n\\nSayacı daha sonra geri almak mümkün olmaz.",\r
"Son düzenlenen fiş numarası",\r
"Son düzenlenen fiş numarası ({0})",\r
"Son düzenlenen fiş artık zaman nedeniyle fiş düzenlemeyi engellemez. Onay yalnızca cihazdaki tarih ve saat şu anda doğruysa verilebilir.",\r
"Son fiş {0} tarihli, bugün ise {1} ({2} gün). Kasa bu kadar süre beklemediyse ilk fişten önce cihazdaki tarihi ve yılı kontrol edin.",\r
"Veritabanının son anlık görüntüsü hasarlıydı. Veritabanı önceki anlık görüntüden ve günlükten geri yüklendi",\r
"Son {0} saat",\r
"Son 48 saat",\r
"mağaza sorumlusu",\r
"POST",\r
"POST, GET",\r
"Ayarla",\r
"{0} EUR olarak ayarla",\r
"{0} sürümü mevcut, ancak feed'de Android paketi için geçerli (HTTPS) bir adres yok.",\r
"İzin imzası geçerli değil. İzni yalnızca bakım ekibi verir.",\r
"Misafir imzası",\r
"Talimat imzası yayıncının anahtarıyla eşleşmiyor. Talimat yürütülmedi.",\r
"İmza bir bütün olarak geçerli değil.",\r
"İstek imzası geçerli değil.",\r
"Mesajın yanlış bölümü imzalanmış.",\r
"İmzalı talimat 7 günden eski (veya geçerli zamanı yok) — yürütülmedi; yeni talimat düzenleyin.",\r
"Yalnızca bu modül tarafından oluşturulan istek (racunXml / depozitXml / enuXml) imzalanır.",\r
"Alacak",\r
"En az bir ödeme şekli gereklidir.",\r
"bankanın ECR şartnamesi gereklidir",\r
"Uygulamanın yeni bir sürümü (1.5) gereklidir.",\r
"Uygulamanın yeni sürümü gerekli (tutarlı SoftPOS).",\r
"Uygulamanın yeni sürümü gerekli.",\r
"Yeniden giriş yapmanız gerekiyor (garson ve PIN).",\r
"Yeniden giriş yapmak gerekir.",\r
"Seçim yapılmalıdır:",\r
"Programın yeniden başlatılması gerekir.",\r
"Kasa bilgileri kontrol edilip yeniden onaylanmalıdır.",\r
"Satış noktası bilgileri kontrol edilip yeniden onaylanmalıdır.",\r
"Bon kodu girilmelidir.",\r
"Kasanın sunucuyla eşleştirilmesi gerekir (IRIS CORVINA Sunucusu bölümü).",\r
"Odaya tüketim",\r
"Oda harcaması",\r
"Onay",\r
"Numara onayı",\r
"Kasa onayı",\r
"Onay girilmedi (NOVA). Hiçbir şey değiştirilmedi.",\r
"Katılım payı belgesi",\r
"ÖDENEN KATILIM PAYI BELGESİ",\r
"Paket boyutu onayı",\r
"Satış noktası onayı",\r
"Cihaz saati onayı",\r
"onay: çalışma saatleri dışında fiş",\r
"Onaylandı",\r
"Onaylandı (odayı tutar)",\r
"Onayla",\r
"ENU'yu listeden onayla…",\r
"İadeyi onayla",\r
"Cihaz saatini onayla",\r
"Onaylayan",\r
"muhasebeci onaylar",\r
"bağlı",\r
"Bağlı barkodlar",\r
"Bağlı",\r
"Bağla",\r
"Barkodu bir ürünle ilişkilendir",\r
"Ürünle bağla",\r
"Mevcut ürünle bağla",\r
"Bağlantı",\r
"Kasanın firmaya bağlanması",\r
"Firmaya bağlanma",\r
"Sunucuya bağlanılıyor…",\r
"Bağlanıyor…",\r
"{0} tutarının karta iadesi terminalde / banka uygulamasında yapılır.",\r
"Karta iade",\r
"Karta iade başarısız ({0}): {1}",\r
"İade",\r
"iade ({0} kalem{1})",\r
"avans iadesi",\r
"Avans iadesi",\r
"AVANS İADESİ — AVANS FİŞİNİN DÜZELTME FİŞİ",\r
"Avans iadesi yönetici onayı gerektirir. İade yapılmadı.",\r
"İade, fiş tutarını aşacak ({0}; zaten iade edilen {1}). İade yapılmadı.",\r
"Malın bir kısmının iadesi",\r
"Malın bir kısmının iadesi: düzeltme fişi no.",\r
"Verilmiş ilacın iadesine izin verilmez. Verme hatası, fişin neden belirtilerek iptal edilmesiyle düzeltilir.",\r
"İade mümkündür",\r
"İade yalnızca düzenlenmiş ve iptal edilmemiş bir fişten yapılabilir.",\r
"İade kaydedildi: düzeltme fişi {0}.",\r
"MÜŞTERİYE İADE (para üstü)",\r
"Karta iade",\r
"Karta iade: müşteri aynı kartı terminale yaklaştırır.",\r
"Terminalde iade",\r
"povrat REAL",\r
"Mal iadesi",\r
"{0} numaralı fiş için iade",\r
"Havale ile iade, rezervasyonda PIB numaralı bir cari gerektirir.",\r
"Önceki sürüme dönüş başarısız oldu.",\r
"Önceki sürüme dönme yalnızca Windows kasasında vardır.",\r
"Fişi masasına geri gönderme (sipariş olmadan)",\r
"İhlal",\r
"Çek",\r
"Kataloğu sunucudan çek",\r
"Misafir çağrısı çözüldü.",\r
"Misafir çağrıları",\r
"çağrılar: {0}",\r
"PRAŠAK ZA PEC",\r
"Terazi barkodu kuralları",\r
"Kurallar ve vergiler",\r
"Tesis kuralları kaydedildi.",\r
"boş",\r
"Boş fiş.",\r
"Değer içermesi gereken boş alanlar: {0}.",\r
"Tatil",\r
"TATİL",\r
"Tatil",\r
"boş = uygulama yalnızca açılır",\r
"Boş = vizesiz.",\r
"boş = Karadağca'dan Kiril",\r
"boş = etkinlik sonuç kodu",\r
"boş = kontrol edilmez",\r
"boş = eczacı değil",\r
"Boş = fiyat listesine göre.",\r
"boş = varsayılan",\r
"boş = ilk USB cihaz veya vid:pid",\r
"boş = ilk USB cihaz veya Bluetooth adresi",\r
"Boş = konaklama oranı.",\r
"Boş = konaklama oranı. Ücrete hiçbir zaman konaklama vergisi eklenmez.",\r
"boş veya çok uzun dosya adı",\r
"ikametgâh",\r
"İkamet adresi",\r
"Sayılan nakit (€)",\r
"Kapanıştan önce sayılan nakit zorunludur.",\r
"Sayılan nakit geçerli değil (örn. 125,50).",\r
"Sayılan",\r
"Sayılan: {0}",\r
"Sayılan: {0}. Fark kapanış raporunda (Z) görünür.",\r
"Sayılan: girilmedi",\r
"Proforma",\r
"PROFORMA — mali fiş değildir. Ciroya dahil edilmez ve Vergi İdaresi'ne bildirilmez.",\r
"Proforma {0}",\r
"Proforma {0} iptal edildi.",\r
"Proforma {0} kaydedildi ({1}).",\r
"Proforma {0}, artık katalogda bulunmayan ürünler olmadan yüklendi: {1}. Tutar: {2}.",\r
"Proforma {0} ekrana yüklendi ({1}).",\r
"Proforma {0} yüklendi. Güncel fiyatlarla tutar {1}, proformada {2}.",\r
"Proforma {0}, {1} tarihli, {2}.\\nİptal edilen proforma sepete yüklenemez.\\n\\nNeden (isteğe bağlı):",\r
"Proforma iptal edildi.",\r
"Proforma fiş ekranına yüklenmiş. İptal etmeden önce ekrandan kaldırılması gerekir.",\r
"Proforma zaten beklemede.",\r
"Proforma zaten iptal edilmiş.",\r
"Proforma bulunamadı.",\r
"Ekrandaki fişten proforma (mali fiş değildir); proforma listesi",\r
"Masa için proforma hazırlanmaz. Masanın hesabı mali fişle tahsil edilir.",\r
"Proforma, ekrandaki fişten (kalemler, indirimler, müşteri) oluşturulur. Kaydedildikten sonra fiş ekrandan kaldırılır; proforma daha sonra sepete yüklenir ve mali fiş olarak tahsil edilir.",\r
"proforma. Daha eskiler için arama gerekir.",\r
"Çok uzun alanlar: {0}.",\r
"dosya adı çok uzun: {0}",\r
"Genel bakış",\r
"Silinen fişlerin incelemesi",\r
"Görüntüleme erişim günlüğüne kaydedilir (kullanıcı, zaman, neden).",\r
"Seçilen dönem için tahsilattan önceki tüm silmelerin incelemesi: silinen fişler ve fişlerden kaldırılan kalemler (kim, ne zaman, ne, ne kadar, neden ve fişin sonradan tahsil edilip edilmediği).",\r
"Önizleme: {0} / {1} ürün{3}",\r
"Yalnızca görüntüleme. Değişiklikleri ayar yetkisi olan bir kullanıcı yapar.",\r
"tarayıcı",\r
"tarayıcı (IndexedDB)",\r
"{0} dosyasına yarım kalan yazma tamamlanamıyor ({1})",\r
"Terminalde kesildi (deneme).",\r
"Kesildi.",\r
"mağazanın Wi-Fi ağı üzerinden. Eşleştirme: ana kasadaki QR kodu (",\r
"Aşım: {uredjaja, dana} ≥ 0 olan tam sayılar olmalıdır.",\r
"geçiş modu (sunucu + klasör)",\r
"geçiş modu: sunucu ve klasör üzerinden",\r
"Geçiş modu: veri alışverişi klasör üzerinden de",\r
"önceki 7'ye göre",\r
"Girilen çalışma saatlerine göre kasa bugün çalışmıyor.",\r
"taşınıyor",\r
"Taşıma / birleştirme — masa {0}",\r
"Masa taşıma / birleştirme",\r
"Barkodun başka bir ürüne taşınması",\r
"Başka bir odaya taşıma",\r
"taşındı",\r
"Taşı",\r
"Taşı / birleştir",\r
"Masayı taşı / birleştir…",\r
"Ürün ambalaj bilgilerinin aktarılması başarısız oldu: {0}",\r
"Ürün ambalaj bilgilerinin aktarılması: {0}",\r
"Kalan",\r
"Dağıtılacak {0} kaldı.",\r
"Kurumun uygulamasına aktarma",\r
"Aktarma: bildirim burada hazırlanır ve kurumun uygulamasına girilir.",\r
"Yazışma",\r
"Önerilen",\r
"Ara rapor",\r
"ara rapor (X)",\r
"PRESJEK | Kasa:{0} | {1}..{2} | Racuna:{3} | Promet:{4} EUR | Got:{5} | Kar:{6} | Popust:{7}",\r
"Ara rapor saati",\r
"3 kattan büyük değişiklik atlanır: {0} (\\"3 kattan büyük değişiklikleri de dahil et\\" işaretli değil).",\r
"Atla",\r
"Önceki gün",\r
"Önceki veriler",\r
"Önceki kayıt sürüyor.",\r
"Ara",\r
"Ara (ad veya kod)",\r
"Ürün arama",\r
"Ürün ara: ad veya kod…",\r
"Barkod, kod veya adın bir kısmıyla arayın.",\r
"Tedarikçi, numara ve kaynağa göre ara",\r
"Ada göre ara",\r
"Ara: numara, tutar, müşteri, kasiyer, IKOF…",\r
"Ara: numara, müşteri, PIB…",\r
"Ara: ad, oda",\r
"Ara: ad, telefon, oda",\r
"fişe dönüştürüldü",\r
"Fişe dönüştürülenler",\r
"{0} sürümü indirildi ve doğrulandı. Kurulum vardiya kapatıldıktan sonra yapılabilir; veriler korunur.",\r
"{0} sürümü indirildi ve doğrulandı. Mevcut sürümün üzerine kurulur; veriler korunur.",\r
"{0} sürümü indirildi ve doğrulandı. Yeni sürüm, vardiya kapatıldıktan sonra kasanın bir sonraki başlatılışında uygulanır.",\r
"{0} sürümü indirildi ve doğrulandı. Yeni sürüm, program bir sonraki başlatıldığında uygulanır.{1}",\r
"{0}{1} sürümü indirildi",\r
"İndirilen sürüm diskte geçerli değil, bu nedenle kurulumdaki sürüm çalışıyor. Güncellemenin yeniden indirilmesi gerekir.",\r
"İndirilen sürüm daha yeni bir Setup gerektiriyor ({0} veya daha yeni). O zamana kadar mevcut sürüm çalışmaya devam eder.",\r
"Alınan ayarlar: {0}.",\r
"İndirildi: {0} ürün (kâr marjı {1} %)",\r
"İndirme zaten sürüyor.",\r
"Katalog indiriliyor…",\r
"İndirme başarısız oldu.",\r
"Yeni sürüm indiriliyor.",\r
"Bu cihazda yeni sürüm indirilemez.",\r
"{0} sürümü indiriliyor…",\r
"indirme: {0}",\r
"Al",\r
"E-reçeteleri getir",\r
"Devral ve gönder",\r
"İndir ve yükle",\r
"Yeni sürümü indir",\r
"Şimdi indir",\r
"Masayı devral",\r
"çok fazla dosya",\r
"Art arda çok fazla yanlış PIN girildi. {0} sonra tekrar denenebilir.",\r
"Güncelleme adresinde çok fazla yönlendirme var.",\r
"Soyad",\r
"Soyadı ve adı",\r
"kapanışta",\r
"Pricing Rule",\r
"Rezervasyon kaynağına göre gelir",\r
"Müsait oda başına gelir",\r
"Konaklama geliri",\r
"giriş",\r
"Bildirim",\r
"Giriş kaydı",\r
"Misafir bildirimi — {0} {1}",\r
"Misafir bildirimi",\r
"Program hatası bildir",\r
"Bildirim kopyalandı.",\r
"Bildirim yayıncıya gönderildi.",\r
"Bildirim kaydedildi ve sunucu bağlantısı kurulduğunda gönderilir.",\r
"Kasiyer girişi",\r
"Kullanıcı bildirimi: {0}",\r
"Giriş başarısız.",\r
"Giriş başarısız. Kasiyer yeniden seçilmelidir.",\r
"Yetkili makamlara bildirim",\r
"Polise giriş bildirimi",\r
"Turizm örgütüne bildirim",\r
"Aktarma için bildirim",\r
"prijava.cuvanjeGodina",\r
"prijava.rokPolicijaSati",\r
"prijava.rokToSati",\r
"prijava.turistickaOrganizacija",\r
"Misafir bildirimleri",\r
"Bildir",\r
"Girişi kaydet",\r
"Hata bildir",\r
"giriş yapan kasiyer eczacı olarak kayıtlı değil",\r
"Polise bildirildi",\r
"Turizm örgütüne bildirildi",\r
"önce",\r
"{0} gün önce",\r
"{0} gün önce",\r
"{0} sa önce",\r
"{0} dk önce",\r
"{0} sn önce",\r
"Önerilen ad: {naziv}",\r
"Garson telefonlarından sipariş alma açık değil (Ayarlar → Garson telefonları).",\r
"Bu firma için yayıncıda teknik hataların alınması kapalı. Kuyruktaki hatalar gönderilmez.",\r
"FZO payının mali fişte gösterilmesi: fiş, hastanın ödediği tutar üzerinden düzenlenir (FZO payı kalem indirimidir). Bu yöntemin muhasebeci ve Gelir ve Gümrük İdaresi ile teyit edilmesi gerekir.",\r
"{0} kayıttan 500'ü gösteriliyor — aramayı daraltın.",\r
"Gösterilen son",\r
"Son {0} proforma gösteriliyor. Daha eskiler için arama gerekir.",\r
"Gösterilen ilk",\r
"İlk {0} fiş gösteriliyor. Diğerleri için dönemin veya aramanın daraltılması gerekir.",\r
"İlk {0} gösteriliyor. Diğer ürünlere arama ile ulaşılabilir.",\r
"Gösterilen nokta: {0} / {1}",\r
"Gösterilen:",\r
"Göster",\r
"{0} göster",\r
"Verileri göster",\r
"Tüm kasaları göster",\r
"Kasanın yalnızca seçilen faaliyetlere ait bölümleri gösterilir. Seçim yapılmazsa her şey gösterilir. Eşleştirilmiş kasa seçimi sunucuya da yazar, firmanın tüm programları için.",\r
"PRIL",\r
"\\"{0}\\" eki izin verilmiyor (izin verilenler: günlük, görüntü, bağlam).",\r
"Ek bir nesne olmalıdır.",\r
"ek: ekran görüntüsü (bu pencerenin)",\r
"ek: kasanın teknik günlüğü (son 200 işlem, tutarlar ve fişler olmadan)",\r
"Ekli sertifika X.509 değil.",\r
"Garson telefonlarından sipariş kabul et",\r
"primary",\r
"Uygula",\r
"Uygula ({0})",\r
"Şuna da uygula…",\r
"KDV oranlarının tarihe göre uygulanması başarısız oldu: {0}",\r
"Zamanlanmış fiyatların uygulanması başarısız oldu: {0}",\r
"Programın bir sonraki başlatılışında uygulanır.",\r
"Alınan nakit, nakit ödenecek tutardan az.",\r
"Alınan nakit geçerli bir tutar değil.",\r
"Alınma",\r
"Alınan (boş = tam tutar)",\r
"alınan fiyat değişikliği: {0}",\r
"Alınan {0}, para üstü {1}.\\n\\nPara üstü tutarı onaylansın mı?",\r
"Alınan nakit",\r
"primljeno REAL",\r
"PRINCES",\r
"PRINGLES",\r
"Deneme kasası hazırlanıyor…",\r
"Vergi İdaresi kuyruğunun hazırlanması başarısız oldu: {0}",\r
"Ekran erişimi — IRIS CORVINA desteği",\r
"Ekran erişimine izin verildi. Destek bilgilendirildi.",\r
"ekrana erişim: {0}",\r
"Erişim yalnızca onayınızla mümkündür. Onay verilmezse destek ekranı göremez ve hiçbir şey değişmez. Her erişim yayıncıda kaydedilir.",\r
"Misafir verilerine erişim",\r
"Özel anahtar sertifikayla uyuşmuyor.",\r
"cihazdaki uygulamanın özel alanı",\r
"uygulamanın özel alanı, klasör {0}",\r
"özel reçete",\r
"geçici dosya tamamen yazılmadı",\r
"PROBA",\r
"Müşteri ekranını dene",\r
"MÜŞTERİ EKRANI DENEMESİ",\r
"Deneme müşteri ekranına gönderildi.",\r
"Deneme tahsilatı 1,00 €",\r
"Bağlantı denemesi (durum)",\r
"PROBA-{0}-{1}",\r
"PROBA-POTVRDA-{0}",\r
"Deneme kasası",\r
"Deneme kasası (satış noktasız)",\r
"Deneme kasası ayarlandı",\r
"Deneme kasası hiçbir satış noktasına bağlı değildir (deneme, eğitim): {0} ve ayarlarda girilen etiketle.\\n\\nListeden bir kasa daha sonra seçilebilir (Ayarlar → Kasa).",\r
"deneme",\r
"deneme (bu cihazda oluşturuldu)",\r
"Deneme FZO (eğitim — kurgusal e-reçeteler)",\r
"Deneme FZO (eğitim)",\r
"DENEME FZO (eğitim)",\r
"probni INTEGER",\r
"DENEME MODU",\r
"DENEME MODU — FİŞ VERGİ İDARESİ'NE BİLDİRİLMEDİ",\r
"DENEME MODU · TEST",\r
"Yüzde önceliklidir. İkisi de boş = indirim yok.",\r
"tahmin",\r
"Tahmin",\r
"PROD",\r
"Satış",\r
"satış ({0} kalem{1})",\r
"Satış = fişler ve iptaller; Zayi = zayi edilen mal (ciro değildir)",\r
"Alkol / tütün satışı",\r
"Son kullanma tarihi geçmiş ürünün satışı ({0}, son kullanma {1})",\r
"çek satışı (nominal değer fişe eklenir), çek bakiyesi sorgulama, liste",\r
"Müşteriye göre satışlar {0}",\r
"Hediye bonu satışı etkin değil (Ayarlar → Eklentiler).",\r
"Satış: tutar seçmek bonu fişe kalem olarak ekler; ödemeden sonra kasa kodlu bir bon yazdırır. Bonla ödeme: \\"Daha fazla yöntem\\" → Bon (kod).",\r
"Satış noktaları",\r
"Satış noktaları: {0} · pakettaki kasalar: {1}",\r
"Satış noktası",\r
"Firmanın satış noktası",\r
"CANLI ORTAM",\r
"Deneme süresinin uzatılması",\r
"Bir gece uzat",\r
"Program güncellendi",\r
"Program {0} sürümüne güncellendi.",\r
"Programı kapatıp yeniden açmanız gerekir.",\r
"Programda yüklenecek ürün veritabanı yok.",\r
"Programda gönderilecek günlük yok.",\r
"Program sunucuya bağlı değil (Ayarlar → Sunucu).",\r
"Program sunucuya bağlı değil.",\r
"Program sunucuya bağlı değil. Menü düzenleme, sunucu bağlantısıyla çalışır (Ayarlar → Sunucu).",\r
"Üretici",\r
"Üretici adı en fazla 80 karakter olabilir.",\r
"Üretici",\r
"proizvodjac TEXT",\r
"promet",\r
"Ciro",\r
"CİRO",\r
"Vergi yükümlülüğü devredilen gaz, elektrik ve ısıtma/soğutma teslimi (elle)",\r
"Ürüne göre ciro",\r
"Saate göre ciro",\r
"Fiyatları değiştir",\r
"Fiyatı değiştir",\r
"Kasiyeri değiştir",\r
"Kasayı değiştir…",\r
"Mağazayı değiştir",\r
"Genel fiyatı değiştir",\r
"{0} ürünün fiyatı değiştirilsin mi?{1}",\r
"Değiştirilen fiyat sayısı: {0}{1}.",\r
"Değişim",\r
"Kasa değişikliği",\r
"PRONTO",\r
"Reçete edilen",\r
"reçetedeki ilaç mevcut değil",\r
"PROPOLIS RAK",\r
"PROSEC",\r
"PROSECCO",\r
"Ortalama fiş",\r
"Ortalama fiyat",\r
"Ortalama",\r
"Geçen ay",\r
"Veri alışverişi alanı",\r
"Otomatik yazdırma kontrolü başarısız oldu: {0}",\r
"Güncellemeler denetleniyor…",\r
"veritabanı kontrolü başarısız oldu",\r
"Bon kontrolü",\r
"Fiyat sorgulama",\r
"Fiyat sorgulama, ürünü fişe eklemez.",\r
"Firma fiyat listesi kontrol ediliyor…",\r
"Para kontrolü",\r
"Veri doğrulama",\r
"Bağlantı denetleniyor…",\r
"denetim: {0}",\r
"Sunucuyla doğrulandı",\r
"Kontrol edildi…",\r
"Kontrol et",\r
"Güncellemeleri denetle",\r
"Fiyatları şimdi denetle",\r
"Klasörü şimdi denetle",\r
"Kâğıdı kontrol et",\r
"Yeniden denetle",\r
"Şimdi kontrol et",\r
"Bağlantıyı denetle",\r
"Miktarı, fiyatı ve oranı kontrol edin.",\r
"İkinci monitörde pencere",\r
"PRp",\r
"PRSUT",\r
"PRŠUT",\r
"Önce oda türlerini girin.",\r
"public class KasaRaw {",\r
"public static void Posalji(string stampac, byte[] b) {",\r
"PUEBLO",\r
"PUEBLO TEQUILA",\r
"yanıp sönüyor",\r
"Tam tutar",\r
"PUT",\r
"PUTER",\r
"QR kodları ve alan adı",\r
"Masa QR kodları",\r
"QR kodlar firmanın kendi alan adına yönlendirir (düzenleyicide → \\"QR kodlar ve alan adı\\" bölümüne yazılır)",\r
"QR menü — ayarlar",\r
"QR menü — menü içeriği",\r
"QR menü yiyecek-içecek modunda çalışır (Ayarlar → Yiyecek-içecek).",\r
"Sıra",\r
"r.datum >= ? AND r.datum <= ?",\r
"r.fic IS NOT NULL",\r
"r.fiscal_status IN ('ceka', 'error')",\r
"r.smjena_id = ?",\r
"r.smjena_id = ? AND date(r.datum) = ?",\r
"r.vrsta = 'otpis'",\r
"fiş)",\r
"račun",\r
"Hesap",\r
"fatura {0}",\r
"Fiş {0}",\r
"{0} fişi zaten bir özet fişe dahil edilmiş.",\r
"{0} fişi KDV oranlarına göre hesaplanamaz.",\r
"Fiş {0}:",\r
"Fiş {0}…: oranlara göre toplam ({1}) fiş tutarına ({2}) eşit değil.",\r
"fiş {0}{1}",\r
"Fatura no",\r
"{0} numaralı fiş iptal edildi (storno).{1}",\r
"Fiş no. {0} iptal edildi.",\r
"Fiş no. {0}, {1} tarihli, {2}.\\n\\nİptal fişi düzenleniyor; bu fiş kayıtlarda iptal edilmiş olarak kalır. İptal geri alınamaz.\\n\\nİptal nedeni:",\r
"Misafirin hesabı ödenmedi ({0} EUR). Çıkıştan önce tahsil edin.",\r
"otel fişi",\r
"Fiş ve yazdırma",\r
"Fiş, seçim penceresi olmadan doğrudan seçilen yazıcıya gider. \\"Varsayılan yazıcı (Windows)\\", Windows'ta varsayılan olarak ayarlanmış yazıcıdır. Yazıcı seçim penceresi yalnızca \\"(her yazdırmada seçim)\\" ile açılır. Belgeler sırayla, tek tek yazdırılır.",\r
"Fişte {0} farklı oran/muafiyet var, Vergi İdaresi en fazla 20 kabul eder.",\r
"Fişte {0} kalem var, Vergi İdaresi en fazla 1000 kabul eder. Fişin birden fazla fişe bölünmesi gerekir.",\r
"Bu proforma için düzenlenen fiş bu kasanın veritabanında yok.",\r
"Fiş boşaltıldı ve silinen fişlerin kaydında kalır (Daha fazla → Silinen fişler).",\r
"Fiş IKOF olmadan düzenlendi.",\r
"Fiş, kasa farklı bir ortamda (TEST / ÜRETİM) çalışırken düzenlenmiştir ve bu servise gönderilmez.",\r
"Fiş {0} numaralı odaya düzenlendi. Oda hesabına kayıt, sunucu bağlantısını bekliyor.",\r
"Fiş 6 saatten fazla önce düzenlenmiş. Sonradan gönderim olarak gönderilmelidir.",\r
"Fiş beklemeye alındı.",\r
"Fiş silindi ve silinenler kaydında kalır (Daha fazla → Silinen fişler).",\r
"Bekleyen fiş silindi.",\r
"Fiş avanstan ödenmiş ve avans fişi bu tutar için zaten düzeltilmiş. İptal yapılmadı.",\r
"Fiş terminal üzerinden kartla ödendi{0}. Terminalde {1} {2}?",\r
"Fiş boş.",\r
"Fiş Vergi İdaresi'ne ÜRETİM ortamında bildirildi, kasa ise şu anda deneme ortamında çalışıyor. İade yapılmadı. İade için ortamın yeniden ÜRETİM'e alınması gerekir (Ayarlar → Fiskalizasyon).",\r
"Fiş Vergi İdaresi'ne ÜRETİM ortamında bildirildi, kasa ise şu anda deneme ortamında çalışıyor. İptal yapılmadı. İptal için ortamın yeniden ÜRETİM'e alınması gerekir (Ayarlar → Fiskalizasyon).",\r
"Fiş Vergi İdaresi'ne bildirildi, bu nedenle iade de bildirilmelidir ve kasa şu anda gönderemiyor: {0} İade yapılmadı.",\r
"Fiş Vergi İdaresi'ne bildirildi, bu nedenle iptal de bildirilmelidir ve kasa şu anda gönderemiyor: {0} İptal yapılmadı.",\r
"Fiş kaydedildi: {0} ({1}){2}{3}",\r
"FİŞ İPTAL EDİLDİ (iptal no.",\r
"Fiş iptal edildi: iptal fişi no.",\r
"Fiş iptal edildi.",\r
"Fiş zaten bir özet fişe dahil edilmiş (başka bir kasada düzenlenmiş). İptal yapılmadı.",\r
"Fiş zaten bir özet fişe dahil edilmiş.",\r
"Fiş zaten bir özet fişe dahil edilmiş. İptal yapılmadı.",\r
"Fiş zaten tamamen iptal edilmiş.",\r
"Fiş zaten iptal edilmiş.",\r
"Fiş zaten ekrana geri getirildi ve beklemede (\\"Bekleyenler\\").",\r
"Fiş, artık katalogda bulunmayan ürünler olmadan ekrana geri getirildi: {0}.",\r
"Fiş ekrana geri getirildi.",\r
"Odaya yazılan fişte başka bir ödeme yöntemi olamaz.",\r
"Kasa kapatılırken girilmekte olan fiş geri yüklenemedi (kayıt bozuk). Fişin yeniden girilmesi gerekir.",\r
"Kasa kapatılırken girilmekte olan fiş ekrana geri getirilmedi: ürünlerinden hiçbiri artık katalogda yok ({0}). Silinen fişlere kaydedildi (Daha fazla → Silinen fişler).",\r
"İptal edilen fiş farklı bir ortamda (TEST / ÜRETİM) düzenlenmiştir, bu nedenle iptal de bu servise gönderilmez.",\r
"İptal edilen fişte IKOF yok, bu nedenle iptal bildirilemez.",\r
"İptal edilen fiş Vergi İdaresi'ne bildirilmemiştir (deneme modunda düzenlenmiştir), bu nedenle iptal de gönderilmez.",\r
"İadenin yapıldığı fiş mevcut değil.",\r
"Bir fiş yalnızca bir avans fişi taşıyabilir, bu nedenle serbest avans bu tahsilatta tamamen kullanılamaz. Bir kısmını başka bir yöntemle veya ayrıca tahsil edin. Hiçbir şey düzenlenmedi.",\r
"Bir fiş yalnızca bir avans fişi taşıyabilir. Avansın bir kısmı kullanılmadı; kalanı ayrıca tahsil edin.",\r
"Fişi beklemeye al",\r
"Beklemedeki fiş okunamıyor.",\r
"Ekrandaki fiş",\r
"Ekrandaki fiş boş.",\r
"Ekrandaki fiş boş. Proforma, ekrandaki fişin kalemlerinden oluşturulur: ürünler fiş için olduğu gibi girilir, ardından \\"Proforma\\" düğmesine basılır.",\r
"Ekrandaki fiş boş. Proforma, fişin kalemlerinden hazırlanır.",\r
"Ekrandaki fiş bu arada değişti. Zayiat kaydedilmedi.",\r
"Atıfta bulunulan fiş henüz Vergi İdaresi'ne bildirilmedi. Daha sonra tekrar deneyin.",\r
"Misafirin odasına fiş…",\r
"Odaya yazılan fiş bu kasada mevcut değil veya IKOF'u yok.",\r
"Odaya yazılan fiş IKOF olmadan düzenlenemez (mali onay etkin değil veya sertifika yok). Fiş düzenlenmedi.",\r
"Odaya yazılan fiş için rezervasyon gerekir.",\r
"Fiş mevcut değil.",\r
"Fişte IKOF yok (düzenlenirken imzalanmamış).",\r
"Fişte hiçbir ödeme yöntemi yok.",\r
"Fişte kalem yok.",\r
"Fiş düzenlenmedi",\r
"Fiş düzenlenmedi{0}, ancak {1} ödemesi terminalde onaylandı. Ödeme terminalde iptal edilir veya fişi yeniden düzenleme denemesi için tutulur (aynı tutardaki sonraki tahsilat onu yeni tahsilat olmadan kullanır).",\r
"Fiş bulunamadı.",\r
"Fiş bu avanstan ödenmedi.",\r
"Fiş bir özet fiş değil.",\r
"{0} tarihli fiş ekrana geri getirildi.",\r
"avanstan ödenen fiş",\r
"Avanstan ödenen fiş",\r
"Avanstan ödenen fiş iptal edildi. Avans fişi bunun için düzeltilmez.",\r
"Avanstan ödenen fiş kasada iptal edilmez: oda hesabındaki avans kullanılmış olarak kalır. İptal yapılmadı.",\r
"Terminal bağlantısı olmadan kartla ödenen fiş (manuel onay)",\r
"Ekrandaki fiş \\"{0}\\" siparişinde.",\r
"ertelenmiş ödemeli fiş",\r
"Ertelenmiş ödemeli fiş",\r
"ERTELENMİŞ ÖDEMELİ FİŞ",\r
"ertelenmiş ödemeli fiş {0}",\r
"Ertelenmiş ödemeli fişte başka bir ödeme yöntemi olamaz.",\r
"Ertelenmiş ödemeli fiş, fiş dışında ücret veya vergi taşıyamaz: özet fiş yalnızca fiş tutarlarını kapsar.",\r
"Ertelenmiş ödemeli fiş ücret taşıyamaz: özet fiş yalnızca fiş tutarlarını kapsar.",\r
"Ertelenmiş ödemeli fişte IKOF yok, bu nedenle özet fişe girmez.",\r
"Hediye bonlu fiş (satılan veya bonla ödenen) yalnızca tüm fişin iptaliyle iade edilir. Tutar bu durumda bona geri yüklenir.",\r
"Fiş, avans fişi olarak kendi IKOF'una atıfta bulunuyor.",\r
"Fiş, referans fişler arasında kendi IKOF'una atıfta bulunuyor.",\r
"Fiş imzalanamıyor ({0}). Fiş düzenlenmedi. Sertifikayı kontrol edin (Ayarlar → Mali onay).",\r
"Fiş tahsil edilmez ve Vergi İdaresi'ne gönderilmez. Silinen fiş ekrana geri getirilip tahsil edilebilir (Daha fazla → Silinen fişler).",\r
"Fiş {0} fişe atıfta bulunuyor, Vergi İdaresi en fazla 1000 kabul eder. Birden fazla özet fiş düzenlenmelidir.",\r
"Oda hesabı",\r
"Oda hesabı {0}",\r
"Oda hesabı az önce değiştirildi. Hiçbir şey düzenlenmedi.",\r
"Oda hesabı sunucuda bulunamadı.",\r
"Oda hesabı şu anda başka bir kasada tahsil ediliyor.",\r
"Masanın fişi okunamıyor.",\r
"Fiş artık son düzenlenen fiş değil veya {0} dakikadan fazla geçti. İptal, fiş görünümünden yapılabilir (Fişler → fiş → İptal et).",\r
"Konaklama fişi ve oda tüketimi için toplu fiş",\r
"racun_uid TEXT",\r
"Fiş: {0} · {1}",\r
"Fiş",\r
"İndirimli fişler",\r
"Misafirin geliş saatinden itibaren hesaplanır.",\r
"fiş. Diğerleri için dönemin veya aramanın daraltılması gerekir.",\r
"IKOF ve QR hesapla",\r
"Bilgisayar yerel ağa bağlı değil (Wi-Fi / kablo). Telefonlar onu bulamaz.",\r
"računi",\r
"Fişler",\r
"müşterisiz fişler",\r
"Fişler no.",\r
"Fişler ve raporlar",\r
"Bekletilen fişler",\r
"Bekleyen fişler ( ) — tahsil edilmedi",\r
"Bekleyen fişler ({0}) — tahsil edilmedi",\r
"Bekleyen fişler ({0}) kapanıştan sonra da kayıtlı kalır.",\r
"ödemeden önce silinen fişler ve kaldırılan kalemler, son 48 saat; daha eskileri şef görür",\r
"ödemeden önce silinen fişler ve kaldırılan kalemler, son 48 saat; daha eskilerini amir görür",\r
"ödemeden önce silinen fişler ve kaldırılan kalemler, son 48 saat; daha eskileri şef görür",\r
"Tahsilattan önce silinen fişler, girilen tüm kalemleriyle. Her silme kaydedilir: kim, ne zaman, ne, ne kadar, neden",\r
"Özet fişe dahil edilen fişler",\r
"Avanstan ödenen fişler",\r
"İş",\r
"İŞ",\r
"Yerel IRIS sunucusu üzerinden çalışmak (kendi CA'sının sertifikası) kasa 1.8.0 veya daha yeni sürümün kurulumunu gerektirir (yeni Setup). Android'de yerel sunucu henüz desteklenmiyor.",\r
"Yerel IRIS sunucusu üzerinden çalışmak için kasanın yeni bir Setup'ı gerekir (1.8.0 veya üzeri).",\r
"Çalışıyor —",\r
"Çalışıyor — menüde {0} masa var, siparişler bu kasaya gelir",\r
"genel fiyatlarla çalışır",\r
"RADLER",\r
"Çalışma mağazası",\r
"İşlem",\r
"İşlem zaten işlendi.",\r
"İşlemin geçerli bir numarası yok.",\r
"Bu numaralı bir işlem zaten var (başka bir telefon).",\r
"Görev yeri",\r
"Kasanın bugünkü çalışma saatleri: {0}–{1}.",\r
"RAKIJA",\r
"RAKIJA DUNJA",\r
"RAKIJE",\r
"Kabuklular",\r
"RAMAZZOTTI",\r
"Önceki müşteriler",\r
"Erken çıkış",\r
"açıldığında {0} MB'tan büyük olurdu",\r
"Müsait (oda-gece)",\r
"Aralık veya virgülle ayrılmış liste.",\r
"Salon düzeni",\r
"Salon düzeni kaydedildi.",\r
"Dağıtılan",\r
"Fiş tutarından {0} fazla dağıtıldı.",\r
"RAUCH",\r
"Mal çıkışı 134000 — PAZ+IZF fişleri ile KDV dahil hasılat (mal faturaları kendi tutarını ekler)",\r
"Fark",\r
"Fark (terminal − kasa)",\r
"Tutar farkı: terminal − kasa (manuel onaylar hariç)",\r
"Kapanışta en az şu fark (€)",\r
"Vardiya kapanışında fark: {0} {1} €",\r
"Fark kapanış raporunda (Z) görünür.",\r
"Fark: {0}",\r
"Neden",\r
"Neden (örn. misafir vazgeçti)",\r
"Silme gerekçesi zorunludur (örn. \\"misafir vazgeçti\\").",\r
"Zayi nedeni",\r
"Çekmecenin açılma nedeni zorunludur.",\r
"İade nedeni",\r
"İade gerekçesi zorunludur.",\r
"Görüntüleme nedeni",\r
"İptal nedeni",\r
"neden",\r
"Şimdi alışveriş yap",\r
"Sunucu ile veri alışverişi yapıldı: gönderilen {0}, alınan {1}{2}",\r
"Veri alışverişi",\r
"Veri alışverişi klasör üzerinden yapılıyor (Google Drive); kasa IRIS CORVINA sunucusuna bağlı değil.",\r
"Klasör üzerinden veri alışverişi (Google Drive)",\r
"Klasör üzerinden veri alışverişi (Google Drive){0} · kasa sunucu ile eşleştirilmemiş",\r
"Klasör üzerinden veri alışverişi",\r
"Sunucu üzerinden veri alışverişi:",\r
"Sunucu üzerinden veri alışverişi: {0}{1}",\r
"Muhasebe ve Yönetici ile veri alışverişi sunucu üzerinden yapılır: kasa vardiya kapanışlarını, fiyat değişikliklerini ve yeni ürünleri gönderir; fiyat listesini ve fiyat değişikliklerini alır; internet erişimi olur olmaz birkaç saniye içinde. Eşleştirilmiş kasanın veri alışverişi klasörüne ihtiyacı yoktur; {0}yalnızca yedek için kullanılır (aşağıdaki bölüm). Satış ve yazdırma sunucuya bağlı değildir.",\r
"Muhasebe ile veri alışverişi ayarlanmamış. Kasanın sunucuyla eşleştirilmesi (Ayarlar → IRIS CORVINA sunucusu) veya alışveriş klasörünün ayarlanması (Ayarlar → Google Drive) gerekir.",\r
"Sunucuyla veri alışverişi sürüyor.",\r
"Sunucu ile veri alışverişi: {0}",\r
"Sunucuyla veri alışverişi…",\r
"Veri alışverişi: yeni değişiklik yok.{0}",\r
"Resepsiyon",\r
"Resepsiyon (misafirlerin kişisel bilgileri)",\r
"Otel resepsiyonu",\r
"Resepsiyon, kasanın sunucuya bağlı olmasını ve otelin açık olmasını gerektirir (Ayarlar → İşletme modu).",\r
"Reçete",\r
"Reçete {0}: {1}",\r
"Reçete {0}: ilaç fişte yok.",\r
"Reçetenin süresi {0} tarihinde doldu.",\r
"Reçete zaten karşılanmış.",\r
"RED BULL",\r
"REDBULL",\r
"Sıra numarası",\r
"Sıra numarası sıfır veya pozitif bir tam sayı olmalıdır.",\r
"Fiş sıra numarası pozitif bir tam sayı olmalıdır (verilen: {0}).",\r
"Sıra",\r
"Menüdeki sıra",\r
"Gruptaki sıra",\r
"Satır",\r
"ref TEXT",\r
"Referans fiş {0}…: düzenlenme zamanı 2026-07-31T07:01:00+02:00 biçiminde değil.",\r
"Referans fiş: IKOF geçerli değil (\\"{0}\\").",\r
"RELKON",\r
"REMY MARTIN",\r
"PIN sıfırlama (servis): {0}, kasiyer: {1}",\r
"Kasa şefinin PIN'ini sıfırlamak, yayıncının anahtarıyla İMZALANMIŞ bir talimat gerektirir — IRIS Admin'de admin/owner rolüyle (imzalı) talimat düzenleyin. Talimat yürütülmedi.",\r
"REXONA",\r
"rez. {0} · {1} kişi",\r
"REZANC",\r
"Rezervasyon",\r
"Rezervasyon iptal edildi.",\r
"Rezervasyon yeniden onaylandı. Misafirin girişini kaydedin.",\r
"Rezervasyon kaydedildi.",\r
"Rezervasyon girildi.",\r
"Rezervasyon kapatıldı: misafir gelmedi.",\r
"Rezervasyon bulunamadı.",\r
"Rezervasyonlar",\r
"Rezervasyon bu arada başka bir kullanıcı tarafından değiştirildi. Görünüm yenilendi.",\r
"Rezerve edilen tür",\r
"Rezerve",\r
"Bu klasöre veritabanı yedeği, kasa kurulumu 1.3.6'dan itibaren çalışır (yeni Setup). O zamana kadar kasa, kendi veri klasöründe (Kopije) günlük kopyalar oluşturur.",\r
"Klasöre yedekleme için kasa sürümü 1.3.6 veya daha yenisi gerekir (yeni Setup).",\r
"Klasöre yedek: {0}",\r
"Yedek: {0}",\r
"Rejim",\r
"Rejim",\r
"{0} rejimi özel eczanede FZO hesabına verilmez.",\r
"Eczane modu (reçeteli ilaç yalnızca reçete ve eczacı ile, ilaç iadesi yasak)",\r
"Eczane modu açık değil (⋯ Daha fazla → Eczane — ayarlar).",\r
"Eczane modu, FZO ile bağlantı, katılım payı, eczacılar",\r
"Çalışma modu",\r
"Sonuçlar",\r
"Balık",\r
"RIBLJI ŠTAP",\r
"RIFF",\r
"right",\r
"Çözüldü",\r
"RIZA",\r
"RIŽA",\r
"RIZLA",\r
"Dil sözlüğü geçerli değil.",\r
"satılamayan ve iade edilemeyen mal; stoktan düşülür, belge mali değildir",\r
"Zayiat edilecek mallar ekranda satışta olduğu gibi girilir (okutulur), ardından zayiat seçilir (Daha fazla → Mal zayiatı).",\r
"mal",\r
"Vade",\r
"süre {0} önce doldu",\r
"Polis için süre: {0}",\r
"Polise bildirim süresi",\r
"Polise bildirim süresi (saat)",\r
"Turizm örgütüne bildirim süresi",\r
"Turizm örgütüne bildirim süresi (saat)",\r
"Ödeme süresi (gün)",\r
"belgenin geçerlilik süresi",\r
"Geçerlilik süresi en fazla {0} gün olabilir.",\r
"Geçerlilik süresi, proformanın hazırlandığı günden önce olamaz.",\r
"Proforma geçerlilik süresi geçerli bir tarih değil.",\r
"Fişlerin Vergi İdaresi'ne gönderilme süresi, düzenlendikten sonra 48 saattir. İnternet bağlantısını kontrol edin; göndermek için göstergeye tıklayın.",\r
"ROL",\r
"ROSA",\r
"ROSE",\r
"ROSTILJ",\r
"ROŠTILJ",\r
"ROTHMANS",\r
"Rožaje",\r
"ROZE",\r
"manuel onay",\r
"Manuel onay",\r
"kasiyerin manuel onayı",\r
"Slipten manuel onay",\r
"elle bildirim",\r
"Ürünü elle seç (barkod okunamadığında)",\r
"Elle indirim {0} % (şef olmadan en çok {1} %)",\r
"Amir PIN'i olmadan manuel indirim, en fazla (%)",\r
"Kasiyerin manuel indirimi (kampanyasız kalemlerde ve tüm fişte) malın değerinin bu yüzdesinin üzerindeyse, tahsilatta amirin PIN'i gerekir. Kampanyalar ve sadakat müşterileri sayılmaz. 0 veya boş = sınırsız.",\r
"Manuel indirim şundan büyükse (%)",\r
"Elle yapılan indirimler",\r
"Elle",\r
"elle",\r
"RUKAVIC",\r
"RUM",\r
"Rusça",\r
"Bu noktada fiyatı veya satışı olan",\r
"Bu fişten malın bir kısmı zaten iade edilmiş (iade). İptal yapılmadı. Kalan kısım \\"Malın bir kısmını iade et\\" ile iade edilir.",\r
"KDV dahil",\r
"Son faturalardan",\r
"Otel fişinden malın bir kısmı iade edilemez. Fişin tamamı iptal edilir, ardından yenisi düzenlenir.",\r
"Avanstan ödenen fişten malın bir kısmı iade edilemez. Fişin tamamı iptal edilir, ardından yenisi düzenlenir.",\r
"Ertelenmiş ödemeli fişten malın bir kısmı iade edilemez. Fişin tamamı iptal edilir, ardından yenisi düzenlenir.",\r
"Kaynak masa",\r
"Özet fişin bir kısmı iade edilemez. Özet fişin tamamı iptal edilir.",\r
"kasanın okuyamadığı bir yöntemle sıkıştırılmış",\r
"şablon",\r
"Kaydet",\r
"Tartı için ürünleri kaydet (CSV)",\r
"Sipariş fişi olmadan kaydet",\r
"Alan adını kaydet",\r
"Misafiri kaydet",\r
"Değişiklikleri kaydet",\r
"Bu kasadaki değişiklikleri dosyaya kaydet",\r
"Tablo olarak kaydet (CSV)",\r
"Kataloğu dosyaya kaydet",\r
"Kuralları kaydet",\r
"Proformayı kaydet",\r
"Düzeni kaydet",\r
"Etiketler için tabloyu kaydet (CSV)",\r
"{0} grubu kaydedildi.",\r
"Kaydedildi: {0}",\r
"Kaydedildi: {0}.",\r
"Kaydedildi.",\r
"Şimdi",\r
"şimdi {0}{1} · {2} fiyat · kod {3}",\r
"Şimdi: deneme kasası",\r
"tajne.json dosyasının içeriği bozuk",\r
"içerik aktarım sırasında bozuldu",\r
"İçerik bu arada başka bir programda değiştirildi. Yeni durum yüklendi; değişiklik kaydedilmedi.",\r
"kısayollar (bağlantılar) içeriyor",\r
"Bildirimleri ve teklifleri kabul ediyor",\r
"Onay {0}{1} tarihinde verildi.",\r
"Onay tarihi",\r
"Onay {0} tarihinde geri çekildi.",\r
"Web sitesi",\r
"Tüm grubu menüden gizle",\r
"gizli",\r
"gizli",\r
"Salon",\r
"SALAMA",\r
"Bakiye",\r
"Bakiye {0} EUR",\r
"bakiye {0} EUR",\r
"Oda hesabı bakiyesi {0} EUR. Misafirin çıkışı ödenmemiş bakiye ile yapılsın mı?",\r
"Oda hesabı bakiyesi ödenmedi: {0} EUR.",\r
"{0} gönderiliyor…",\r
"gönderiliyor",\r
"Vergi İdaresi'ne gönderiliyor: kalan {0}",\r
"Fişleri Vergi İdaresi'ne gönder",\r
"Teknik hataları yayıncıya gönder",\r
"SALVET",\r
"SAMBUCA",\r
"yalnızca İngilizcesi olmayanlar",\r
"Yalnızca mutfak ekranı (kağıtsız)",\r
"Yalnızca dükkânın yerel ağı.",\r
"Yalnızca onay vermiş ve onayını geri çekmemiş kişiler. Her dışa aktarma erişim günlüğüne kaydedilir.",\r
"yalnızca sunucu üzerinden",\r
"yalnızca sunucu üzerinden (klasör veri alışverişi için kullanılmaz)",\r
"Yalnızca temizlenecek odalar",\r
"SAMPANJAC",\r
"ŠAMPANJAC",\r
"ŠAMPANJCA",\r
"SAMPON",\r
"ŠAMPON",\r
"BAR",\r
"SAPUN",\r
"SARDIN",\r
"SAT",\r
"Saat onaylandı. Tahsilatın tekrarlanması gerekir.",\r
"Telefon ve kasa saatleri arasında 10 dakikadan fazla fark var. Telefonda otomatik saati açın ve kasanın saatini kontrol edin.",\r
"sat TEXT",\r
"Arka plan saati başlatılmadı: {0}",\r
"Arka plan saati: {0}",\r
"Arka plan saati: okunamayan çalışan işlem iletisi",\r
"Cihaz saati",\r
"cihaz saati {0}.{1}. {2} gösteriyordu",\r
"Cihaz saati onaylandı.",\r
"silme sırasında cihaz saati ileri alınmıştı",\r
"Cihaz saati geri alınmış: son fiş {0} tarihinde düzenlendi ve saat şimdi daha erken bir zamanı gösteriyor. {1}",\r
"Cihaz saati geri alınmış: yönetici saati {0} olarak onayladı ve saat şimdi daha erken bir zamanı gösteriyor. {1}",\r
"Cihaz saati, son fişten (veya son saat onayından) daha erken bir zamanı gösteriyor. Saat ileri alınıp sonra düzeltilmiş olabilir.\\n\\nSaat şu anda doğruysa amir bunu onaylar ve kasa fiş düzenlemeye devam eder. Değilse cihazın tarih ve saatinin ayarlanması gerekir.",\r
"SAUVIGNON",\r
"SAVANNA",\r
"Šavnik",\r
"Özet, mesaj içeriğiyle uyuşmuyor.",\r
"Scan for the menu & ordering",\r
"SCHWEPP",\r
"bu kasada başlatılamadı",\r
"SECER",\r
"ŠECER",\r
"ŠEĆER",\r
"şef",\r
"Şef",\r
"şefte her zaman vardır",\r
"Şefin PIN'i yok, bu nedenle şef onayı istenmez. PIN \\"Düzenle\\" düğmesiyle girilir.",\r
"PIN'li şef",\r
"kasa şefi",\r
"select",\r
"selected",\r
"Hardal",\r
"SENF",\r
"SENSATION",\r
"Eylül",\r
"Eylül",\r
"Seri",\r
"Seri {0} satıştan çekildi ({1}). Bu seriden ilaç verilmez.",\r
"seri satıştan çekildi",\r
"serija TEXT",\r
"Seri / USB port (COM)",\r
"Seri port kapalı.",\r
"Seri port yeni kasa Setup'ı gerektirir (kabuk 2111).",\r
"Seri portlar: {0}",\r
"Seri portlar…",\r
"Sertifika",\r
"Kasanın sertifikası ve anahtarları başlatma sırasında okunamadı, bu yüzden sunucu bağlantısı da kaydedilemiyor. Kasanın yeniden başlatılması gerekir. Hata tekrarlanırsa: Ayarlar → Mali onay → \\"Okunamayan anahtarları at…\\".",\r
"Sertifika ve anahtarlar okunamıyor",\r
"Sertifika ve anahtarlar okunamıyor (Mali onay bölümü). Bu çözülene kadar sunucu bağlantısını kaydetmek mümkün değil.",\r
"Sertifika ve anahtarlar KAYDEDİLMEDİ — tajne.json dosyası yazılamıyor ({0}). Mevcut dosyaya dokunulmadı.",\r
"Sertifika ve anahtarlar tam olarak yazılmadı; mevcut dosya değiştirilmeden bırakıldı.",\r
"Sertifika ve anahtarlar doğru okunuyor, bu nedenle atılacak bir şey yok.",\r
"Sertifika ve anahtarlar başlangıçta okunamadı, bu nedenle şu anda değiştirilemez. Kasanın yeniden başlatılması gerekir. Hata tekrarlanırsa: Ayarlar → Fiskalizasyon → \\"Okunamayan anahtarları at…\\".",\r
"Sertifika ve anahtarı bu kasadan silinir. Kasa deneme anahtarına geçer ve fişleri Vergi İdaresi'ne göndermeyi bırakır.\\n\\nYeniden gönderim için sertifikanın dosyadan yeniden içe aktarılması gerekir.{0}",\r
"Sertifikanın süresi {0} tarihinde doldu. Yeni bir sertifika gerekir.",\r
"Sertifikanın süresi doldu. Yeni bir sertifika gerekir.",\r
"Sertifika PIB {0} için düzenlenmiş, ancak ayarlardaki firma PIB'i {1}. Bu firmaya ait bir sertifika gerekir. Kasa başka bir firmaya aitse firmayı değiştirin (Ayarlar → Fişteki firma) ve o firmanın fiyat listesinden kasayı seçin.",\r
"Sertifika iptal edilmiş.",\r
"Sertifika kaldırıldı",\r
"Sertifika içe aktarıldı",\r
"yerel sunucu sertifikasının süresi dolmuş (bilgisayardaki tarihi kontrol edin)",\r
"yerel sunucu sertifikası henüz geçerli değil (bilgisayardaki tarihi kontrol edin)",\r
"Sertifika kayıtlı bir veren kurum (CA) tarafından verilmemiş. Mali onay sertifikası gerekir (CoreIT veya Pošta CG).",\r
"Sertifika geçerli değil.",\r
"Sertifika okunamıyor veya RSA (X.509) değil.",\r
"Sertifika okunamıyor: {0}",\r
"Sunucu sertifikası, yerel sunucunun kayıtlı CA parmak iziyle uyuşmuyor — bağlantı kesildi",\r
"sunucu sertifikası yerel sunucunun kayıtlı CA'sını imzalamıyor",\r
"sunucu sertifikası okunamıyor",\r
"sunucu sertifikası yerel sunucunun kayıtlı CA'sı tarafından imzalanmamış",\r
"Sertifika yalnızca {0} tarihinden itibaren geçerlidir.",\r
"Mali onay sertifikasının süresi {0} tarihinde doldu. Fişler düzenlenir, ancak yeni sertifika içe aktarılana kadar Vergi İdaresi'ne gönderilemez (Ayarlar → Fiskalizasyon). Sonradan gönderim süresi 48 saattir.",\r
"Mali onay sertifikası {0} tarihine kadar geçerlidir. Yeni sertifikanın zamanında içe aktarılması gerekir (Ayarlar → Fiskalizasyon).",\r
"Sertifika, imza anahtarı ve sunucu parolası okunamadı ({0}). Veriler değiştirilmedi. Kasanın yeniden başlatılması gerekir. Hata tekrarlanırsa anahtarlar atılabilir ve sertifika yeniden içe aktarılabilir (Ayarlar → Fiskalizasyon). O zamana kadar kasa, veri göndermeden deneme modunda çalışır.",\r
"Sunucu",\r
"IRIS CORVINA sunucusu (veri alışverişi)",\r
"Sunucu, eşleştirme bağlantısından farklı bir CA parmak izi bildiriyor. Bağlantı kurulamadı.",\r
"Sunucu bu kasayı reddetti (cihaz sunucuda devre dışı). Kasa her 15 dakikada bir yeniden dener. Çalışmaya devam etmek için bağlantının kesilmesi (\\"Bağlantıyı kes\\") ve kasanın yeni bir kodla eşleştirilmesi gerekir.",\r
"Sunucu bu kasayı reddetti.",\r
"Sunucu kaydı reddetti: {0}",\r
"Sunucu {0} hatasıyla yanıt verdi.",\r
"Sunucu JSON olmayan bir yanıt döndürdü.",\r
"{0} adresindeki sunucu yanıt vermiyor.",\r
"Sunucu yanıt vermiyor ({0} sn). Veri alışverişi arka planda devam ediyor; kasa dosyaları gönderim kuyruğunda bekliyor.{1}",\r
"Sunucu yanıt vermiyor (zaman aşımı).",\r
"Sunucu, talep durumunu kasaya döndürmez. Yayıncının yanıtı (onaylandı / reddedildi) destek mesajları üzerinden gelir (Mesajlar sekmesi).",\r
"Sunucu özet fiş iptalini bilmiyor (eski sunucu sürümü). Sunucudaki kalemler beklemeye geri alınmadı; sunucunun yükseltilmesi gerekir.",\r
"Sunucu kullanılamıyor",\r
"Sunucuya ulaşılamıyor — yeniden alım yapılmadı.",\r
"Sunucuya ulaşılamıyor. Kasa dosyaları kuyrukta bekliyor ve bağlantı kurulduğunda gönderilir.{0}",\r
"Sunucuya erişilemiyor. Talimat sonuçları gönderilmeyi bekliyor.",\r
"Sunucu ayarlanmamış.",\r
"sunucu sertifika göndermedi",\r
"Sunucu kabul etmedi",\r
"Sunucu bu kasadan gelen bir değişikliği kabul etmedi: {0}",\r
"Sunucu fiyatlı hiçbir ürün döndürmedi. Katalog değiştirilmedi.",\r
"Sunucu reddetti",\r
"Sunucu değişikliği reddetti",\r
"Sunucu değişikliği reddetti: {0}",\r
"Sunucu bu kasayı farklı bir işaretle ({0}) yönetiyor, kasa ise şimdi {1} olarak çalışıyor; bu nedenle sunucu kasanın dosyalarını (fiyat değişiklikleri, kapanışlar) reddediyor. Kasanın yeniden eşleştirilmesi (Ayarlar → Sunucu: \\"Bağlantıyı kes\\", ardından yeni kodla \\"Eşleştir\\") veya yayıncıdan işaret değişikliği istenmesi (Destek → Talep) gerekir.",\r
"Sunucu bu kasayı farklı bir kodla yönetiyor.",\r
"Garson telefonu sunucusu açık değil — tablet bağlanamaz.",\r
"Güncelleme sunucusu hatayla yanıt verdi (HTTP {0}).",\r
"Güncelleme sunucusuna ulaşılamıyor ({0}).",\r
"Güncelleme sunucusuna ulaşılamıyor. Ağ bağlantısı olmayabilir.",\r
"Fiş sunucusu — ERPNext (eski, isteğe bağlı)",\r
"Telefonlar için sunucu başlatılamadı: {0}",\r
"Sunucu, adres {1}.\\n\\nSertifika parmak izi (CA):\\n{2}\\n\\nParmak izi, mağazadaki bilgisayarda IRIS Server programının \\"Genel bakış\\" ekranındaki parmak iziyle karşılaştırılmalıdır. Eşleştirmeden sonra kasa yalnızca bu CA'nın sertifikasını kabul eder.",\r
"SERVICE",\r
"Vergi İdaresi servisi şu anda çalışmıyor. Gönderim otomatik olarak tekrarlanır.",\r
"servis talimatları: yürütülen {0}, hata {1}",\r
"SET",\r
"{0} ile {1} arasında sezonluk duraklama. Program yalnızca verileri okumak ve dışa aktarmak için çalışır.",\r
"Kayıtlı ikameti olan mevsimlik işçi",\r
"SHA-256",\r
"show",\r
"Kod",\r
"kod",\r
"Kod",\r
"Kod {0} · fiyat {1} (fiyat, listede fiyata dokunularak değiştirilir).",\r
"kod {0} · KDV {1} %{2}{3}",\r
"kod {0}{1}",\r
"kod {0}{1} · {2} · KDV {3} %{4}",\r
"Kod {0}{1}{2}",\r
"Kod / barkod (ör. 3*7613…)",\r
"Kod / barkod / adın bir kısmı",\r
"sifra = ?",\r
"Ürün kodu zorunludur.",\r
"bon kodu",\r
"Bon kodu",\r
"Kod boşluk içermemelidir.",\r
"Kod bulunamadı. Arama sonuçları gösteriliyor.",\r
"sifra, naziv, cijena, pdv_stopa, jm, grupa, podgrupa, svoja, cijena_vrijeme, cijena_utc, grupa_id, proizvodjac, neto, neto_jm, pakovanje, max_zaliha",\r
"SIGNAL",\r
"SIJALIC",\r
"Senkronize ediliyor…",\r
"sentetik",\r
"Sentetik",\r
"SIR",\r
"SIRCE",\r
"SIRĆE",\r
"Rulo genişliği",\r
"Ham yazdırma başarısız oldu: {0}",\r
"gri",\r
"Tarayın — menü ve sipariş",\r
"Son kullanma tarihi geçmiş ürün okutuldu: {0} (son kullanma {1}{2})",\r
"Yazdırmadan bekleme listesinden kaldır (etiketler zaten raflarda)",\r
"1 kaldır",\r
"Masadan bir adet kaldırılsın mı?",\r
"Konaklamayı kısalt",\r
"Bir gece kısalt",\r
"SLADOLED",\r
"SLANINA",\r
"Günlük gönderimi programın bu sürümünde desteklenmiyor.",\r
"Gönderim kapatıldı. Kasa deneme modunda çalışıyor.",\r
"Gönderim kapalı. \\"Fişleri Vergi İdaresi'ne gönder\\" seçeneğinin etkinleştirilip ayarların kaydedilmesi gerekir.",\r
"Gönderim tamamlandı.",\r
"Vergi İdaresi'ne gönderim ayarlanmamış.",\r
"Vergi İdaresi'ne gönderim kapalı ve gönderilmemiş iletiler var. Gönderim Ayarlar → Mali onay bölümünden açılır.",\r
"Vergi İdaresi'ne gönderim kapalı Açmak için: Ayarlar → Fiskalizasyon → \\"Fişleri Vergi İdaresi'ne gönder\\", ardından \\"Kaydet\\".",\r
"Vergi İdaresi'ne gönderim açık, ancak kasa hazır değil: {0} Fiş düzenlenmedi. Nedenin giderilmesi (Ayarlar → Fiskalizasyon / Kasiyerler) veya gönderimin kapatılması gerekir.",\r
"Vergi İdaresi'ne gönderim hâlâ bekliyor ({0}). Her şey gönderilene kadar deneme ortamına geçilemez.",\r
"Vergi İdaresi'ne gönderim ayarlanmamış.",\r
"Vergi İdaresi'ne gönderim açık değil.",\r
"Vergi İdaresi'ne gönderiliyor…",\r
"Bu programda görsel gönderme desteklenmiyor.",\r
"Görsel gönderiliyor…",\r
"Teknik hataların yayıncıya gönderilmesi kapalı (Ayarlar → Destek ve hatalar).",\r
"teknik hataların gönderimi kapalı (Ayarlar → Destek ve hatalar)",\r
"Tatlılar",\r
"SLATKO",\r
"SLAUF",\r
"Görme engelli / sağır-dilsiz kişi, otizmli kişi",\r
"Kör hasılat sayımı (kasiyer beklenen tutarı görmez)",\r
"Kör sayım: kasada ne kadar olması gerektiğini sorumlu ve kapanış (Z) görür.",\r
"Kör sayım: sayılan nakit aşağıya girilir. Beklenen bakiye ve fark kapanıştan sonra görünür; yönetici bunları öncesinde de görür.",\r
"görsel",\r
"Resim {0} × {1} pikselden küçük.",\r
"Görüntü aktarım sırasında bozuldu.",\r
"Görsel gönderildi. Değişiklik henüz kaydedilmedi.",\r
"Görüntü boş.",\r
"Görsel çok büyük ve yeterince küçültülemiyor.",\r
"Görüntü {0} KB'tan büyük.",\r
"Resim PNG, JPEG veya WebP biçiminde olmalıdır.",\r
"Görsel mevcut değil",\r
"Görsel bulunamadı.",\r
"Ekteki görüntü PNG veya JPEG data-URL (base64) olmalıdır.",\r
"Yenilenebilir reçete ile bir sonraki verilişi {0} tarihinden itibaren mümkündür.",\r
"Sonraki gün",\r
"Bir sonraki fiş, bir fazla numara alır.",\r
"SLJIVOVICA",\r
"ŠLJIVOVICA",\r
"izinli",\r
"Serbest avans",\r
"Serbest avans {0} EUR ödemelere sayıldı.",\r
"Boş",\r
"Boş, temiz",\r
"boş oda",\r
"Dönemde bu türde boş oda sayısı: {0}.",\r
"Boş",\r
"small",\r
"SMASH",\r
"SMINK",\r
"ŠMINK",\r
"SMIRNOFF",\r
"Vardiya",\r
"Vardiya #{0}",\r
"Vardiya #{0} açıldı (kasa avansı {1}).{2}",\r
"Vardiya #{0} kapatıldı (Z).",\r
"Vardiya #{0} kapatılıyor ve bundan sonra değiştirilemez.",\r
"Vardiya hâlâ açık. Ara rapor (X) \\"Vardiya\\" altındadır.",\r
"Vardiya {0} tarihinde açıldı ve {1} fiş içeriyor ({2}).\\n\\nBugünkü satıştan önce kapanış (Z) gerekir: hasılat kapanış gününe yazılır, bu nedenle önceki günün cirosu bugünün tarihi altına kaydedilirdi.",\r
"Vardiya açık ve fişler içeriyor. Başka bir kasa yalnızca vardiya kapanışından (Z) sonra seçilebilir.",\r
"Vardiya açık ve fişleri var. Kasa değişikliği ancak vardiya kapanışından (Z) sonra mümkündür.",\r
"Vardiya açık ve fişleri var. Kasa kodunun (ENU) değiştirilmesi ancak vardiya kapanışından (Z) sonra mümkündür.",\r
"Vardiya açık. Vardiya kapanışı (Z) gerekir.",\r
"Vardiya zaten açık ve fişleri var. Açılış kasa avansı değiştirilmedi.",\r
"Vardiya bulunamadı.",\r
"Önceki günün vardiyası",\r
"vardiya açık",\r
"Vardiya bu arada değişti. Güncel durum gösteriliyor.",\r
"Vardiyada zaten fişler var. Açılış kasa avansı değiştirilemez; fark para girişi veya çıkışı olarak kaydedilir.",\r
"vardiya: {0} · {1}",\r
"Vardiyalar",\r
"Konaklama",\r
"Konaklama (KDV dahil)",\r
"Konaklamayı ödeyen",\r
"SMOKI",\r
"SMOOTHIE",\r
"SMRZNUT",\r
"Dondurulmuş ürünler",\r
"dondurulmuş",\r
"SNICKERS",\r
"veritabanı anlık görüntüsü tam okunmadı ({0} / {1} bayt)",\r
"veritabanı anlık görüntüsü tam olarak yazılmadı",\r
"veritabanı anlık görüntüsü başlatılmadı",\r
"Başlangıçta veritabanı anlık görüntüsü alınamadı ({0}). Fişler günlükte kayıtlı. Cihazda yer açın.",\r
"Veritabanı kaydedilemedi: {0}",\r
"SO",\r
"Oda",\r
"oda {0}",\r
"Oda {0}",\r
"Oda {0} — {1}",\r
"Oda {0} — {1}{2}",\r
"Oda {0} — bu dönemde dolu",\r
"Oda {0} · {1}\\nOdaya ödeme yapılabilir. Tutar {2}.",\r
"Oda {0} · {1}: odaya yazdırma reddedildi. {2}",\r
"{0} numaralı oda dolu değil.",\r
"Oda {0}: {1}.",\r
"Oda {0}{1}",\r
"Oda bu dönemde dolu: {0}",\r
"Oda dolu: {0}",\r
"Oda temiz olarak işaretlenmedi.",\r
"{0} kodlu bir oda zaten mevcut.",\r
"temizlenecek oda",\r
"Odalar",\r
"Temizlenecek odalar",\r
"odalar, rezervasyonlar, misafirler, oda hesabı, avans ve tahsilat",\r
"Odalar: toplam {0}, dolu {1}, boş {2}, temizlenecek {3}, kullanım dışı {4}.",\r
"SOBRANIE",\r
"SODA BIKARB",\r
"Soya",\r
"SOK",\r
"SOMERSBY",\r
"Firmanın kendi alan adı: {0}",\r
"Kendi alan adı: girilmemiş.",\r
"SOS",\r
"SPAGET",\r
"ŠPAGET",\r
"birleştirme",\r
"span",\r
"Hizmet şartnamesi ve sertifika, FZO tarafından sözleşmeli eczaneye verilir.",\r
"Etiket listesi boş.",\r
"Listede {0} ürün var; fiş rulosu uzun olacak.\\nDaha kısa bir liste için dönemin veya aramanın daraltılması gerekir.",\r
"Liste boş. Ürünler barkod, kod veya adın bir kısmıyla eklenir.",\r
"Proforma listesi",\r
"Kat",\r
"Kat {0}",\r
"Öğrenim",\r
"hazır",\r
"Hazır: {0}",\r
"SPRITE",\r
"SPUMANTE",\r
"Çar",\r
"Çarşamba",\r
"Sırpça (Kiril)",\r
"ST",\r
"Misafir iptal ettiğinde ödenen avansa ne olacağı.",\r
"Neyin tahsil edildiği",\r
"Sabit alanlar",\r
"Yazdırma",\r
"Yazdırma bekliyor: yazıcı seçim penceresi açık. Sonraki belgeler, bu pencere kapatıldıktan sonra sırayla yazdırılır.",\r
"Yazdırma kesildi — bilgisayarın belleği bu belge için yetmedi. Kasayı kapatıp yeniden başlatın (o zamana kadar yazdırma çalışmaz); uzun raporu parçalar halinde yazdırın.",\r
"Yazdırma bu cihazda kullanılamıyor.",\r
"Yazdırma başarısız: {0}",\r
"Zayi edilen malın ürüne göre yazdırılması",\r
"Son fişi yazdır",\r
"Ürüne göre cironun yazdırılması",\r
"Yazıcı",\r
"Yazıcı",\r
"\\"{0}\\" yazıcısı ham işi (ESC/POS) kabul etmiyor — ağ modunu veya başka bir yazıcı seçin.",\r
"\\"{0}\\" yazıcısı Windows'ta bulunamadı (tam adı Ayarlar'dan kontrol edin).",\r
"\\"{0}\\" yazıcısı tüm verileri almadı — bağlantıyı ve kâğıdı kontrol edin.",\r
"\\"{0}\\" yazıcısı Windows'ta bulunamadı. Ayarlar'dan (Fiş ve yazdırma) bir yazıcı seçin.",\r
"{0}:{1} yazıcısı yanıt vermiyor.",\r
"Yazıcı {0}:{1}: {2}",\r
"Çekmece yazıcısı",\r
"Yazıcı hazır.",\r
"Yazıcı seçilmedi (her yazdırmada seçim). Her tahsilattan sonra kasadan odağı alan bir yazıcı seçim penceresi açılır; belgeler sırayla, yalnızca önceki pencere kapatıldığında yazdırılır. Bu pencere olmadan yazdırmak için bir yazıcı veya \\"Varsayılan yazıcı (Windows)\\" seçin.",\r
"Yazıcı durum bildirmedi.",\r
"yazıcı 60 saniye içinde yanıt vermedi",\r
"Sipariş fişi yazıcısı (mutfak)",\r
"Bar yazıcısı",\r
"Yazdır",\r
"Etiketi yazdır",\r
"Tahsilattan hemen sonra yazdır",\r
"yazdırma reddedildi",\r
"Yazdırıldı",\r
"Standard Buying",\r
"Bakiye",\r
"Kasa durumu",\r
"gün başı bakiyesi",\r
"Rezervasyon durumu",\r
"Gönderim durumu okunamıyor:",\r
"Gönderim durumu okunamıyor: {0}",\r
"STAPIC",\r
"ŠTAPIĆ",\r
"Eski",\r
"stara_svoja INTEGER",\r
"Eski kod",\r
"IRIS adresli eski QR kodları çalışmaya devam eder.",\r
"Daha eski (amir)…",\r
"STARK",\r
"ŠTARK",\r
"STAROPRAMEN",\r
"StartPagePrinter(h); int w; bool ok = WritePrinter(h, b, b.Length, out w); EndPagePrinter(h); EndDocPrinter(h);",\r
"Durum",\r
"status = 'obrisan'",\r
"status = 'otvoren'",\r
"Sertifika durumu bilinmiyor.",\r
"Beklemeye al",\r
"Masa {0}'a koy",\r
"kalem",\r
"kalem {0}",\r
"{0} kalemi (\\"{1}\\"): {2} tutarı, miktar × fiyattan ({3}) büyük.",\r
"{0}. kalem, {1} ürünü değil.",\r
"{0}. kalem bu fişte yok.",\r
"Kalem {0}{1}",\r
"Kalem silindi.",\r
"Kalem iptal edildi.",\r
"Kalem zaten mutfağa / bara gönderildi. Silmeyi şef onaylar: şefin PIN'i ve bir gerekçe gereklidir.",\r
"Kalem mutfağa / bara zaten gönderildi. Kaldırmayı şef onaylar (PIN ve neden); mutfağa İPTAL gider.",\r
"kalemler",\r
"Kalemler",\r
"Kalemleri beklemeye al (müşteri para getirmeye gidiyor)",\r
"Sipariş kalemleri masadan kaldırılır; gönderilmiş kalemler için mutfağa / bara iptal gönderilir.",\r
"Kalemler beklemede (Bekleyenler → Ekrana geri getir).",\r
"Kalemler başka bir fişle zaten tahsil edildi. Bu fiş iptal edilmelidir.",\r
"Ödemeden önce kaldırılan kalemler ({0})",\r
"Tahsilattan önce fişten kaldırılan kalemler (kalemin kaldırılması veya miktarın azaltılması); ardından fiş düzenlendi. Her silme kaydedilir: kim, ne zaman, ne, ne kadar.",\r
"kalem",\r
"Kalem",\r
"STELLA",\r
"Muhasebe'den bir fiyat listesi geldi. Bunun hangi kasa olduğunun seçilmesi gerekir.",\r
"gelen",\r
"STIKS",\r
"ŠTIPALJK",\r
"Masa",\r
"\\"{0}\\" masası yok. Masalar kasada girilir (Ayarlar → Yiyecek-içecek).",\r
"masa {0}",\r
"Masa {0}",\r
"masa {0} ({1})",\r
"Masa {0} beklemede.",\r
"{0} numaralı masa boş.",\r
"Masa {0}, {1} masasına taşındı.",\r
"{0} numaralı masa devralındı.",\r
"{0} numaralı masa boş.",\r
"Masa {0}, masa {1} ile birleştirildi.",\r
"{0} numaralı masa şu anda kasada açık. Kasiyer masayı bıraktığında değişiklik yapılabilir.",\r
"{0} numaralı masayı {1} yönetiyor. Masa devralınabilir.",\r
"{0} numaralı masayı {1} yönetiyor. Birleştirmek için önce o masanın devralınması gerekir.",\r
"Masa {0}: misafir siparişi iptal etti (QR menü). Masa kasada açık; kalemler masaya dönüldüğünde kaldırılır (Masaya).",\r
"Masa {0}: misafir siparişi iptal etti (QR menü).{1}",\r
"Masa {0}: misafir hesabı istiyor ({1}).",\r
"Masa {0}: misafir hesabı istiyor.",\r
"Masa {0}: misafir garsonu çağırıyor.",\r
"Masa {0}: misafir siparişinin sipariş fişi yazdırılmadı. Yazıcı kullanılamıyor.",\r
"Masa {0}: misafirin siparişi (QR menü) bekliyor. Masa kasada açık; sipariş, masaya dönüldüğünde eklenir (Masaya).",\r
"Masa {0}: misafir siparişi (QR menü), kalem: {1}, tutar {2} €.{3}",\r
"Masa {0}: misafirin siparişi reddedildi ({1}).",\r
"Masa {0}: misafirin siparişi işlenmedi ({1}).",\r
"Masa {0}: iptal fişi (misafir siparişi iptal edildi) yazdırılmadı.",\r
"Masa {0}: iptal yazdırılmadı ({1}). Mutfağın / barın bilgilendirilmesi gerekiyor.",\r
"Masa {0}: gönderilmiş kalemin iptali ({1}).",\r
"Masa {0}{1}",\r
"Masa ekranda. Önce beklemeye geri alınması gerekir (\\"Masaya\\").",\r
"Masa kasada açık (ödeme). Telefondan değişiklik yapılamaz.",\r
"Masa boş.",\r
"Masa bu arada kapatıldı.",\r
"Masa kasada zaten kapatılmış — garsonu çağırın.",\r
"Masa seçilmedi (\\"Masalar\\" düğmesi).",\r
"sto TEXT",\r
"Masa artık kasada yok — garsonu çağırın.",\r
"Masaya bakan",\r
"STOCK",\r
"masa menüde, siparişler bu kasaya gelir",\r
"Masalar",\r
"Masalar (adlar, virgülle ayrılmış)",\r
"Masalar (garson)",\r
"Masalar farklı olmalıdır.",\r
"Masalar girilmedi (Ayarlar → Yiyecek-içecek, örn. \\"1, 2, 3, Bar\\").",\r
"Masalar girilmemiş (Ayarlar → Yiyecek-içecek).",\r
"Masaları salonda durdukları yere sürükleyin. Masa görünümü onları bu düzene göre gösterir.",\r
"Masalar ızgara olarak gösterilir.",\r
"Masalar: ekranda masa, taşıma, hesabı bölme",\r
"Oran",\r
"Avans fişindeki oran",\r
"Yiyecek oranı",\r
"Konaklamayla birlikte yiyecek oranı (%)",\r
"İptal ücreti oranı",\r
"Konaklama oranı",\r
"KDV oranı (%)",\r
"Avans fişinde KDV oranı (%)",\r
"İptal ücretinde KDV oranı (%)",\r
"konaklama oranı",\r
"İptaller",\r
"iptaller {0}",\r
"İptal et",\r
"Fişi iptal et…",\r
"iptal edildi",\r
"İptal edildi",\r
"İptal edilenler",\r
"stornirao_uid TEXT",\r
"iptal",\r
"İptal",\r
"İptal ({0})",\r
"Otel belgesinin iptali IKOF olmadan düzenlenemez (fiskalizasyon açık değil veya sertifika yok). İptal yapılmadı.",\r
"iptal fişi",\r
"İptal fişi",\r
"İptal fişi iptal edilemez.",\r
"Fişin iptali",\r
"{0} fişinin iptali",\r
"{0}{1} fişinin iptali",\r
"İptal edilen fiş no.",\r
"Kasada fiş iptali",\r
"Reçeteli fişin iptali bir neden gerektirir (ör. verme hatası).",\r
"Fiş iptali: karta iade",\r
"Kalem iptali",\r
"ÖZET FİŞ İPTALİ — DÜZELTME ÖZET FİŞİ",\r
"Özet fiş iptalinin tutarı negatif olmalıdır (özetteki fişler eksi işaretli).",\r
"Özet fiş iptali IKOF olmadan düzenlenemez (fiskalizasyon açık değil veya sertifika yok). İptal yapılmadı.",\r
"storno_uid TEXT",\r
"iptal, silmeler, yüksek indirimler, çekmece, nakit, farklar; yalnızca şef",\r
"İptal, geçersiz kılma, silme, büyük indirimler, fişsiz çekmece, limiti aşan nakit, kapanışta fark. Sahip aynı uyarıları Yönetici'de görür.",\r
"Yabancı",\r
"Yabancı misafir",\r
"STREČ",\r
"strong",\r
"STRONGBOW",\r
"elektrik",\r
"Cmt",\r
"Cumartesi",\r
"SUDZUK",\r
"SUDŽUK",\r
"özet fiş",\r
"ÖZET FİŞ",\r
"özet fiş {0}{1}",\r
"Özet fiş bir müşteri adına düzenlenmiş, ancak fişlerden bazıları o müşteriye düzenlenmemiş.",\r
"Özet fiş zaten iptal edilmiş.",\r
"Özet fiş, atıfta bulunduğu fişleri belirtmelidir (her birinin IKOF, zaman ve tutarı).",\r
"Özet fiş, atıfta bulunduğu fişleri belirtmelidir.",\r
"Özet fişte ücret olamaz: tek tek fişler dışında ciro yoktur.",\r
"Özet fişte indirim olamaz.",\r
"Özet fiş kalem taşımaz: ciro zaten tek tek fişlerdedir.",\r
"Özet fişte IKOF yok, bu nedenle iptal düzenlenemez.",\r
"Özet fişin fiş listesi yok.",\r
"Özet fişte oranlara göre toplamlar yok.",\r
"Özet fiş, ertelenmiş ödemeyi (ORDER) değil, gerçek ödeme yöntemini taşır.",\r
"Özet fiş, ertelenmiş ödemeyi değil, gerçek ödeme yöntemini taşır.",\r
"Avanstan ödenen özet fiş kasada iptal edilmez: avans kullanılmış olarak kalır. İptal yapılmadı.",\r
"Havale ile ödenen özet fiş bir müşteri adına düzenlenir, oysa oda harcaması bu müşteri olmadan düzenlenmiş. Oda harcamasını başka bir yöntemle veya ayrıca tahsil edin. Hiçbir şey düzenlenmedi.",\r
"Özet fiş en fazla 1000 fişe atıfta bulunabilir (verilen: {0}). Birden fazla özet fiş düzenlenmelidir.",\r
"Özet fiş en fazla 1000 fişe atıfta bulunabilir.",\r
"Özet fiş, \\"Fiş iptali\\" yoluyla iptal edilir (düzeltme özet fişi).",\r
"Özet fiş: aynı KDV oranı iki kez belirtilmiş.",\r
"Özet fiş: %{0} oranı, listedekinden daha fazla fişte belirtilmiş.",\r
"Özet fiş: tek tek fişlerin toplamı ({0}) oranlara göre toplama ({1}) eşit değil.",\r
"Kükürt dioksit ve sülfitler",\r
"SUNCOKRET",\r
"SUNĐER",\r
"SUNDJER",\r
"SUNKA",\r
"ŠUNKA",\r
"SUPA",\r
"Susam",\r
"sv-SE",\r
"tümü",\r
"Bu fişteki tüm mallar zaten iade edildi.",\r
"Her değişiklik bu satış noktası için fiyat değişikliği olarak kaydedilir ve Muhasebe'ye gönderilir.",\r
"Listedeki her ürün, fiyatı ve kg / l fiyatı olan bir etikettir.",\r
"Listedeki her ürün, fiyatı ve kg / l fiyatı olan bir etikettir.{0}",\r
"Fişsiz her açma kaydedilir (kim, ne zaman, neden) ve sahip bunu uyarılarda görür.",\r
"Her satış noktasının kendi fiyatları vardır. Bu cihazın bulunduğu kasayı seçin veya kasa listede yoksa \\"Bu kasa bu noktada\\"yı seçin. O noktanın fiyatları yüklenir.",\r
"Her satış noktasının kendi fiyatları vardır. Bu cihazın bulunduğu kasayı seçin veya kasa listede yoksa \\"Bu kasa bu noktada\\"yı seçin. O noktanın fiyatları yüklenir.{0}",\r
"tümü",\r
"Tümü",\r
"Tümü ({0} EUR)",\r
"Tüm gruplar",\r
"Hepsi tek bir toplu fişte",\r
"Tüm odalar temiz.",\r
"Masanın tüm kalemleri zaten gönderildi. Sipariş fişi için yeni kalem yok.",\r
"tüm kalemler kaldırıldı",\r
"Tüm kalemler kaldırıldı",\r
"tüm masalar ({0})",\r
"tüm türler",\r
"Tüm oda türleri",\r
"SVEĆ",\r
"SVESK",\r
"tümü",\r
"Tümü",\r
"Tüm menü ürünleri mevcut.",\r
"tüm kasiyerler",\r
"\\"{0}\\" içindeki tümü",\r
"SVIJEĆ",\r
"SVINJ",\r
"kendi",\r
"Şimdi eşitle",\r
"Senkronizasyon: gönderildi {0}{1}, sırada {2}",\r
"synced",\r
"sayfa",\r
"sayfa",\r
"Tablo kaydedildi: {0}",\r
"elektronik etiketler için tablo ve terazi ürünleri (PLU)",\r
"Oda panosu",\r
"table",\r
"Yerel ağ üzerinden tablet",\r
"tam tutar",\r
"üstüne",\r
"Tam",\r
"Bu proforma zaten ekranda.",\r
"bu fiş iptal edildi",\r
"Bu fiş zaten ekranda.",\r
"Bu fiş zaten geri getirilip tahsil edildi.",\r
"Mali fişte vergi",\r
"Fiş dışında tahsil edilen vergi, fişteki gerçek ödemelerden fazla.",\r
"Vergi tesisin geliri değildir; belediyeye ödenir.",\r
"Vergi, KDV matrahına dahildir",\r
"taksa.bezTaksePoslijeNoci",\r
"taksa.danIzvjestaja",\r
"taksa.djecaDo",\r
"taksa.exOznaka",\r
"taksa.rokUplateDana",\r
"taksa.umanjenjeProc",\r
"taksa.umanjenoDo",\r
"taksa.uOsnoviciPdv",\r
"TANQUERAY",\r
"tbody",\r
"td",\r
"TEA",\r
"TECHNICALERROR",\r
"Gönderilmeyi bekleyen teknik hatalar",\r
"gönderilmeyi bekleyen teknik hata: {0}",\r
"TEKILA",\r
"Yanıt metni zorunludur.",\r
"Mesaj metni zorunludur.",\r
"tel.",\r
"Telefon",\r
"\\"{0}\\" telefonunun bağlantısı kesildi.",\r
"\\"{0}\\" telefonu artık sipariş gönderemez; tekrar çalışması için yeniden eşleştirilmesi gerekir. Telefonun bağlantısı kesilsin mi?",\r
"Telefon \\"{0}\\" kasası ile eşleştirildi.",\r
"Telefon eşleştirildi.",\r
"Garson telefonu",\r
"Garson telefonu fiş düzenlemez: garson üzerinde masa seçer ve siparişleri işletmedeki ana kasaya (Wi-Fi üzerinden) gönderir; ana kasa siparişi yazdırır ve fişi düzenler. Eşleştirme ana kasada yapılır (Ayarlar → Garson telefonları → \\"Telefonu eşleştir\\"). Devam edilsin mi?",\r
"Garson telefonu yalnızca Android'de çalışır.",\r
"Telefon işletmenin Wi-Fi ağında olmalıdır. Garson daha sonra adı ve PIN'i ile giriş yapar (Ayarlar → Kasiyerler).",\r
"Telefon bu kasayla eşleştirilmemiş veya bağlantısı kesilmiş. Yeniden eşleştirme gerekli.",\r
"Telefon siparişleri gönderir",\r
"telefon TEXT",\r
"Windows'taki kasa, garson telefonlarını Setup 1.4 veya daha yenisiyle kabul eder. Yeni bir Setup kurulmalıdır.",\r
"Garson telefonlarını yalnızca Windows'taki kasa kabul eder (Setup 1.4 veya daha yeni).",\r
"Garson telefonları (işletmenin Wi-Fi ağı üzerinden siparişler)",\r
"Telefonlar yalnızca \\"Yiyecek-içecek\\" modunda çalışır.",\r
"TEQUIL",\r
"TEQUILA",\r
"TEREA",\r
"termal rulo",\r
"Terminal farklı bir tutar onayladı ({1} yerine {0}).",\r
"Terminal hazır.",\r
"Terminal hazır. ({0})",\r
"Terminal başka bir işlemin yanıtını döndürdü.",\r
"Terminal meşgul.",\r
"Terminal yanıt vermiyor.",\r
"Terminal bu işlemi desteklemiyor.",\r
"Terminal kullanılamıyor: manuel onay öner",\r
"Terminal net",\r
"Terminal banka onayı almadı.",\r
"Terminal kullanılamıyor (deneme).",\r
"Terminal kullanılamıyor: {0}",\r
"Terminal kullanılamıyor. Karttan tahsilat yapılmadı.",\r
"Terminal sonuç bildirmedi (deneme).",\r
"Terminal {0} ödemesinin sonucunu bildirmedi ({1}). Karttan tahsilat yapılmış olabilir. Ödemenin onaylanıp onaylanmadığı terminalde veya slipte kontrol edilmelidir.\\n\\nSlipteki onay numarası (onaylandıysa):",\r
"Terminal {0} sn içinde sonuç bildirmedi.",\r
"Terminal sonuç bildirmedi. Sonuç terminalde kontrol edilmelidir.",\r
"Terminal isteği almadı.",\r
"Deneme terminali (cihazsız)",\r
"Deneme terminali hazır.",\r
"terminal: {0}",\r
"Terminal: {0}",\r
"Terminal: {0} işlem, {1}.",\r
"Terminal: onaylanan ({0})",\r
"terminal: satış {0}",\r
"TEST",\r
"text/html; charset=utf-8",\r
"text/plain; charset=utf-8",\r
"text/xml; charset=utf-8",\r
"textarea",\r
"Ağırlık",\r
"Ağırlık terazi aralığının dışında.",\r
"Ağırlık sabit değil. Terazinin durması beklenmelidir.",\r
"Tartılan ürünün ağırlığı kasaya bağlı teraziden okunur. Fişe yalnızca sabit ağırlık girer; kasiyer onaylar. Toledo 8217 (ve bu moddaki Dibal / CAS): komut \\"W\\"; CAS: terazi \\"ST,GS,…kg\\" satırını gönderir; genel: ağırlık içeren herhangi bir satır.",\r
"th",\r
"thead",\r
"İstek gövdesi geçerli değil.",\r
"TIN",\r
"Tür",\r
"Tür şunlardan biri olmalıdır: {0}.",\r
"Tivat",\r
"TJESTENIN",\r
"To",\r
"Bu zaten bu ürünün fiyatı.",\r
"Masadaki tüm kalemler bunlar. Masanın tamamı yalnızca kasada, bir gerekçeyle silinebilir (silme kaydı).",\r
"TOALET PAPIR",\r
"TOBLERON",\r
"Bu garson kasada yok (veya etkin değil).",\r
"Böyle bir silinmiş fiş yok.",\r
"Bu fiş artık beklemede değil.",\r
"token {0}:{1}",\r
"TOMATO SOS",\r
"TONIC",\r
"TONIK",\r
"TOPLJENI",\r
"TOST",\r
"tr",\r
"Süresiz lisans ({0}): sınırsız, tüm modüller",\r
"traka",\r
"Terminal işlemi bulunamadı.",\r
"Terminal işlemleri",\r
"TRAPIST",\r
"TRAVARICA",\r
"Ağda aranıyor…",\r
"yeni bir Setup'ın kurulmasını gerektiriyor . Programdan yükleme mümkün değil.",\r
"Ağda IRIS Server'ı ara",\r
"hesap istiyor",\r
"Ticaret (mağazalar, büfeler, dükkânlar)",\r
"TROLLI",\r
"Gider",\r
"dönemdeki işçilik maliyeti",\r
"Giderler",\r
"Üç harfli kod, ör. DEU.",\r
"Üç harfli kod, ör. MNE.",\r
"Üç harfli kod.",\r
"Hamile / 1 yıla kadar yeni anne",\r
"try { DI d = new DI(); d.n = \\"Kasa\\"; d.t = \\"RAW\\"; if (StartDocPrinter(h, 1, d) == 0) throw new Exception(\\"KASA_NE_PRIMA\\");",\r
"TUBORG",\r
"TUNA",\r
"Turizm örg.",\r
"Turistik villa",\r
"Turistik apartmanlar",\r
"Türkçe",\r
"Tuzi",\r
"TWIX",\r
"type=\\"password\\" inputmode=\\"numeric\\" maxlength=\\"8\\"",\r
"type=\\"text\\" inputmode=\\"decimal\\"",\r
"type=\\"text\\" inputmode=\\"decimal\\" class=\\"iznos\\"",\r
"Yazdırma penceresinde A4 yazıcı veya PDF olarak kaydetme seçilir.",\r
"Yazdırma penceresinde A4 yazıcı seçilmelidir (fiş yazıcısı rulo içindir).",\r
"Dosyada kodu, adı ve fiyatı olan hiçbir ürün yok. Katalog değiştirilmedi.",\r
"Dosyada RSA özel anahtarı yok. Anahtar içeren bir .pfx/.p12 dosyası gerekir (.cer değil).",\r
"Dosyada özel anahtarla eşleşen sertifika (X.509) yok.",\r
"Dokumenti\\\\Kasa klasöründe",\r
"Klasörde PIB {0} firmasının fiyat listesi yok, ancak PIB {1} için var. Bu kasa o firmaya aitse PIB ve adın değiştirilmesi gerekir (Ayarlar → Fişteki firma).",\r
"Kasada {0} € nakit var (limit {1} €) — fazlasını ayırın",\r
"Kasada {0} nakit var (limit {1}). Fazlalık ayrılmalıdır (Vardiya → Çekme).",\r
"Bu arada bir şey değişti (vardiya, bekleme, gönderim). Yeniden kontrol edilmesi gerekir.",\r
"tahsil ediliyor",\r
"Tesiste",\r
"Bu grupta ürün yok.",\r
"Bu vardiyada hiç fiş yok.",\r
"Bu pakette bu kasanın satış noktası (\\"{0}\\") yok. Fiyatlar değiştirilmedi.",\r
"Bu dönemde",\r
"Bu dönemde",\r
"Bu dönemde fiyat listesi en az {0} gece gerektirir.",\r
"Firmanın paketinde hiç satış noktası yok. Mağaza Muhasebe'de eklenir (Ayarlar → Mağazalar) ve kasalara yayımlanır (Kasa fiyat listesi → \\"Şimdi veri alışverişi yap\\" veya \\"Fiyat listesini dosyaya kaydet\\").",\r
"Pakette {0} sürümü var, ancak {1} isteniyor — paket kabul edilmiyor.",\r
"Pakette {0} satış noktası yok.",\r
"O satış noktası pakette yok.",\r
"İletide kontrol karakteri var (ileti bu programda oluşturulmamış).",\r
"Mesajda imza eksik.",\r
"Mesajda isteğin kendisi eksik.",\r
"Son {0} saatte",\r
"Tarayıcıda veri alışverişi klasörü yok.",\r
"Tarayıcıda veri alışverişi klasörü yok. Dosya elle içe aktarılır.",\r
"tamam",\r
"Tamam",\r
"Gönderim sırasında: {0}.",\r
"tamam: {0}",\r
"Listede {0} kodlu kasa yok.",\r
"Özet fişe yalnızca ertelenmiş ödemeli fişler (ve iptalleri) girer.",\r
"sürüyor / kesildi",\r
"Yiyecek-içecekte ekrandaki fiş bir masaya bağlıdır: \\"Sipariş\\" mutfağa / bara yalnızca henüz gönderilmemiş olanı yazdırır ve masayı beklemeye alır; ödemede olağan bir mali fiş düzenlenir. \\"Beklemeye al\\" ve \\"Bekleyenler\\" düğmeleri \\"Masaya\\" ve \\"Masalar\\" olur. Kalem notu (✎) sipariş fişinde yazdırılır.",\r
"Kullanımda",\r
"Windows'ta varsayılan yazıcı ayarlanmadı.",\r
"UBRUS",\r
"Okul gezisi katılımcısı",\r
"Paketi yükle",\r
"Dosyadan paket yükle…",\r
"Yeniden yükle",\r
"Sepete yükle",\r
"Yüklendi: {0} ürün ({1})",\r
"Yüklendi: {0} ürün, {1} barkod{3}",\r
"Bu noktanın fiyatları ( ) yükleniyor. Düzenlenmiş fişler değişmez.",\r
"Bu noktanın fiyatları ({0}) yükleniyor. Düzenlenmiş fişler değişmez.",\r
"Fiyatlar yükleniyor: {0}…",\r
"Fiyatlar yükleniyor…",\r
"Dosya yükleniyor…",\r
"Misafirler yükleniyor…",\r
"Garsonlar kasadan yükleniyor…",\r
"Paket yükleniyor",\r
"Hesap yükleniyor…",\r
"Masalar yükleniyor…",\r
"Yükleniyor…",\r
"Yiyecek-içecek",\r
"Yiyecek-içecek (kafe, restoran)",\r
"Yiyecek-içecek (kafeler, restoranlar)",\r
"Yiyecek-içecek (masalar, mutfak siparişi)",\r
"yerleşik sürüm",\r
"dahili Sunmi yazıcı",\r
"Dahili Sunmi yazıcı (üretici servisi)",\r
"uid TEXT",\r
"uid, radnja, barkod, sifra, sa_sifre, naziv, komada, vrijeme, vrijeme_utc, ko, kasir_id, izvor, uredjaj, enu, svoja, upijena, ponistava",\r
"uid, sifra, naziv, jm, pdv_stopa, barkod, stara, cijena, mjesto, enu, pj, vrijeme, ko, izvor, uredjaj, svoja",\r
"Kaldırmalar:",\r
"Sertifikanın kaldırılması",\r
"Bağlantının kaldırılması geri alınamaz. Barkod ürünle yeniden ilişkilendirilir.",\r
"açık",\r
"Açık",\r
"Açık: kasa, misafirin imzalayacağı bir slip yazdırır.",\r
"Açık: restoran ve bardaki kasalar tüketimi oda hesabına yazar.",\r
"Açık: yerel turizm örgütüne bildirim de takip edilir.",\r
"Açık: varıştan bir gün sonra giriş yapılmamış rezervasyon \\"Gelmedi\\" durumuna geçer.",\r
"Açık: vergi misafir başına hesaplanmaz.",\r
"Açık: vergiye konaklama oranı uygulanır.",\r
"Masalarda QR menüyü aç (bu kasa kendi işletmesinin siparişlerini alır)",\r
"3 kattan büyük değişiklikleri de dahil et",\r
"Bu seçenek açıldığında program ortak barkod kataloğuna şunları gönderir: barkod, ürün adı, birim ve KDV oranı. Fiyatlar, miktarlar, tedarikçiler ve firma bilgileri gönderilmez. Gönderilen veriler, bilinmeyen bir barkod girildiğinde ad önerisi için programın tüm kullanıcıları tarafından kullanılır. Seçenek istenildiği zaman kapatılabilir; daha önce gönderilen veriler katalogda kalır.",\r
"Kaldır",\r
"Barkodu kaldır",\r
"{0} barkodunu kaldır",\r
"Listeden kaldır",\r
"PIN'i kaldır",\r
"Sertifikayı kaldır",\r
"Görseli kaldır",\r
"{0} listeden kaldırılsın mı?\\nGirilen paket boyutları saklanmaya devam eder.",\r
"Kaldırılan kalemler",\r
"tahsilattan önce kaldırıldı",\r
"Tahsilattan önce kaldırıldı",\r
"zayi kaydından önce kaldırıldı",\r
"Zayiattan önce kaldırıldı",\r
"proformadan önce kaldırıldı",\r
"uklonjeno REAL",\r
"{0} numaralı masadan kaldırıldı{1}.",\r
"Ukraynaca",\r
"Toplam",\r
"TOPLAM",\r
"TOPLAM · indirim {0}{1}",\r
"TOPLAM · indirim geçerli değil",\r
"Toplam KDV",\r
"Toplam indirim",\r
"Ödenecek toplam",\r
"ul",\r
"Karadağ'a giriş",\r
"İndirim hakkı olmayan indirilecek KDV (\\"indirim hakkı yok\\" işaretli alımlar + elle ekleme)",\r
"Yurt içi mal ve hizmet alımlarında indirilecek KDV (tedarikçi faturaları + ekipman/giderler + yan giderler)",\r
"Ulcinj",\r
"ULJE",\r
"Rol",\r
"ULOSC",\r
"ULOŠC",\r
"UMAK",\r
"İndirimli tutar, yaşa kadar",\r
"İndirimli tutar, yaşa kadar (yıl)",\r
"İndirim (%)",\r
"Yukarıdaki yaş sınırına kadar olan misafirler için indirim.",\r
"İndirim: 0 ile 100 % arasında",\r
"İndirimli",\r
"Barkodları gir",\r
"UNIMPLEMENTED",\r
"UNIONPAY",\r
"giriş",\r
"Giriş",\r
"Miktar girişi",\r
"Yeni ürün girişi iptal edilmez. Ürün \\"artık satılmıyor\\" olarak işaretlenebilir.",\r
"Tesis girişi",\r
"PIN girişi",\r
"Sayılan nakit tutarı girilir.",\r
"UPALJAC",\r
"UPALJAČ",\r
"eşleştirildi",\r
"\\"{0}\\" telefonu eşleştirildi.",\r
"eşleştirildi",\r
"eşleştirilmiş kasa",\r
"Eşleştirilmiş kasa ve gönderilmemiş siparişler telefondan silinir. Tekrar çalışmak için kasadaki QR kodu ile yeni bir eşleştirme gerekir.",\r
"Eşleştirilmiş Bluetooth cihazları…",\r
"Eşleştirilenler: {0}",\r
"Eşleştir",\r
"Telefon eşleştir…",\r
"Eşleştirme başarısız: QR kodu bu kasaya ait değil.",\r
"Kasa ile eşleştiriliyor…",\r
"Sunucuyla eşleştirme",\r
"Garson telefonunu eşleştirme",\r
"UPC-A",\r
"upijena TEXT",\r
"Diske yazma mümkün değil; veri kaydedilmedi. {0} Bir dakika sonra yeniden denenebilir.",\r
"Diske yazma başarısız oldu; veri kaydedilmedi. ({0})",\r
"Sunucuya kayıt bekliyor: {0}",\r
"Tesis kaydediliyor…",\r
"Ürünün paket boyutunu girme",\r
"Kalan tutarı girin",\r
"Önceki belgelerin sunucuya kaydı hâlâ bağlantı bekliyor. {0}, kayıt tamamlandığında.",\r
"Ekranda bir fiş girişi devam ediyor.",\r
"Ekranda bir fiş girişi devam ediyor. Silinen fiş geri getirilmedi.",\r
"Ekrandaki fişin kaydı sürüyor. Proforma yüklenmedi.",\r
"Fiş kaydediliyor…",\r
"Odalar kaydediliyor…",\r
"Gelen klasörüne yazma kesildi.",\r
"Yeni bir PIN girildi ve \\"PIN'i kaldır\\" da işaretlendi. Bu ikisinden yalnızca biri geçerlidir.",\r
"Girilen yazılım kodu başka bir üreticiye ait. Bu kasanın yazılım kodu gereklidir.",\r
"Girilen misafir: {0} / {1}.{2}",\r
"elle girildi",\r
"Giren: {0} · {1}{2}{3}",\r
"Kaydet",\r
"Para girişini kaydet",\r
"Para çıkışını kaydet",\r
"Rezervasyonu gir",\r
"Gecelik fiyatı girin.",\r
"Misafirin adını ve soyadını girin.",\r
"Rezervasyon sahibinin adını girin.",\r
"Aynı alan adını buraya girin ve kaydedin. Sunucu sertifikayı (https) ilk açılışta kendisi oluşturur — en fazla 1 dakika.",\r
"Avans tutarını girin.",\r
"Tesis adını girin.",\r
"Her oda türünün adını girin.",\r
"Hizmet açıklamasını girin.",\r
"Oda kodlarını girin.",\r
"Oda kodunu girin.",\r
"Nedeni girin.",\r
"Girin: {0}.",\r
"KDV'siz vergi kalemine yazılır.",\r
"Talep",\r
"Talep (odayı tutmaz)",\r
"Talepler",\r
"Talepler, onaylananlar, tesiste olanlar",\r
"Ödenen avans oda hesabından iade edilir (Avansı iade et).",\r
"Ödenen",\r
"Ödeme",\r
"Ödemeler",\r
"Uyarılar",\r
"Sahip için uyarılar",\r
"Son kullanma öncesi uyarı (gün)",\r
"Kaplıca veya iklim tedavisine sevk edilmiş",\r
"Cihaz",\r
"{0}:{1} cihazı yanıt vermiyor.",\r
"Cihaz {0}:{1}: {2}",\r
"Cihaz yeniden kasa olarak çalışacak (kasa seçimi, fişler).",\r
"Cihaz bağlantıyı kapattı.",\r
"Kasa cihazları",\r
"USB (OTG kablosu)",\r
"USB (OTG)",\r
"USB yazıcı (Android, OTG kablosu)",\r
"using System; using System.Runtime.InteropServices;",\r
"Bozuk para / para üstü",\r
"Hizmet oda hesabına eklendi.",\r
"Hizmetler",\r
"Hizmetler (BT, ajanslar, danışmanlık, servisler, kiralama)",\r
"Sal",\r
"Salı",\r
"İletinin UUID'si geçerli değil: \\"{0}\\".",\r
"Fiyatları / kataloğu dosyadan içe aktar…",\r
"Fiyat değişikliklerini dosyadan içe aktar…",\r
"Anahtarı içe aktar (PEM)…",\r
"Ayarları dosyadan içe aktar (config.json)…",\r
"Sertifikayı içe aktar",\r
"Sertifikayı içe aktar (.pfx)…",\r
"Fiyatların / kataloğun içe aktarılması",\r
"Katalog içe aktarma",\r
"Mali fiş no.",\r
"Mali fiş no. {0}",\r
"Net miktar birimiyle birlikte miktar da girilir.",\r
"Net miktarla birlikte birim de seçilir (net birim).",\r
"Net miktarla birlikte birim de girilir (KG, G, L, ML, M veya KOM).",\r
"zayiat ile",\r
"fiş ile",\r
"Her kalem için iade edilen miktar girilir (boş = iade edilmez). Düzeltme fişi yalnızca iade edilen malı kapsar; indirimler orantılı olarak hesaplanır. Para ödendiği şekilde iade edilir: havale → havale ile (kasadan nakit verilmez), yalnızca kart → kartla, aksi halde nakit.",\r
"VAFL",\r
"Tartı",\r
"terazi / dahili",\r
"Terazi ağırlık göndermedi.",\r
"Terazi: {0}",\r
"Terazi: {0} kg (sabit).",\r
"Terazi: {0} kg = {1}",\r
"Para birimi",\r
"Mali fişin dışında (çıktıda ayrı satır)",\r
"Çalışma saatleri dışı",\r
"Kullanım dışı",\r
"VANILIN",\r
"VARIKIN",\r
"VAT",\r
"Geçerlilik tarihi",\r
"{0} tarihine kadar geçerli",\r
"{0} tarihine kadar geçerli{1}",\r
"Fiyat listesinde o gün için dönem yoksa geçerlidir.",\r
"Geçerlilik başlangıcı",\r
"vazi_do TEXT",\r
"şimdiden {0} sa",\r
"{0} numaralı fiş zaten düzenlendi. Sayaç geriye alınamaz.",\r
"{0} numaralı fiş zaten düzenlendi. Sayacı geri almak mümkün değil.",\r
"3 kattan büyük (işaretli)",\r
"Vegan",\r
"VEGETA",\r
"Vejetaryen",\r
"büyük",\r
"Büyük miktar",\r
"Büyük değişiklik: {0} → {1}. Onaylamak için \\"Kaydet\\"e (Enter) bir kez daha basın.",\r
"Yüksek para üstü",\r
"VELO",\r
"VERMUT",\r
"Sürüm",\r
"sürüm {0}",\r
"{0} sürümü yüklendi. Kasanın kapatılıp yeniden açılması gerekir.",\r
"{0} sürümü indirildi ve yüklendi.",\r
"{0} sürümü indirildi ve bir sonraki başlatmada uygulanır.",\r
"Sürüm {0} indirildi ve bir sonraki açılışta uygulanacak. Yeniden başlatmak için göstergeye tıklayın.",\r
"{0} sürümü indirildi ve doğrulandı.",\r
"Sürüm {0} indirildi. Kurmak için göstergeye tıklayın.",\r
"{0} sürümü zaten indirildi. Kasanın kapatılıp yeniden açılması gerekir.",\r
"{0} sürümü bu kasada başlatılamadı",\r
"{0} sürümü bu kasada başlamadı, bu nedenle önceki sürüme dönüldü. Bakım ekibiyle iletişime geçin.",\r
"{0} sürümü yeni bir Setup'ın kurulmasını gerektiriyor. Programdan yükleme mümkün değil.",\r
"Kurulum sürümü",\r
"Kasa kurulumunun sürümü bilinmiyor — güncelleme yapılamaz.",\r
"Çalışan sürüm",\r
"Bağlantı",\r
"{0} barkodunun bağlantısı geri alındı.",\r
"Bağlantı kotalı (mobil veri).",\r
"Bağlantı indirme sırasında kesildi.",\r
"Bağlantı zaten iptal edildi.",\r
"Bağlantı bulunamadı.",\r
"Bağlantı çalışıyor. Oturum açan kullanıcı: {0}",\r
"FZO bağlantısı",\r
"FZO servisi bağlantısı ayarlanmamış.",\r
"FZO servisi bağlantısı ayarlanmamış. Servis şartnamesini ve sertifikayı FZO sözleşmeli eczaneye sağlar.",\r
"Yayıncıyla bağlantı",\r
"Sunucuya bağlantı",\r
"Sunucu bağlantısı kesildi.",\r
"Sunucu bağlantısı yeniden kuruldu.",\r
"Sunucu bağlantısı kullanılamıyor. Yeniden deneniyor.",\r
"Sunucu bağlantısı ayarlanmadı.",\r
"Sunucu bağlantısı, kurulu bir kasada (Windows, Android) çalışır; tarayıcıda çalışmaz.",\r
"Terminal bağlantısı yanıttan önce kesildi.",\r
"Terminal bağlantısı kesildi: {0}",\r
"Terminal bağlantısı yeni kasa Setup'ı gerektirir (kabuk 2111).",\r
"Terminale bağlanılıyor…",\r
"Cihaz bağlantısı kesildi.",\r
"Cihaz bağlantısı açılmadı.",\r
"Cihaz bağlantısı uygulamanın yeni sürümünü gerektirir.",\r
"Bağlantı artık mevcut değil. İptal mümkün değil.",\r
"Barkod bağlantısını yalnızca yönetici geri alabilir. PIN'li bir yönetici girilmelidir (Ayarlar → Kasiyerler).",\r
"VICEROY",\r
"VILJAM",\r
"VILJAMOVKA",\r
"VINJAK",\r
"VINO",\r
"VIOLETA",\r
"Havale",\r
"Havale diğer ödeme yöntemleriyle birleştirilemez.",\r
"Havale aynı fişte nakit veya kartla birleştirilemez. İki fiş düzenlenmelidir.",\r
"Havale, aynı fişte nakit, kart, bono veya anlık transfer ile birleştirilemez.",\r
"VIRSL",\r
"VIRŠL",\r
"VISA",\r
"fazla",\r
"Daha fazla",\r
"Bu barkod birden fazla üründe var (aşağıdaki listeden seçin).",\r
"Birden fazla üründe bu barkod var. Ürün listeden seçilir.",\r
"Birden fazla ödeme yöntemi",\r
"Diğer ödeme yöntemleri · havale · not…",\r
"Artık katalogda yok: {0}",\r
"3 kattan fazla",\r
"VISKI",\r
"Vize",\r
"Vize geçerlilik tarihi",\r
"vjernost_naziv TEXT",\r
"vjernost_telefon TEXT",\r
"kendi",\r
"VLAZNE MARAM",\r
"VLAŽNE MARAM",\r
"VOĆNI JOG",\r
"VODA",\r
"VODKA",\r
"VOGUE",\r
"VOTKA",\r
"Misafire iade edilir",\r
"Süresi dolan indirimlerin geri alınması başarısız oldu: {0}",\r
"Süresi dolan indirimlerin geri alınması: {0}",\r
"{0} sürümüne geri dönmek mümkün değil. Veritabanı zaten {1} sürümüne uyarlandı ve eski sürümler onu güvenle kullanamaz.",\r
"Ürün verilerinin geri yüklenmesi başarısız oldu: {0}",\r
"Önceki sürümü geri yükleme",\r
"Barkod bağlantılarının geri yüklenmesi başarısız oldu: {0}",\r
"geri getirildi → fiş",\r
"geri getirildi → fiş{1}",\r
"Sürüm geri alındı",\r
"{0} sürümü geri alındı.",\r
"{0} sürümü geri yüklendi. Programın bir sonraki açılışında uygulanır.",\r
"{0} sürümü geri yüklendi. Program bir sonraki başlatıldığında uygulanır.{1}",\r
"iade edildi",\r
"İade edilen",\r
"iade edilen {0}",\r
"geri alınan şef değişikliği: {0}",\r
"{0} karta iade edildi.",\r
"Geri getirilip tahsil edilen:",\r
"vraceno TEXT",\r
"VRANAC",\r
"Geri al",\r
"Avansı iade et",\r
"Fiyatları geri yükle",\r
"Fiyatları firmanın son paketinden geri yükle",\r
"Ekrana geri getir",\r
"Ekrana geri getir ve tahsil et",\r
"Kasaya döndür",\r
"Önceki sürümü geri yükle",\r
"Kaydedilene dön",\r
"Kullanıma al",\r
"Cihazı kasa moduna döndür",\r
"{0} sürümü geri yüklensin mi? Veriler korunur. Değişiklik program yeniden başlatıldığında geçerli olur.",\r
"VREĆA ZA",\r
"Değer",\r
"Puan değeri (€)",\r
"Puanların değeri fiş tutarından büyük.",\r
"Zayi edilen malın değeri",\r
"Değişiklik değeri zorunludur (örn. 10 veya -5).",\r
"MAL DEĞERİ",\r
"Mal değeri:",\r
"Kaldırılanın değeri:",\r
"Onaylandı değerleri",\r
"Vazgeçildi değerleri",\r
"Saat",\r
"vrijeme >= ?",\r
"Olay zamanı cihaz saatinden ileride. Cihazın tarih ve saatini kontrol etmeniz gerekir.",\r
"Olay zamanı okunamıyor.",\r
"Giriş saati şimdi kaydedilir; misafir bildirim süresi bu saatten itibaren işler.",\r
"Avans fişinin düzenlenme zamanı geçerli değil.",\r
"Düzenlenme zamanı 2026-07-31T07:01:00+02:00 biçiminde değil (verilen: \\"{0}\\").",\r
"Fişin düzenlenme zamanı gelecekte. Cihaz saatini kontrol etmeniz gerekir.",\r
"Fişin düzenlenme zamanı okunamıyor.",\r
"Fişteki zaman cihaz saatinden ileride. Cihazın tarih ve saatini kontrol etmeniz gerekir.",\r
"Cihaz saati Vergi İdaresi saatinden izin verilenden (6 saat) fazla farklı veya gelecekte. Cihazda doğru tarih ve saati ayarlamanız gerekir.",\r
"Depozito değişiklik zamanı Vergi İdaresi saatinden izin verilenden fazla farklı. Cihaz saatini ayarlamanız veya bildirimi sonradan gönderim olarak göndermeniz gerekir.",\r
"Rezervasyon saati geçerli değil (örn. 19:30).",\r
"Gönderim zamanı 2026-07-31T07:01:00+02:00 biçiminde değil (verilen: \\"{0}\\").",\r
"vrijeme_utc TEXT",\r
"vrijeme_z TEXT",\r
"Tür",\r
"Tür (Muhasebe'den)",\r
"Kimlik türü TIN (PIB/JMB) olmalıdır.",\r
"Belge türü",\r
"Kasa türü Muhasebe'den gelen verilerde belirtilmemiş.",\r
"Tesis türü",\r
"Reçete türü geçerli değil.",\r
"tür seçilir",\r
"Görüntü türü geçersiz.",\r
"Oda türü",\r
"Terminal türü",\r
"İstek gövdesi türü desteklenmiyor.",\r
"Terazi türü",\r
"Vize türü",\r
"Oda türleri",\r
"Kasa türünü (mağaza veya kiosk) Muhasebe belirler (Kasa fiyat listesi → Kasalar ve mağazalar). Yanlış tür Muhasebe'de düzeltilir; o zamana kadar şef bunu Ayarlar → Kasa bölümünden değiştirebilir.",\r
"warn",\r
"WC",\r
"WEBP",\r
"WELLNESS",\r
"WHERE {0}",\r
"WHERE aktivan=1",\r
"WHERE kod LIKE ?",\r
"WHERE svoja = 1",\r
"WHISK",\r
"WHISKEY",\r
"WHISKY",\r
"Windows",\r
"Windows tajne.json dosyasının kilidini açamıyor — başka bir Windows hesabı tarafından veya başka bir bilgisayarda kilitlenmiş",\r
"Windows yazıcısı (ham)",\r
"Windows yazıcısı yalnızca Windows'ta bulunur.",\r
"Windows şu anda tajne.json dosyasının kilidini açamıyor — şifreleme kullanılamıyor",\r
"WINSTON",\r
"Wolt, Glovo, Telefon",\r
"Wolt, Glovo, telefon; sipariş numaralı masa olarak",\r
"YIPPY",\r
"Z (vardiya kapatıldı)",\r
"Açık vardiya olmadan Z",\r
"\\"{0}\\" için (satır {1}) en fazla {2} iade edilebilir (fişte {3}, zaten iade edilen {4}).",\r
"\\"{0}\\" için en fazla {1} iade edilebilir.",\r
"{0} ürünü için en fazla {1} iade edilebilir (fişte {2}, zaten iade edilen {3}).",\r
"Temizlenecek",\r
"Doğrudan yazdırma ve para çekmecesi için kasanın yeni bir Setup'ı gerekir (1.5).",\r
"Kurulum için bu programdan kurulumuna izin verilmelidir (telefon ayarları → Bilinmeyen uygulamaları yükle), ardından tekrar \\"Şimdi yükle\\" seçilmelidir.",\r
"Verilecekler",\r
"Bu yıl başka bir programda çalışmış kasa için o programın düzenlediği son fiş numarası girilir; numaralandırma bundan devam eder.",\r
"Bu yıl başka bir programda çalışmış kasa için o programın son fiş numarası girilir; numaralandırma bundan devam eder.",\r
"Ödenecek",\r
"Tahsil edilecek: {0} EUR",\r
"Eğitim ve deneme için, firmasız: ürünler elle eklenir (⋯ Daha fazla → Ürünler ve fiyatlar). Firma daha sonra Ayarlar → Kasa bölümünde bağlanır.",\r
"{0} belediyesi için vergi tutarı {1} EUR.",\r
"Bu gün için",\r
"Bu gün için rezervasyon yok.",\r
"Kasa bu yazıcının kâğıt durumunu okuyamıyor.",\r
"Bu terminal türü için kasa tutar göndermez (Ayarlar → Kasa cihazları).",\r
"Firmanın tüm cihazları (kasalar, Muhasebe, Yönetici) sunucuyla eşleştirilene kadarki dönem için: kasa dosyalarını klasöre de yazar, fiyat listesini ve değişiklikleri de oradan okur. Tüm cihazlar eşleştirildiğinde geçiş modu kapatılır ve klasör yalnızca yedek için kullanılır. Yapılandırılmış bir klasör gerekir.",\r
"Havale ile ödeme için müşteri (PIB ve ad) girilmelidir.",\r
"Bildirim için eksik: {0}.",\r
"Firmaya fiş için; havale için zorunludur. Gerçek kişi: PIB yerine JMBG veya kimlik belgesi numarası.",\r
"\\"Diğer\\" nedeni için not zorunludur.",\r
"\\"{0}\\" kalemi için ertelenmiş ödemeli fişin verileri eksik (başka bir kasada düzenlenmiş).",\r
"Sertifika içe aktarmak için firmanın PIB numarası gerekir (Ayarlar → Fiskalizasyon).",\r
"{0} sürümü için önce yeni kasa Setup'ı ({1} veya daha yeni) kurulmalıdır. Bu bilgisayardaki Setup {2}. Kasa verileri korunur.",\r
"{0} sürümü için önce yeni kasa Setup'ı kurulmalıdır. Bu bilgisayardaki Setup {2}. Kasa verileri korunur.",\r
"Havale için müşteri (PIB ve ad) girilmelidir.",\r
"Değiştirme için hastanın onayı gerekir.",\r
"Žabljak",\r
"Unut",\r
"Kasayı unut",\r
"Unutulan PIN",\r
"ZACIN",\r
"ZAČIN",\r
"Son denetim",\r
"Son alışveriş",\r
"Son",\r
"Son fişler",\r
"Alıkonulan avans iptal ücreti olarak hesaplanır.",\r
"Alıkonulan kısım iptal ücretidir",\r
"şu anda içindeki ürünleri ve fiyatları korur",\r
"Koru",\r
"Fiş için tut",\r
"Borçlandırılan",\r
"Borçlandırılan {0} EUR · ödenen {1} EUR · bakiye {2} EUR",\r
"İstek tekrarlandı (reddedildi).",\r
"Talep yayıncıya gönderildi.",\r
"İstek çok büyük.",\r
"İstek zaten imzalanmış.",\r
"Yerel sunucuya yapılan istek bir https adresi ve CA parmak izi gerektirir.",\r
"İstek geçerli değil.",\r
"İstek terminale gönderilmedi: {0}",\r
"talep: {0}",\r
"Talepler",\r
"Firma talepleri",\r
"Bu kasadan gönderilen talepler",\r
"Zamanlanmış fiyatlar",\r
"Fiyat listesindeki zamanlanmış fiyatlar kaydedilmedi: {0}",\r
"Kapanış",\r
"kapanış (Z)",\r
"Kapanış {0}",\r
"Gün sonu (deneme).",\r
"Gün sonu terminalde yapıldı.",\r
"Terminalde gün sonu",\r
"Gün sonu terminalde yapılır (Concert bunu kasaya aktarmaz).",\r
"Vardiya kapanışı (Z)",\r
"parola ile korunuyor",\r
"Kapanışlar klasöre yazılmadı: {0}",\r
"kapatıldı",\r
"Kapatıldı",\r
"Kapat",\r
"Vardiyayı kapat (Z)…",\r
"Değiştir",\r
"Kataloğu değiştir",\r
"Değişim",\r
"Değiştirme (özel reçete: yalnızca reçetedeki ilaç yoksa ve hasta kabul ediyorsa)",\r
"Değiştirme yalnızca reçete edilen ilaç bulunmadığında yapılabilir.",\r
"Değiştirme yalnızca aynı etken madde, form ve dozdaki bir ilaçla yapılabilir.",\r
"Reçete edilen ilacın FZO hesabına değiştirilmesine izin verilmez.",\r
"şunun yerine",\r
"{0} yerine",\r
"ZAMRZNUT",\r
"Yuvarlama",\r
"kasa seçilene kadar hatırlanıyor",\r
"kayıtlı parmak izi bir CA sertifikasının parmak izi değil",\r
"{0} kaydı yazılmadı ({1})",\r
"Proforma kaydı okunamıyor.",\r
"Kayıt, fişten kaldırılmış kalemleri içeriyor. Bunlar ekrana fiş olarak geri getirilemez.",\r
"kasa kapatılırken bulundu",\r
"Kapatıldı",\r
"Kapat",\r
"Programı kapat",\r
"dolu",\r
"Dolu (gerçekleşen)",\r
"Toplam",\r
"Ödemeler toplamı ({0}) fiş tutarından ({1}) az.",\r
"Ödemeler toplamı ({0}) fiş tutarından ({1}) fazla ve fazlası nakitten iade edilemez.",\r
"Ödemeler toplamı ({0}) ödenecek tutardan ({1}) fazla.",\r
"Ödemeler toplamı ({0}) yetersiz: {1} EUR eksik.",\r
"Ödemeler toplamı ({0}) avans tutarına ({1}) eşit değil.",\r
"Ödemelerin toplamı ({0}) fiş tutarına ({1}) eşit değil.",\r
"Ödemeler toplamı ({0}) özet fiş tutarına ({1}) eşit değil.",\r
"Ödemeler toplamı ({0}), tahsil edilecek tutara ({1}) eşit değil.",\r
"Gösterilenlerin toplamı",\r
"Fişlerin toplamı sıfır veya daha az. Özet fiş gerekmez.",\r
"ŽELE",\r
"ZEMICK",\r
"ZEMIČK",\r
"kadın",\r
"Zeta",\r
"ZEWA",\r
"ZILAVK",\r
"ŽILAVK",\r
"ZILET",\r
"ŽILET",\r
"çok parçalı ZIP veya ZIP64",\r
"Anlık ödemeler için firmanın banka hesabı",\r
"Gluten içeren tahıllar",\r
"ZLATNA DUNJA",\r
"ZLATNA SLJIVA",\r
"ZLATNA ŠLJIVA",\r
"amblem",\r
"Amblem",\r
"Firma logosu",\r
"Amblem kare olmalıdır (kenar farkı en fazla 10 %).",\r
"Bölge henüz tanınmadı.",\r
"ZVAK",\r
"ŽVAK",\r
"ZYN",\r
"Yeni sürümün yayını yayıncı imzası doğrulamasından geçemedi. Güncelleme indirilmedi.",\r
"Yeni sürümün yayınında yayıncı imzası yok. Güncelleme indirilmedi.",\r
"Geçerli sürümlere ilişkin veriler yayıncı imzası doğrulamasından geçemedi. Güncelleme indirilmedi.",\r
"Geçerli sürümlere ilişkin verilerin süresi doldu, bu nedenle güncellemeler şu anda doğrulanamıyor. Denetim kendiliğinden tekrarlanır.",\r
"{0} sürümü geri çekildi. Sonraki sürüm bekleniyor.",\r
"Yayınlanan {0} sürümü, daha önce yayınlanan {1} sürümünden eski. Güncelleme indirilmedi.",\r
"güncelleme denetimi",\r
"güncelleme akışı: yayın biçimi geçersiz",\r
"güncelleme akışı: yayın imzası geçersiz",\r
"güncelleme akışı: imzalı yayın başka bir program için düzenlenmiş",\r
"güncelleme akışı: imzasız yayın",\r
"güncelleme akışı: durum imzası geçersiz",\r
"güncelleme akışı: durum başka bir program için düzenlenmiş",\r
"güncelleme akışı: durumun süresi doldu",\r
"güncelleme akışı: durum son kabul edilenden eski",\r
"güncelleme akışı: durumsuz yayın",\r
"güncelleme akışı: yayın daha önce imzalanandan düşük",\r
"· vardiya başında veya sonunda",\r
"(son {0} / {1})",\r
"(fiş:",\r
"{0}\\n\\nMüşteri {1} yaşında veya daha büyük olmalıdır. Kimlikteki doğum tarihi (zorunlu değil):",\r
"{0} sa · 48 saatlik süreye kalan: {1} sa",\r
"{0}: {1} (100 fişte {2}; diğer kasiyerler {3})",\r
"{0}: {1} (100 fişte {2})",\r
"🌙 İş gününe göre ciro",\r
"📶 İnternetsiz çalışma",\r
"🛡 Kasiyere göre istisnalar",\r
"Ürün eklenmedi: doğum tarihine göre müşteri {0} yaşında.",\r
"Program güncellemesi, destek, Fon e-reçetesi",\r
"İnternetsiz",\r
"Başka kasada satılan çek, veri alışverişi ulaştıktan sonra burada geçerli olur.",\r
"ödeme öncesi silmeler",\r
"bağlantı bekliyor",\r
"Fiyatlar, ürünler, barkodlar, kampanyalar",\r
"COALESCE(NULLIF(r.kasir, ''), '{0}')",\r
"Doğum tarihi geçerli değil. Gün.ay.yıl olarak girin, örneğin 15.03.2008.",\r
"Olaylar",\r
"Olaylar{0}",\r
"Aynı bilgisayarda ikinci pencere.",\r
"Müşteri ekranı",\r
"Dosyalar kuyrukta bekler ve bağlantı geri geldiğinde kendiliğinden gönderilir.",\r
"fişsiz çekmece",\r
"Fişsiz çekmece",\r
"Çekmece fişsiz açıldı — {0}",\r
"Misafir internet üzerinden sipariş verir; garson telefonlarından siparişler çalışır.",\r
"sa · 48 saatlik süreye kalan:",\r
"Fiş düzenleme (nakit, kart, havale)",\r
"İşaretlenen kasiyer:",\r
"Kasiyere göre istisnalar",\r
"Takvim günü",\r
"Takvim günü {0} (fiş: {1})",\r
"Kasa internetsiz de satış yapar: veriler cihazdadır; Vergi İdaresine ve ofise gidenler kuyrukta bekler ve bağlantı geri geldiğinde kendiliğinden gönderilir.",\r
"Kasa, lisansta yazan gün sayısı kadar bağlantısız çalışır; sonrasında sunucuya bağlanması gerekir.",\r
"Katalog kasadadır. Ofisten yeni fiyatlar bağlantı geri geldiğinde ulaşır.",\r
"Düzeltme fişi kasada düzenlenir ve her fiş gibi sonradan gönderilir.",\r
"En eski bekleyen",\r
"Bu dönemde fiş veya olay yok.",\r
"etkin değil",\r
"Hiçbir kasiyer diğerlerinden sapmıyor.",\r
"Bunun gece yarısından sonrası (fiş:",\r
"Bunun gece yarısından sonrası (fiş: {0})",\r
"Satışı reddet",\r
"Vergi İdaresince reddedildi (Ayarlar’da inceleme gerekir)",\r
"Banka terminalinde kartla ödeme",\r
"Hediye çekleri ve sadakat puanları",\r
"İndirimler (fiş:",\r
"İndirimler (fiş: {0})",\r
"Karşılaştırma",\r
"Fişten ürün iadesi",\r
"İadeler",\r
"gece yarısından sonra çalışan işyeri için özet; yalnızca yönetici",\r
"Gece yarısından sonra çalışan işyeri için özet: fişler iş gününün başlangıcından ertesi günün aynı saatine kadar toplanır. Fiş tarihi, mali veriler, vardiyalar, kapanışlar (Z) ve günlük rapor değişmez.",\r
"Vergi İdaresine depozito bildirimi aynı kuyrukta bekler.",\r
"İş gününe göre ciro",\r
"Lisans kontrolü",\r
"Yaş kontrolü",\r
"Yaş kontrolü: satış onaylanmadı — {0}",\r
"Masalarda QR menü (misafir siparişleri)",\r
"r.datum >= ? AND r.datum < ?",\r
"Fiş, IKOF ve QR kodunu kasada alır; Vergi İdaresine sonradan gönderilir.",\r
"Fiş ödeme öncesi silindi",\r
"Fişler kuyrukta bekler ve bağlantı geri geldiğinde kendiliğinden gönderilir; iletim süresi düzenlemeden itibaren 48 saattir.",\r
"Vergi İdaresine gönderilmeyi bekleyen fiş ve bildirimler",\r
"İşyerinin yerel ağı üzerinden, internetsiz çalışır.",\r
"çalışır",\r
"İş günü",\r
"İş günü {0}: {1} – {2} {3}",\r
"İş günü başlangıcı",\r
"İş günü gece yarısı başlar, bu nedenle takvim günüyle aynıdır.",\r
"Muhasebe ve Yönetici ile veri alışverişi (kapanışlar, canlı ciro, fiyatlar)",\r
"elle indirimler: cironun % {0}",\r
"elle indirimler: cironun % {0} (diğer kasiyerler % {1})",\r
"Vergi İdaresine gönderim",\r
"Fişlerin Vergi İdaresine gönderimi",\r
"Vardiya: depozito, para çekme, ara rapor (X), kapanış (Z)",\r
"kasanın bağlantısız neler yaptığı ve şu anda neyin gönderilmeyi beklediği",\r
"Fiş, etiket ve rapor yazdırma",\r
"Yazıcı kasaya veya yerel ağa bağlıdır.",\r
"Şu anki durum",\r
"Yaş",\r
"Yaş: onaylanmadı",\r
"Kalemler ödeme öncesi kaldırıldı",\r
"Masalar, mutfak siparişi, garson telefonları, mutfak ekranı",\r
"iptaller ve iadeler",\r
"vardiya başında veya sonunda iptal ve iadeler: {0}",\r
"İptaller, iadeler, ödeme öncesi silmeler, fişsiz çekmece açmalar, elle indirimler ve onaylanmayan yaş kontrolleri; işlemi yapan kasiyere göre. Bir kasiyer, en az üç böyle olayı olduğunda ve diğer kasiyerlerin iki katı sıklıkta olduğunda işaretlenir. İşaret bir kontrol uyarısıdır, kanıt değildir.",\r
"kasiyere göre iptaller, iadeler, silmeler, fişsiz çekmece, elle indirimler ve yaş kontrolleri; yalnızca yönetici",\r
"İptaller: {0}",\r
"İptal, ürün iadesi, \\"İptal et\\"",\r
"SUMMARY",\r
"Terminalin kendi bağlantısı vardır; kasa yalnızca ödeme şeklini kaydeder.",\r
"Bağlantı gerektirir; bağlantı geri geldiğinde devam eder.",\r
"bağlantı gerekir",\r
"Cihazın ağ bağlantısı",\r
"zorunlu değil",\r
"Kasadan tedarikçi ödemesi",\r
"Bankaya yatırma",\r
"Hasılat teslimi",\r
"Küçük gider",\r
"Bozuk para / takviye",\r
"\\"Diğer\\" nedeni seçildiğinde not zorunludur.",\r
"Çekilen paranın iadesi",\r
"— neden seçin —",\r
"Ürün eklenmedi: yaş kontrolü tamamlanmadı.",\r
"Tarih gelecekte. Hâlâ {0} gösteriliyor.",\r
"Dönem, seçilen tarihe kadarki son {0} güne kısaltıldı.",\r
"Veri alışverişi kontrolü sürüyor. Sonuç, biter bitmez gösterilecek.",\r
"Neden seçilmedi. Listeden bir neden seçin.",\r
"Veri alışverişi kontrol edildi.{0}",\r
"Sonraki gün gelecekte.",\r
"Veri alışverişi kontrol edildi.",\r
"; önünde: {0}",\r
"; adımlar: {0}",\r
"{0} {1} ms",\r
"kuyruk bekleniyor",\r
"0,00 € tutarında fiş kes",\r
"veritabanı dışa aktarımı ({0} KB)",\r
"veritabanı dışa aktarımı (yedek kopya)",\r
"toplu değişiklik + anlık kayıt",\r
"Para kasadan nakit olarak iade edilir.",\r
"Para karta iade edilir (kasadan nakit çıkmaz).",\r
"Para banka havalesiyle iade edilir (kasadan nakit çıkmaz).",\r
"yeni günlük",\r
"“{0}” bildirimi kapatıldı. Okutulan ürün fişe ekleniyor.",\r
"Bildirim kapatıldı. Okutulan ürün fişe ekleniyor.",\r
"İndirim malın değerine eşit olduğundan fiş tutarı 0,00 €.\\n\\nTutarsız fiş yalnızca mal gerçekten bedelsiz verildiğinde kesilir. Aksi halde indirimin düzeltilmesi gerekir.",\r
"yazma hazırlığı",\r
"veritabanı denetimi",\r
"Fiş birden fazla yöntemle ödenmiştir. İade tutarının tamamı kasadan nakit olarak ödenir.",\r
"0,00 € tutarında fiş",\r
"0,00 € tutarında fiş (indirim malın değerine eşit)",\r
"günlük satırı diske",\r
"veritabanı anlık kaydı",\r
"veritabanı anlık kaydı (gerekirse)",\r
"veritabanı anlık kaydı (otomatik)",\r
"anlık kayıt diske",\r
"yavaş yazma: {0} — {1} ms bekledi, {2} ms sürdü{3}{4}",\r
"yazma (işlem)",\r
"Her kalem için iade edilen miktar girilir (boş = iade edilmez). Düzeltme fişi yalnızca iade edilen malı kapsar; indirimler orantılı olarak hesaplanır.",\r
", Vergi Dairesi test sistemi (TEST)",\r
", giren: {0}",\r
": aylık poşet raporu için \\"poşet\\" ürün kodları (virgülle), ayın 5'ine kadar (Daha fazla → Plastik poşetler). Ürün kataloğundaki \\"Plastik poşetler (ücret)\\" grubundaki ürünler burada girilmeden de sayılır.",\r
". Ara rapor (X) ve günlük / dönemsel rapor vardiya penceresinde ve fiş listesindedir.",\r
". Başka (önceki) bir sertifikayla veya başka bir kasada imzalanan fiş farklı IKOF verir.",\r
". Fişler kalır (telefon ve ad olmadan). Muhasebedeki kaydı Muhasebe siler (talep kasa kapanışlarıyla gider). Silme geri alınamaz.",\r
". Müşteri yeniden onay verene kadar sadakat kullanılmaz.",\r
"· gün: {0}",\r
"· tütün indirimsiz",\r
"· işyeri kodu",\r
"· düzeltme:",\r
"· işyeri",\r
"· işyeri {0} · operatör {1}. Ara rapor (X) ve günlük / dönemsel rapor vardiya penceresinde ve fiş listesindedir.",\r
"· operatör",\r
"· toplam",\r
"( ), bildirim sürümü",\r
"(onaylayan {0})",\r
"(Yönetmelik, Karadağ Resmî Gazetesi 1/26).",\r
"(Kişisel Verilerin Korunması Kanunu, Karadağ Resmî Gazetesi 133/26): sadakat, müşterinin kayıtlı onayıyla kullanılır (ekranda ve kâğıtta bildirim); süreden uzun alışveriş yapmayan müşterinin verileri kendiliğinden silinir, fişler kalır. Görünüm: Daha fazla → Sadakat müşterileri — veri koruma.",\r
"{0} — adet",\r
"{0} Seçimdeki tütün ürünleri: {1}{2}.",\r
"{0} Yeni sertifika içe aktarılana kadar mali fiş kesilmez (Ayarlar → Mali kayıt → Sertifika içe aktar). Yeni sertifikayı yetkili sağlayıcı firmanın talebiyle verir.",\r
"{0} adet",\r
"{0} adet · {1}",\r
"{0}, Vergi Dairesinin verdiği biçimde değil (ab123cd456).",\r
"{0} Fiş kesilmedi.",\r
"{0} Sadakat kullanılmadan önce onay {1}.",\r
"{0}: onay {1} tarihinde geri alındı. Müşteri yeniden onay verene kadar sadakat kullanılmaz.\\n\\nYeni onay kaydedilsin mi?",\r
"📝 Ayar değişiklik günlüğü",\r
"🔎 IKOF kontrolü",\r
"🔐 Sadakat müşterileri — veri koruma",\r
"🖨 Raporu yazdır",\r
"🖨 Bildirimi yazdır",\r
"🧾 Müfettiş raporları",\r
"🛍 Plastik poşetler",\r
"🛍 Plastik poşetler (ücret)",\r
"Güncelleme adresi",\r
"apoteka.*",\r
"Ürün katalogda bulunamadı.",\r
"Plastik poşet olarak işaretli ürünler",\r
"Otomatik güncelleme",\r
"Nakit yok.",\r
"Müşteri onayı olmadan sadakat kullanılmaz.",\r
"silme (saklama süresi)",\r
"talep üzerine silme",\r
"Müşteri verilerinin silinmesini şef PIN ile onaylar. PIN doğru değil.",\r
"Sadakat müşterisi verilerini silme",\r
"Şu numara için onay, puanlar ve sadakat müşterisi silinir:",\r
"Kupür başına adet. Toplam \\"Sayılan nakit\\" alanına gider; döküm vardiyayla saklanır ve hasılatla yazdırılır.",\r
"{0} için adet geçerli değil (tam sayı, 0 veya daha fazla).",\r
"Fiş numarası (sıra numarası)",\r
"Fiş numarası (sıra numarası) sıfırdan büyük bir tam sayı olmalıdır.",\r
"Kupürlere göre nakit sayımı",\r
"Kupürlere göre sayım, hasılatla döküm",\r
"Vergi Dairesine gönderilmeyi bekliyor",\r
"Tütün ürününün fiyatı kasada değiştirilmez: fiyat listesindeki fiyatla satılır (Özel Tüketim Vergisi Kanunu, md. 50). Fiyat Muhasebede değiştirilir.",\r
"md. 17",\r
"md. 25",\r
"COALESCE(ko, '') <> '{0}'",\r
"date(r.datum) <= ?",\r
"date(r.datum) >= ?",\r
"Düzenleme tarihi ve saati",\r
"Düzenleme tarihi ve saati geçerli değil (ör. 21.11.2026 10:15:30 veya QR koddaki gibi).",\r
"GÜNLÜK TOPLAMLAR",\r
"Ayar değişiklik günlüğü",\r
"ELEKTRONİK GÜNLÜK",\r
"elektronik günlük, bağlantısız fişler, düzeltme fişleri, günlük toplamlar; yazdırma ve dosya (USB)",\r
"ENU",\r
"Talep kaydı",\r
"Dosya seçilen yere kaydedilir (Windows'ta USB'ye de); telefonda Belgeler/Kasa klasörüne. Her rapor ENU kodunu, işyeri kodunu ve operatörü taşır.",\r
"fiskal.*",\r
"Mali kayıt kapatıldı ({0}{1}){2}",\r
"Değişim klasörü",\r
"Nakit sınırı (€)",\r
"Hatalar yayıncıya",\r
"IKOF fişteki ile AYNI.",\r
"IKOF fişteki ile AYNI DEĞİL.",\r
"Fişteki IKOF (karşılaştırma için)",\r
"Mali kaydı kapatma (CANLI)",\r
"CANLI ortamda mali kaydı kapatmak şef PIN'i ve gerekçe gerektirir (Mali Kayıt Kanunu, md. 11). Kapatma kaydedilir ve sahibine bildirilir; mali kayıt kapalıyken kesilen fişlerde mali kayda alınmadıkları yazılır.",\r
"Kapatılan:",\r
"pasif müşterinin saklama süresi doldu",\r
"Ayar değişikliği: {0}",\r
"Fiş tutarı",\r
"Kalem tutarı",\r
"IKOF hesapla",\r
"Hesaplanan IKOF",\r
"Poşet sayısı raporu Çevre Koruma Ajansına {0} tarihine kadar verilir (Yönetmelik, Karadağ Resmî Gazetesi 1/26).",\r
"Rapor verildi",\r
"{0}.{1}. dönemi plastik poşet raporu {2}.{3}. tarihine kadar verilir: {4} adet (ücret {5} €). Rapor: ⋯ Daha fazla → Plastik poşetler.",\r
"{0}.{1}. raporu Ajansa verildi mi?",\r
"veri dışa aktarma",\r
"müşteriye veri dışa aktarma",\r
"kasa (otomatik)",\r
"Kasada imza anahtarı yok (Ayarlar → Mali kayıt).",\r
"Kasa CANLI ortamda çalışıyor. Mali kaydın kapatılması kaydedilir ve sahibine bildirilir; kapalıyken kesilen fişlerde \\"FİŞ MALİ KAYDA ALINMADI\\" yazar ve Vergi Dairesine bildirilmez.",\r
"CANLI ortamdaki kasa yalnızca PIN'li kayıtlı bir şefle çalışır (Ayarlar → Kasiyerler).",\r
"mali kayıt sertifikası anahtarı",\r
"kim, ne zaman, eski → yeni; yalnızca şef",\r
"ENU kodu",\r
"İşyeri kodu",\r
"Yazılım kodu programa gömülüdür (Mali Kayıt Kanunu, md. 15 f. 4) ve girilmez: CANLI",\r
"adet ·",\r
"Veri kopyası (dosya)…",\r
"Veri kopyası kaydedildi: {0}",\r
"düzeltme (mal iadesi)",\r
"düzeltme (iptal)",\r
"Düzeltilen fiş",\r
"Düzeltme",\r
"Müşteri vergi no",\r
"Sadakat müşterisi",\r
"Müşteriye bildirim verildi ve müşteri sadakat programı için veri işlenmesini onaylıyor.",\r
"lower(COALESCE(a.grupa, '')) LIKE '%kes%naknad%'",\r
"lower(COALESCE(a.grupa, '')) LIKE '%plasti%kes%'",\r
"lower(COALESCE(a.podgrupa, '')) LIKE '%kes%naknad%'",\r
"lower(COALESCE(a.podgrupa, '')) LIKE '%plasti%kes%'",\r
"Ay geçerli değil.",\r
"işyeri başına aylık adet toplamı, ayın 5'ine kadar rapor",\r
"Tütün ürünlerinde indirim, kampanya, puan ve hediye yasaktır (Tütün Ürünlerinin Kullanımını Sınırlama Kanunu, md. 12).",\r
"Onay yöntemi bilinmiyor.",\r
"50 µm'den kalın poşet başına 0,05 € ücret (Yönetmelik, Karadağ Resmî Gazetesi 1/26). Satıcı poşet sayısını her ay, önceki ay için ayın 5'ine kadar Çevre Koruma Ajansına bildirir. Poşet, aşağıda işaretli üründür (veya katalogdaki \\"Plastik poşetler (ücret)\\" grubunda).",\r
"Oluşturuldu",\r
"Firma adı",\r
"Dönemde ciro yok.",\r
"Kayıtlı değişiklik yok.",\r
"mali kayda alınmadı",\r
"mali kayda alınmadı (deneme modu)",\r
"İşaretli ürün yok.",\r
"İmzalanacak dizi",\r
"Yeni onay",\r
"ör. 1001, 1002",\r
"ör. arıza, sertifika değişimi",\r
"Müşteriye bildirim",\r
"Veri işleme bildirimi",\r
"{1} aydan uzun süredir alışveriş yapmayan {0} sadakat müşterisinin verileri silindi (saklama süresi, Ayarlar → Eklentiler). Fişler kalır.",\r
"Verileri sil",\r
"Müşteri verilerini sil (şef)…",\r
"Bundan sonra müşteri yeniden onay verene kadar bu numara için sadakat (indirim, puan) kullanılmaz. Veriler silinene veya süre dolana kadar kalır.",\r
"reddedildi (Vergi Dairesi)",\r
"onaylayan {0}",\r
"osjetljivo = 1",\r
"Muafiyet dayanağı",\r
"Dayanak: müşteri onayı. Onay gönüllüdür ve her an geri alınabilir; geri almadan önceki alışverişleri etkilemez.",\r
"Poşet olarak işaretle (şef)",\r
"KDV hesaplanmadı — KDV Kanunu {0}",\r
"KDV hesaplanmadı (oran %0)",\r
"Vergi no (mali kayıt)",\r
"Firma vergi no",\r
"Vergi numarası geçerli değil (8 hane; gerçek kişi için 13).",\r
"Vergi mükellefi vergi no",\r
"Şef PIN'i zorunludur.",\r
"Şef PIN'i doğru değil. {0}",\r
"İşyeri",\r
"Ödemeler",\r
"placeholder=\\"zorunlu değil\\"",\r
"placeholder=\\"ör. 21.11.2026 10:15:30\\"",\r
"Plastik poşetler",\r
"Plastik poşetler (ücret)",\r
"Plastik poşetler (kodlar)",\r
"Plastik poşetler {0}",\r
"Kupürlere göre…",\r
"Bu kasanın sadakat müşterisi hakkında sakladığı veriler (Kişisel Verilerin Korunması Kanunu, Karadağ Resmî Gazetesi 133/26, md. 16 ve 21).",\r
"{0} aydan uzun süredir alışveriş yapmayan müşterinin verileri kendiliğinden silinir (günde bir kez). Şu an: {1}.",\r
"Müşteri verileri silindi.",\r
"Veriler: telefon numarası, ad (müşteri verirse), programdaki alışverişler (tarih, tutar, indirim, puan).",\r
"Ayar",\r
"İptal şef gerektirir",\r
"Vergi: SERTİFİKA SÜRESİ DOLDU",\r
"İmza:",\r
"İmza: {0}. Başka (önceki) bir sertifikayla veya başka bir kasada imzalanan fiş farklı IKOF verir.",\r
"imzalı onay formu",\r
"müşteri ekranında müşteri onayı",\r
"onayın geri alınması",\r
"Onayın geri alınması",\r
"Onayı geri al",\r
"Müşteri hakları: verilere erişim ve kopya, düzeltme, silme, işlemenin kısıtlanması, taşınabilirlik ve itiraz. Talep kasada veya veri sorumlusuna yapılır.",\r
"Kupürlere göre sayılan: {0}. Döküm yazdırılsın mı?",\r
"Verildi",\r
"Verildi",\r
"CANLI ortamdan çıkış",\r
"CANLI ortamdan TEST'e geçiş",\r
"Denetim makamına şikâyet: Kişisel Verilerin Korunması ve Bilgiye Serbest Erişim Ajansı.",\r
"sadakat kullanılmadan önce.",\r
"kasa deneme anahtarı (Vergi Dairesi sertifikası olmadan)",\r
"Vergi Dairesi test sistemi (TEST)",\r
"Satıcı",\r
"Yaş kontrolü",\r
"r.vrsta = 'storno'",\r
"FİŞ MALİ KAYDA ALINMADI",\r
"Fişler mali kayıt ve muhasebe kurallarına göre saklanır; silmeden sonra telefon numarası ve ad üzerlerinde görünmez.",\r
"Gerekçe / onaylayan",\r
"Gerekçe zorunludur.",\r
"Saklama süresi",\r
"Pasif müşterinin saklama süresi (ay)",\r
"Saklama süresi ayarlı değil (Ayarlar → Eklentiler).",\r
"Saklama: onay sürdükçe, programdaki son alışverişten en fazla {0} ay.",\r
"Saklama: onay sürdükçe.",\r
"Rapor son tarihi",\r
"rulo",\r
"Şef olmadan manuel indirim (%)",\r
"Veri sorumlusu: {0}.",\r
"Dosyaya kaydet (CSV)…",\r
"Dosyaya kaydet (JSON)…",\r
"Sadakat programı için verilerimin işlenmesini onaylıyorum.",\r
"Onay",\r
"Onay verildi",\r
"Onay {0} tarihinde verildi ({1}), bildirim sürümü {2}{3}.",\r
"Onay geri alındı",\r
"Onay {0} tarihinde geri alındı. Müşteri yeniden onay verene kadar sadakat kullanılmaz.",\r
"Onay geri alındı.",\r
"Onay kaydedildi.",\r
"Onay zaten {0} tarihinde geri alındı.",\r
"Sadakat müşterisi onayı",\r
"onay, bildirim, veri kopyası, talep üzerine silme",\r
"Fişleri Vergi Dairesine gönder (sertifika kaldırma)",\r
"yalnızca hassas",\r
"GEREKMİYOR",\r
"gerekiyor",\r
"Mali kayıt sertifikasının süresi {0} tarihinde doluyor (kalan {1} {2}). Yeni sertifika zamanında alınıp içe aktarılmalıdır (Ayarlar → Mali kayıt). Süre dolduktan sonra kasa mali fiş kesmez.",\r
"Mali kayıt sertifikasının süresi {0} tarihinde doldu. Yeni sertifika içe aktarılana kadar mali fiş kesilmez (Ayarlar → Mali kayıt → Sertifika içe aktar).",\r
"Mali kayıt sertifikasının süresi {0} tarihinde doldu. Yeni sertifika içe aktarılana kadar kasa mali fiş kesmez (Ayarlar → Mali kayıt → Sertifika içe aktar). Yeni sertifikayı yetkili sağlayıcı (CoreIT) firmanın talebiyle verir.",\r
"ürün kodu veya barkodu",\r
"\\"Poşet\\" ürün kodları",\r
"Kör sayım",\r
"Nakit dökümü",\r
"st.sifra IN ({0})",\r
"Ödemeden sonra yazdır",\r
"Eski",\r
"KDV oranı",\r
"Kasa ayarlarındaki her değişiklik: kim, ne zaman, eski → yeni. Hassas değişiklikler (mali kayıt, kodlar, indirim ve uyarı sınırları) sahibine uyarı olarak da gider (Yönetici).",\r
"Amaç: sadakat programı — sadakat müşterisine indirim ve alışverişlerde puan.",\r
"müşteri telefonu",\r
"Ay içinde hiç poşet satılmadı.",\r
"Dönemde böyle fiş yok.",\r
"Toplam fiş tutarı (€)",\r
"Toplam fiş tutarı geçerli değil.",\r
"TOPLAM · indirim {0}{1}{2}",\r
"Toplam: {0}",\r
"Kaydedildi.",\r
"Onayı kaydet",\r
"Onayı kaydet…",\r
"Toplamı gir",\r
"Uyarı: silme (€)",\r
"Uyarı: indirim (%)",\r
"Uyarı: fark (€)",\r
"sözlü, ekranda / kâğıtta bildirimden sonra",\r
"Sadakat yalnızca müşteri onayıyla",\r
"Sadakat: saklama süresi (ay)",\r
"Sadakat: onay zorunlu",\r
"Puan değeri, indirim uygulanan malların tutarından büyük (tütün ürünlerinde indirim ve puan yoktur).",\r
"Bu numara için kayıtlı onay yok.",\r
"Bu numara için onay kaydı yok.",\r
"Vergi müfettişi için (Mali kayıt işlevsel şartnamesi, \\"ENU'da IKOF doğrulama\\"): IKOF, fiş parametrelerinden ve bu kasanın dijital imzasından yeniden hesaplanır. Aynı parametreler her zaman aynı IKOF'u verir.",\r
"vergi müfettişi için: fiş parametrelerinden IKOF ve fişle karşılaştırma",\r
"müşteri talebi",\r
"Kişisel Verilerin Korunması Kanunu (Karadağ Resmî Gazetesi 133/26, 19.03.2027'den itibaren): kanıtlanabilir onay, müşteriye bildirim, onayın geri alınması, veri kopyası ve talep üzerine silme. Fişler kalır; silmeden sonra telefon numarası ve ad üzerlerinde görünmez.",\r
"Kişisel Verilerin Korunması Kanunu (Karadağ Resmî Gazetesi 133/26). Bildirim sürümü: {0}.",\r
"Sadakat müşterisi veri koruma",\r
"DÜZELTME FİŞLERİ GÜNLÜĞÜ",\r
"BAĞLANTISIZ KESİLEN FİŞLER GÜNLÜĞÜ",\r
"Tütün ürününün grubu kasada değiştirilmez (tütünde indirim ve fiyat kanunla sınırlıdır). Grup Muhasebede değiştirilir.",\r
"— 5 gün içinde (Mali Kayıt Kanunu md. 18).",\r
": ertelenmiş ödemeli {0} {1}, toplam",\r
": kupon satışı (Diğer → Hediye kuponları) ve kuponla ödeme (Diğer yöntemler → Kupon). Kupon firmanın tüm kasalarında geçerlidir (sunucu üzerinden paylaşım). Kupon satışı",\r
". Sonradan ödenen nakitsiz fatura (havale) firma banka hesabını ve ödeme vadesini içerir.",\r
". Vergi idaresine BOUNDBOOK işaretiyle 5 gün içinde gönderilir.",\r
"· kullanılabilir",\r
"(ORDER). Tahsilat daha sonra",\r
"(kurumsal müşteriye irsaliye, masa için tur) ve",\r
"(sipariş, catering, rezervasyon, hizmet, toptan) ve avanstan ödeme;",\r
"(havale)",\r
"(Diğer → Mali belgeler → Toplu fatura).",\r
"(Diğer → Mali belgeler):",\r
"{0} diğer ödeme yöntemleriyle birleştirilemez.",\r
"{0}: her kupon ayrı bir kalemdir (miktar 1).",\r
"{0}: kupon avans faturasıyla düzenlenir ([FS] 5.8).",\r
"{0}: kupon geçerlilik tarihi 2026-12-31 biçiminde değil.",\r
"{0}: kupon seri numarası “{1}” 12-2026-34567890 biçiminde değil.",\r
"⚠ Düzeltme — hatalı fatura…",\r
"🧾 Mali belgeler",\r
"ABW AFG AGO AIA ALA ALB AND ARE ARG ARM ASM ATA ATF ATG AUS AUT AZE BDI BEL BEN BES BFA BGD BGR BHR BHS BIH BLM BLR BLZ BMU BOL BRA BRB BRN BTN BVT BWA CAF CAN CCK CHE CHL CHN CIV CMR COD COG COK COL COM CPV CRI CUB CUW CXR CYM CYP CZE DEU DJI DMA DNK DOM DZA ECU EGY ERI ESH ESP EST ETH FIN FJI FLK FRA FRO FSM GAB GBR GEO GGY GHA GIB GIN GLP GMB GNB GNQ GRC GRD GRL GTM GUF GUM GUY HKG HMD HND HRV HTI HUN IDN IMN IND IOT IRL IRN IRQ ISL ISR ITA JAM JEY JOR JPN KAZ KEN KGZ KHM KIR KNA KOR KWT LAO LBN LBR LBY LCA LIE LKA LSO LTU LUX LVA MAC MAF MAR MCO MDA MDG MDV MEX MHL MKD MLI MLT MMR MNE MNG MNP MOZ MRT MSR MTQ MUS MWI MYS MYT NAM NCL NER NFK NGA NIC NIU NLD NOR NPL NRU NZL OMN PAK PAN PCN PER PHL PLW PNG POL PRI PRK PRT PRY PSE PYF QAT REU ROU RUS RWA SAU SDN SEN SGP SGS SHN SJM SLB SLE SLV SMR SOM SPM SRB SSD STP SUR SVK SVN SWE SWZ SXM SYC SYR TCA TCD TGO THA TJK TKL TKM TLS TON TTO TUN TUR TUV TWN TZA UGA UKR UMI RKS URY USA UZB VAT VCT VEN VGB VIR VNM VUT WLF WSM YEM ZAF ZMB ZWE",\r
"adv_iic TEXT",\r
"adv_vrijeme TEXT",\r
"ALB",\r
"Arnavutluk",\r
"“KDV sistemi dışı satış” ürünü",\r
"Avusturya",\r
"AUT",\r
"Avans ve hediye kuponu aynı faturada kullanılamaz. İki fatura düzenlenmelidir.",\r
"Sipariş, catering, salon rezervasyonu, hizmet veya mal teslimi için avans. Mal faturasında avans “Avans” ödeme yöntemi olarak seçilir; kalan nakit, kart veya havale ile ödenir.",\r
"Avans faturası düzenlendi: {0}.",\r
"Avans faturası burada iptal edilmez. Avans “Avans iadesi” ile iade edilir (Diğer → Mali belgeler → Avanslar).",\r
"avans faturası, avans iadesi, ertelenmiş ödeme için toplu fatura, avans faturalarının azaltılması",\r
"Avans faturaları",\r
"Avans faturaları etkin değil (Ayarlar → Eklentiler).",\r
"Müşteri olmadan toplu fatura için bir etiket (masa, sipariş) gerekir.",\r
"dayanaksız (oran 0)",\r
"etiketsiz",\r
"nakitsiz",\r
"Nakitsiz ve nakit ertelenmiş ödemeli faturalar aynı toplu faturaya girmez.",\r
"Ertelenmiş ödemeli nakitsiz faturada müşteri (vergi no ve ad) olmalıdır.",\r
"Ertelenmiş ödemeli nakitsiz faturalar toplu olarak havale ile ödenir.",\r
"BIH",\r
"Belarus",\r
"BLR",\r
"{0} kuponu bu avans faturasında yok.",\r
"Kupon bir kez kullanılır (kalan iptal olur)",\r
"BON-",\r
"Bosna-Hersek",\r
"BOUNDBOOK",\r
"no. {0} · {1} · kullanılabilir {2}",\r
"SGK no.",\r
"Fatura defteri numarası en fazla 20 karakterdir.",\r
"Fatura defteri numarası zorunludur.",\r
"Kart numarası",\r
"satıcı kart numarası",\r
"Müşteri numarası",\r
"Fatura defterindeki fatura numarası zorunludur.",\r
"Defterdeki fatura numarası",\r
"Sosyal güvenlik numarası",\r
"Bekleyen:",\r
"Bekleyen: {0}",\r
"Çekya",\r
"CHE",\r
"CHN",\r
"COMPANY",\r
"Karadağ",\r
"CZE",\r
"Defterdeki tarih ve saat geçersiz (gelecekte olamaz).",\r
"Düzenleme tarihi",\r
"DEU",\r
"drzava TEXT",\r
"efi_naknadno TEXT",\r
"Mali belgeler",\r
"FRA",\r
"Fransa",\r
"GBR",\r
"h.dok = 'order'",\r
"h.rezervacija IS NULL",\r
"h.soba = ?",\r
"Hollanda",\r
"HRV",\r
"Hırvatistan",\r
"HUN",\r
"ve bildirildi",\r
"Avans faturasının IKOF'u geçersiz (32 karakter, 0–9 ve A–F).",\r
"düzeltme (ERROR_CORRECTIVE)",\r
"Düzeltme (ERROR_CORRECTIVE) yalnızca satış faturası için düzenlenir.",\r
"Avans, ertelenmiş ve toplu belgelerin düzeltmesi kasada desteklenmez.",\r
"{0} faturasının düzeltmesi (sonraki kontrolde hata)",\r
"{0} no.lu faturanın düzeltmesi düzenlendi{1}.",\r
"Hatalı fatura düzeltmesi",\r
"hatalı fatura düzeltmesi (ERROR_CORRECTIVE)",\r
"Hatalı fatura düzeltmesi (ERROR_CORRECTIVE)",\r
"Hatalı fatura düzeltmesi (ERROR_CORRECTIVE) iptal edilmez. Aynı fatura için yeni düzeltme düzenlenir.",\r
"Hatalı fatura düzeltmesi vergi idaresine gönderilir, kasa şu anda gönderemiyor: {0} Düzeltme düzenlenmedi.",\r
"Hatalı fatura düzeltmesi vergi idaresine gönderilir, kasa şu anda gönderemiyor. Düzeltme düzenlenmedi.",\r
"Düzeltme imzalanamıyor (anahtar yok). Düzeltme düzenlenmedi.",\r
"ISR",\r
"ITA",\r
"İtalya",\r
"Avanstan, avans faturası tutarından fazlası ödenemez.",\r
"Defter no. {0} · {1} (kaldır)",\r
"fatura defterinden",\r
"Fatura defterinden",\r
"Fatura defteri no.",\r
"Düzeltme düzenle",\r
"Toplu fatura düzenle ({0})",\r
"Avans tutarı (€)",\r
"Avanstan ödenen tutar sıfırdan büyük olmalıdır.",\r
"İade tutarı (kullanılabilir {0})",\r
"İsrail",\r
"Kasa veya mali servis çalışmadığında faturalar elle şuraya yazılır:",\r
"Avans veya hediye kuponu faturada kullanıldığında avans faturası düzeltme faturasıyla azaltılır (KDV iki kez hesaplanmasın). Kasa bunu vardiya kapanışında kendisi yapar.",\r
"Avans veya hediye kuponu faturada kullanıldığında avans faturası düzeltme faturasıyla azaltılır (KDV iki kez hesaplanmasın). Kasa bunu vardiya kapanışında kendisi yapar. {0}",\r
"şirket kartı",\r
"Şirket kartı",\r
"Şirket kartı ve diğer nakitsiz ödemeler aynı faturada diğer yöntemlerle birleştirilmez. İki fatura düzenlenmelidir.",\r
"Şirket kartı ve diğer nakitsiz ödemeler aynı faturada nakit veya kartla birleştirilemez. İki fatura düzenlenmelidir.",\r
"Şirket kartı, satıcı kartı, diğer nakitsiz",\r
"satıcı kartı",\r
"Satıcı kartı",\r
"Çin",\r
"Fatura defteri",\r
"knjiga_broj TEXT",\r
"fatura defterine",\r
"Kupon avans düzeltmesi: kupon toplamı kuponlarla ödenen tutara eşit değil.",\r
"Kosova",\r
"Müşteri — ad",\r
"Müşteri — vergi no / kimlik no (havale için zorunlu)",\r
"{0} müşterisi toplu faturayı havale ile öder (nakitsiz)",\r
"Müşteri / etiket",\r
"kupac_drzava TEXT",\r
"kupac_vrsta TEXT",\r
"Müşteri: “{0}” ülkesi listedeki bir kod değil (ISO 3166-1, üç harf, örn. MNE, SRB, DEU).",\r
"Müşteri: bilinmeyen numara türü “{0}” (olası: TIN, ID, PASS, VAT, TAX, SOC).",\r
"Müşteri: vergi no 8, kimlik no 13 hanelidir (verilen: “{0}”). Yabancı müşteri için ülke ve numara türü seçilmelidir.",\r
"Müşteri: vergi no 8, kimlik no 13 hanelidir. Yabancı müşteri için ülke ve numara türü seçilmelidir.",\r
"Nakitsiz faturalar için sertifika parolası",\r
"Macaristan",\r
"MKD",\r
"Avans faturasında kullanılabilir: {0}.",\r
"Bir faturada yalnızca aynı faturayla satılan kuponlar (aynı avans faturası) kullanılabilir. İki fatura düzenlenmelidir.",\r
"Bir faturada yalnızca aynı avans faturasından (aynı faturayla satılan) kuponlar kullanılabilir. İki fatura düzenlenmelidir.",\r
"Bir faturada en fazla 20 kupon kullanılabilir.",\r
"Bir faturada yalnızca bir satıcı kartı kullanılabilir.",\r
"Bir faturada yalnızca bir satıcı kartı kullanılabilir. İki fatura düzenlenmelidir.",\r
"Hediye kuponuna indirim yapılmaz: avans faturası kuponun nominal değeri üzerinedir.",\r
"Faturada: {0} (avans faturası). Kupon ödemeden sonra yazdırılır.",\r
"{0} kupon kaleminde {1} kaldı, düzeltme {2}.",\r
"nacin TEXT",\r
"Seçilen faturalardan bazıları artık toplu fatura beklemiyor (zaten dahil veya iptal).",\r
"Avans faturası yok.",\r
"Toplu fatura bekleyen fatura yok.",\r
"Bilinmeyen ödeme yöntemi: “{0}” (olası: Nakit, Kart, Havale, Kupon, Anlık, Şirket kartı, Satıcı kartı, Diğer nakitsiz).",\r
"Bekleyen bir şey yok.",\r
"Almanya",\r
"NLD",\r
"NOINTERNET",\r
"Yeni avans faturası…",\r
"örn. 15/2026",\r
"örn. Avans — catering 25.11.",\r
"örn. Masa 4",\r
"ertelenmiş",\r
"ertelenmiş ödeme",\r
"Ertelenmiş ödeme — toplu fatura sonra",\r
"Ertelenmiş ödeme ve toplu fatura",\r
"Açıklama (avans ne için)",\r
"Açıklama / müşteri",\r
"ORDER",\r
"Muhasebede “KDV sistemi dışı satış” olarak işaretlenen ürün için vergi idaresine giden muafiyet dayanağı. Muhasebeci onaylar.",\r
"diğer nakitsiz",\r
"Diğer nakitsiz",\r
"vergi idaresince onaylanmış. Burada her böyle fatura sonradan girilir (aynı kalemler ve ödeme) ve vergi idaresine şu işaretle gönderilir:",\r
"Bu hatalı fatura düzeltmesidir. Mal iadesi asıl faturadan yapılır.",\r
"Etiket (isteğe bağlı)",\r
"Etiket (masa, sipariş)",\r
"KDV numarası (yabancı firma)",\r
"pdv REAL",\r
"Vergi no / kimlik no",\r
"Kuponla veya avanstan ödeme fatura IKOF'u gerektirir (mali kayıt kapalı veya sertifika yok). Fatura düzenlenmedi.",\r
"Kuponla ödeme, kuponu düzenleyen avans faturasının IKOF'unu taşımalıdır.",\r
"Kuponla ödeme kupon seri numarasını taşımalıdır.",\r
"Satıcı kartıyla ödeme kart numarasını taşımalıdır.",\r
"Satıcı kartıyla ödeme: kart numarası girilmelidir.",\r
"Hediye kuponu fatura defterinden girilmez.",\r
"Hediye kuponu satın alırken ödenir (avans faturası alınan ödeme için düzenlenir).",\r
"Hediye kuponu ayrı (avans) faturayla, aynı faturada başka mal olmadan satılır.",\r
"Hediye kuponu ayrı (avans) faturayla satılır. Önce ekrandaki malların tahsilatı yapılmalı veya kaldırılmalıdır.",\r
"POL",\r
"Polonya",\r
"Vergi numarası (yabancı)",\r
"Ayrı sertifika:",\r
"Nakitsiz faturalar için ayrı sertifika",\r
"Satıcı kart numarası girilmelidir.",\r
"Avans iadesi: {0}.",\r
"İade 0,01 ile {0} arasındadır.",\r
"boş = anlık ödeme hesabı",\r
"satış ({0} kalem{1}){2}",\r
"satış {0} faturaya bölündü ({1} kalem{2})",\r
"r.datum <= ?",\r
"r.datum >= ?",\r
"r.kupac_pib = ?",\r
"r.stornirao_uid IS NULL",\r
"r.vrsta = 'racun'",\r
"{1} tarihli {0} no.lu fatura, {2}.\\n\\nDüzeltme YALNIZCA vergi idaresi portalında (SEP → Hatalı faturalar) sonraki kontrollerden sonra hatalı işaretlenen fatura için düzenlenir. Aynı fatura (kalemler, ödemeler, müşteri) doğru hesapla gönderilir; ciro ve para değişmez. Süre: hatanın işaretlenmesinden itibaren 8 gün.{3}\\n\\nNot (isteğe bağlı):",\r
"Faturada {0} kalem var, vergi idaresi bir faturada en fazla {1} (ve en fazla 150 kB) kabul eder. Yalnızca tek yöntemle, fatura indirimi, sadakat, kupon, avans ve ertelenmiş ödeme olmadan ödenen fatura otomatik bölünür. Birkaç küçük fatura düzenlenmelidir.",\r
"Faturada {0} kalem var, vergi idaresi en fazla {1} kabul eder. Fatura birkaç faturaya bölünmelidir.",\r
"Faturada 1000'den fazla kalem var ve {0} fatura olarak düzenlendi (toplam {1}).",\r
"Defterdeki fatura 5 günden eski: elektronik teslim süresi (Mali Kayıt Kanunu md. 18) geçti. Fatura yine de girilir ve gönderilir.",\r
"Fatura defterinden fatura",\r
"Fatura defterindeki fatura 30 günden eski. Kasada girilemez; vergi idaresine başvurulmalıdır.",\r
"Fatura defterindeki fatura BOUNDBOOK sonradan teslim işaretiyle gönderilir.",\r
"Fatura defterindeki fatura gerçek ödeme yöntemiyle girilir.",\r
"Fatura defterine elle yazılan fatura (kasa veya mali servis çalışmadı) satış ekranında girilir: kalemler girilir, sonra",\r
"Fatura {0} gün önce düzenlendi: 8 günlük süre geçmiş olabilir.",\r
"Fatura iptal edildi; düzeltme gerekmez.",\r
"SEP'in (Hatalı faturalar) sonraki kontrollerden sonra hatalı işaretlediği fatura",\r
"Fatura mali kayda alınmamış (JIKR yok). Düzeltme yalnızca vergi idaresinin aldığı ve sonraki kontrolde hatalı işaretlediği fatura için düzenlenir.",\r
"Ertelenmiş ödemeli fatura avanstan ödenmez.",\r
"Fatura şimdi şu ödeme yöntemiyle düzenlenir:",\r
"fatura",\r
"faturalar (havale, şirket kartı, firmanın ertelenmiş ödemesi): yetkili kişinin imzası; nakit faturaları firma mührü imzalar. Seçilmezse tek sertifika hepsi için geçerlidir.",\r
"Tahsilat bekleyen ertelenmiş ödemeli faturalar (kurumsal müşteriye irsaliye, masa turu). Toplu fatura bir müşteriye veya bir etikete düzenlenir.",\r
"RKS",\r
"Ödeme vadesi",\r
"Ödeme vadesi (gün)",\r
"Ödeme vadesi 0 ile 365 gün arasındadır.",\r
"Ödeme vadesi fatura tarihinden önce olamaz.",\r
"Ödeme vadesi geçerli bir tarih değil.",\r
"Havale ödeme vadesi (gün)",\r
"rok_dana INTEGER",\r
"rok_placanja TEXT",\r
"RUS",\r
"Rusya",\r
"Kupon avans faturasının bir kısmı iade edilmez. Faturanın tamamı iptal edilir (kuponlar kullanılmamış).",\r
"ertelenmiş ödemeli, toplam",\r
"Bu faturadan malın bir kısmı iade edildi; düzeltme kasada mümkün değil.",\r
"her kuponun seri numarasıyla (FS v5, 3.5 ve 5.8); kuponla ödeme vergi idaresine avans faturasının IKOF'u ve kupon numarasıyla “SVOUCHER” olarak gider, avans faturası vardiya kapanışında kullanılan tutar kadar azaltılır. Bu yöntemi",\r
"ABD",\r
"Kupon seri numarası “{0}” 12-2026-34567890 biçiminde değil.",\r
"Sertifika (nakitsiz)",\r
"Nakitsiz faturalar için sertifika içe aktarıldı{0}",\r
"Nakitsiz faturalar için sertifika bu kasadan silinir. “Nakitsiz faturalar için ayrı sertifika” açıkken kasa faturaları vergi idaresine göndermez.",\r
"Kuzey Makedonya",\r
"Slovenya",\r
"SOC",\r
"SRB",\r
"Sırbistan",\r
"Gelecekteki satışın KDV oranı",\r
"İsviçre",\r
"İsveç",\r
"SVN",\r
"SVOUCHER",\r
"SWE",\r
"TAX",\r
"tip_racuna TEXT",\r
"TUR",\r
"Türkiye",\r
"Birleşik Krallık",\r
"Nakitsiz faturalar için ayrı sertifika açık ama içe aktarılmamış (Ayarlar → Mali kayıt).",\r
"Bu sertifikayı kaldır",\r
"UKR",\r
"Ukrayna",\r
"Avans faturalarının azaltılması",\r
"avans faturalarının azaltılması ({0})",\r
"Avans faturalarının azaltılması şunlar için yapılmadı: {0}",\r
"Avans faturasının azaltılması — avans kullanıldı",\r
"Avans faturasının azaltılması — hediye kuponları kullanıldı",\r
"Azaltma şunlar için yapılmadı: {0}",\r
"Azaltılan avans faturası: {0}.",\r
"Şimdi azalt",\r
"Fatura defterinden fatura girişi…",\r
"USA",\r
"Nakitsiz için sertifika içe aktar (.pfx)…",\r
"VAT_CL17 (varsayılan)",\r
"vd TEXT",\r
"Havale müşteri gerektirir: müşterisiz toplu fatura nakit veya kartla ödenir.",\r
"Diğer ödeme yöntemleri → Fatura defterinden fatura girişi",\r
"Düzenleme saati (saat:dakika)",\r
"Fatura defterindeki düzenleme saati gelecekte.",\r
"Fatura defterindeki düzenleme saati geçersiz (tarih ve saat).",\r
"Saat, saat:dakika olarak girilmelidir, örn. 14:30.",\r
"Numara türü",\r
"vrsta_avansa TEXT",\r
"vrsta_id TEXT",\r
"vsn TEXT",\r
"Şirket kartı için müşteri (vergi no ve firma adı) girilmelidir.",\r
"Bu fatura için düzeltme zaten düzenlendi.",\r
"dönem için; ödeme yöntemleri",\r
"Şirket kartıyla ödeme için müşteri (vergi no ve firma adı) girilmelidir.",\r
"Toplu fatura için ertelenmiş ödemeli fatura seçilmedi.",\r
"toplu fatura",\r
"Toplu fatura",\r
"Müşterisiz toplu fatura aynı etiketli faturaları kapsar (masa, sipariş).",\r
"Toplu fatura düzenlendi: {0}.",\r
"Toplu fatura sonra (irsaliye, tur)…",\r
"Toplu fatura tek müşteriye düzenlenir: seçilen faturalar farklı müşterilere ait.",\r
"Toplu fatura…",\r
"Toplu faturalar etkin değil (Ayarlar → Eklentiler).",\r
"toplu faturayla",\r
"Firma banka hesabı (havale)",\r
"ziro_racun TEXT",\r
"— ÇAĞRI",\r
", kaynak {0}",\r
"; çağrı bekleyen servis gönderilmedi",\r
"· seçilen {0}",\r
"· para üstü",\r
"“{0}”: {1} alt grubu yok.",\r
"“{0}”: KDV oranı {1}; 21, 15, 7 veya 0 değil — kasanın varsayılan oranı geçerli.",\r
"Bu kasanın satışlarından “Sık birlikte alınan” (kasa ve garson telefonu)",\r
"(ekstralar: {0} uyarı)",\r
"(“Yiyecek-içecek — gelişmiş” bölümünden ayarlanır).",\r
"(rezervasyonda kapora var)",\r
"(ekstralarla)",\r
"{0} · KDV %{1} · yemeğe ekstra",\r
"{0} (onaylayan: {1})",\r
"{0}: “{1}” iki kez seçildi.",\r
"{0}: {1} (onaylayan {2})",\r
"{0}: {1} belgesi düzenlendi.",\r
"{0}: seçim zorunludur.",\r
"{0}: en fazla {1} {2}.",\r
"{0}: bilinmeyen seçim “{1}”.",\r
"{0}: en az {1} seçilmelidir.",\r
"{0}{1} · {2} kal.{3}{4}{5}",\r
"{0}{1} (masada {2})",\r
"{0}en fazla {1}",\r
"{0}Kalem, kodunun, alt grubunun veya grubunun istasyonuna gider; geri kalanı varsayılana.",\r
"% · yemeğe ekstra",\r
"+ {0} ekstralar",\r
"+ İstasyon",\r
"▶ Servisi çağır:",\r
"▶ Servisi çağır: {0}",\r
"▶ Çağır:",\r
"▶ Çağır: {0}",\r
"⚙ Yiyecek-içecek — gelişmiş",\r
"🍷 Temsil / ikram / personel yemeği",\r
"👤 Garsona göre hasılat",\r
"🖨 Yazdır (Bluetooth)",\r
"🧑‍🍳 Mutfak{0}",\r
"1 (aynısı Muhasebe / Yönetici paketiyle gelir; açıklama: docs/nove-funkcije/ugostiteljstvo-2.md). Şu an:",\r
"Alerjenler",\r
"QR menüden alerjenler: {0} ürün.",\r
"Ürüne göre alerjenler",\r
"Toz kırmızı biber",\r
"{0} ürünü kasa kataloğunda yok.",\r
"avans_uid TEXT",\r
"servissiz",\r
"Servissiz",\r
"Soğansız",\r
"KDV hesaplanmadan",\r
"KDV'siz",\r
"Bluetooth yazıcı",\r
"Eşit paylar için misafir sayısı: 2 ile 30 arası.",\r
"çağrı bekliyor",\r
"Sık birlikte:",\r
"{0} ile sık birlikte:",\r
"Sık birlikte:",\r
"Ekstra tanımı geçerli bir JSON değil.",\r
"Ekstra tanımı beklenen biçimde değil.",\r
"Tatlı",\r
"pay",\r
"en fazla {0}",\r
"İyi pişmiş",\r
"DOD-{0}-{1}",\r
"Ekstralar",\r
"Yemek ekstraları",\r
"Yemeğe ekstralar",\r
"Yemeğe ekstralar (pişme, garnitür, peynir…)",\r
"Ekle{0}",\r
"“{0}” ekstrası kasa kataloğunda yok (kod {1}). Ekstra tanımı kontrol edilmelidir.",\r
"Ekstra, yemek üzerinden değiştirilir (yemek adının altındaki ekstra metnine dokunun).",\r
"Ekstra, yemekle birlikte kaldırılır (veya yemek kaldırılıp başka ekstralarla yeniden sipariş edilir).",\r
"Borçlu",\r
"Ekran",\r
"Mutfak ekranı",\r
"Mali fişi ana kasa düzenler.",\r
"Mali fişi ana kasa düzenler.{0}",\r
"Biçim",\r
"Biçim {0} 1 (aynısı Muhasebe / Yönetici paketiyle gelir; açıklama: docs/nove-funkcije/ugostiteljstvo-2.md). Şu an: {1} grup{2}.",\r
"Fiş nerede yazdırılsın?",\r
"Ana yemek",\r
"misafir, vesile, personel adı",\r
"Misafirler geldi",\r
"Misafirler geldi — {0}",\r
"hazır",\r
"Bu kalem hazır",\r
"Izgara sebze",\r
"“{0}” grubu iki kez yazılmış; ilki geçerli.",\r
"“{0}” grubunun seçeneği yok ve atlandı.",\r
"“{0}” grubu: “{1}” seçeneği iki kez yazılmış; ilki geçerli.",\r
"“{0}” grubu: adsız seçenek atlandı.",\r
"Kimliği veya adı olmayan grup atlandı.",\r
"Gruplar / alt gruplar (virgülle)",\r
"IKOF: {0}",\r
"veya: eşit paylar (misafir sayısı)",\r
"İç belge",\r
"İç belgeyi şef onaylar.",\r
"İç belgeler açık değil (Ayarlar → Yiyecek-içecek).",\r
"İç belgeler açık değil (Yiyecek-içecek — gelişmiş).",\r
"İç belgeler açık (şef onaylar)",\r
"interno TEXT",\r
"Geçerli: {0} grup.",\r
"seçim",\r
"“{0}” seçimi bu ürünün ekstralarına ait değil.",\r
"seçim",\r
"Belge düzenle",\r
"Teslim tutarı geçerli değil.",\r
"{0} masasının tutarı {1} €. Masa yenilenmeli ve ödeme tekrarlanmalı.",\r
"JIKR: {0}",\r
"Kasa ödemeyi onaylamadı (bağlantı). Ödeme aynı istekle tekrarlanmalı.",\r
"Gecikme (kırmızı) dakika sonra",\r
"kgs",\r
"Miktar yemeği izler",\r
"Bu misafirin ödediği her kalemin miktarı ödeme için ekranda kalır; kalanı masaya döner. Kalemin bir kısmı: ör. 0,5 = yarım pizza. Yemek ekstraları yemekle gider. Eşit paylar için misafir sayısı girilir (kalemler o zaman boş bırakılır).",\r
"Garson",\r
"garson seçer",\r
"Garson zorunludur.",\r
"Masaya hizmet eden garson (masa hesabı) veya fişi düzenleyen kasiyer. “Teslim edilen” = garsonun teslim ettiği nakit; “borç” = masada tahsil edilip henüz teslim edilmeyen nakit.",\r
"Garson telefondan tahsil eder (fişi bu kasa düzenler)",\r
"konobar TEXT",\r
"Garsonlar",\r
"Az pişmiş",\r
"Servis",\r
"Servis (başlangıç, ana yemek, tatlı)",\r
"Servis {0}",\r
"2. servis ve sonrası “Sonraki servisi çağır”ı bekler",\r
"Servis 4",\r
"Servis 5",\r
"servis çağrı bekliyor",\r
"Servis geçerli değil.",\r
"Ürün grubuna göre servis",\r
"Servisler (başlangıç, ana yemek, tatlı)",\r
"Servisler açık",\r
"servisler, yazdırma istasyonları, mutfak ekranı, yemek ekstraları, alerjenler, telefondan ödeme; yalnızca şef",\r
"MAC adresi geçerli değil.",\r
"Telefon yazıcısının MAC adresi (ör. 00:11:22:33:44:55).",\r
"Telefon yazıcısının MAC adresi.",\r
"yumuşakçalar",\r
"Masa hesabının 1/{0}'i ödeme için ekranda; kalanı ({1} {2}) {3} masasında. Sonraki misafir için: {4} eşit pay.",\r
"Ekranda bir hesap var. Önce masaya geri gönderilmeli veya ödenmeli.",\r
"Ekranda kalem yok.",\r
"Kasada",\r
"bu kasada",\r
"Müessese ikramı",\r
"telefon yazıcısında (Bluetooth)",\r
"{0} masasında mutfağa / bara gönderilmemiş kalemler var. Sipariş gönderilmeli veya ödeme onsuz onaylanmalı.",\r
"{0} masasında bekletilen servis yok.",\r
"Masada çağrı bekleyen servis yok.",\r
"Telefonda",\r
"Ödeme yöntemi geçerli değil (nakit veya kart).",\r
"en az {0},",\r
"en az {0}, en fazla {1}",\r
"{0} siparişi gönderildi ({1} {2}){3}. {4} masası beklemede.",\r
"Sipariş yazdırılmadı; servis çağrılmadı. Yazıcı kontrol edilmeli.",\r
"Sipariş artık yok.",\r
"Kasadan ve garson telefonlarından siparişler. “Hazır” (siparişin tamamı veya kalem kalem) garsona hazır olduğunu bildirir. Mutfak tableti: “Mutfak” modunda Android uygulaması (garson telefonu gibi eşleştirilir).",\r
"Ödendi.",\r
"Ödeme",\r
"Ödeme — kasa bekleniyor…",\r
"Ödeme — masa {0}",\r
"{0} ödemesi kasa tarafından onaylanmadı.",\r
"Ödeme kasa tarafından onaylanmadı. Vazgeçmeden önce kasada fiş düzenlenmediği kontrol edilmeli.",\r
"Ödeme yapılmadı.",\r
"Telefondan ödeme kasada açık değil (Ayarlar → Yiyecek-içecek).",\r
"Yine de tahsil et",\r
"Gönderilmemiş kalemler",\r
"Bilinmeyen biçim “{0}” ({1} bekleniyor).",\r
"kasa tarafından onaylanmadı.",\r
"yeni tur{0}",\r
"Yeni kalemler çağrı bekleyen serviste (masa görünümünde “Servisi çağır”).",\r
"ör. tuzsuz",\r
"zorunlu",\r
"Personel yemeği",\r
"bunun açık masaları ( )",\r
"bunun açık masaları ({0})",\r
"Onaylayan (şef)",\r
"Ödemeden vazgeç",\r
"opis TEXT",\r
"kuruyemiş",\r
"Açık vardiya",\r
"Masayı aç",\r
"Kağıt",\r
"Garsona göre hasılat",\r
"Satış fiyatından KDV (ihtiyatlı)",\r
"KDV satış fiyatından hesaplanır",\r
"KDV uygulaması",\r
"Pişme derecesi",\r
"Pizzalar",\r
"Patates kızartması",\r
"Tekrarla (aynı istek)",\r
"indirim",\r
"Kimin onayladığı yazılmalı.",\r
"“{0}” servisi çağrıldı (sipariş {1}). {2} masası beklemede.",\r
"boş = kalemlere göre",\r
"Teslim kaydedildi.",\r
"Para teslimi — {0}",\r
"garson para teslimi",\r
"Teslim…",\r
"Teslimler",\r
"Başlangıçlar:1; Ana yemekler:2; Tatlılar:3",\r
"Başlangıç",\r
"QR menüden al",\r
"Öneriler",\r
"Garnitür",\r
"Teslim alan",\r
"Örnek",\r
"Alınan tutar fiş tutarından az.",\r
"Alınan {0} · para üstü {1}",\r
"Misafirden alınan (nakit, isteğe bağlı)",\r
"garsona göre satış, nakit ve kart; para teslimi; yalnızca şef",\r
"Fiş QR kodu (Vergi İdaresi) — misafir telefonla tarar.",\r
"fiş düzenlendi",\r
"Fiş kasada yazdırıldı.",\r
"Fiş telefon yazıcısında yazdırıldı.",\r
"Telefondan ödenen fiş yazdırılır",\r
"Fişte QR kod yok (deneme modu).",\r
"Fiş düzenlenmedi: {0} Masa geri yüklendi.",\r
"Fiş kasada YAZDIRILMADI — yazıcı kontrol edilmeli.",\r
"Fiş kasada yazdırılır.",\r
"Fiş telefon yazıcısında yazdırılır.",\r
"Masa fişi, masaya hizmet eden garsonun operatör kodunu taşır (garsonun kendi kodu varsa)",\r
"Sebep zorunludur (ör. misafir, vesile, personel adı).",\r
"Ürün başına bir satır: “kod: numaralar” (1–14:",\r
"Ürün başına bir satır: “kod: numaralar” (1–14: {0}).",\r
"Temsil",\r
"Temsil / ikram / personel yemeği",\r
"Temsil, “ikram”, personel yemeği",\r
"Rezervasyon yok.",\r
"ekrandaki mallar ödemesiz, sebep ve şef onayıyla",\r
"Ekrandaki mallar ödemesiz stoktan düşülür. Belge mali fiş değildir; raporlarda ve Muhasebe özetinde satış ve zayiattan ayrı görünür. KDV uygulaması:",\r
"Ekrandaki mallar ödemesiz stoktan düşülür. Belge mali fiş değildir; raporlarda ve Muhasebe özetinde satış ve zayiattan ayrı görünür. KDV uygulaması: {0} (“Yiyecek-içecek — gelişmiş” bölümünden ayarlanır).",\r
"Izgara",\r
"Şu an temel ayarlardaki düzen (mutfak + bar) geçerli. Buradaki değişiklik onun yerini alır.",\r
"Kodlar",\r
"Peynir",\r
"smjena_id = ?",\r
"Tuz",\r
"Orta pişmiş",\r
"Telefonda yazdırma başarısız: {0}",\r
"Fiş yazdırma",\r
"Yazıcı ayarlanmadı.",\r
"Telefon yazıcısı kaydedildi.",\r
"Telefon yazıcısı kaldırıldı.",\r
"Yazdırma istasyonları (mutfak, bar, ızgara, pizza, tatlı…)",\r
"Kalem, kodunun, alt grubunun veya grubunun istasyonuna gider; geri kalanı varsayılana.",\r
"Sipariş kalemi yok.",\r
"{0} masası şu an kasada açık. Kasiyer masayı geri verince ödeme mümkündür.",\r
"{0} masasında açık hesap yok (belki zaten ödendi).",\r
"Masa {0}: misafirler {1}{2}.",\r
"Masa {0}: “{1}” servisi çağrı bekliyor.",\r
"Masa {0}: “{1}” servisi hemen gider.",\r
"Masa {0}: telefondan tahsil edildi ({1}), {2} {3} €.",\r
"Masa {0}: “{1}” servisi çağrıldı.",\r
"Masa {0}: {1} fişi düzenlendi ({2}, {3} €).{4}",\r
"Jambon",\r
"Tüm istasyonlar",\r
"KDV uygulamasını muhasebeci onaylar; Muhasebe özeti tür, sebep, onaylayan ve orana göre KDV'yi taşır.",\r
"Yiyecek-içecek — gelişmiş",\r
"Yiyecek-içecek — kaydedildi{0}.",\r
"Teslimi kaydet",\r
"Uyarı (sarı) dakika sonra",\r
"upozori",\r
"uz_red INTEGER",\r
"{0} sürümü desteklenmiyor; sürüm 1 olarak okunur.",\r
"vrijeme >= ? AND vrijeme <= ?",\r
"İç belge türü geçerli değil.",\r
"Patates baharatı",\r
"{0} · {1} kişi",\r
"misafirler: {0}",\r
"rez. {0}",\r
"ödenecek",\r
"· masa rezervasyonu",\r
"(no. {0})",\r
"%15 (yiyecek, servis)",\r
"Kapora — rezervasyon {0}",\r
"Kapora — rezervasyon {0}, {1}.{2}. {3}",\r
"kapora {0}",\r
"Rezervasyon için kapora fişi düzenlendi{0}.",\r
"no. {0} · {1} · kalan {2}{3}",\r
"Kapora fişi (mali) düzenlenir. Masa ödenirken tutar “Diğer ödeme yöntemleri → Kapora” ile düşülür.",\r
"Kapora tutarı zorunludur.",\r
"Ödendi",\r
"Rezervasyonda zaten kapora var.",\r
"{0} masasında rezervasyon kaporası var. Ödeme kasada alınır (kaporadan ödeme).",\r
"KDV oranı",\r
"; müşteriye fiş kopyası etkin değil",\r
"; müşteriye fiş kopyası: evet",\r
"(ENU {0})",\r
"(kasa sunucuya bağlandığında)",\r
"(kupac vjernosti) | pib:",\r
"(veri yok)",\r
"(onay {0})",\r
"(PDF) ödemeden sonra e-posta ile; kâğıt fiş eskisi gibi verilir. Sunucu bağlantısı yoksa kopya bekler ve sonra gönderilir.",\r
"{0} · kasa {1}",\r
"{0} {1} {2} {3} re",\r
"{0} ürün",\r
"{0} rg {1} {2} {3} {4} re f",\r
"{0} RG {1} w {2} {3} m {4} {5} l S",\r
"{0}, {1} (kasa {2}). Rapor ektedir (PDF ve Excel).",\r
"<?xml version=\\"1.0\\" encoding=\\"UTF-8\\" standalone=\\"yes\\"?>",\r
"<< /Title {0} /Producer (IRIS CORVINA){1} /CreationDate ({2}) >>",\r
"<< /Type /Catalog /Pages 2 0 R >>",\r
"<< /Type /Encoding /BaseEncoding /WinAnsiEncoding /Differences [{0}] >>",\r
"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding 5 0 R >>",\r
"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding 5 0 R >>",\r
"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {0} {1}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {2} 0 R >>",\r
"<< /Type /Pages /Kids [{0}] /Count {1} >>",\r
"✉ {0} (kaldır)",\r
"✉ E-posta{0}",\r
"✉ E-posta ile",\r
"✉ Fiş kopyasını e-posta ile gönder…",\r
"E-posta adresi geçerli değil (ör. ad@ornek.me).",\r
"E-posta adresi geçerli değil.",\r
"Adresler firma posta ayarlarındadır (Yönetici); kasa adres seçmez.",\r
"kampanya: {0}, indirim",\r
"BT {0} rg /{1} {2} Tf {3} {4} Td ({5}) Tj ET",\r
"BT {0} rg /F1 7.5 Tf {1} {2} Td ({3}) Tj ET",\r
"Cacute",\r
"Ccaron",\r
"Vergi Dairesi onayı bekleniyor (JIKR).",\r
"bekliyor: {0}",\r
"Dcroat",\r
"Kasa e-postası",\r
"Müşteri e-postası",\r
"Bu kasada e-posta kullanılamıyor.",\r
"E-posta: {0} ileti gönderilmedi (Diğer → E-posta).",\r
"E-fiş",\r
"Elektronik fiş kopyası",\r
"ELEKTRONİK FİŞ KOPYASI — asıl belge kasada verilen kâğıt fiştir.",\r
"Excel",\r
"Excel tablosu kaydedildi:",\r
"FEFF",\r
"MALİ FİŞ",\r
"Sahibi veya muhasebeciyi seçin.",\r
"rapor",\r
"Rapor e-posta ile gönderim sırasına alındı.",\r
"Kasa {0} · {1}{2}",\r
"Kasa sunucuyla eşleşmedi — iletiler bekliyor.",\r
"Kasa IRIS CORVINA sunucusuyla eşleşmedi — rapor dosya olarak kaydedilebilir.",\r
"muhasebeciye",\r
"Kime",\r
"fiş kopyası",\r
"Fiş kopyası {0} adresine gidiyor{1}.",\r
"müşterilere fiş kopyaları ve sahibe/muhasebeciye raporlar; gönderim durumu",\r
"fiş kopyası",\r
"MÜŞTERİ",\r
"Müşteri alır:",\r
"Ara toplam (fiş indirimi öncesi)",\r
"Onay şekli",\r
"Tahsil edilen satış",\r
"Dışa aktarılacak ürün yok.",\r
"İleti yok.",\r
"Dışa aktarılacak tablo yok.",\r
"Müşteriye bildirim (adresin saklanması)",\r
"Dayanak: müşteri onayı. Onay isteğe bağlıdır ve her zaman geri alınabilir; bu durumda adres silinir.",\r
"Ürüne göre zayiat",\r
"Mal zayiatı (satış değil)",\r
"PDF",\r
"PDF kaydedildi:",\r
"KDV {0} (matrah {1})",\r
"pib:",\r
"Ödeme yöntemine göre",\r
"Veriler: e-posta adresi, sadakat müşterisinin telefon numarası veya kurumsal müşterinin vergi numarası ile.",\r
"Yeniden dene",\r
"Fiş indirimi {0}",\r
"Mesaj (isteğe bağlı)",\r
"Raporu e-posta ile gönder",\r
"Firma postası etkin{0}.",\r
"Firma postası etkin değil (Yönetici → E-posta ve raporlar).",\r
"MAL İADESİ — DÜZELTME FİŞİ",\r
"Müşteri hakları: erişim, düzeltme, silme, işlemenin kısıtlanması, taşınabilirlik ve itiraz; Kişisel Verilerin Korunması ve Bilgiye Serbest Erişim Ajansı'na da şikâyet.",\r
"sunucuya iletildi",\r
"Fişin Vergi Dairesi'nde doğrulanması",\r
"Kontrol edildi {0}.",\r
"FİŞ",\r
"Racun {0}.pdf",\r
"Fiş kasada bulunamadı.",\r
"Fişler ve indirim öncesi satış",\r
"Saklama süresi: onay sürdüğü, yani sadakat müşterisi var olduğu sürece.",\r
"Kalem",\r
"İPTAL FİŞİ",\r
"FİŞ İPTALİ",\r
"sayfa {0} / {1}",\r
"Amaç: fişin elektronik kopyasının müşterinin adresine gönderilmesi (kâğıt fişe ek olarak).",\r
"tel:",\r
"trailer\\n<< /Size {0} /Root 1 0 R /Info 6 0 R >>\\nstartxref\\n{1}\\n%%EOF",\r
"Firma posta ayarlarında sahip veya muhasebeci adresi yok (Yönetici → E-posta ve raporlar).",\r
"ÖDENECEK TOPLAM",\r
"sahibe ve muhasebeciye",\r
"Müşteriyle saklanan adres (onay",\r
"Müşteriyle saklanan adres (onay {0}).",\r
"Adresi {0} müşterisiyle sakla (müşterinin onayıyla)",\r
"Banka hesabı",\r
"· kart",\r
"· Menajerden kasiyer:",\r
"· en fazla %{0} indirim",\r
"· bağlı",\r
"· bağlandı {0} · Menajerden kasiyer: {1} · liste {2}",\r
"· liste",\r
"{0}\\n\\nÜrün fiziksel olarak burada mı? Satış devam eder, fark sayımda görünür.",\r
"telefondan {0} ({1}): {2}",\r
"{0}: işletme stoğuna göre {1} (veri {2}.{3}. {4}).",\r
"{0}: PIN (veya kart) gerekli — onaylayan {1}.{2}",\r
"{0}{1}: onaysız indirim (%)",\r
"📱 Telefondan iste",\r
"yönetici",\r
"Yazıcı adresi (ESC/POS)",\r
"Hızlı tuşlar",\r
"Onay bekliyor",\r
"Nakit yatırma",\r
"Nakit yatırma ve çekme",\r
"Onay günlüğü",\r
"Fiyat değişikliğinden sonra etiket",\r
"Çekmece: adres",\r
"mali ve güvenlik ayarları uzaktan değiştirilmez",\r
"Mali ayarlar uzaktan değiştirilmez.",\r
"Kasiyer başına nakit",\r
"İndirim sınırı 0 ile 100 arasında bir yüzdedir.",\r
"Kasiyer indirim sınırı 0 ile 100 arasında bir yüzdedir (boş = rol sınırı).",\r
"granica_popusta REAL",\r
"HKDF",\r
"{0} kaldı",\r
"Menajerden",\r
"yazdırırken seç",\r
"Her yazdırmada yazıcı seç",\r
"Fiyat ve ürün değişikliği",\r
"izmjena TEXT",\r
"Raporlar ve denetim",\r
"kart kayıtlı",\r
"Kart hiçbir etkin kasiyere kayıtlı değil.",\r
"kartica_hes TEXT",\r
"kartica_so TEXT",\r
"Kasa Menajere bağlandı (firma anahtarı {0}). Menajerden kasiyer: {1}.",\r
"Kasa ne sunucuya ne de değişim klasörüne bağlı — kod kontrol edilemiyor.",\r
"„{0}\\" kasiyeri Menajerde kayıtlı. Değişiklikler (PIN, rol, işletmeler, iptal) Menajerde yapılır ve tüm kasalara ulaşır.",\r
"Menajerden kasiyerler: {0}",\r
"Menajerden kasiyerler: {0} (liste {1})",\r
"Kasiyerler, PIN'ler ve roller Menajerde tüm kasalar için aynı anda girilebilir (çalışan iptali dahil). Kasa bir kez, Menajer yönetici cihazındaki kodla bağlanır (Kasa zinciri → Kasa kodu).",\r
"Kasiyerler, PIN'ler ve roller Menajerde tüm kasalar için aynı anda girilebilir (çalışan iptali dahil). Kasa bir kez, Menajer yönetici cihazındaki kodla bağlanır (Kasa zinciri → Kasa kodu).{0}",\r
"Firma anahtarı:",\r
"Kart kodu en az {0} karakterdir (kart okuyucu kendisi girer).",\r
"Kart kodu en az {0} karakterdir (kart okuyucu girer).",\r
"Kod geçersiz veya süresi dolmuş. Menajer yönetici cihazından kod gerekli (Kasa zinciri → Kasa kodu).",\r
"Operatör kodu: {0} · PIN: {1}{2}{3}{4}",\r
"Kasa kodu 12 karakterdir (ör. AB12-CD34-EF56), Menajer yönetici cihazından.",\r
"Kasa kodu Menajer yönetici cihazında görünür (Kasa zinciri → Kasa kodu). Kod bir kez girilir; sonra kasiyerler, roller ve ayarlar firma anahtarıyla imzalı olarak sunucudan gelir.",\r
"Yazıcı kod sayfası",\r
"Kısa son kullanma tarihi",\r
"Kasa zinciri: {0}",\r
"Menajer (kasa zinciri)",\r
"Menajer: {0}",\r
"Menajerde değiştirilir",\r
"Sunucuda bu firmanın kasa listesi var — yalnızca kod gerekli.",\r
"Sunucuda bu firmanın Menajer kasa listesi henüz yok (vergi no {0}). Menajer yönetici cihazının çevrimiçi olması gerekir.",\r
"Ödemeye devam et",\r
"Son 30 günde onay yok.",\r
"stok yok",\r
"Kayda göre stok yok",\r
"bağlı değil",\r
"Yeni kasiyer listeleri, ayarlar ve telefon onayları artık gelmeyecek. Menajer kasiyerleri şimdiki gibi kalır (son liste).",\r
"„Diğer\\" ile zorunlu",\r
"objekti TEXT",\r
"reddedildi",\r
"Telefondan reddedildi: {0}{1}.",\r
"Onaylar: {0}",\r
"Onayı sahip veya şef telefondan da verebilir (Menajer).",\r
"Telefondan onay",\r
"Telefondan onay kullanılamıyor (kasa Menajere bağlı değil veya kapalı). Şef PIN'i gerekli.",\r
"onaylandı",\r
"Telefondan onaylandı: {0}{1}.",\r
"Onaylayan",\r
"Onaylı diğer işlemler",\r
"Hasarlı ürün / ambalaj",\r
"PIN / kart",\r
"PIN yanlış veya bu kişi bu işlemi onaylamıyor ({0}).",\r
"İş günü başlangıcı",\r
"Menajerden ayarlar: {0}",\r
"Kasa ayarları",\r
"Nakit çekme",\r
"{1} fişinde %{0} indirim{2}{3}",\r
"Onaysız indirim (%)",\r
"Onaysız indirim 0 ile 100 arasında bir yüzdedir (boş = rol sınırı).",\r
"Sınır üstü indirim",\r
"popust_odobrio TEXT",\r
"popust_razlog TEXT",\r
"mağaza müdürü",\r
"Mağaza müdürü",\r
"bağlı",\r
"Menajere bağlandı (anahtar {0}){1}",\r
"Yeniden bağla (yeni kod)",\r
"Menajere bağla",\r
"Menajere bağla…",\r
"Menajere bağlanma",\r
"geri çekildi",\r
"Rol hakları",\r
"Rol hakları kaydedildi.",\r
"Rol hakları…",\r
"boş = ayarlardaki „Şefsiz elle indirim\\"",\r
"boş = rol sınırı",\r
"Menajer bağlantısını kesme",\r
"Bağlantıyı kes",\r
"Menajer bağlantısını kes",\r
"X raporu ve vardiya kapanışı (Z)",\r
"Kartla da giriş: kartı okuyucuya tutun.",\r
"imleç alandayken kartı okuyucuya tutun; boş = değişiklik yok",\r
"Stoksuz satış",\r
"İndirim nedeni (%{0})",\r
"İndirim nedeni zorunlu",\r
"Şikâyet",\r
"Onay talebi süresi (dk)",\r
"Elle indirim %{0} (onaysız en fazla %{1})",\r
"Elle indirim neden gerektirir",\r
"PIN ile iptal, iade, fire, indirim ve fiyatları onaylar (Rol hakları).",\r
"Şefin tüm hakları vardır. Yetkisi olmayan işlemi kasiyer onayla yapar (yetkili kişinin PIN'i veya kartı ya da Menajer üzerinden telefondan). Aynı hakları Menajer tüm kasalara gönderebilir.",\r
"şef",\r
"Rulo genişliği (mm)",\r
"Menajer listesi başka bir firma anahtarıyla imzalanmış ({0}; kasa {1} ile bağlı). Kasanın kodla yeniden bağlanması gerekir.",\r
"Menajer listesinde geçerli firma anahtarı imzası yok ve uygulanmadı.",\r
"Menajer kasiyer listesinde PIN'li etkin şef yok — „{0}\\" şefi bu kasada etkin kalır (ÜRETİM şefsiz çalışmaz).",\r
"Sürekli müşteri / sözleşme",\r
"Mutfak sipariş yazıcısı",\r
"Bar sipariş yazıcısı",\r
"Fiş yazıcısı",\r
"stok {0}",\r
"işletme stoğu (veri",\r
"işletme stoğu (veri {0})",\r
"Stok: {0}",\r
"Fiş iptali ve geçersiz kılma",\r
"Bu kart zaten başka bir kasiyere kayıtlı.",\r
"telefon",\r
"Talep eden",\r
"type=\\"password\\" inputmode=\\"numeric\\" maxlength=\\"40\\"",\r
"Kartı kaldır",\r
"„Diğer\\" ile not yazılması gerekir.",\r
"Kasa terazisi",\r
"Terazi: ağırlık barkodu",\r
"Terazi: barkod kuralları",\r
"Büyük miktar (toptan)",\r
"Menajer bağlantısı kesildi.",\r
"Menajer bağlantısı kesildi{0}",\r
"Talep sahibe ve şeflere gönderildi (Menajer → Onay bekliyor).",\r
"Talep {0}:{1} daha geçerli",\r
"Onay talebi yanıtsız sona erdi. Şef PIN'iyle onay mümkündür.",\r
"ortak (açılış yatırma, Z'de ödeme)",\r
"Çalışan",\r
"telefondan istendi: {0}",\r
"Satır başına karakter (ESC/POS)",\r
"{0}: {1} PIN'i gerekli (veya kart).{2}",\r
"PIN yanlış veya bu kişi bu işlemi onaylamıyor (onay: {0} PIN'i).",\r
"mağaza müdürü",\r
": kartı okuyucuya yaklaştırın.",\r
"{0}: kartı okuyucuya yaklaştırın.",\r
"← Çalışma girişi",\r
"bu seçenek olmadan işaretlenmemiş madde not gerektirir",\r
"Bugün kayıtlı olay yok.",\r
"Kart terminali gün sonu yapıldı",\r
"Olay",\r
"Geliş / çıkış",\r
"Geliş / çıkış: PIN girişi",\r
"kasiyer gelişi",\r
"Geliş kaydedildi",\r
"Kayıt kartla da",\r
"Çalışma süresi kaydı: çalışanı seçin, ardından PIN (veya kart). Kasa girişi değişmez.",\r
"Çalışma süresi kaydı Yönetici'de tutulur (plan ve gerçek geliş); kasa olayları gönderir.",\r
"Çekmecedeki nakit sayıldı",\r
"Kart terminali açık ve bağlı",\r
"kasa çıkış yapılmadan kapatıldı; son işlem zamanı",\r
"Kasa, yazıcı ve okuyucu çalışıyor; kağıt rulosu yerinde",\r
"Vardiya kontrol listesi",\r
"Kontrol listesi: vardiya açılışı",\r
"Kontrol listesi: vardiya kapanışı",\r
"Vardiya açılışında ve Z raporundan önce liste",\r
"Vardiya listesi",\r
"vardiya listesi ({0})",\r
"Vardiya listesi kaydedildi.",\r
"Vardiya listesi…",\r
"Bilinmeyen devam olayı türü.",\r
"madde işaretlenmediğinde zorunlu",\r
"Önceki oturumdan kasiyer çıkışı kaydedilmedi: {0}",\r
"kasadan çıkış",\r
"kasiyer çıkışı",\r
"Çıkış kaydedildi",\r
"Çekmecedeki açılış nakdi sayıldı",\r
"boş = yerleşik maddeler",\r
"Kartla da giriş",\r
"kasaya giriş",\r
"başka kasiyer giriş yaptı",\r
"Bugünkü devam",\r
"devam kaydedilmedi: {0}",\r
"Bekleyen fişler incelendi",\r
"Çalışan",\r
"Çalışma yeri temiz ve düzenli",\r
"Çalışma yeri temizlendi, cihazlar kapatıldı",\r
"Uygun olmayan madde not ile işaretsiz kalır.",\r
"Açılış maddeleri",\r
"maddeler „;\\" ile ayrılır",\r
"Kapanış maddeleri",\r
"Listedeki tüm maddeler işaretlenmelidir.",\r
"Tüm maddeler işaretlenmelidir",\r
"Tüm maddeler işaretlenmelidir.",\r
"Kayıt başarısız.",\r
"Kayıt başarısız. Çalışanı yeniden seçin.",\r
"İşaretlenmemiş maddeler için not gereklidir.",\r
", son",\r
". Aşağıdaki miktarlar iade edilmemiş olanlardır.",\r
"· kasa",\r
"· kasa {0}{1}",\r
"(arşiv)",\r
"(arşiv bölümü: {0})",\r
"(VKN {0}), kasa {1}, fiş {2}, son {3}.",\r
"(son {0})",\r
"), kasa",\r
"{0} · {1} · {2} MB",\r
"{0} ({1} tarihinden eski)",\r
"{0} MB",\r
"{0} / {1}, {2}.",\r
"{0} İade yapılmadı.",\r
"{0} fiş · {1} kalem · {2}",\r
"↩ Başka kasanın fişi",\r
"↩ Başka kasanın fişi veya eski fiş",\r
"↩ Başka kasanın fişi…",\r
"⇪ Fişleri sunucuya gönder",\r
"⚙ Arşiv ayarları",\r
"✔ Arşivi kontrol et",\r
"⟲ Yedekten geri yükleme",\r
"⟲ Yedekten geri yükleme…",\r
"📷 QR tara",\r
"🗄 Fiş arşivi",\r
"🗄 Şimdi arşivle",\r
"AND id = ?",\r
"arşiv",\r
"Arşiv boş.",\r
"Fiş arşivi bu cihazda kullanılamıyor.",\r
"fiş arşivi: {0}",\r
"fiş arşivi: {0} fiş, veritabanı {1} → {2} MB ({3} ms)",\r
"Şu kadar günden eski fişler arşivlenir (en az {0})",\r
"Arşivlenen fişlerin yaşı (gün)",\r
"Kasada arşivleme",\r
"Fiş arşivleme",\r
"Fiş arşivleme kapalı (Ayarlar → Fiş arşivi).",\r
"Eski fişlerin kasada arşivlenmesi",\r
"Arşivleme sürüyor: {0} / {1} fiş…",\r
"Arşivleme sürüyor…",\r
"{0} fiş arşivlendi ({1} kalem, arşiv bölümü: {2}). Veritabanı: {3} → {4} MB.",\r
"Arşivlenen fiş",\r
"{0} arşiv dosyası eksik. Sunucudaki kopyadan geri yüklenmesi gerekir (Diğer → Fiş arşivi → Arşivi kontrol et).",\r
"Arşiv dosyası doğru yazılmadı (geri okunan içerik farklı). Arşivleme durduruldu; veritabanı değiştirilmedi.",\r
"Kasa veritabanı",\r
"Kasa veritabanı {0} yedeğinden geri yüklendi. Önceki veritabanı saklandı ({1}). {2}{3}",\r
"kasa veritabanı açılamadı",\r
"Kasa veritabanı, programın bir sonraki başlatılışında seçilen yedekle değiştirilir. Mevcut veritabanı silinmez: kasa veri klasöründeki ayrı „Prije vraćanja\\" klasörüne taşınır. Sertifika, sunucu bağlantısı ve fiş arşivi kalır. Yedek önce kontrol edilir.",\r
"Kasa veritabanı yeniden başlatmada yedekle değiştirilir. Program şimdi kapanıp yeniden başlayacak.\\n\\nOnaylamak için VRATI kelimesini yazın.",\r
"Kasa veritabanı bu yedekle değiştirilir; mevcut (hasarlı) veritabanı silinmez. Onaylamak için VRATI kelimesini yazın.",\r
"Fiş numarası, IKOF veya fişteki QR kod",\r
"Fiş sayacı son verilen numaranın sonrasına ayarlandı: {0}.",\r
"Fiş sayacı zaten son verilen numaranın sonrasında.",\r
"Geri yüklemeden sonra fiş sayacı ayarlanmadı: {0}",\r
"Fiş sayacı ayarlandı ({0}): {1}",\r
"geri yüklemeden sonra fiş sayacı ayarlandı: {0}",\r
"Geri yüklemeden sonra fiş sayaçları kasanın verdiği son numaranın sonrasına ayarlanır (mevcut veritabanı ve sunucudaki numaralar) — hiçbir sıra numarası tekrarlanmaz.",\r
"Arşiv bölümleri",\r
"Bu arşiv bölümü bu veritabanında bilinmiyor: {0}",\r
"Bölüm sunucudaki kopyadan geri yüklenebilir („Obnovi sa servera\\" düğmesi).",\r
"dokumenti:",\r
"Arşiv dosyası okunamıyor (JSON).",\r
"Arşiv dosyası sunucudan geri yüklendi ({0} fiş).",\r
"Dosya bir kasa fiş arşivi değil.",\r
"Veritabanı boyut sınırı (MB)",\r
"Veritabanı boyut sınırı geçerli değil.",\r
"Seçilen yedek artık yok. Yedek listesini yeniden açın.",\r
"seçilen dosya bir kasa veritabanı değil",\r
"Veritabanı şu boyutu aştığında (MB, 0 = sınır yok)",\r
"kasa {0}",\r
"Kasa boştayken günde bir kez kendisi arşivler. Veritabanı boyut sınırını aştığında şu kadar eski fişler arşivlenir:",\r
"Kasa boştayken günde bir kez kendisi arşivler. Veritabanı boyut sınırını aştığında {0} günden eski fişler arşivlenir.",\r
"kasa sunucuyla eşleştirilmemiş",\r
"Kasa IRIS CORVINA sunucusuyla eşleştirilmemiş (Ayarlar → Sunucu).",\r
"kasası",\r
"{0} kasasının",\r
"{0}{1} kasasının, {2} tarihli, {3}.",\r
"En az bir kalem için miktar zorunludur (veya „Vrati sve\\").",\r
"günlük yedek (kasa klasörü)",\r
"Yedek başka bir firmaya ait (VKN {0}), kasa ise VKN {1} için çalışıyor. Geri yükleme mümkün değil.",\r
"Yedek başka bir kasaya ait ({0}), bu kasa ise {1} olarak çalışıyor.",\r
"Yedekte firma verisi ve fiş yok (boş kasa).",\r
"Yedek bir kasa veritabanı değil: {0}",\r
"Yedek geçerli değil.",\r
"Yedek tamamen okunamadı ({0} / {1} bayt).",\r
"Yedek açılamıyor: {0}",\r
"Yedek okunamıyor.",\r
"yedek yalnızca okunur",\r
"Yedek:",\r
"düzeltme",\r
"Bu fişe ait düzeltme fişleri (tüm kasalar):",\r
"Bu fişe ait düzeltme fişleri (tüm kasalar): {0}. Aşağıdaki miktarlar iade edilmemiş olanlardır.",\r
"toplu değişiklik + sıkıştırma + anlık görüntü",\r
"MB",\r
"En az {0} gün (Muhasebe için kapanış dosyası 90 günlük ürün bazlı satışı taşır).",\r
"Geçersiz arşiv dosyası adı: {0}",\r
"Hasarlı bölümler:",\r
"Hasarlı bölümler: {0} / {1}.",\r
"Arşivlenecek fiş yok.",\r
"Bu cihazda veritabanı yedeği yok.",\r
"Bu cihazda veritabanı yedeği yok. Destek ile iletişime geçin.",\r
"Bilinmeyen yedek.",\r
"Sunucudan geri yükle",\r
"Geri yüklenen arşiv dosyası doğru yazılmadı.",\r
"reddedildi: {0}",\r
"Arşivlenecek kalan: {0} (sonraki tur).",\r
"Arşiv dosyası parmak izi kasa veritabanındaki parmak izi ile uyuşmuyor (bu, bu arşiv bölümünün dosyası değil).",\r
"Arşiv dosyası içerik parmak izi kayıtlı parmak iziyle uyuşmuyor (dosya hasarlı veya değiştirilmiş).",\r
"Fiş arşivi ayarları",\r
"Vergi İdaresi bu fişi düzenleyen kasada reddetti; iade bildirilemez.",\r
"Gönderilen {0}, onaylanan {1}, gönderilmeyi bekleyen {2}.",\r
"Son arşivleme",\r
"Yedekteki son fiş",\r
"Fiş numarasını (ör. 125 veya 125/2026), IKOF'u girin ya da fişteki QR kodu tarayın.",\r
"Onay girilmedi. Yedek geri yüklenmedi.",\r
"Sunucuda onaylanan",\r
"İade — fiş {0}",\r
"sunucu kontrolü olmadan iade ({0})",\r
"Aynı firmanın başka kasasına ait veya eski fişin iadesi ve iptali (sunucu)",\r
"aynı firmanın başka kasasına ait veya eski fişin iadesi ve iptali; fişteki numara, IKOF veya QR",\r
"Aynı firmanın başka bir kasasının düzenlediği fişin veya eski (arşivlenmiş) fişin iadesi ve iptali. Fiş sunucuda numaraya (ör. 125 veya 125/2026), IKOF'a veya müşteri fişindeki QR koda göre aranır. Düzeltme fişini, orijinalin IKOF'u ile bu kasa düzenler.",\r
"İade yalnızca satış fişinden mümkündür (düzeltme fişinden veya düzeltmeden değil).",\r
"Başka kasanın fişinin veya eski (arşivlenmiş) fişin iadesi IRIS CORVINA sunucusuna bağlantı gerektirir. İade yapılmadı.",\r
"Bu fişten iade şu anda {0} kasasında yapılıyor. Bitmesini bekleyip tekrar deneyin.",\r
"sunucudan iade ({0}{1})",\r
"{0}/{1}{2}{3} fişine iade",\r
"İade, fiş no.",\r
"Yedekten geri yükleme kurulu kasada çalışır (Windows, Android).",\r
"Yedekten geri yükleme 2111 veya daha yeni kasa kurulumu gerektirir (yeni Setup).",\r
"bildirildi",\r
"Prije vracanja",\r
"Yedek kontrol ediliyor…",\r
"Kontrol sürüyor…",\r
"kontrol edildi {0}",\r
"Sunucudaki {0} fişi kasa veritabanıyla uyuşmuyor. Geri yükleme yapılmadı.",\r
"{0} fişi dosyada yok",\r
"{0} fişi: dosyadaki kalemler veritabanıyla uyuşmuyor",\r
"Otel fişi veya avanstan ödenen fiş, onu düzenleyen kasada iade edilir.",\r
"Fiş başka bir firma tarafından düzenlendi (VKN {0}). İade yalnızca bu firmanın fişleri için mümkündür.",\r
"Fiş Vergi İdaresine CANLI ortamda bildirildi, kasa şimdi test ortamında çalışıyor. İade yapılmadı.",\r
"Fiş, onu düzenleyen kasada henüz Vergi İdaresine bildirilmedi (gönderim bekliyor). Bildirildikten sonra iade mümkündür.",\r
"Fiş sunucuda bulunamadı. Onu düzenleyen kasa henüz göndermemiş olabilir (sunucu bağlantısı yok).",\r
"Fiş arşiv dosyasında yok: {0}",\r
"Fiş kendi arşiv bölümünde yok ({0}).",\r
"Hediye çekli fiş (çek satıldı veya çekle ödendi), onu düzenleyen kasada iptal ile iade edilir.",\r
"Veritabanındaki fişler",\r
"Şu anda kasadaki fişler",\r
"Yedekteki fişler",\r
"klasöre yedek (Google Drive)",\r
"Arşiv dosyası içeriği hasarlı (açma).",\r
"Arşiv dosyası içeriği okunamıyor.",\r
"Arşiv dosyası içeriği geçerli değil.",\r
"veritabanı sıkıştırma (VACUUM)",\r
"Sunucu bu işlemi desteklemiyor (daha yeni bir sunucu sürümü gerekli).",\r
"Sunucuya erişilemedi: yedekten sonra aynı kasa koduyla başka bir cihazda fiş düzenlendiyse son numarayı kontrol edin (Ayarlar → Mali kayıt → „Postavi…\\").",\r
"Sunucu fiş kalemlerini döndürmedi.",\r
"Gönderim başarısız: {0}",\r
"Fişlerin sunucuya gönderimi",\r
"Fişleri sunucuya gönder (sunucuda arşiv, başka kasada iade)",\r
"Arşive hazır",\r
"kasa arşivinde ve sunucuda eski fişler, arşiv kontrolü, yedekten geri yükleme",\r
"Vergi İdaresine bildirilmiş ve sunucuda onaylanmış eski fişler kasa diskindeki arşive gider; veritabanında kısa kayıt kalır (numara, tarih, tutar, IKOF, JIKR, ödemeler, orana göre KDV), böylece raporlar ve günlükler aynı rakamları verir ve kasa daha hızlı açılır. Arşivlenmiş fişin kalemleri arşivden okunur (görüntüleme, fiş kopyası, müfettiş günlüğü); iade ve iptal sunucu üzerinden yapılır.",\r
"Arşivdeki kalemler (KDV oranına göre toplam)",\r
"Tüm arşiv bölümleri geçerli ({0}).",\r
"o zaman {0} günden eski fişler arşivlenir",\r
"Yedekler aranıyor…",\r
"Sunucuda aranıyor…",\r
"Başka kasanın fişini aramak IRIS CORVINA sunucusuna bağlantı gerektirir (Ayarlar → Sunucu).",\r
"Yedekte {0} fiş, kasada {1} fiş var: yedekten sonra düzenlenen {2} fiş kasa veritabanında olmayacak (sunucuda ve Vergi İdaresinde kalır). Geri yüklemeden sonra fiş sayaçları son verilen numaranın sonrasına ayarlanır.",\r
"Kasa veritabanının {0} yedeğinden geri yüklenmesi",\r
"Arşiv bölümünün veritabanına geri alınması",\r
"Yedekten geri yükleme",\r
"Yedekten geri yükleme başarısız: {0} Kasa mevcut veritabanıyla çalışıyor.",\r
"{0} yedeğinin geri yüklenmesi",\r
"vracen",\r
"veritabanına geri alındı",\r
"Veritabanına geri alınan: {0} fiş.",\r
"VRATI",\r
"Yedeği geri yükle",\r
"Bu yedeği geri yükle",\r
"İade edilmemiş her şeyi iade et",\r
"Veritabanına geri al",\r
"— “NLB/Payten — aynı cihazda” (NLB/Payten bölümünde ayarlanır); kasa başka bir cihazdaysa — “NLB/Payten — ağ / Bluetooth üzerinden”:",\r
"— fiş, aynı tutarın bir sonraki tahsilatında bu ödemeyle düzenlenir.",\r
", bu nedenle kasa bağlantıyı kontrol eder, tutar terminalde girilir (onay numarasının manuel onayı).",\r
", sürüm {0}",\r
"(Castles Saturn1000, Android) tutarı aynı cihazdaki NLB “Powered by Payten” uygulamasına gönderir ve sonucu okur: onay numarası, maskeli kart, kart türü. Kasa kart işlemez. İptal ve slip kopyası Payten uygulaması üzerinden yapılır.",\r
"(Castles)",\r
"(yazıcı)",\r
"{0}\\n\\n(Özet kopyalandı — Payten / Castles'a iletilebilir.)",\r
"{0} (sonuç kasa yeniden başlatıldıktan sonra alındı)",\r
"{0}{1}{2} [sınıf {3}]",\r
"978 veya EUR",\r
"adres (şablon)",\r
"Eylem: kopya",\r
"Eylem: iade",\r
"Eylem: özet",\r
"Eylem: satış",\r
"Eylem: iptal",\r
"Aktivite (sınıf)",\r
"aktiviteler: {0}",\r
"{0} uygulaması bu cihazda yüklü değil.",\r
"NLB/Payten uygulaması Android terminalde çalışır (kasa aynı cihaza kurulu).",\r
"Payten uygulaması iptal edilen aktiviteyle birlikte “onaylandı” bildirdi.",\r
"Payten uygulaması farklı bir tutar tahsil etti ({1} yerine {0}).",\r
"Payten uygulaması başka bir ödemenin sonucunu döndürdü.",\r
"Payten uygulaması sonuç vermeden kapandı.",\r
"Payten uygulaması bu işlemi kasadan kabul etmez — uygulamanın kendisinde yapılır (İptal / Kopya / Özet).",\r
"Payten uygulaması bu cihazda bulunamadı.",\r
"Payten uygulaması ödeme sonucunu döndürmedi.",\r
"Payten uygulaması kasaya zamanında yanıt vermedi.",\r
"Payten uygulaması: {0} {1}{2}",\r
"Uygulama sonuçsuz kapandı",\r
"Ödeme uygulamaları: {0}",\r
"APPROVED,OK,SUCCESS,00,000",\r
"Bluetooth (eşleşmiş): {0}",\r
"Bluetooth {0}",\r
"sent (sayı)",\r
"sent (metin)",\r
"DECLINED,REJECTED,DENIED,FAILED,05,51,55",\r
"Doğrudan fiş yazdırma (ESC/POS) Ayarlar → Eklentiler bölümünde ayarlanır. Kağıt durumu burada kontrol edilir: Sunmi üretici servisiyle, diğer ESC/POS yazıcılar “DLE EOT 4” sorgusuyla (yazıcı sorguya yanıt vermelidir). NLB terminali Castles Saturn1000: “Terminalin dahili yazıcısı” (57 mm rulo = 32 karakter) — kasa, cihazın USB veya Bluetooth aygıtı olarak sunduğu yazıcıyı arar; Castles yazıcı SDK'sı herkese açık değildir, bu nedenle cihazda doğrulanana kadar bu bir varsayımdır (“Cihaz özeti” düğmesi). Doğrudan yazdırma başarısız olursa fiş Android yazdırma sistemi üzerinden yazdırılır. Sahada toptan satış için: 58 mm (32 karakter) veya 80 mm (48 karakter) Bluetooth yazıcı kurumsal müşteriyi (ad, vergi no, adres) ve kart onay numarasını da yazdırır.",\r
"Payten App-to-App spesifikasyonunu verene kadar (herkese açık değil) — spesifikasyona göre girilir. “proba” paketi = akışı denemek için sahte Payten uygulaması. Terminal türü “NLB/Payten — aynı cihazda” olmalıdır.",\r
"DRUGA{0}",\r
"“Payten uygulamasını bul” düğmesi veya proba",\r
"bankanın ECR spesifikasyonu henüz mevcut değil",\r
"NLB/Payten terminaliyle ECR bağlantısı bankanın spesifikasyonunu bekliyor — tutar terminale gönderilmez.",\r
"EUR “12.50” (metin)",\r
"EUR (sayı)",\r
"IP, Bluetooth adresi, InnerPrinter, USB “vid:pid” (boş = ilk USB yazıcı; dahili: boş = otomatik bulunur)",\r
"Tek alanda JSON",\r
"JSON: istek alanı",\r
"Kasa kurulu",\r
"Kasa tutarı terminale gönderir, terminal sonucu döndürür (onay numarası, maskeli kart, kart türü). Fiş ancak terminal ödemeyi onayladıktan sonra düzenlenir. NLB terminali (Castles Saturn1000, NLB “Powered by Payten” uygulaması): kasa kurulu olduğunda",\r
"Kopya",\r
"Kopya (deneme)",\r
"Son slipin kopyası",\r
"Slip kopyası (deneme).",\r
"Kasadan slip kopyası",\r
"Slip kopyası yazdırıldı.",\r
"Slip kopyası terminalde yapılır.",\r
"Müşteri vazgeçti (deneme)",\r
"müşteri vazgeçti (karttan çekilmedi)",\r
"Sahte Payten uygulaması (deneme)",\r
"ağ {0}",\r
"NLB terminalinde",\r
"terminalin kendisinde",\r
"Payten uygulaması bulundu: {0}. Paket alanına girildi — kaydetmek için “Kaydet”.",\r
"Birden fazla olası uygulama bulundu ({0}) — paket elle girilir.",\r
"Bu cihazdaki NLB/Payten uygulamasında ödeme: müşteri kartı okutur, takar veya geçirir.",\r
"Payten uygulamasında bir ödeme zaten sürüyor.",\r
"Eylem ve alan adları (Payten spesifikasyonuna göre)",\r
"Aşağıdaki adlar bir varsayımdır",\r
"belirsiz — kasiyer uygulamadaki Özet'i kontrol eder",\r
"Payten uygulamasından bilinmeyen sonuç: {0}",\r
"hiçbiri bulunamadı (Payten, NLB, Castles).",\r
"Payten uygulaması girilmemiş (Daha fazla → Kasa cihazları → NLB/Payten → Payten uygulamasını bul).",\r
"Payten uygulaması girilmemiş.",\r
"Yapılmadı.",\r
"NLB/Payten — aynı cihazda (App-to-App)",\r
"NLB/Payten — ağ / Bluetooth üzerinden (ECR, spesifikasyon bekleniyor)",\r
"örn. sema://pay?amount={centi}&ref={ref}&callback={povratak}",\r
"Tutar biçimi",\r
"Payten uygulama paketi",\r
"PAYTEN-PROBA",\r
"PENDING",\r
"Intent alanları",\r
"Terminal numarası alanı",\r
"Tahsil edilen tutar alanı",\r
"Dönüş adresi alanı",\r
"İşlem türü alanı",\r
"port {0}",\r
"Kasa uygulamasının yeni sürümü gerekli (NLB/Payten).",\r
"Kasa uygulamasının yeni sürümü gerekli.",\r
"Kasadan karta iade",\r
"kasa dönüş adresi (iriskasa://placanje/…)",\r
"Kasa dönüş adresi bu uygulama sürümünde kullanılamıyor.",\r
"Dönüş adresi bu ödemenin referansını taşımıyordu.",\r
"boş = aynı",\r
"boş = gönderilmez",\r
"boş = eyleme göre",\r
"boş = uygulama başlangıç ekranı",\r
"boş = sonuç alanlarda",\r
"Kasadan özet (gün sonu)",\r
"Cihaz özeti",\r
"Cihaz özeti Android cihazda çalışır.",\r
"Cihazda deneme uygulaması",\r
"Payten uygulamasını bul",\r
"PT{0}",\r
"Payten uygulamasında yapılır.",\r
"REFUND",\r
"REPORT",\r
"REPRINT",\r
"Sonuç",\r
"aktivite sonucu",\r
"Sonuç: JSON alanı",\r
"Adres şablonu",\r
"SALE",\r
"Android yazdırma servisleri: {0}",\r
"servisler: {0}",\r
"Üretici sistem kütüphaneleri: {0}",\r
"Kasadan iptal (aynı gün)",\r
"İptal: onay numarası alanı",\r
"İptal: orijinal referans alanı",\r
"İptal: RRN alanı",\r
"terminal: slip kopyası {0}",\r
"terminal: yeniden başlatma sonrası sonuç {0}",\r
"Terminalin dahili yazıcısı (Castles Saturn1000 ve benzerleri)",\r
"terminalin dahili yazıcısı (Castles Saturn1000)",\r
"Bu cihazdaki deneme Payten uygulaması girildi (kasadaki aktivite: Onayla / Reddet / Vazgeç / Sonuçsuz). “Kaydet”, ardından “Ödeme denemesi”.",\r
"Yapıldı.",\r
"Cihaz: {0} {1}, Android {2}{3}",\r
"USB cihazları: {0}",\r
"Terminal bağlantısı var ({0}). {1}",\r
"VOID",\r
"Reddedildi için değerler",\r
"Tür: kopya",\r
"Tür: iade",\r
"Tür: özet",\r
"Tür: satış",\r
"Tür: iptal",\r
"Adres biçimindeki istek için adres şablonu gerekir (NLB/Payten → Adres şablonu).",\r
"İstek",\r
"— uygulayıcı yok —",\r
"— başka saat —",\r
"— yok (yalnızca ad) —",\r
"; avans “Diğer ödeme yöntemleri”nde seçilir",\r
"· avans {0}",\r
"· avans {0} · tahsil edilecek",\r
"· garanti {0} ay",\r
"· sınır {0}",\r
"· uygulayan {0}",\r
"· tahsil edildi",\r
"· PIB {0}",\r
"· hatırlatma gönderildi",\r
"· hesap {0}",\r
"· tahsil edilecek",\r
"(tekliften sonra)",\r
"{0} · {1} · {2} dk",\r
"{0} · {1} dk",\r
"{0} · KDV %{1} · {2}",\r
"{0} {1}: iptal nedeni",\r
"{0} ay",\r
"randevudan {0} ay sonra",\r
"{0}, randevu planlamak, randevu değişikliklerini bildirmek ve ayrı onayla randevudan önce e-posta hatırlatması göndermek için müşterinin adını, telefon numarasını ve e-postasını işler. Veriler, işleyen (IRIS CORVINA, program sunucusu) dışında üçüncü kişilere verilmez. Telefon ve e-posta {1} silinir; müşteri her zaman verilere erişim, düzeltme veya silme talep edebilir ve onayını geri çekebilir.",\r
"{0}: iş emrindeki fiyat ({1}) kasa fiyat listesinden ({2}) yüksek",\r
"{0}: kasa ürün kodu yok",\r
"{0}: katalogdaki KDV oranı (%{1}) iş emrinden (%{2}) farklı",\r
"{0}Müşteri",\r
"% yazılı onay gerektirir (Tüketici Koruma Kanunu, md. 21).",\r
"% müşterinin önceden yazılı onayını gerektirir. Kabul edilen teklifi servis ve müşteri imzalar; bir nüsha müşteriye verilir.",\r
"+ Yeni randevu",\r
"+ Cihaz / araç kabulü",\r
"+ Kalem (işçilik, parça, malzeme)",\r
"⚙ Hizmetler — ayarlar",\r
"✍ imza",\r
"✍ Müşteri imzası",\r
"👤 Uygulayana göre satış",\r
"📅 Randevular",\r
"📅 Randevular{0}",\r
"📷 Cihaz fotoğrafı",\r
"🔧 İş emirleri",\r
"🔧 Servis iş emirleri",\r
"🔧 İş emirleri{0}",\r
"🖨 Teklif",\r
"🖨 Kabul belgesi",\r
"🖨 İş emri",\r
"Ürün kasa kataloğunda yok.",\r
"Avans — iş emri {0}, {1}",\r
"Avans — randevu {0} {1}, {2}",\r
"Avans faturası düzenlendi ({0}).",\r
"yok",\r
"IKOF olmadan",\r
"Uygulayıcı yok",\r
"Renk (#RRGGBB, isteğe bağlı)",\r
"Müşteri verilerinin silinmesi",\r
"Müşteri verilerinin silinmesi (kişisel verilerin korunması)",\r
"Talep üzerine müşteri telefonunun ve e-postasının silinmesi",\r
"numara, müşteri, seri no, plaka",\r
"parça bekleniyor",\r
"Parça bekleniyor",\r
"onay bekleniyor",\r
"Parça beklemek, onaylanmış veya üzerinde çalışılan bir iş emrinin aşamasıdır.",\r
"KDV hariç fiyat",\r
"Fiyat müşteri onayını aşıyor: tahsilattan önce yazılı onay gerekir.",\r
"Fiyat onaya göre %{0} üzerinde arttı ({1} € → {2} €): müşterinin yazılı onayı kaydedilene kadar iş emri tamamlanmaz ({3} fıkra 2).",\r
"Gün geçerli değil.",\r
"Tarih ({0}) kabul tarihi {1} öncesinde",\r
"Tarih ({0}) gelecekte.",\r
"Tarih ({0}) geçerli değil.",\r
"Tarih veya saat geçerli değil.",\r
"Teslim alma tarihi tamamlanma tarihinden önce.",\r
"Kabul tarihi",\r
"Teşhis",\r
"Teşhis, kabul edilmiş iş emrinin aşamasıdır (müşteri onayından önce).",\r
"yemek eki",\r
"İkinci hizmet",\r
"Başka saat (SS:DD)",\r
"elektronik (e-posta, mesaj)",\r
"en-GB",\r
"Dosya bir görsel değil.",\r
"İşçilik garantisi",\r
"İşçilik garantisi (ay)",\r
"Garanti: ay sayısı.",\r
"Aynı telefon / e-posta ile tüm diğer randevularda da",\r
"Müşterinin adı soyadı",\r
"Müşteri adı girilmedi.",\r
"Randevu düzenleme",\r
"Üzerinde",\r
"{0} üzerinde onay imzalı tekliftir; %{1} üzeri artış yazılı onay gerektirir (Tüketici Koruma Kanunu, md. 21).",\r
"Avans tutarı geçerli değil.",\r
"KDV dahil tutar, indirim sonrası; iptaller satışı azaltır. “—” = uygulayanı olmayan kalemler (mal, hizmet dışı kalemler).",\r
"uygulayıcı",\r
"Uygulayıcı",\r
"Uygulayan (ad)",\r
"uygulayıcı (kişi)",\r
"Uygulayan / yer",\r
"Uygulayan / yer: artık aktif değil",\r
"izvrsilac TEXT",\r
"Hizmeti uygulayan",\r
"Uygulayan:",\r
"Uygulayanlar Hizmetler → Ayarlar'da girilir (kasa veya Yönetici).",\r
"uygulayanlar, yerler, hizmet süresi ve malzemeler; yalnızca yönetici",\r
"uygulayana ve yere göre takvim, randevu, randevu → fiş, avans",\r
"Müşteri",\r
"Müşteri (ad soyad veya unvan)",\r
"Müşteri teklifi reddetti, cihaz onarılmadan iade ediliyor mu?",\r
"müşteri geldi",\r
"Müşteri girilmedi.",\r
"Müşteri cihazın teslimini ve kabul belgesindeki bilgileri onaylar.",\r
"Müşteri teslim aldı",\r
"Müşteri tamamlanmış cihazı teslim alır (şu an: {0}). Reddedilen teklifteki cihaz \\"reddedildi\\" işlemiyle iade edilir.",\r
"Müşteri e-posta ile hatırlatma istiyor",\r
"Cihazı ({0}) kim teslim alıyor?",\r
"Kasiyer / operatör kodu (isteğe bağlı)",\r
"Miktar (işçilik: saat)",\r
"İletişim",\r
"İletişim (telefon, e-posta)",\r
"Alıcı (firma)",\r
"Firma alıcı {0}: fiş firmaya düzenleniyorsa alıcıyı fişe girin (Alıcı düğmesi).",\r
"Firma alıcı: unvan",\r
"Firma alıcı: vergi no (isteğe bağlı)",\r
"Arıza / talep",\r
"Malzeme “{0}”: katalog kodu ve hizmet başına miktar.",\r
"Ücretlendirilen malzeme (kod:miktar, …)",\r
"Malzeme kasa kataloğunda yok: {0}",\r
"Fiyata dahil malzeme (kod:miktar, …)",\r
"hizmet malzemesi",\r
"Hizmet malzemesi hizmet miktarını izler.",\r
"yer (koltuk, bölme, salon)",\r
"Yer (koltuk, bölme, salon)",\r
"Ekranda giriliyor olan bir fiş var: tahsil edilmeli veya beklemeye alınmalı.",\r
"müşteri talebiyle",\r
"Onay şekli",\r
"Müşteri onay yöntemi seçilmedi.",\r
"İş emri {0}",\r
"İş emri {0} ekranda{1}.",\r
"İş emri {0} tahsil edildi; yalnızca teslim alma değiştirilebilir.",\r
"İş emri {0} tahsil edildi; kalemler değiştirilemez.",\r
"İş emri {0} kabul edildi.",\r
"İş emri {0} kapalı ({1}); kalemler değiştirilemez.",\r
"İş emri {0}: kabulde müşteri imzası ve kabul belgesi yazdırılsın mı?",\r
"İş emrinde yapılan iş, parça ve malzeme kalemi yok.",\r
"İş emrinde kalem yok: onay; iş, parça ve malzeme içeren teklife verilir.",\r
"İş emri bulunamadı.",\r
"İş emri kasada tahsil edilemez: {0}. Muhasebe faturası ile tahsil edin veya kalemleri düzeltin.",\r
"Ad girilmedi.",\r
"Artık aktif değil",\r
"Bilinmeyen iş emri aşaması.",\r
"Bilinmeyen iş emri işlemi.",\r
"gelmedi",\r
"Gelmedi",\r
"Kasa kataloğunda yok (fişte değil): {0}",\r
"Yeni uygulayan",\r
"Yeni uygulayan (kuaför, teknisyen, doktor)",\r
"Yeni randevu — hizmetler ve uygulayan",\r
"Yeni yer",\r
"Yeni yer (koltuk, bölme, salon)",\r
"örn. Dell 5420 dizüstü, Golf 7",\r
"Telefonu ve e-postayı sil",\r
"Teklif veya fiyat artışı reddedilir (şu an: {0}).",\r
"Reddedildi / iade edildi",\r
"Arıza açıklaması / talep",\r
"Arıza açıklaması / müşteri talebi",\r
"Arıza açıklaması girilmedi.",\r
"Ekipman",\r
"Cihazla teslim edilen ekipman",\r
"Matrah {0} · KDV {1} ·",\r
"Randevuyu iptal et",\r
"Randevu iptali",\r
"Hizmetten sonra ara (dk)",\r
"e-posta veya mesajla yazılı onay",\r
"şahsen verilen yazılı onay",\r
"yazılı (imza)",\r
"ürüne göre (hizmet = işçilik, mal = parça)",\r
"Müşteri verileri silindi (randevu: {0}).",\r
"Hizmet ayarları",\r
"Hatırlatma e-posta ile gider: müşterinin e-postasını girin.",\r
"Müşteri hatırlatması, çalışma saatleri ve veri saklama süresi: Yönetici → Hizmetler → Ayarlar.",\r
"Teklif",\r
"teklif verildi",\r
"Müşteriye teklif",\r
"Teklifte kalem yok: fiyatlarıyla iş, parça ve malzeme girin.",\r
"İşçilik, malzeme ve parça dökümlü teklif (Tüketici Koruma Kanunu, md. 21). Fiyatın şu orandan fazla artması:",\r
"İşçilik, malzeme ve parça dökümlü teklif (Tüketici Koruma Kanunu, md. 21). Fiyatın %{0} üzerinde artması müşterinin önceden yazılı onayını gerektirir. Kabul edilen teklifi servis ve müşteri imzalar; bir nüsha müşteriye verilir.",\r
"Teklif, kabul edilmiş iş emri veya fiyat artışı onayı bekleyen iş emri için verilir (şu an: {0}).",\r
"ONARIM TEKLİFİ",\r
"Hizmetle birlikte ayrı fiş kalemi.",\r
"Tahsilattan sonra stoktan düşülür (tüketim, fişte değil).",\r
"İmza ve yazdır",\r
"İmza boş.",\r
"İmza iş emrine kaydedildi.",\r
"Müşteri imzası —",\r
"Müşteri imzası — {0}",\r
"imzalı teklif (iki taraf)",\r
"onaylandı",\r
"Randevu için önerilen avans (€)",\r
"Konu",\r
"Nesne (cihaz, araç)",\r
"Nesne girilmedi.",\r
"Teslim alan",\r
"Teslim alındı",\r
"Teslim",\r
"Kabul",\r
"Cihaz / araç kabulü",\r
"cihaz veya araç kabulü, durum, parça ve işçilik, teklif ve onay, tahsilat",\r
"Kabul belgesi",\r
"KABUL BELGESİ",\r
"Ek görüntülenemiyor.",\r
"Ekler",\r
"Kabul et",\r
"Onay",\r
"onay imzalı tekliftir; şu oranın üzerindeki artış:",\r
"Müşteri onayı",\r
"Onay, teklifli iş emri veya fiyat artışı için kaydedilir (şu an: {0}).",\r
"Uygulayana göre satış",\r
"Uygulayana göre satış {0} – {1}",\r
"Fiş {0} — hizmet fiyatına dahil malzeme",\r
"İş, müşteri onayından sonra başlar (şu an: {0}).",\r
"İş emri",\r
"İŞ EMRİ",\r
"İş emri {0} — {1}",\r
"İş emirleri",\r
"Servis iş emirleri",\r
"Sunucu kuyruğu:",\r
"Sunucu kuyruğu: {0} kayıt kabul edilmedi — {1}",\r
"RN-{0}-{1}",\r
"İmzayı kaydet",\r
"Müşteri onayı (telefon, e-posta)",\r
"Seri numarası / plaka",\r
"Sunucuda henüz hizmetler yok (eski sunucu sürümü).",\r
"Servis",\r
"servis işe başlamadan yazılı teklif verir. Cihaz bu kabul belgesiyle teslim alınır.",\r
"Ürün kodu veya barkodu (katalogdan)",\r
"Fotoğraf iş emrine eklendi.",\r
"Resim okunamıyor.",\r
"Ne ayarlanıyor",\r
"Teklif müşteri imzası için yazdırılsın mı?",\r
"Kabuldeki durum",\r
"Kabuldeki durum (hasarlar)",\r
"Kalem \\"{0}\\": fiyat geçerli değil.",\r
"Kalem \\"{0}\\": miktar sıfırdan büyük olmalı.",\r
"Kalem \\"{0}\\": KDV oranı %21, 15, 7 veya 0.",\r
"Kalem \\"{0}\\": tür iş, parça veya malzeme.",\r
"İş emri kalemi",\r
"Kalemin adı yok.",\r
"Geldi",\r
"Hizmet KDV oranı",\r
"Tümü (30 gün)",\r
"Müşterinin telefonu ve e-postası sunucudan silinir; ad baş harfler olarak kalır. Silme geri alınamaz.",\r
"Telefon ve e-posta yalnızca müşteri onayıyla girilir (onay şeklini seçin).",\r
"Randevu {0} ({1}) ekranda{2}.",\r
"Randevu değiştirildi.",\r
"Randevu oluşturuldu: {0} {1}.",\r
"Randevu: {0}",\r
"Randevular",\r
"Randevular —",\r
"Randevular — {0}",\r
"Randevular ve iş emirleri kasanın sunucuya bağlı olmasını gerektirir (Ayarlar → Sunucu).",\r
"Süre (dk)",\r
"Hizmet süresi ve malzemesi",\r
"Süre: en az 5 dakika.",\r
"Yer gerektirir (koltuk, bölme, salon)",\r
"yazılı teklif gerektirir",\r
"Üçüncü hizmet",\r
"Kasa kataloğunda hizmet yok (Muhasebe kataloğunda “Hizmetler” grubu).",\r
"üzerinde çalışılıyor",\r
"Üzerinde çalışılıyor",\r
"Takvimden kaldır",\r
"Toplam {0}",\r
"KDV dahil toplam",\r
"kayıt kabul edilmedi —",\r
"Onayı kaydet",\r
"Hizmet",\r
"Katalogdan hizmet",\r
"Hizmet ayarlandı.",\r
"Hizmetler — ayarlar",\r
"Hizmetler (randevular, iş emirleri, uygulayan)",\r
"döneme göre uygulayan bazında hizmetler; yalnızca yönetici",\r
"Randevu hizmetleri kasa kataloğunda yok: {0}",\r
"Hizmetler: {0} sunucu kaydı kabul edilmedi (Hizmetler → Randevular → Sunucu kuyruğu).",\r
"sözlü (yazılı teklif eşiğine kadar)",\r
"sözlü (şahsen veya telefonla)",\r
"Malzeme tüketimi kaydedilmedi: {0}",\r
"hizmet için malzeme tüketimi",\r
"iade",\r
"Planlananlara geri al",\r
"Onarım tutarı {0} €, {1} € üzerinde: servis ve müşteri tarafından imzalanan, iş, malzeme ve parçaları belirten yazılı teklif gerekir ({2} fıkra 1 ve 3).",\r
"Onarım tutarı {0} €, {1} € üzerinde: onaydan önce iş, malzeme ve parçaları belirten yazılı teklif verilir ({2} fıkra 1).",\r
"Saat (müsait)",\r
"Randevu saati: SS:DD.",\r
"Firma için: firmaya fiş veya fatura.",\r
"{0} € üzerindeki onarımda kabul edilen teklifi servis ve müşteri imzalar; bir nüsha müşteriye verilir ({1} fıkra 3).",\r
"Değeri şundan fazla olan onarım için:",\r
"Değeri {0} üzerindeki onarım için servis işe başlamadan yazılı teklif verir. Cihaz bu kabul belgesiyle teslim alınır.",\r
"%{0} üzerindeki fiyat artışı için müşterinin şahsen veya uzaktan iletişim araçlarıyla verilmiş önceden yazılı onayı gerekir ({1} fıkra 2).",\r
"Planla",\r
"Tüketici Koruma Kanunu (\\"KD Resmî Gazetesi\\" 12/26), md. 21",\r
"Üzerinde çalışılan iş emri tamamlanır (şu an: {0}).",\r
"tamamlandı (tahsil edildi)",\r
"Tamamlandı",\r
"tamamlama",\r
"Kalem toplamı ({0} €) verilen tekliften ({1} €) %{2} fazla: yeni teklif verin.",\r
", stok {0}",\r
"· fark {0}.",\r
"(veya kart)",\r
"(nakit fişler + yatırılan − çekilen).",\r
"{0}\\n\\nÜrünün fiziksel olarak burada olduğunu onaylıyor musunuz? Satış kaydedilir, fark sayımda görünür.",\r
"{0}: {1} PIN'i gerekli{2}.{3}",\r
"📣 Yöneticiye bildir: ürün tükeniyor",\r
"“{0}” ürünü kasa kataloğunda yok.",\r
"hızla tükenen ürün (bugün / yarın); uyarılara ve şube ikmal önerisine gider",\r
"Ürün seçilmedi.",\r
"Şirket müşterisine avans faturası (fatura mali onayı)",\r
"Teslim etmeden",\r
"Şirket müşterisine nakitsiz fatura (fatura mali onayı)",\r
"Kupürlere göre sayıyorum",\r
"başka ürün — kod veya barkod",\r
"Fatura mali onayı",\r
"ve ikmal ile sipariş önerisine girer. Bağlantı yoksa bekler ve sonraki kasa dosyasıyla gönderilir.",\r
"kapalı = ad ve PIN ile giriş",\r
"Yöneticiye bildir: ürün tükeniyor",\r
"Kasiyer kendi payının sayılan nakdini girer; kasiyere göre fark X ve Z raporundadır",\r
"Yönetici bilgilendirildi: {0} — {1}.",\r
"Açık vardiya veya giriş yapmış kasiyer yok.",\r
"ürün seçildiyse isteğe bağlı",\r
"bugün tükeniyor",\r
"yarın tükeniyor",\r
"önümüzdeki günlerde tükeniyor",\r
"yasal zorunluluk değildir (Tüketici Koruma Kanunu fişte fiyat, yüzde ve indirim tutarını ister)",\r
"ör. 3 adet kaldı, müşteriler soruyor",\r
"Beklenen:",\r
"{0} için beklenen:",\r
"Mağaza müdürü yalnızca kasiyer ve garson ekler ve değiştirir. Şef ve mağaza müdürünü şef ekler.",\r
"Bir ürün seçilmeli veya kod girilmelidir.",\r
"Sayılan nakit girilmelidir (ör. 125,50).",\r
"Satışı onaylıyorum",\r
"Payımın sayılan nakdi (€)",\r
"Teslim et",\r
"Nakit teslimi — {0}",\r
"Kasiyer {0} nakit teslimi: sayılan {1} €, beklenen {2} €",\r
"Nakit teslimi: {0} {1}{2}",\r
"Nakdimi teslim et…",\r
"Nakit teslimini giriş yapmış kasiyer yapar.",\r
"teslim etti {0}",\r
"Kasiyerin kartla girişi",\r
"Kod veya barkod (başka ürün)",\r
"Kasiyerin bu vardiyada aldığı nakit girilir (çekmecedeki payı).",\r
"Toplamı giriyorum",\r
"Uyarı şube yöneticisine gider:",\r
"Toplu fatura (fatura mali onayı)",\r
", vadesi geçmiş {0}",\r
", borç tahsilatı",\r
", vade {0}",\r
"· KDV hariç",\r
"· KDV hariç {0}{1} · matrah {2} · KDV {3}{4}",\r
"· limit {0}",\r
"· matrah",\r
"· iskonto {0} %",\r
"( ) borç ödemesi olarak .",\r
"({0}) borç ödemesi olarak{1}.",\r
"(faturasız — borca ödeme)",\r
"(limit {0}, borç {1}).",\r
"(en eskisi {0} UTC)",\r
"(Muhasebe verisi)",\r
"{0} — mal durumu",\r
"{0} — depoya iade (mevcut {1})",\r
"{0} — fiş {1}",\r
"{0} — hasarlı",\r
"{0} · VKN {1}{2}",\r
"{0} (müşteride {1})",\r
"{0} (istenen {1}, mevcut {2})",\r
"{0} mali fiş 36 saatten uzun süredir Vergi İdaresi onayını (JIKR) bekliyor (en eskisi {1}). Teslim süresi iki gündür (Mali Kayıt Kanunu, md. 17). Kasa en kısa sürede internete bağlanmalı; süre dolmadan mümkün değilse Vergi İdaresine bildirilmelidir.",\r
"{0} Nakit ödeme izinli değil (kasa ayarı). Kart veya havale ile ödenebilir.",\r
"{0} Nakit ödeme mümkün değil.",\r
"{0} / {1}{2} — açık {3}",\r
"{0} Araç stoğunun üzerinde satış yapılamaz.",\r
"{0}: ambalaj miktarı tam adet olmalıdır.",\r
"{0}: araçta {1}.",\r
"{0}: istenen {1}, mevcut {2}",\r
"♻ Ambalaj iadesi",\r
"💶 Borç tahsilatı",\r
"📋 Sürücü hesap kapanışı",\r
"📶 Vergi onayı olmayan fişler",\r
"🖨 A4 fiş",\r
"🚚 Araç stoğu",\r
"Ambalaj",\r
"Ambalaj satış konusu değildir ve KDV matrahına girmez; iade edilir veya değeriyle borçlandırılır.",\r
"Ambalaj satış konusu değildir ve KDV matrahında yoktur.",\r
"Onaysız düzenlenmez",\r
"Kontrol yok",\r
"Pazar ve tatillerde uyarı yok",\r
"BLOKELİ",\r
"vadeli ödeme için blokeli",\r
"Numara {0}",\r
"Müşterinin iade ettiği adet. Ambalaj yalnızca kayıt amaçlı izlenir (KDV Kanunu md. 20/13).",\r
"kasa fiyatı",\r
"fiyat listesi {0}",\r
"crveno",\r
"Tarih {0}",\r
"Tarih ve saat",\r
"Borç",\r
"borç {0}",\r
"Borç {0}{1}{2}{3} (Muhasebe verisi)",\r
"Kayıt belgesi",\r
"kurumsal müşteriden kasa, şişe, palet; müşterideki ambalaj bakiyesi",\r
"Sunucu uyarısıyla müşteri {0} nakit (toplam ≥ 10.000 €), onaylayan {1}: {2}",\r
"Müşteriden 10.000 € toplamı aşan nakit (bağlantılı işlemler)",\r
"Satıştan nakit",\r
"Satıştan nakit {0}, borç tahsilatı {1}.{2}",\r
"Nakit kabul edilmez",\r
"ACİL: {0} mali fiş 48 saatten uzun süredir Vergi İdaresi onayını (JIKR) bekliyor (en eskisi {1}). Bağlantısız düzenlenen fişlerin teslim süresi iki gündür (Mali Kayıt Kanunu, md. 17). Kasa hemen internete bağlanmalı; mümkün değilse gecikme nedeni Vergi İdaresine bildirilmelidir.",\r
"Sağlam (stoğa döner)",\r
"araçtan",\r
"Seç",\r
"Verilen",\r
"Müşterilere verilen",\r
"Tutar {0} faturasının açık kısmından ({1} €) büyük.",\r
"Tahsilat tutarı geçersiz.",\r
"Fiş tutarı {0} müşterinin kullanılabilir limitini {1} aşıyor{2}",\r
"KDV dahil tutar",\r
"Muhasebedeki gibi. Nakit ve kart fişleri limit kontrolü olmadan düzenlenir.",\r
"kart",\r
"Kasa (ENU) {0}",\r
"onaylayıcısız kasa",\r
"KOPYA",\r
"DÜZELTME FİŞİ (İADE)",\r
"Müşteri {0} vadeli ödeme için blokeli{1}.",\r
"Müşteri kurumsal müşteri listesinde yok.",\r
"Ödemeden önce müşteri zorunlu",\r
"kurumsal müşteri açık faturayı veya borcu öder; makbuz (mali fiş değildir), nakit kasaya",\r
"limit {0}",\r
"Müşteri limiti ve blokajı (havale, vadeli)",\r
"Müşteri limiti",\r
"Araçta yeterli mal yok: {0}. Fiş düzenlenmedi.",\r
"Kalem azami miktarı",\r
"En fazla {0} (faturanın açık kısmı).",\r
"Borç tahsilatı",\r
"Borç tahsilatı (nakit)",\r
"Onaylı nakit borç tahsilatı ({0}) — {1}",\r
"Tahsilat kaydedildi: {0} ({1}).",\r
"Sahada tahsilat.",\r
"Devam",\r
"Düzenlenmez",\r
"Bu VKN veya adla kurumsal müşteri yok. Kurumsal müşteriler Muhasebeden gelir (kasa paketi).",\r
"Bilinmeyen ambalaj kalemi: {0}",\r
"Müşterilerde net",\r
"Mali fiş değildir",\r
"Hiç ambalaj miktarı girilmedi.",\r
"Bu kasanın işyeri toptandır. \\"Toptan\\" modu Ayarlar → Çalışma modu bölümünden seçilir.",\r
"Bu kasanın işyeri bir araçtır (seyyar işyeri). \\"Saha\\" modu Ayarlar → Çalışma modu bölümünden seçilir.",\r
"Muhasebede bu kasanın işyeri: {0}.",\r
"İşyeri: {0}",\r
"Onaylı limit üstü / blokeli müşteriye vadeli ödeme ({0}) — {1}, fiş {2}",\r
"Limit üstü veya blokeli müşteriye vadeli ödeme",\r
"Nakit borç tahsilatı için yeni vardiya (#{0}) açıldı.",\r
"Ambalajlar: {0} (örn. \\"3 {1}\\")",\r
"PDF (A4)",\r
"PDF kaydedildi: {0}",\r
"KDV oranı",\r
"Kurumsal müşterinin VKN'si veya adı:",\r
"fiş / fatura no.",\r
"Araç stoğuna göre yeterli mal yok:\\n{0}\\n\\nDevam edilsin mi?",\r
"En az bir miktar girilmelidir.",\r
"Müşteri (VKN ve ad) girilmelidir — \\"Toptan\\" / \\"Saha\\" modu.",\r
"Ambalaj iadesi",\r
"AMBALAJ İADESİ",\r
"Ambalaj iadesi kaydedildi.",\r
"depoya mal iadesi, hasarlı mal, nakit ve ambalaj teslimi",\r
"Depoya iade",\r
"Depoya iade, sayılan iade malıdır; araç stoğuna göre fark eksik (veya fazla) olarak çıkar.",\r
"İade edilebilir ambalaj",\r
"İade edilebilir ambalaj — yalnızca kayıt (KDV Kanunu md. 20/13)",\r
"İade edilebilir ambalaj Muhasebede tanımlı değil (kasa paketinde ambalaj yok).",\r
"İade edilebilir ambalaj yalnızca kayıt amaçlı izlenir (KDV Kanunu md. 20/13) ve satış konusu değildir.",\r
"Kurumsal müşteriye satışta iade edilebilir ambalaj",\r
"Ödeme referansı",\r
"Ödeme referansı:",\r
"Teslim eden (müşteri)",\r
"Teslim eden (sürücü)",\r
"Teslim edilen nakit (€) — teslim edilecek {0}",\r
"Teslim edilen nakit negatif olamaz.",\r
"Teslim edilen nakit geçersiz.",\r
"Teslim alan ({0})",\r
"Teslim alan (depo / vezne)",\r
"Makbuz",\r
"MAKBUZ",\r
"Makbuz {0}",\r
"Makbuz mali fiş değildir (önceden düzenlenmiş fiş ödenir). Nakit kasaya (vardiyaya) girer.",\r
"Makbuz, önceden düzenlenmiş fişin ödendiğini teyit eder ve mali fişin yerini tutmaz. Nakit şirket hesabına yatırılır (hasılat teslimi).",\r
"Makbuz, önceden düzenlenmiş fişin ödendiğini teyit eder ve mali fişin yerini tutmaz. Nakit şirket hesabına yatırılır (hasılat teslimi).{0}",\r
"Deneme modu — fiş Vergi İdaresine bildirilmedi.",\r
"Araçtan satış (seyyar işyeri).",\r
"Araç stoğu üzerinde satış (saha)",\r
"Satılan",\r
"Sıra",\r
"İskonto",\r
"İskonto %",\r
"müşteri iskontosu",\r
"Fiş / fatura",\r
"A4 fiş {0}",\r
"Fiş şu kasada düzenlendi",\r
"Fiş {0} kasasında düzenlendi. {1}",\r
"Vadeli ödemeli fiş yalnızca onayla düzenlenir. Nakit ve kart fişleri onaysız düzenlenir.",\r
"Vergi İdaresi onayı olmayan fişler:",\r
"Vergi İdaresi onayı olmayan fişler: {0}.",\r
"Vergi İdaresi onayını bekleyen fişler:",\r
"Mevcut",\r
"Hesap kapanışı kaydedildi.",\r
"Hesap kapanışı kaydedildi. {0} kalemde fark var.",\r
"Sürücü hesap kapanışı",\r
"SÜRÜCÜ HESAP KAPANIŞI",\r
"Kapat",\r
"Malı veren",\r
"Malı alan (müşteri imza ve kaşesi)",\r
"vade {0} g.",\r
"Hasarlı",\r
"Hasarlı (satılmaz)",\r
"İade sonrası müşterideki ambalaj bakiyesi:",\r
"Araç stoğu",\r
"ARAÇ STOĞU",\r
"Saha (araçtan satış)",\r
"\\"Toptan\\" / \\"Saha\\" modunda ödemeden önce müşteri (VKN ve ad) girilmelidir. Fiş düzenlenmedi.",\r
"sözleşme fiyatı{0}",\r
"Teslim edilecek toplam",\r
"İadeyi kaydet",\r
"Ödeyen",\r
"Ödeyen",\r
"Uyarı",\r
"Onaylı uyarı",\r
"Uyar (limit üstü); blokaj onayla",\r
"Yükleme (veri)",\r
"yükleme, satılan, mevcut; araç zimmet çıktısı",\r
"Yüklenen",\r
"Fişe ait",\r
"Toptan (cash & carry, kurumsal müşteriler)",\r
"Toptan ve saha",\r
"toptan — \\"Toptan\\" modu önerilir",\r
"Sürücü",\r
"Araç",\r
"araç (seyyar işyeri) — \\"Saha\\" modu önerilir",\r
"Müşterilerden iade",\r
"Bu araç için yükleme verisi yok (araç stoğu Muhasebeden kasa paketiyle gelir).",\r
"Pazar çalışma yasağı (İç Ticaret Kanunu, md. 35b) perakende ticarete uygulanır. İşyeri bireylere de satıyorsa kapatılmalıdır.",\r
"Araç stoğu",\r
"Müşterinin nakit toplamı 10.000 €'ya ulaşıyor (md. 65/2).",\r
"Sunucudaki müşteri nakit toplamı ≥ 10.000 €",\r
"Diğer kasalar ve Muhasebe ile toplam kontrol edilmedi (sunucuya bağlantı yok).",\r
"Müşteri limiti ve blokajı",\r
"Saha satışı: araç stoğunun üzerinde satış",\r
"— kasanın onayı bekleniyor…",\r
"Ödeme {0} — kasanın onayı bekleniyor…",\r
"Sonradan gönderim işareti olmayan fişin gönderim zamanı düzenleme zamanına eşit olmalıdır (aksi halde Vergi İdaresi reddeder, hata 11).",\r
"Veritabanı kaydediliyor… Düzenlenen fişler kaydedildi; kasa birazdan devam edecek.",\r
"Cihaz 30 saniye içinde yazdırmayı başlatmadı. Yazdırmanın tekrarlanması gerekiyor."\r
]\r
`;export{a as default};
