const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-sfuwvzF6.js","./index-DNzFMgCo.js"])))=>i.map(i=>d[i]);
import{_ as e}from"./index-DJiS4X9N.js";import{registerPlugin as t}from"./index-DNzFMgCo.js";const _=t("Share",{web:()=>e(()=>import("./web-sfuwvzF6.js"),__vite__mapDeps([0,1]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
