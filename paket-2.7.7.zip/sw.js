// Service worker za web verziju Knjigovodstva — GENERISAN, ne mijenjati ručno.
// Pravi ga scripts/napravi-sw.mjs poslije svakog build-a.
//
// Uloga: aplikacija mora raditi i bez mreže (u radnji signal zna da padne), a nova
// objava na GitHub Pages-u mora sama stići do telefona. Zato se pri instalaciji
// keširaju svi fajlovi verzije, a stari keševi se brišu pri aktivaciji (osim jednog prethodnog).
const VERZIJA = "2.7.7"
const KES = 'knjigovodstvo-' + VERZIJA
const FAJLOVI = [
  "LICENCE-TRECIH-LICA.txt",
  "assets/Agencija-cKC7H0if.js",
  "assets/CjenovniciVP-mhD4BOKr.js",
  "assets/GkPartneri-YrwYD6PH.js",
  "assets/Izgradnja-CpoN5V2l.js",
  "assets/IzvozPosebnihEvidencija-EuOFuB7g.js",
  "assets/KasaRacuni--z6gOuLU.js",
  "assets/KaseNalozi-CsozI-9-.js",
  "assets/Kompenzacije-CdMRXJG0.js",
  "assets/Korisnici-BRfg_9M9.js",
  "assets/KupciVP-CdWsg6kQ.js",
  "assets/LjudiMenadzer-DbG-06qD.js",
  "assets/Materijal-JOiwkEsC.js",
  "assets/MenadzerRoba-DMb9eu0M.js",
  "assets/MjestaTroska--FtX5Xl-.js",
  "assets/NalogGlavnom-iZQG6gCv.js",
  "assets/NarudzbeKupaca-CnpDrY_3.js",
  "assets/Nekretnine-CO8h82WU.js",
  "assets/Normativi-DTXJ66fe.js",
  "assets/PinDijalog-D3p8a8uT.js",
  "assets/PorezOdbitakForma-B_myfd7R.js",
  "assets/PorezOdbitakPregled-LzAyh2Ac.js",
  "assets/Povrati-CFJGJ3RR.js",
  "assets/Prigovori-w4NOyEET.js",
  "assets/PrilagodiMeni-CYPSl32r.js",
  "assets/Proizvodnja-Al5bQHPJ.js",
  "assets/Projekti-De1ztPVj.js",
  "assets/RadniNalozi-DCf_Y-O8.js",
  "assets/ServisPodesavanja-CyErETLx.js",
  "assets/Teren-IUXvhu5-.js",
  "assets/TragIzmjena-k8Ns9bKB.js",
  "assets/Ugovori-DUGHCHl-.js",
  "assets/UvozNabavka-D9amW3pr.js",
  "assets/ZaPregled-C7h-rO4S.js",
  "assets/ZatvaranjePerioda-DBTWjADS.js",
  "assets/Zspnft-B1xpXYoA.js",
  "assets/_virtual_licence-trecih-lica-yX7bAhEi.js",
  "assets/agencija-CUvv8GyN.js",
  "assets/agencijaIzvoz-DnRJZ40H.js",
  "assets/amblem-svijetli-192-CoeYFji2.png",
  "assets/amblem-svijetli-96-BNRmYCi1.png",
  "assets/amblem-tamni-192-Dlvx0PIq.png",
  "assets/amblem-tamni-96-D-JBuMdz.png",
  "assets/bankpdf-BLgbPKO7.js",
  "assets/cijene-DXpADJQB.js",
  "assets/en-DtmMT9KU.js",
  "assets/index-0mu-p_a-.css",
  "assets/index-BF-KysGO.js",
  "assets/index-BgPkWOLT.js",
  "assets/index-CArUGCqz.js",
  "assets/index-CFp-yKaQ.js",
  "assets/index-CYV7CKW2.js",
  "assets/index-CpDIlO9b.js",
  "assets/index-DNzFMgCo.js",
  "assets/index-ggsP5-uy.js",
  "assets/izgradnja-CggbOyuw.js",
  "assets/izvozposebnih-BjU48OmZ.js",
  "assets/jezik-D_QvaOId.js",
  "assets/kasenalozi-Y_2Ns2eJ.js",
  "assets/kljucevi-DbT-bQ9c.js",
  "assets/knjpregled-18rQAewD.js",
  "assets/kompenzacije-C_sICkyr.js",
  "assets/konsolidacija-IxbLDd_L.js",
  "assets/kupcivpexcel-KCwWH4SF.js",
  "assets/menadzeranaliza-B77fp9jf.js",
  "assets/menadzerljudi-BDq268Ol.js",
  "assets/menadzernabavka-Qy7JcOMF.js",
  "assets/menadzerroba-OOQY71pc.js",
  "assets/menadzertok-CoGAqE9p.js",
  "assets/menadzervp-D2uTKETP.js",
  "assets/mjestatroskaizvj-Dwx2TQIG.js",
  "assets/nekretnine-D-_WqaEU.js",
  "assets/nlbizvod-CGhqOvpd.js",
  "assets/normativi-BsylKGbP.js",
  "assets/pdf-radnik-BtRoVg8m.js",
  "assets/pdf.worker-Mx0w3D2U.js",
  "assets/pdfkompenzacije-cGGMvkWQ.js",
  "assets/pdfmaterijalno-BW3r9rs1.js",
  "assets/pdfnekretnine-6nXYKV5A.js",
  "assets/pdfservis-ClD6XhPe.js",
  "assets/pdfzspnft-B_zgpaUj.js",
  "assets/povrati-DNnLA3EL.js",
  "assets/proizvodnja-t7ApVNX-.js",
  "assets/razlika-radnik-DzhdHiTg.js",
  "assets/renumeracija-BdjyBRtS.js",
  "assets/ru-BNPUSmKT.js",
  "assets/salterizvod-B0Y7lt7t.js",
  "assets/servisnalozi-CYRcTQbV.js",
  "assets/sql-wasm-UFUCzYNW.wasm",
  "assets/tr-ClrPGbhp.js",
  "assets/uvoznakalk-Da3bZcH9.js",
  "assets/web-BXJjiGQ6.js",
  "assets/web-C7ac2BY7.js",
  "assets/web-DRnNXkco.js",
  "assets/web-sfuwvzF6.js",
  "assets/worker.min-32WLk7pY.js",
  "assets/zspnft-BKeKvwDr.js",
  "assets/zspnftindikatori-DLmgB8yb.js",
  "ikone/favicon-32.png",
  "ikone/ikona-180.png",
  "ikone/ikona-192.png",
  "ikone/ikona-512.png",
  "ikone/ikona-maskable-512.png",
  "index.html",
  "manifest.webmanifest"
]
const OBAVEZNI = ["index.html","assets/index-BgPkWOLT.js","assets/index-0mu-p_a-.css"]

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const kes = await caches.open(KES)
    // cache: 'reload' = mimo HTTP keša pregledača. GitHub Pages šalje max-age=600, pa je običan zahtjev dvije objave
    // u 10 minuta punio NOVI keš STARIM index.html-om (bijeli ekran ili zaglavljena stara verzija).
    const uzmi = f => kes.add(new Request(f, { cache: 'reload' }))
    // index.html i njegovi fajlovi MORAJU ući, i to iz OVE verzije — inače instalacija pada, a stara verzija radi dalje
    await Promise.all(OBAVEZNI.map(uzmi))
    const html = await (await kes.match('index.html')).text()
    for (const m of html.matchAll(/(?:src|href)=["']\.?\/?(assets\/[^"'?#]+)["']/g)) {
      if (!FAJLOVI.includes(m[1])) throw new Error('index.html nije iz verzije ' + VERZIJA + ' (' + m[1] + ')')
    }
    // Ostalo pojedinačno, da jedan promašaj ne obori cijelu instalaciju (fetch ispod ga dopuni kad zatreba).
    await Promise.all(FAJLOVI.filter(f => !OBAVEZNI.includes(f)).map(f => uzmi(f).catch(() => {})))
    await self.skipWaiting()
  })())
})

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    // Jedan prethodni keš ostaje: stranica koja je bila otvorena kad je stigla nova verzija i dalje lijeno učitava
    // SVOJE dijelove (PIN dijalog, cijene, renumeracija…), a server ih poslije objave više nema. Stariji se brišu.
    const brojke = k => k.slice('knjigovodstvo-'.length).split('.').map(Number)
    const novijiPrvo = (a, b) => { const x = brojke(a); const y = brojke(b); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (y[i] || 0) - (x[i] || 0); return 0 }
    const prethodni = (await caches.keys()).filter(k => k !== KES && k.startsWith('knjigovodstvo-')).sort(novijiPrvo)
    for (const k of await caches.keys()) if (k !== KES && k !== prethodni[0]) await caches.delete(k)
    await self.clients.claim()
  })())
})

self.addEventListener('fetch', e => {
  const zahtjev = e.request
  if (zahtjev.method !== 'GET') return
  const adresa = new URL(zahtjev.url)
  if (adresa.origin !== self.location.origin) return   // MAPR i ostalo ide direktno

  e.respondWith((async () => {
    const kes = await caches.open(KES)

    // Aplikacija je jedna stranica: svaka navigacija vodi na index.html.
    if (zahtjev.mode === 'navigate') {
      return (await kes.match('index.html')) || (await fetch(zahtjev))
    }

    // tekući keš, pa prethodni (dijelovi stare stranice koja je još otvorena)
    const izKesa = (await kes.match(zahtjev, { ignoreSearch: true })) || (await caches.match(zahtjev, { ignoreSearch: true }))
    if (izKesa) return izKesa

    try {
      const odgovor = await fetch(zahtjev)
      if (odgovor.ok && odgovor.type === 'basic') kes.put(zahtjev, odgovor.clone())
      return odgovor
    } catch (greska) {
      const rezerva = await kes.match('index.html')
      if (rezerva && zahtjev.destination === 'document') return rezerva
      throw greska
    }
  })())
})
